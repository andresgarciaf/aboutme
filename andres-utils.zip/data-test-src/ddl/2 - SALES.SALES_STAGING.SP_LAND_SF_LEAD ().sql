CREATE OR REPLACE PROCEDURE "SP_LAND_SF_LEAD"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE
	--Declare output variables
        Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 
	Final_output OBJECT;
	Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-05		By: Harini Nagarajan
		Purpose: Landing table for sf_lead
		Sample Run Command:
		call	SALES.SALES_STAGING.sp_Land_Sf_Lead (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);
		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------
		2019-06-21	Veena		added Lead_Source=''Web''	
		2020-03-12  	Venkatesh         Used joiner on Sf_lead_type_cmb to fix failure in leads
		2020-04-29	Matt		add new fields for leads enhancement	
		2020-06-18	Matt		add additional filter on update only step
		2020-07-09	Matt		handle ''undefined'' stock number
		2020-08-07  	Vamsi             add new field data_entry_method
		2020-09-03	Sofia		changed to reserved container as part of CCPA
		2020-10-08      Vamsi       Web_leads decommission changes (add new columns adcode_datetime,adcode,sessionid,visitorid) lines 225,251,319,345
	*****************************************************************************************************************************************************************************/

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	BEGIN

		Activity_Name := ''sp_Land_Sf_Lead'';
		Code_Lines := 457;
		Database_Source := ''Edw_Salesforce'';
		Database_Stage := ''Sales_Landing'';
		Database_Target := ''Sales_Landing'';
		Process_Id := 458;
		Table_Source := ''Sf_Lead'';
		Table_Stage := ''Sf_Lead'';
		Table_Target := ''Sf_Lead'';
		Version := 1.7;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

	---------------------- 0 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set METADATA_CONTROLS.Run_Time_Results Record To Zero'';
			CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;
			Sql_Statement := ''Get Parameters'';

			Start_Time := (SELECT
				CASE
					WHEN (
						SELECT
							CAST(TRUNC( Parameter_Value) AS INTEGER) 
							FROM
							DATAOPS.METADATA_VIEWS.Parameters_Sales
							WHERE	Parameter_Name IN (''Leads_Origin_Start_Days'' )) = 9999
						THEN TO_TIMESTAMP(''1980-01-01 13:52:22'')
		ELSE (
						SELECT
							TO_TIMESTAMP(TO_DATE(DATEADD(''DAY'',-CAST(TRUNC( Parameter_Value) AS INTEGER),CURRENT_TIMESTAMP(0))))
			FROM
							DATAOPS.METADATA_VIEWS.Parameters_Sales
			WHERE	Parameter_Name IN (''Leads_Origin_Start_Days'' ) )
				END);

	---------------------- 1 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM (
					SELECT DISTINCT Email,
						Web_Lead_Submit_Date_Utc,
						Stock_Number,
						Store_Location_Number,
						Lead_Type_Desc
				FROM
						SALES.EDW_SALESFORCE_RESERVED_VIEWS.Sf_Lead --changed to reserved container as part of CCPA
				LEFT JOIN
							SALES.SALES_STAGING.sf_lead_type_cmb
				ON       Lead_Type = Lead_Type_Key
				WHERE	Ss_Insert_Ts_Utc >= :Start_Time AND Lead_Source =''Web'') Cnt_src ;
			Count_Source := COALESCE (:Record_Count , 0);
			IF (Count_Source = 0) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;

				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;

	---------------------- 2 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.SALES_LANDING.Sf_Lead;

	---------------------- 3 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert Into '' ||Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.SALES_LANDING.Sf_Lead (Lead_Id_Cs,Is_Deleted,Master_Record_Id_Cs,Last_Name,First_Name,
				Salutation,Middle_Name,Suffix,Name_Text,Record_Type_Id_Cs,Title_Text,
				Company,Street,City,State,Postal_Code,Country,State_Code,Country_Code,
				Latitude,Longitude,Phone,Mobile_Phone,Fax,Email,Website,Photo_Url,
				Description,Lead_Source,Status,Industry,Rating,Annual_Revenue,
				Number_Of_Employees,Owner_Id_Cs,Has_Opted_Out_Of_Email,Is_Converted,
				Converted_Date,Converted_Account_Id_Cs,Converted_Contact_Id_Cs,
				Converted_Opportunity_Id_Cs,Is_Unread_By_Owner,Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,Last_Updated_Ts_Utc,Last_Activity_Date,
				Do_Not_Call,Has_Opted_Out_Of_Fax,Last_Viewed_Ts_Utc,Last_Referenced_Ts_Utc,
				Last_Transfer_Date,Jigsaw,Jigsaw_Contact_Id,Email_Bounced_Reason,
				Email_Bounced_Ts_Utc,Origin_Store_Location,Closed_Lost_Reason,
				Day_And_Date_Created,Lead_Type,Store_Location_Number,Waitlist,
				Closed_Time_Utc,Creation_Time_Utc,Customer_Description,Home_Delivery,
				Matched_Account_Id_Cs,Matched_Opportunity_Id_Cs,Origin,Reltio_Id,
				Removal_Notes,Situation_Notes,Subsequent_Web_Lead,Suggested_Owner_Id_Cs,
				Suggested_Time_Utc,Unformatted_Phone,Visit_Purpose_Appraisal,
				Visit_Purpose_Browse,Visit_Purpose_Financing,Visit_Purpose_Specific_Vehicle,
				User_Division,User_Region,User_Store,Comments,Converted_Date_Time_Utc,
				Parent_Lead,Stock_Number,Web_Lead_Id,Web_Customer_Question,Web_Requested_App_Date_Utc,
				Contact_Preference,Do_Not_Email,Web_Lead_Submit_Date_Utc,Web_Status,
				Oe_Contact_Id,Oe_Customer_Id,Store_Employee_Id,Ss_Insert_Ts_Utc,
				Ss_Lst_Upd_Ts_Utc,Db_Source,Ss_Db_Status,Insert_Ts,Lst_Upd_Ts,
				nice_work_item_id_cs, system_closed_Reason, origin_queue, data_entry_method, adcode_datetime, adcode, sessionid, visitorid)
			SELECT DISTINCT TRIM(Lead_Id_Cs),
				Is_Deleted,
				Master_Record_Id_Cs,
				Last_Name,
				First_Name,
				Salutation,
				Middle_Name,
				Suffix,
				Name_Text,
				Record_Type_Id_Cs,
				Title_Text,
				Company,
				Street,
				City,
				State,
				Postal_Code,
				Country,
				State_Code,
				Country_Code,
				Latitude,
				Longitude,
				Phone,
				Mobile_Phone,
				Fax,
				Email,
				Website,
				Photo_Url,
				Description,
				Lead_Source,
				Status,
				Industry,
				Rating,
				Annual_Revenue,
				Number_Of_Employees,
				Owner_Id_Cs,
				Has_Opted_Out_Of_Email,
				Is_Converted,
				Converted_Date,
				Converted_Account_Id_Cs,
				Converted_Contact_Id_Cs,
				Converted_Opportunity_Id_Cs,
				Is_Unread_By_Owner,
				Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,
				Last_Updated_Ts_Utc,
				Last_Activity_Date,
				Do_Not_Call,
				Has_Opted_Out_Of_Fax,
				Last_Viewed_Ts_Utc,
				Last_Referenced_Ts_Utc,
				Last_Transfer_Date,
				Jigsaw,
				Jigsaw_Contact_Id,
				Email_Bounced_Reason,
				Email_Bounced_Ts_Utc,
				Origin_Store_Location,
				Closed_Lost_Reason,
				Day_And_Date_Created,
				Lead_Type,
				Store_Location_Number,
				Waitlist,
				Closed_Time_Utc,
				Creation_Time_Utc,
				Customer_Description,
				Home_Delivery,
				Matched_Account_Id_Cs,
				Matched_Opportunity_Id_Cs,
				Origin,
				Reltio_Id,
				Removal_Notes,
				Situation_Notes,
				Subsequent_Web_Lead,
				Suggested_Owner_Id_Cs,
				Suggested_Time_Utc,
				Unformatted_Phone,
				Visit_Purpose_Appraisal,
				Visit_Purpose_Browse,
				Visit_Purpose_Financing,
				Visit_Purpose_Specific_Vehicle,
				User_Division,
				User_Region,
				User_Store,
				Comments,
				Converted_Date_Time_Utc,
				Parent_Lead,
				CASE
					WHEN Stock_Number = ''undefined''
						THEN ''0'' ELSE COALESCE(Stock_Number,''0'')
				END AS Stock_Number,
				Web_Lead_Id,
				Web_Customer_Question,
				Web_Requested_App_Date_Utc,
				Contact_Preference,
				Do_Not_Email,
				Web_Lead_Submit_Date_Utc,
				Web_Status,
				Oe_Contact_Id,
				Oe_Customer_Id,
				Store_Employee_Id,
				Ss_Insert_Ts_Utc,
				Ss_Lst_Upd_Ts_Utc,
				Db_Source,
				Ss_Db_Status,
				Insert_Ts,
				Lst_Upd_Ts,
				nice_work_item_id_cs,
				system_closed_Reason,
				origin_queue,
				data_entry_method,
				adcode_datetime,
				adcode,
				sessionid,
				visitorid
			FROM
				SALES.EDW_SALESFORCE_RESERVED_VIEWS.Sf_Lead --changed to reserved container as part of CCPA
			LEFT JOIN
					SALES.SALES_STAGING.sf_lead_type_cmb
			ON       Lead_Type = Lead_Type_Key
			WHERE	Ss_Insert_Ts_Utc>=:Start_Time
				AND Lead_Source =''Web''
			QUALIFY
				ROW_NUMBER() OVER (PARTITION BY Email, Web_Lead_Submit_Date_Utc, Stock_Number, Store_Location_Number, Lead_Type_Desc
				ORDER BY Ss_Lst_Upd_Ts_Utc, Parent_Lead ASC NULLS FIRST ) = 1;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 1 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Update source count for update only records in '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM (
					SELECT DISTINCT Email,
						Web_Lead_Submit_Date_Utc,
						Stock_Number,
						Store_Location_Number,
						Lead_Type_Desc
					FROM
						SALES.EDW_SALESFORCE_RESERVED_VIEWS.sf_lead --changed to reserved container as part of CCPA
					LEFT JOIN
							SALES.SALES_STAGING.sf_lead_type_cmb
					ON       Lead_Type = Lead_Type_Key
					WHERE	Ss_lst_upd_Ts_Utc >= :Start_Time
					AND Lead_Source =''Web''
					AND	TRIM(lead_id_cs) IN (
							SELECT
								collate(source_record_id,''UTF8'') FROM
								SALES.SALES_RESERVED_VIEWS.Fact_Touchpoint_Details
							WHERE source_record_Type_key IN (894))
					AND	TRIM(lead_id_cs) NOT IN (
							SELECT
								TRIM(lead_id_cs) FROM
								SALES.SALES_LANDING.sf_lead
						)) Cnt_src ;
			Count_Source := Count_Source + COALESCE (:Record_Count , 0);
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);
	---------------------- 3 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert Into '' ||Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.SALES_LANDING.Sf_Lead (Lead_Id_Cs,Is_Deleted,Master_Record_Id_Cs,Last_Name,First_Name,
				Salutation,Middle_Name,Suffix,Name_Text,Record_Type_Id_Cs,Title_Text,
				Company,Street,City,State,Postal_Code,Country,State_Code,Country_Code,
				Latitude,Longitude,Phone,Mobile_Phone,Fax,Email,Website,Photo_Url,
				Description,Lead_Source,Status,Industry,Rating,Annual_Revenue,
				Number_Of_Employees,Owner_Id_Cs,Has_Opted_Out_Of_Email,Is_Converted,
				Converted_Date,Converted_Account_Id_Cs,Converted_Contact_Id_Cs,
				Converted_Opportunity_Id_Cs,Is_Unread_By_Owner,Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,Last_Updated_Ts_Utc,Last_Activity_Date,
				Do_Not_Call,Has_Opted_Out_Of_Fax,Last_Viewed_Ts_Utc,Last_Referenced_Ts_Utc,
				Last_Transfer_Date,Jigsaw,Jigsaw_Contact_Id,Email_Bounced_Reason,
				Email_Bounced_Ts_Utc,Origin_Store_Location,Closed_Lost_Reason,
				Day_And_Date_Created,Lead_Type,Store_Location_Number,Waitlist,
				Closed_Time_Utc,Creation_Time_Utc,Customer_Description,Home_Delivery,
				Matched_Account_Id_Cs,Matched_Opportunity_Id_Cs,Origin,Reltio_Id,
				Removal_Notes,Situation_Notes,Subsequent_Web_Lead,Suggested_Owner_Id_Cs,
				Suggested_Time_Utc,Unformatted_Phone,Visit_Purpose_Appraisal,
				Visit_Purpose_Browse,Visit_Purpose_Financing,Visit_Purpose_Specific_Vehicle,
				User_Division,User_Region,User_Store,Comments,Converted_Date_Time_Utc,
				Parent_Lead,Stock_Number,Web_Lead_Id,Web_Customer_Question,Web_Requested_App_Date_Utc,
				Contact_Preference,Do_Not_Email,Web_Lead_Submit_Date_Utc,Web_Status,
				Oe_Contact_Id,Oe_Customer_Id,Store_Employee_Id,Ss_Insert_Ts_Utc,
				Ss_Lst_Upd_Ts_Utc,Db_Source,Ss_Db_Status,Insert_Ts,Lst_Upd_Ts,
				nice_work_item_id_cs, system_closed_Reason, origin_queue, SF_Update_Only_Flag, data_entry_method,
				adcode_datetime, adcode, sessionid, visitorid)
			SELECT DISTINCT TRIM(Lead_Id_Cs),
				Is_Deleted,
				Master_Record_Id_Cs,
				Last_Name,
				First_Name,
				Salutation,
				Middle_Name,
				Suffix,
				Name_Text,
				Record_Type_Id_Cs,
				Title_Text,
				Company,
				Street,
				City,
				State,
				Postal_Code,
				Country,
				State_Code,
				Country_Code,
				Latitude,
				Longitude,
				Phone,
				Mobile_Phone,
				Fax,
				Email,
				Website,
				Photo_Url,
				Description,
				Lead_Source,
				Status,
				Industry,
				Rating,
				Annual_Revenue,
				Number_Of_Employees,
				Owner_Id_Cs,
				Has_Opted_Out_Of_Email,
				Is_Converted,
				Converted_Date,
				Converted_Account_Id_Cs,
				Converted_Contact_Id_Cs,
				Converted_Opportunity_Id_Cs,
				Is_Unread_By_Owner,
				Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,
				Last_Updated_Ts_Utc,
				Last_Activity_Date,
				Do_Not_Call,
				Has_Opted_Out_Of_Fax,
				Last_Viewed_Ts_Utc,
				Last_Referenced_Ts_Utc,
				Last_Transfer_Date,
				Jigsaw,
				Jigsaw_Contact_Id,
				Email_Bounced_Reason,
				Email_Bounced_Ts_Utc,
				Origin_Store_Location,
				Closed_Lost_Reason,
				Day_And_Date_Created,
				Lead_Type,
				Store_Location_Number,
				Waitlist,
				Closed_Time_Utc,
				Creation_Time_Utc,
				Customer_Description,
				Home_Delivery,
				Matched_Account_Id_Cs,
				Matched_Opportunity_Id_Cs,
				Origin,
				Reltio_Id,
				Removal_Notes,
				Situation_Notes,
				Subsequent_Web_Lead,
				Suggested_Owner_Id_Cs,
				Suggested_Time_Utc,
				Unformatted_Phone,
				Visit_Purpose_Appraisal,
				Visit_Purpose_Browse,
				Visit_Purpose_Financing,
				Visit_Purpose_Specific_Vehicle,
				User_Division,
				User_Region,
				User_Store,
				Comments,
				Converted_Date_Time_Utc,
				Parent_Lead,
				CASE
					WHEN Stock_Number = ''undefined''
						THEN ''0'' ELSE COALESCE(Stock_Number,''0'')
				END AS Stock_Number,
				Web_Lead_Id,
				Web_Customer_Question,
				Web_Requested_App_Date_Utc,
				Contact_Preference,
				Do_Not_Email,
				Web_Lead_Submit_Date_Utc,
				Web_Status,
				Oe_Contact_Id,
				Oe_Customer_Id,
				Store_Employee_Id,
				Ss_Insert_Ts_Utc,
				Ss_Lst_Upd_Ts_Utc,
				Db_Source,
				Ss_Db_Status,
				Insert_Ts,
				Lst_Upd_Ts,
				nice_work_item_id_cs,
				system_closed_Reason,
				origin_queue,
				''Y'' AS SF_Update_Only_Flag,
				data_entry_method,
				   adcode_datetime,
				adcode,
				sessionid,
				visitorid
			FROM
				SALES.EDW_SALESFORCE_RESERVED_VIEWS.sf_lead --changed to reserved container as part of CCPA
			LEFT JOIN
					SALES.SALES_STAGING.sf_lead_type_cmb
			ON       	Lead_Type = Lead_Type_Key
			WHERE	Ss_lst_upd_Ts_Utc>=:Start_Time
			AND	Lead_Source =''Web''
			AND	TRIM(lead_id_cs) NOT IN (
					SELECT
						TRIM(lead_id_cs) FROM
						SALES.SALES_LANDING.sf_lead
				)
			AND	TRIM(lead_id_cs) IN (
					SELECT
						collate(source_record_id,''UTF8'') FROM
						SALES.SALES_RESERVED_VIEWS.Fact_Touchpoint_Details
					WHERE source_record_Type_key IN (894))
			QUALIFY
				ROW_NUMBER() OVER (PARTITION BY Email, Web_Lead_Submit_Date_Utc, Stock_Number, Store_Location_Number, Lead_Type_Desc
				ORDER BY Ss_Lst_Upd_Ts_Utc, Parent_Lead ASC NULLS FIRST ) = 1;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 4 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;

			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.SALES_LANDING.Sf_Lead;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF ( Count_Source <> Count_Stage ) THEN
				Sql_Statement :=''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.METADATA_CONTROLS.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;

			RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	---------------------------- 5 ---------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
			Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Stage , :Error_Count ,
			0 , :Count_Source);

	----------------------------- 6 -------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id);
			CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Stage, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Stage;
		
			Final_output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
			RETURN :Final_output;
	EXCEPTION 
	When Planned_Exception then 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	When OTHER then 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.SALES_STAGING.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )         
		VALUES         ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT         INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES         (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

    		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

END;
';