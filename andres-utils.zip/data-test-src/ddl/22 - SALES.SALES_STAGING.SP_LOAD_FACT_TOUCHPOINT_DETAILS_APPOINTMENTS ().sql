CREATE OR REPLACE PROCEDURE "SP_LOAD_FACT_TOUCHPOINT_DETAILS_APPOINTMENTS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-08		By: Veena G

		Purpose: 

		call	SALES.Sales_Staging.sp_Load_Fact_Touchpoint_Details_Appointments (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		Modified Date	Modified By		Notes
		-------------	-----------		--------------------------------------------------------------------------------------------------------------------------------------------
		2019-04-16	Gayathri   		Replaced Lead_key & appointment_key population with Touchpoint_Attribute_Key
		2019-04-22	Veena   			Added Customer_Activity_Key condition in Step no 2, 7 and 11
		2019-10-15	Harini			Changed to reserved container as part of CCPA.
		2020-02-26        Venkatesh                  Added logic to update BI_Update_Log table

	*****************************************************************************************************************************************************************************/
	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Database_Metadata VARCHAR(100); -- For Surrogate Key Checking

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(6); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Table_Metadata 	VARCHAR(100); -- For Surrogate Key Checking

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

	-- Custom Procedure Variables
		Index_Exists	BYTEINT := 0; -- Used To Signal Whether An Index Needs To Be Dropped

		Index_Limit	INTEGER := 0; -- Used to determine Whether An Index Needs To Be Dropped

		Record_Type_Key	SMALLINT	DEFAULT 0; -- Holds Source_Record_Type_Key for Fact_Touchpoint_Details

		Cust_Act_Key	SMALLINT	DEFAULT 0; -- Holds Customer_Activity_Key for Fact_Touchpoint_Details

		Yesterday_Count	INTEGER := 0; -- Number of row with yesterday date

		Max_Activity_Day_Key INTEGER; -- Maximum date of activities loaded

		Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 

     	Planned_Exception   Exception (-20001, ''Exception based on Error_Condition'');

	BEGIN

		Activity_Name := ''sp_Load_Fact_Touchpoint_Details_Appointments'';
		Code_Lines := 819;
		Database_Source := ''Sales_Staging'';
		Database_Stage := ''Sales_Staging'';
		Database_Target := ''Sales'';
		Database_Metadata := ''Metadata_Controls'';
		Process_Id := 458;
		Record_Type_Key := 918;
		Cust_Act_Key := 530;
		Table_Source := ''Fact_Touchpoint_Details_Appointments'';
		Table_Stage := ''Fact_Touchpoint_Details_Appointments'';
		Table_Target := ''Fact_Touchpoint_Details'';
		Table_Metadata := ''Surrogate_Key_Check'';
		Version := 1.2;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
	FROM
			Accounting.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;
--	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	P1:
		-- Start Of Procedural Steps With Exception Handler
	BEGIN

	--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;

	---------- 1 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                 			                ''Confirm Data Exists In The Stage Table '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Record_Count := 0;
			Sql_Statement := Activity_Desc;

			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments;
			Count_Source := COALESCE ( :Record_Count , 0 );
			IF (( Count_Source  = 0 ) /*OR ( SQLSTATE = ''02000'' )*/) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_Id);
				Sql_Statement := Activity_Desc;
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Target;
				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;

	---------- 2 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Records That Already Exist In The Target'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Stg
				SET
					Stg.Touchpoint_Detail_Key = Fnl.Touchpoint_Detail_Key
				FROM
					SALES.Sales_Reserved_Views.Fact_Touchpoint_Details Fnl  --Changed to reserved container as part of CCPA
	WHERE 	Stg.Source_Record_Type_Key = Fnl.Source_Record_Type_Key
	AND	Stg.Customer_Activity_Key	= Fnl.Customer_Activity_Key
	AND  	TRIM(STG.Source_Record_ID)	= TRIM(FNL.Source_Record_ID);
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	--------- 3 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Drop target indexes if the number of staged records > Index_Limit'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			Count_Last := 0;
			SQL_Statement := ''Determine count of records that will change'';
			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments
		WHERE	Touchpoint_Detail_Key = -1 ;
			Count_Last := COALESCE ( :Record_Count , 0 );
			SELECT
				CAST(TRUNC( Parameter_Value) AS INTEGER)  INTO
				:Index_Limit
		FROM
				DATAOPS.Metadata_Views.Parameters_Sales
		WHERE 	Parameter_Name =''Web_Lead_Index_Limit'';
			IF (Count_Last > Index_Limit) THEN
				------- 4 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If Idx_Activity_Day_Key Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
-- 				SELECT
					
-- 					CASE
-- 						WHEN (
-- 							SELECT DISTINCT
-- --								 Indexname
-- 									   	   FROM 	 Dbc.Indicesv
-- 									 	   WHERE
-- 								TABLE_SCHEMA = ''Sales''
-- 										   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 										   AND
-- --										       	 Indexname
-- 										       	           = ''Idx_Activity_Day_Key'' )
-- 							IS NOT NULL
-- 							THEN 1 ELSE 0
-- 					END
-- 				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary Idx_Activity_Day_Key'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index Idx_Activity_Day_Key'';
--						DROP 	INDEX Idx_Activity_Day_Key ON Sales.Fact_Touchpoint_Details;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;

				------- 5 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If Idx_Customer_Activity_Key Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
-- 				SELECT
					
-- 					CASE
-- 						WHEN (
-- 							SELECT DISTINCT
-- --								 Indexname
-- 									   	   FROM 	 Dbc.Indicesv
-- 									 	   WHERE
-- 								TABLE_SCHEMA = ''Sales''
-- 										   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 										   AND
-- --										       	 Indexname
-- 										       	           = ''Idx_Customer_Activity_Key'' )
-- 							IS NOT NULL
-- 							THEN 1 ELSE 0
-- 					END
-- 				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary Idx_Customer_Activity_Key'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index Idx_Customer_Activity_Key'';
--						DROP 	INDEX Idx_Customer_Activity_Key ON Sales.Fact_Touchpoint_Details;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;

				------- 6 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If Idx_Fact_Touchpoint_Details Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
-- 				SELECT
					
-- 					CASE
-- 						WHEN (
-- 							SELECT DISTINCT
-- --								 Indexname
-- 									   	   FROM 	 Dbc.Indicesv
-- 									 	   WHERE
-- 								TABLE_SCHEMA = ''Sales''
-- 										   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 										   AND
-- --										       	 Indexname
-- 										       	           = ''Idx_Fact_Touchpoint_Details'' )
-- 							IS NOT NULL
-- 							THEN 1 ELSE 0
-- 					END
-- 				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary Idx_Fact_Touchpoint_Details'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index Idx_Fact_Touchpoint_Details'';
--						DROP 	INDEX Idx_Fact_Touchpoint_Details ON Sales.Fact_Touchpoint_Details;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;

				------- 7 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If Idx_Lead_Key Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
-- 				SELECT
					
-- 					CASE
-- 						WHEN (
-- 							SELECT DISTINCT
-- --								 Indexname
-- 									   	   FROM 	 Dbc.Indicesv
-- 									 	   WHERE
-- 								TABLE_SCHEMA = ''Sales''
-- 										   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 										   AND
-- --										       	 Indexname
-- 										       	           = ''Idx_Lead_Key'' )
-- 							IS NOT NULL
-- 							THEN 1 ELSE 0
-- 					END
-- 				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary Idx_Lead_Key'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index Idx_Lead_Key'';
--						DROP 	INDEX Idx_Lead_Key ON Sales.Fact_Touchpoint_Details;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;
				------- 8 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If Ui_Fact_Touchpoint_Details Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
-- 				SELECT
					
-- 					CASE
-- 						WHEN (
-- 							SELECT DISTINCT
-- --								 Indexname
-- 									   	   FROM 	 Dbc.Indicesv
-- 									 	   WHERE
-- 								TABLE_SCHEMA = ''Sales''
-- 										   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 										   AND
-- --										       	 Indexname
-- 										       	           = ''Ui_Fact_Touchpoint_Details'' )
-- 							IS NOT NULL
-- 							THEN 1 ELSE 0
-- 					END
-- 				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary Ui_Fact_Touchpoint_Details'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index Ui_Fact_Touchpoint_Details'';
--						DROP 	INDEX Ui_Fact_Touchpoint_Details ON Sales.Fact_Touchpoint_Details;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;
			END IF;
	------ 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                 			                ''Update existing records in '' || Database_Target || ''.'' || Table_Target;
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_Id);
			SQL_Statement := ''Update attributes in existing Fact records'';
			UPDATE SALES.Sales.Fact_Touchpoint_Details AS FNL
				SET
					Activity_Day_Key = STG.Activity_Day_Key,
					Activity_Minute_Key = STG.Activity_Minute_Key,
					Touchpoint_Attribute_Key = STG.Touchpoint_Attribute_Key,
					Appointment_Interests_Key = STG.Appointment_Interests_Key,
					Customer_Source_Key = STG.Customer_Source_Key,
					Employee_Key = STG.Employee_Key,
					Location_Key = STG.Location_Key,
					Stock_Number_Key = STG.Stock_Number_Key,
					Vehicle_Key = STG.Vehicle_Key,
					Vehicle_Location_Key = STG.Vehicle_Location_Key,
					Activity_Date = STG.Activity_Date,
					Utc_Local_Offset = STG.Utc_Local_Offset,
					Requested_Appointment_Ts_Utc = STG.Requested_Appointment_Ts_Utc,
					Stock_Number_Hold_Flag = STG.Stock_Number_Hold_Flag,
					Source_Customer_Id = STG.Source_Customer_Id,
					Touchpoint_Begin_Ts_Utc = STG.Touchpoint_Begin_Ts_Utc,
					Touchpoint_End_Ts_Utc = STG.Touchpoint_End_Ts_Utc,
					Waitlist_Flag = STG.Waitlist_Flag,
					Duration_Seconds = STG.Duration_Seconds,
					Source_Insert_Ts = STG.Source_Insert_Ts,
					Source_Update_Ts = STG.Source_Update_Ts,
					Edw_Update_Ts = STG.Edw_Update_Ts,
					Dw_Update_Ts = CURRENT_TIMESTAMP(0)
				FROM
					SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments STG
	WHERE
					FNL.Source_Record_Type_Key		=STG.Source_Record_Type_Key
		AND FNL.Customer_Activity_Key	=STG.Customer_Activity_Key
		AND 	TRIM(FNL.Source_Record_Id)	=TRIM(STG.Source_Record_Id)
		AND (FNL.Activity_Day_Key			<>STG.Activity_Day_Key
			OR FNL.Activity_Minute_Key		<>STG.Activity_Minute_Key
			OR FNL.Touchpoint_Attribute_Key  	<>STG.Touchpoint_Attribute_Key
			OR FNL.Appointment_Interests_Key 	<>STG.Appointment_Interests_Key
			OR FNL.Customer_Source_Key		<>STG.Customer_Source_Key
			OR FNL.Employee_Key			<>STG.Employee_Key
			OR FNL.Location_Key			<>STG.Location_Key
			OR FNL.Stock_Number_Key		<>STG.Stock_Number_Key
			OR FNL.Vehicle_Key			<>STG.Vehicle_Key
			OR FNL.Vehicle_Location_Key		<>STG.Vehicle_Location_Key
			OR FNL.Activity_Date			<>STG.Activity_Date
			OR FNL.Utc_Local_Offset		<>STG.Utc_Local_Offset
			OR FNL.Requested_Appointment_Ts_Utc	<>STG.Requested_Appointment_Ts_Utc
			OR FNL.Stock_Number_Hold_Flag		<>STG.Stock_Number_Hold_Flag
			OR FNL.Source_Customer_Id		<>STG.Source_Customer_Id
			OR FNL.Touchpoint_Begin_Ts_Utc	<>STG.Touchpoint_Begin_Ts_Utc
			OR FNL.Touchpoint_End_Ts_Utc		<>STG.Touchpoint_End_Ts_Utc
			OR FNL.Waitlist_Flag			<>STG.Waitlist_Flag
			OR FNL.Duration_Seconds		<>STG.Duration_Seconds
			OR FNL.Source_Insert_Ts		<>STG.Source_Insert_Ts
			OR FNL.Source_Update_Ts		<>STG.Source_Update_Ts
			OR FNL.Edw_Update_Ts			<>STG.Edw_Update_Ts);
			Record_Count := COALESCE ( :SQLROWCOUNT , 0 );
			Count_Target := Record_Count;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_Id);

	---------- 10 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                 			                ''Insert  Into ''|| Database_Target || ''.'' || Table_Target || '' From '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Record_Count := 0;
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales.Fact_Touchpoint_Details (
			Source_Record_Type_Key,
			Activity_Day_Key,
			Activity_Minute_Key,
			Touchpoint_Attribute_Key,
			Appointment_Interests_Key,
			Customer_Activity_Key,
			Customer_Source_Key,
			Employee_Key,
			Lead_Interests_Key,
			Location_Key,
			Stock_Number_Key,
			Vehicle_Key,
			Vehicle_Location_Key,
			Activity_Date,
			Utc_Local_Offset,
			Requested_Appointment_Ts_Utc,
			Stock_Number_Hold_Flag,
			Source_Record_Id,
			Source_Customer_Id,
			Touchpoint_Begin_Ts_Utc,
			Touchpoint_End_Ts_Utc,
			Waitlist_Flag,
			Duration_Seconds,
			Source_Insert_Ts,
			Source_Update_Ts,
			Edw_Update_Ts,
			Dw_Insert_Ts,
			Dw_Update_Ts)
			SELECT
				Fct_Stg.Source_Record_Type_Key,
				Fct_Stg.Activity_Day_Key,
				Fct_Stg.Activity_Minute_Key,
				Fct_Stg.Touchpoint_Attribute_Key,
				Fct_Stg.Appointment_Interests_Key,
				Fct_Stg.Customer_Activity_Key,
				Fct_Stg.Customer_Source_Key,
				Fct_Stg.Employee_Key,
				-1,
				Fct_Stg.Location_Key,
				Fct_Stg.Stock_Number_Key,
				Fct_Stg.Vehicle_Key,
				Fct_Stg.Vehicle_Location_Key,
				Fct_Stg.Activity_Date,
				Fct_Stg.Utc_Local_Offset,
				Fct_Stg.Requested_Appointment_Ts_Utc,
				Fct_Stg.Stock_Number_Hold_Flag,
				TRIM(Fct_Stg.Source_Record_Id)      AS Source_Record_Id,
				Fct_Stg.Source_Customer_Id,
				Fct_Stg.Touchpoint_Begin_Ts_Utc,
				Fct_Stg.Touchpoint_End_Ts_Utc,
				Fct_Stg.Waitlist_Flag,
				Fct_Stg.Duration_Seconds,
				Fct_Stg.Source_Insert_Ts,
				Fct_Stg.Source_Update_Ts,
				Fct_Stg.Edw_Update_Ts,
				CURRENT_TIMESTAMP(0),
				CURRENT_TIMESTAMP(0)
FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments Fct_Stg
WHERE   Fct_Stg.Touchpoint_Detail_Key=-1;
			Record_Count := COALESCE ( :SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Record_Count;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count , :Step_Id);

	---------- 11 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                 			                ''Confirm All Rows Were Copied From '' || Database_Stage || ''.'' || Table_Stage || '' To '' || Database_Target || ''.'' || Table_Target;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, SUBSTR(:Activity_Desc,0,100), :Completed_Flag, :Error_Count, 0, :Step_Id);
			Record_Count := 0;
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM	(
					SELECT
						Stg.Source_Record_Type_Key,
						Stg.Source_Record_Id,
						Stg.Customer_Activity_Key
					FROM
						SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments Stg
					LEFT 	OUTER JOIN
							SALES.Sales_Reserved_Views.Fact_Touchpoint_Details Fnl 	--Changed to reserved container as part of CCPA
					ON       Fnl.Source_Record_Type_Key = Stg.Source_Record_Type_Key
					AND	Fnl.Customer_Activity_Key	= Stg.Customer_Activity_Key
					AND      TRIM(FNL.Source_Record_ID) = TRIM(STG.Source_Record_ID)
					WHERE
						FNL.Source_Record_Key IS NULL) CNT_CHECK ;
			IF (Record_Count >= 1) THEN
				Error_Condition := 4;
				Error_Count := Error_Count + 1;
				INSERT INTO dataops.metadata_controls.error_log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, SUBSTR(:Activity_Desc,0,100), :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, SUBSTR(:Activity_Desc || '' Error'',0,100) , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_Id);
			ELSE
				Target_Balanced := ''Y'';
			END IF;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, SUBSTR(:Activity_Desc,0,100), :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);

	---------- 12 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Create Target Indexes If They Were Dropped'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);

		------- 13 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine If Idx_Activity_Day_Key Index Exists'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Index_Exists := 0;
			Sql_Statement := Activity_Desc;
-- 			SELECT
				
-- 				CASE
-- 					WHEN (
-- 						SELECT DISTINCT
-- --							 Indexname
-- 								   	   FROM 	 Dbc.Indicesv
-- 								 	   WHERE
-- 							TABLE_SCHEMA = ''Sales''
-- 									   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 									   AND
-- --									       	 Indexname
-- 									       	           = ''Idx_Activity_Day_Key'' )
-- 						IS NOT NULL
-- 						THEN 1 ELSE 0
-- 				END
-- 			INTO :Index_Exists ;
			IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index Idx_Activity_Day_Key'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create Idx_Activity_Day_Key'';
--					CREATE 	INDEX Idx_Activity_Day_Key ( Activity_Day_Key ) ON Sales.Fact_Touchpoint_Details ;
			ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			END IF;

		------- 14 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine If Idx_Customer_Activity_Key Index Exists'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Index_Exists := 0;
			Sql_Statement := Activity_Desc;
-- 			SELECT
				
-- 				CASE
-- 					WHEN (
-- 						SELECT DISTINCT
-- --							 Indexname
-- 								   	   FROM 	 Dbc.Indicesv
-- 								 	   WHERE
-- 							TABLE_SCHEMA = ''Sales''
-- 									   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 									   AND
-- --									       	 Indexname
-- 									       	           = ''Idx_Customer_Activity_Key'' )
-- 						IS NOT NULL
-- 						THEN 1 ELSE 0
-- 				END
-- 			INTO :Index_Exists ;
			IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index Idx_Customer_Activity_Key'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create Idx_Customer_Activity_Key'';
--					CREATE 	INDEX Idx_Customer_Activity_Key ( Customer_Activity_Key ) ON Sales.Fact_Touchpoint_Details ;
			ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			END IF;

		------- 15 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine If Idx_Fact_Touchpoint_Details Index Exists'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Index_Exists := 0;
			Sql_Statement := Activity_Desc;
-- 			SELECT
				
-- 				CASE
-- 					WHEN (
-- 						SELECT DISTINCT
-- --							 Indexname
-- 								   	   FROM 	 Dbc.Indicesv
-- 								 	   WHERE
-- 							TABLE_SCHEMA = ''Sales''
-- 									   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 									   AND
-- --									       	 Indexname
-- 									       	           = ''Idx_Fact_Touchpoint_Details'' )
-- 						IS NOT NULL
-- 						THEN 1 ELSE 0
-- 				END
-- 			INTO :Index_Exists ;
			IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index Idx_Fact_Touchpoint_Details'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create Idx_Fact_Touchpoint_Details'';
--					CREATE 	INDEX Idx_Fact_Touchpoint_Details ( Customer_Source_Key ,Location_Key , Source_Customer_Id )
--					ON Sales.Fact_Touchpoint_Details ;
			ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			END IF;

		------- 16 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine If Idx_Lead_Key Index Exists'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Index_Exists := 0;
			Sql_Statement := Activity_Desc;
-- 			SELECT
				
-- 				CASE
-- 					WHEN (
-- 						SELECT DISTINCT
-- --							 Indexname
-- 								   	   FROM 	 Dbc.Indicesv
-- 								 	   WHERE
-- 							TABLE_SCHEMA = ''Sales''
-- 									   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 									   AND
-- --									       	 Indexname
-- 									       	           = ''Idx_Lead_Key'' )
-- 						IS NOT NULL
-- 						THEN 1 ELSE 0
-- 				END
-- 			INTO :Index_Exists ;
			IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index Idx_Lead_Key'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create Idx_Lead_Key'';
--					CREATE 	INDEX Idx_Lead_Key ( Touchpoint_Attribute_Key ) ON Sales.Fact_Touchpoint_Details ;
			ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			END IF;
		------- 17 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine If Ui_Fact_Touchpoint_Details Index Exists'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Index_Exists := 0;
			Sql_Statement := Activity_Desc;
-- 			SELECT
				
-- 				CASE
-- 					WHEN (
-- 						SELECT DISTINCT
-- --							 Indexname
-- 								   	   FROM 	 Dbc.Indicesv
-- 								 	   WHERE
-- 							TABLE_SCHEMA = ''Sales''
-- 									   AND TABLE_NAME = ''Fact_Touchpoint_Details''
-- 									   AND
-- --									       	 Indexname
-- 									       	           = ''Ui_Fact_Touchpoint_Details'' )
-- 						IS NOT NULL
-- 						THEN 1 ELSE 0
-- 				END
-- 			INTO :Index_Exists ;
			IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index Ui_Fact_Touchpoint_Details'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create Ui_Fact_Touchpoint_Details'';
--					CREATE 	UNIQUE INDEX Ui_Fact_Touchpoint_Details (Location_Key, Source_Record_Type_Key, Source_Record_Id) ON Sales.Fact_Touchpoint_Details ;
			ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			END IF;
	---------- 18 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Record_Count := 0;
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key,Process_Control_Key,Process_Status_Key,
			Balanced_Flag,Destination_Database,Destination_Table_Name,Error_Detail_Description,
			Source_Server,Source_Database,Source_Table_Name,Destination_Aggregate_Amount,
			Destination_Record_Count,Error_Record_Count,Source_Aggregate_Amount,
			Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''Na''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);
			Record_Count := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);

	---------- 19 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			IF (Target_Balanced = ''Y'' AND COALESCE ( Error_Count, 0 ) = 0) THEN
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, ''Target_Balanced = '' || :Target_Balanced , :Completed_Flag, :Error_Count, 0 , :Step_Id);
				Sql_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments;
			END IF;

	------- 20 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update BI_Update_Log'';
			Step_ID := Step_ID + 1;
			IF (COALESCE ( Error_Count, 0 ) = 0) THEN
				SELECT
					COUNT(*)
				INTO
					:Yesterday_Count
				FROM
					SALES.Sales_Views.Fact_Touchpoint_Details
				WHERE 	dw_insert_ts >= TO_TIMESTAMP(CURRENT_DATE)
				AND     Source_Record_Type_Key = :Record_Type_Key
				AND     Customer_Activity_Key = :Cust_Act_Key ;
				Yesterday_Count := COALESCE ( Yesterday_Count , 0 );
				SELECT
					MAX(Activity_Day_Key)
				INTO 	:Max_Activity_Day_Key
				FROM
					SALES.Sales_Views.Fact_Touchpoint_Details
				WHERE   dw_insert_ts >= TO_TIMESTAMP(CURRENT_DATE)
				AND     Source_Record_Type_Key = :Record_Type_Key
				AND     Customer_Activity_Key = :Cust_Act_Key ;
				CALL DATAOPS.Metadata_Controls.sp_Insert_Update_BI_Update_Log(37,''Fact Touch Point - Appointment'', :Yesterday_Count, :Max_Activity_Day_Key);
			END IF;

	---------- 21 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_Id);
			Sql_Statement := Activity_Desc;
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count, ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Target;
		END;
		RETURN OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);

	Exception 
		When Planned_Exception then 
			INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
			Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

		When OTHER then 
			Error_Count := Error_Count +1 ; 
			Error_Condition := 9999 ; 
			Out_Error_Count := Error_Count ; 
			Out_Hard_Stop_Error := 1 ; 
			Out_Records_Loaded := Count_Last ; 
			INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	 
			VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 
			INSERT 	INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
			Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 
	END;
';