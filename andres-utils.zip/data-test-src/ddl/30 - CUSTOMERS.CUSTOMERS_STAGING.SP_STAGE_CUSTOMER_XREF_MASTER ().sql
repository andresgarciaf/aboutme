CREATE OR REPLACE PROCEDURE "SP_STAGE_CUSTOMER_XREF_MASTER"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS CALLER
AS '
	DECLARE
		/******************************************************************************************************************************************************************************
			Created: 2019-05-02				BY: Michael
			Purpose: Stage and data into Customer XRef Master from multiple sources.  
				Content in Customer XRef Master prior to ~1/1/2019 is seeded from a separate script

		call	CUSTOMERS.Customers_Staging.sp_Stage_Customer_XRef_Master ( Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

			Modified Date	Modified By	Notes
			-------------	------------	---------------------------------------------------------------------------------------------------------------------------------------------
			2019-06-26	Michael		Rewritten to utilize Source Name supplied in Reltio Crosswalk
			2019-07-02	Michael		Correct Coalesce in P15 & P19
			2019-07-05	Michael		Changed P28.
							Removed DW_Record_ID from certain filters
			2019-07-06	Michael		Updated Name_Last throughout
			2019-07-11	Michael		Update Last_Merge_TS when reassigning
			2019-07-26	Michael		Changed eFinance to Reltio to be an Or
			2019-11-27	Krishna		Changed Credit_Customers view point for CDM3.0 View
			2019-12-04	Aravindakshan	Changed to reserved container as part of CCPA - Phase 1
			2019-12-16	Harini		Changed to reserved container as part of CCPA - Phase 2
			2020-10-05	Matt		Added OTM source record type key 854 to P24
			2020-10-12	Sofia		Web Lead table decommision changes
			2021-07-09	Vamsi		New source CAFALFA data step at 3.1 and updated P4 to include CAFALFA
			2021-09-24	Sofia		P21 to P23 added to merge credit OPUX & checkou data into customer_xref_master
			2022-05-07	Sofia		New source ERP data step at P5 & P6 to include ERP


		*****************************************************************************************************************************************************************************/
		-- Unique Variables for this procedure:
		Index_Exists	BYTEINT := 0; -- Used to signal whether an index needs to be dropped

		Customer_Source   SMALLINT; -- Used to populate Customer source as CDI

		Count_Landing	INTEGER := 0; -- Used to count records from Landing

		First_Start_Time TIMESTAMP(0); -- Earliest Start TS for seeding data

		Run_Now		CHAR(1) := ''N''; -- Defines whether to do updates during the day or at night

		Truncate_Source	CHAR(1) := ''Y''; -- Identifies whether delete records at the end of the proc in EDW_Reltio_Landing

		-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The name of the procedure running

		Activity_Desc	VARCHAR(500); -- A description of the step in the procedure running for the Activity Log

		Batch_Number	INTEGER := 0; -- Holds the Batch Key assigned in the Landing process

		Cache_Record_Key	INTEGER := 0; -- Record_Key in Metadata_Controls.Table_Update_Codes for this table

		Calendar_Key	INTEGER := 0; -- Used to hold today''s Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count of lines of code in this procedure for control purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used for updating the Activity Log

		Count_Last	INTEGER := 0; -- Used within the procedure to compare record count today to yesterday

		Count_Source	INTEGER := 0; -- Used within the procedure to reconcile source to Stage

		Count_Stage	INTEGER := 0; -- Used within the procedure to reconcile source to Stage

		Count_Target	INTEGER := 0; -- Used within the procedure to reconcile Stage to Target

		Database_Source	VARCHAR(100); -- Used to specify the database where data is obtained

		Database_Stage 	VARCHAR(100); -- Used to specify the database in which this procedure runs

		Database_Target	VARCHAR(100); -- Used to specify the public production database 

		Error_Condition	BYTEINT := 0; -- Identifies the last error condition encountered

		Error_Count	SMALLINT := 0; -- Written to Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written to the Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count of hard stop errors encountered by all called procs

		Last_Record_Key	INTEGER := 0; -- Used to identify the existing vs new records

		Process_ID	INTEGER := 0; -- Identifies the Process_Control_Key this Job Process is related to

		Record_Count	INTEGER := 0; -- Multi-purpose

		SQL_Return_Code	INTEGER := 0; -- Holds the SQLCODE reported by Teradata when an error occurs - Written to the Error_Log

		SQL_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic SQL - May be written to Error Log also

		SQL_State_Code	VARCHAR(5) := ''''; -- Holds the value reported for SQLSTATE when an error occurs - Written to the Error_Log

		Start_Time TIMESTAMP(0); -- Time when this procedure starts	

		Step_ID		SMALLINT := 0; -- The Step Number in the procedure that runs next (reflected in the Activity Log)

		Table_Source	VARCHAR(100); -- Source Table Name

		Table_Stage	VARCHAR(100); -- Stage Table Name

		Table_Target	VARCHAR(100); -- Target Table Name

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies whether the Stage, and Target balance

		Version		DECIMAL(6,3) := 0.00; -- The version of this stored procedure in use

		OUT_ERROR_COUNT SMALLINT := 0;

		OUT_HARD_STOP_ERROR BYTEINT := 0;

		OUT_RECORDS_LOADED INTEGER := 0;

		Final_Output Object;
		
		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

	BEGIN

		Activity_Name := ''sp_Stage_Customer_XRef_Master'';
		Code_Lines := 2060;
		Customer_Source := 3;
		Database_Source := ''Multiple'';
		Database_Stage := ''Customers_Staging'';
		Database_Target := ''Customers'';
		Process_ID := 418;
		Table_Source := ''Multiple'';
		Table_Stage := ''Not Applicable'';
		Table_Target := ''Customer_XRef_Master'';
		Version := 3.13;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE() ;
		SELECT
			CASE
				WHEN CURRENT_TIME() BETWEEN TIME ''00:00:01'' AND TIME ''05:00:00''
					THEN ''Y''
				WHEN CURRENT_TIME() >= TIME ''21:00:00''
					THEN ''Y''
			     ELSE ''N''
			END
		INTO
			:Run_Now;

		--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := ''Set Metadata_Controls.Run_Time_Results record to zero'';
			CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Start(
			:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
			:Process_ID , :Process_ID , ''Teradata'' , :Table_Target, :Version ) ;
			SQL_Statement := ''Get parameter value'';

			Start_Time := (SELECT
				CASE
					WHEN (
						SELECT
							Parameter_value
						   FROM
							DATAOPS.Metadata_Views.Parameters_Customer
						   WHERE	  Parameter_Name = ''Reltio_XRef_Pool_Days'' ) = ''9999''
						THEN TO_TIMESTAMP(''1980-01-01 13:52:22'', ''YYYY-MM-DD HH:MI:SS'')

			     ELSE (
						SELECT
							TO_TIMESTAMP(TO_DATE(DATEADD(''DAY'',-CAST(TRUNC(Parameter_Value) AS INTEGER),CURRENT_TIMESTAMP(0))))
				   FROM
							DATAOPS.Metadata_Views.Parameters_Customer
				   WHERE	Parameter_Name =''Reltio_XRef_Pool_Days'' )
				END parameter_value);

			SQL_Statement := ''Set First_Start_Time Parameter'';
			SELECT
				CAST ( Parameter_Value AS TIMESTAMP(0) ) INTO
				:First_Start_Time
		FROM
				DATAOPS.Metadata_Views.Parameters_Customer
		WHERE	Parameter_Name = ''Reltio_XRef_First_Start_TS'' ;

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Reltio XRef Master
		-------- 1 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Store from Reltio_XRef_Master'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Reltio_Customer_Original_CS,
			Reltio_Customer_Last_CS,
			Reltio_Customer_Golden_CS,
			Activity_Day_Key,
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS,
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
			SELECT
				Reltio_Customer_Original_CS,
				Reltio_Customer_Last_CS,
				Reltio_Customer_Golden_CS,
				Activity_Day_Key,
				Customer_Source_Key,
				Name_Last,
				Source_Customer_ID_CS,
				Source_Identifier_ID,
				Source_Name,
				Use_CDI_Flag,
				DW_Source_Name_ID,
				DW_Record_Source_ID,
				DW_Insert_TS,
				DW_Update_TS
			FROM	(
					SELECT
						m.Reltio_Customer_ID_CS AS Reltio_Customer_Original_CS,
						m.Reltio_Customer_ID_CS AS Reltio_Customer_Last_CS,
						m.Reltio_Customer_ID_CS AS Reltio_Customer_Golden_CS,
						d.Calendar_By_Day_Key AS Activity_Day_Key,
						m.Customer_Source_Key,
						COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') AS Name_Last,
						m.Source_Identifier_1 AS Source_Customer_ID_CS,
						m.Source_Identifier_2 AS Source_Identifier_ID,
						CASE
							WHEN m.Source_Identifier_3 = ''NA''
								THEN COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') ELSE m.Source_Identifier_3
						END AS Source_Name,
						m.Original_Source_Update_TS,
						m.Reltio_Load_TS,
						''R'' AS Use_CDI_Flag,
						CASE
							WHEN m.Source_Identifier_3 = ''NA''
								THEN ''C'' ELSE ''X''
						END AS DW_Source_Name_ID,
						11 AS DW_Record_Source_ID,
						CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
						CURRENT_TIMESTAMP(0) AS DW_Update_TS
					FROM
						CUSTOMERS.edw_Customer.Reltio_XRef_Master m
					JOIN
							ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = m.Effective_Date
					LEFT OUTER
					JOIN	(
								SELECT
									Reltio_Customer_ID_CS,
									Name_Last FROM
									CUSTOMERS.edw_Customer.Reltio_Customer
						UNION
								SELECT
									Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
									Organization_Name AS Name_Last
								FROM
									CUSTOMERS.edw_Customer.Reltio_Organization
						) o ON o.Reltio_Customer_ID_CS = m.Reltio_Customer_ID_CS
					WHERE	m.Reltio_Data_Source_Key = 145
					AND	m.Customer_Source_Key = 16
					AND	m.Active_Flag = ''Y''
					AND	m.Reltio_Delete_TS IS NULL
					AND	m.DW_Update_TS >= :Start_Time
				) y
			WHERE	( Activity_Day_Key, Source_Customer_ID_CS::VARCHAR, Source_Identifier_ID::VARCHAR, COALESCE(Source_Name::VARCHAR,'' '') ) NOT IN (
					SELECT
						Activity_Day_Key,
						Source_Customer_ID_CS,
						Source_Identifier_ID,
						Source_Name
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key = 16 )
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY Activity_Day_Key,
							      Source_Customer_ID_CS, Source_Identifier_ID, Source_Name
						  ORDER BY     Original_Source_Update_TS, Reltio_Load_TS  ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 2 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Reltio XRef Master'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS m
				SET
					m.Customer_Key_Original = c.Customer_Key,
					m.Customer_Key_Last = c.Customer_Key,
					m.Customer_Key_Golden = c.Customer_Key,
					m.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master c	--changed to reserved container as part of CCPA
		WHERE	m.Reltio_Customer_Original_CS = c.Source_Customer_ID_CS
		AND	c.Customer_Source_Key = 3
		AND	m.DW_Record_Source_ID = 11
		AND	m.Customer_Key_Original < 0 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- CAF Loans
		-------- 3 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert CAF'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Reltio_Customer_Golden_CS,
			Reltio_Customer_Last_CS,
			Reltio_Customer_Original_CS,
			Activity_Day_Key,
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS,
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
			SELECT
				m.Reltio_Customer_ID_CS,
				m.Reltio_Customer_ID_CS,
				m.Reltio_Customer_ID_CS,
				d.Calendar_By_Day_Key AS Activity_Day_Key,
				m.Customer_Source_Key,
				COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') AS Name_Last,
				m.Source_Identifier_1 AS Source_Customer_ID_CS,
				m.Source_Identifier_2 AS Source_Identifier_ID,
				CASE
					WHEN m.Source_Identifier_3 = ''NA''
						THEN COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') ELSE m.Source_Identifier_3
				END AS Source_Name,
				''R'' AS Use_CDI_Flag,
				CASE
					WHEN m.Source_Identifier_3 = ''NA''
						THEN ''C'' ELSE ''X''
				END AS DW_Source_Name_ID,
				15 AS DW_Record_Source_ID,
				CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
				CURRENT_TIMESTAMP(0) AS DW_Update_TS
			FROM
				CUSTOMERS.edw_Customer.Reltio_XRef_Master m
			JOIN
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = m.Effective_Date
			LEFT OUTER
			JOIN	(
						SELECT
							Reltio_Customer_ID_CS,
							Name_Last FROM
							CUSTOMERS.edw_Customer.Reltio_Customer
				UNION
						SELECT
							Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
							Organization_Name AS Name_Last
						FROM
							CUSTOMERS.edw_Customer.Reltio_Organization
				) o	ON o.Reltio_Customer_ID_CS = m.Reltio_Customer_ID_CS
			WHERE	m.Customer_Source_Key IN (15)
			AND	m.DW_Update_TS >= :Start_Time
			AND	/*m.Source_Identifier_1::VARCHAR*/ 1 NOT IN (
					SELECT
						1 --m.Source_Identifier_1
						FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
						WHERE	Customer_Source_Key IN (15 ) )
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY m.Source_Identifier_1
						  ORDER BY     m.Reltio_Data_Source_Key, d.Calendar_By_Day_Key, m.Reltio_Load_TS ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- CAFALFA Loans
		-------- 3 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert CAFALFA'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Reltio_Customer_Golden_CS,
			Reltio_Customer_Last_CS,
			Reltio_Customer_Original_CS,
			Activity_Day_Key,
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS,
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
			SELECT
				m.Reltio_Customer_ID_CS,
				m.Reltio_Customer_ID_CS,
				m.Reltio_Customer_ID_CS,
				d.Calendar_By_Day_Key AS Activity_Day_Key,
				m.Customer_Source_Key,
				COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') AS Name_Last,
				m.Source_Identifier_1 AS Source_Customer_ID_CS,
				m.Source_Identifier_2 AS Source_Identifier_ID,
				CASE
					WHEN m.Source_Identifier_3 = ''NA''
						THEN COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') ELSE m.Source_Identifier_3
				END AS Source_Name,
				''R'' AS Use_CDI_Flag,
				CASE
					WHEN m.Source_Identifier_3 = ''NA''
						THEN ''C'' ELSE ''X''
				END AS DW_Source_Name_ID,
				23 AS DW_Record_Source_ID,
				CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
				CURRENT_TIMESTAMP(0) AS DW_Update_TS
			FROM
				CUSTOMERS.edw_Customer.Reltio_XRef_Master m
			JOIN
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = m.Effective_Date
			LEFT OUTER
			JOIN	(
						SELECT
							Reltio_Customer_ID_CS,
							Name_Last FROM
							CUSTOMERS.edw_Customer.Reltio_Customer
				UNION
						SELECT
							Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
							Organization_Name AS Name_Last
						FROM
							CUSTOMERS.edw_Customer.Reltio_Organization
				) o	ON o.Reltio_Customer_ID_CS = m.Reltio_Customer_ID_CS
			WHERE	m.Customer_Source_Key IN (23 )
			AND	m.DW_Update_TS >= :Start_Time
			AND	/*m.Source_Identifier_1::VARCHAR*/ 1 NOT IN (
					SELECT
						1 --m.Source_Identifier_1
						FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
						WHERE	Customer_Source_Key IN (23 ) )
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY m.Source_Identifier_1
						  ORDER BY     m.Reltio_Data_Source_Key, d.Calendar_By_Day_Key, m.Reltio_Load_TS ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);


		-------- 4 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for CAF & CAFALFA'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS m
				SET
					m.Customer_Key_Original = c.Customer_Key,
					m.Customer_Key_Last = c.Customer_Key,
					m.Customer_Key_Golden = c.Customer_Key,
					m.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master c	--changed to reserved container as part of CCPA
		WHERE	m.Reltio_Customer_Original_CS = c.Source_Customer_ID_CS
		AND	c.Customer_Source_Key = 3
		AND	m.DW_Record_Source_ID IN (15 ,23 )
		AND	m.Customer_Key_Original < 0 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		-- Reltio XRef Master - ERP
		-------- 5 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert ERP from Reltio_XRef_Master'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Reltio_Customer_Original_CS,
			Reltio_Customer_Last_CS,
			Reltio_Customer_Golden_CS,
			Activity_Day_Key,
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS,
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
			SELECT
				Reltio_Customer_Original_CS,
				Reltio_Customer_Last_CS,
				Reltio_Customer_Golden_CS,
				Activity_Day_Key,
				Customer_Source_Key,
				Name_Last,
				Source_Customer_ID_CS,
				Source_Identifier_ID,
				Source_Name,
				Use_CDI_Flag,
				DW_Source_Name_ID,
				DW_Record_Source_ID,
				DW_Insert_TS,
				DW_Update_TS
			FROM	(
					SELECT
						m.Reltio_Customer_ID_CS AS Reltio_Customer_Original_CS,
						m.Reltio_Customer_ID_CS AS Reltio_Customer_Last_CS,
						m.Reltio_Customer_ID_CS AS Reltio_Customer_Golden_CS,
						d.Calendar_By_Day_Key AS Activity_Day_Key,
						m.Customer_Source_Key,
						COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') AS Name_Last,
						m.Source_Identifier_1 AS Source_Customer_ID_CS,
						m.Source_Identifier_2 AS Source_Identifier_ID,
						CASE
							WHEN m.Source_Identifier_3 = ''NA''
								THEN COALESCE(UPPER(o.Name_Last::VARCHAR), ''NA'') ELSE m.Source_Identifier_3
						END AS Source_Name,
						m.Original_Source_Update_TS,
						m.Reltio_Load_TS,
						''R'' AS Use_CDI_Flag,
						CASE
							WHEN m.Source_Identifier_3 = ''NA''
								THEN ''C'' ELSE ''X''
						END AS DW_Source_Name_ID,
						25 AS DW_Record_Source_ID,
						CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
						CURRENT_TIMESTAMP(0) AS DW_Update_TS
					FROM
						CUSTOMERS.edw_Customer.Reltio_XRef_Master m
					JOIN
							ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = m.Effective_Date
					LEFT OUTER
					JOIN	(
								SELECT
									Reltio_Customer_ID_CS,
									Name_Last FROM
									CUSTOMERS.edw_Customer.Reltio_Customer
						UNION
								SELECT
									Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
									Organization_Name AS Name_Last
								FROM
									CUSTOMERS.edw_Customer.Reltio_Organization
						) o ON o.Reltio_Customer_ID_CS = m.Reltio_Customer_ID_CS
					WHERE	m.Reltio_Data_Source_Key = 145
					AND	m.Customer_Source_Key = 24
					AND	m.Active_Flag = ''Y''
					AND	m.Reltio_Delete_TS IS NULL
					AND	m.DW_Update_TS >= :Start_Time
				) y
			WHERE	( Activity_Day_Key::VARCHAR, Source_Customer_ID_CS::VARCHAR, Source_Identifier_ID::VARCHAR, COALESCE(Source_Name::VARCHAR,'' '') ) NOT IN (
					SELECT
						Activity_Day_Key,
						Source_Customer_ID_CS,
						Source_Identifier_ID,
						Source_Name
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key = 24 )
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY Activity_Day_Key,
							      Source_Customer_ID_CS, Source_Identifier_ID, Source_Name
						  ORDER BY     Original_Source_Update_TS, Reltio_Load_TS  ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 6 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Reltio XRef Master'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS m
				SET
					m.Customer_Key_Original = c.Customer_Key,
					m.Customer_Key_Last = c.Customer_Key,
					m.Customer_Key_Golden = c.Customer_Key,
					m.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master c	--changed to reserved container as part of CCPA
		WHERE	m.Reltio_Customer_Original_CS = c.Source_Customer_ID_CS
		AND	c.Customer_Source_Key = 3
		AND	m.DW_Record_Source_ID = 25
		AND	m.Customer_Key_Original < 0 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-- MyKMX
		-------- 7 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert MyKMX'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Activity_Day_Key,
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS,
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
			SELECT
				d.Calendar_By_Day_Key AS Activity_Day_Key,
				11 AS Customer_Source_Key,
				''NA'' AS Name_Last,
				m.User_ID AS Source_Customer_ID_CS,
				''NA'' AS Source_Identifier_ID,
				CASE
					WHEN TRIM(m.Name_Last) = ''''
						THEN ''NA''
					WHEN m.Name_Last IS NULL
						THEN ''NA''
				     ELSE UPPER(m.Name_Last)
				END AS Source_Name,
				''S'' AS Use_CDI_Flag,
				''S'' AS DW_Source_Name_ID,
				16 AS DW_Record_Source_ID,
				CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
				CURRENT_TIMESTAMP(0) AS DW_Update_TS
			FROM
				SALES.Edw_Stockroom_Reserved_Views.mykmx2_user m   --changed to reserved container as part of CCPA
			JOIN
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = CAST(m.ss_insert_ts AS DATE) 
			WHERE	/*m.User_ID::VARCHAR*/ 1 NOT IN (
					SELECT
						1 --m.User_ID
						FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
						WHERE
						11 = 11 )
			AND	m.lst_upd_ts >= :Start_Time ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 8 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Get Reltio Customer ID for MyKMX'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS m
				SET
					m.Name_Last = UPPER(r.Name_Last),
					m.Reltio_Customer_Last_CS = r.Reltio_Customer_ID_CS,
					m.Reltio_Customer_Golden_CS = r.Reltio_Customer_ID_CS,
					m.Reltio_Customer_Original_CS = r.Reltio_Customer_ID_CS,
					m.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					(
						SELECT
							x.Reltio_Customer_ID_CS,
							x.Source_Identifier_1,
							o.Name_Last,
							x.Reltio_Update_TS
						FROM
							CUSTOMERS.edw_Customer.Reltio_XRef_Master x
						LEFT OUTER
						JOIN	(
									SELECT
										Reltio_Customer_ID_CS,
										Name_Last FROM
										CUSTOMERS.edw_Customer.Reltio_Customer
							UNION
									SELECT
										Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
										Organization_Name AS Name_Last
									FROM
										CUSTOMERS.edw_Customer.Reltio_Organization
							) o	ON o.Reltio_Customer_ID_CS = x.Reltio_Customer_ID_CS
						WHERE	x.Customer_Source_Key = 11
						AND	x.DW_Update_TS >= :Start_Time
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY x.Source_Identifier_1
									  ORDER BY x.Original_Source_Update_TS, x.Reltio_Load_TS ) = 1
					) r
		WHERE	m.Source_Customer_ID_CS::VARCHAR = r.Source_Identifier_1::VARCHAR
		AND	m.Customer_Source_Key = 11 -- MyKMX
		AND	m.Reltio_Customer_Original_CS IS NULL ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 9 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for MyKMX when there is a Reltio ID'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
				SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 11
		AND	m.Customer_Source_Key = 3
		AND	x.Customer_Key_Original = -1
		AND	x.Reltio_Customer_Golden_CS = m.Source_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 10 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Assign Customer Keys for MyKMX'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_ID_Master (
			Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID, Source_Name, Effective_Date)
			SELECT
				11 AS Customer_Source_Key,
				Source_Customer_ID_CS,
				''NA'' AS Source_Identifier_ID,
				Source_Name,
				DATAOPS.UTILITIES.INT_TO_DATE_UDF(Activity_Day_Key - 19000000)  AS Effective_Date
			FROM
				CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
			WHERE	Customer_Source_Key = 11
			AND	Reltio_Customer_Original_CS IS NULL
			AND	Source_Customer_ID_CS::VARCHAR NOT IN (
					SELECT
						Source_Customer_ID_CS
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key = 11
				) ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 11 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for MyKMX'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
				SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 11
		AND	m.Customer_Source_Key = 11
		AND	x.Customer_Key_Original < 0
		AND	x.Source_Customer_ID_CS = m.Source_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Salesforce
		-------- 12 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Salesforce'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Activity_Day_Key,
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS,
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
			SELECT
				d.Calendar_By_Day_Key AS Activity_Day_Key,
				17 AS Customer_Source_Key,
				''NA'' AS Name_Last,
				a.Account_ID_CS AS Source_Customer_ID_CS,
				''NA'' AS Source_Identifier_ID,
				CASE
					WHEN TRIM(a.Last_Name) = ''''
						THEN ''NA''
					WHEN a.Last_Name IS NULL
						THEN ''NA''
				     ELSE UPPER(a.Last_Name)
				END AS Source_Name,
				''S'' AS Use_CDI_Flag,
				''S'' AS DW_Name_Source_ID,
				17 AS DW_Record_Source_ID,
				CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
				CURRENT_TIMESTAMP(0) AS DW_Update_TS
			FROM
				SALES.EDW_Salesforce_Reserved_Views.sf_account a	--changed to reserved container as part of CCPA
			JOIN
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = CAST(a.ss_insert_ts_utc AS DATE) 
			WHERE	a.Account_ID_CS::VARCHAR NOT IN (
					SELECT
						Source_Customer_ID_CS
						FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA 
						WHERE
						17 = 17 ) ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 13 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Get Reltio Customer ID for Salesforce'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS m
				SET
					m.Name_Last = UPPER(r.Name_Last),
					m.Reltio_Customer_Last_CS = r.Reltio_Customer_ID_CS,
					m.Reltio_Customer_Golden_CS = r.Reltio_Customer_ID_CS,
					m.Reltio_Customer_Original_CS = r.Reltio_Customer_ID_CS,
					m.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					(
						SELECT
							x.Reltio_Customer_ID_CS,
							x.Source_Identifier_1,
							o.Name_Last,
							x.Reltio_Update_TS
						FROM
							CUSTOMERS.edw_Customer.Reltio_XRef_Master x
						LEFT OUTER
						JOIN	(
									SELECT
										Reltio_Customer_ID_CS,
										Name_Last FROM
										CUSTOMERS.edw_Customer.Reltio_Customer
							UNION
									SELECT
										Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
										Organization_Name AS Name_Last
									FROM
										CUSTOMERS.edw_Customer.Reltio_Organization
							) o	ON o.Reltio_Customer_ID_CS = x.Reltio_Customer_ID_CS

						WHERE	x.Customer_Source_Key = 17
						AND	x.DW_Update_TS >= :Start_Time
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY x.Source_Identifier_1
									  ORDER BY x.Original_Source_Update_TS, x.Reltio_Load_TS ) = 1
					) r
		WHERE	m.Source_Customer_ID_CS::VARCHAR = r.Source_Identifier_1::VARCHAR
		AND	m.Customer_Source_Key = 17 -- Salesforce
		AND	m.Reltio_Customer_Original_CS IS NULL ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 14 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Reltio Customers assigned to Salesforce Customer ID'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := ''Assign based on Salesforce Customer Key'';
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
				SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 17
		AND	m.Customer_Source_Key = 3
		AND	x.Customer_Key_Original < 0
		AND	x.Reltio_Customer_Golden_CS = m.Source_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 15 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Assign Customer Keys for Salesforce'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_ID_Master (
			Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID, Source_Name, Effective_Date)
			SELECT
				17 AS Customer_Source_Key,
				Source_Customer_ID_CS,
				''NA'' AS Source_Identifier_ID,
				Name_Last AS Source_Name,
				DATAOPS.UTILITIES.INT_TO_DATE_UDF(Activity_Day_Key - 19000000)  AS Effective_Date
			FROM
				CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
			WHERE	Customer_Source_Key = 17
			AND	Reltio_Customer_Original_CS IS NULL
			AND	Source_Customer_ID_CS::VARCHAR NOT IN (
					SELECT
						Source_Customer_ID_CS
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key = 17
				) ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 16 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Salesforce'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := ''Assign based on Salesforce Customer Key'';
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
				SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 17
		AND	m.Customer_Source_Key = 17
		AND	x.Customer_Key_Original < 0
		AND	x.Source_Customer_ID_CS = m.Source_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Orders
		-------- 17 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Store Orders'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Activity_Day_Key, Activity_Key, Customer_Source_Key,
			Customer_Key_Golden, Customer_Key_Last, Customer_Key_Original,
			Reltio_Customer_Golden_CS, Reltio_Customer_Last_CS, Reltio_Customer_Original_CS,
			Source_Customer_ID_CS, Source_Identifier_ID, Source_Name,
			Name_Last, Use_CDI_Flag,
			DW_Source_Name_ID, DW_Record_Source_ID)
			SELECT
				y.Activity_Day_Key,
				y.Activity_Key,
				4 AS Customer_Source_Key,
				COALESCE(m.Customer_Key::VARCHAR, -1) AS Customer_Key_Golden,
				COALESCE(m.Customer_Key::VARCHAR, -1) AS Customer_Key_Last,
				COALESCE(m.Customer_Key::VARCHAR, -1) AS Customer_Key_Original,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Golden_CS,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Last_CS,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Original_CS,
				y.Source_Customer_ID_CS,
				y.Source_Identifier_ID,
				y.Source_Name,
				COALESCE(r.Source_Identifier_3::VARCHAR, ''NA'') AS Name_Last,
				''S'' AS Use_CDI_Flag,
				''S'' AS DW_Source_Name_ID,
				12 AS DW_Record_Source_ID
			FROM	(
					SELECT
						d.Calendar_By_Day_Key AS Activity_Day_Key,
						c.Order_Customer_Key AS Activity_Key,
						LEFT(
						CAST(c.Order_Customer_ID AS VARCHAR), 20) AS Source_Customer_ID_CS,
						LEFT(
						CAST(c.Location_Key AS VARCHAR), 6) AS Source_Identifier_ID,
						CASE
							WHEN c.Order_Customer_Type_Key IN ( 136, 485 )
							THEN COALESCE(UPPER(TRIM(c.Name_Last))::VARCHAR, ''NA'')
						     ELSE COALESCE(UPPER(TRIM(c.Name_Company))::VARCHAR, ''NA'')
						END AS Source_Name
					FROM
						CUSTOMERS.Customers_Reserved_Views.Order_Customers c	--changed to reserved container as part of CCPA
					JOIN
							ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = CAST(c.Source_Insert_TS AS DATE) 
					LEFT OUTER
					JOIN
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x  ON x.Activity_Key = c.Order_Customer_Key	--changed to reserved container as part of CCPA
										     AND	x.Customer_Source_Key = 4
					WHERE	x.Activity_Key IS NULL
					AND	c.DW_Update_TS >= :Start_Time
				) y
			LEFT OUTER
			JOIN
					CUSTOMERS.edw_Customer.Reltio_XRef_Master r ON	r.Source_Identifier_1::VARCHAR = y.Source_Customer_ID_CS
								AND	r.Source_Identifier_2 = y.Source_Identifier_ID
								AND	r.Source_Identifier_3 = y.Source_Name
								AND	r.Customer_Source_Key = 16
								AND	r.Active_Flag = ''Y''
			LEFT OUTER
			JOIN
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m   ON	m.Customer_Source_Key = 3	--changed to reserved container as part of CCPA
								   AND	m.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY y.Activity_Key ORDER BY NULL ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 18 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Reltio Customers assigned to Orders'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
				SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 4
		AND	m.Customer_Source_Key = 3
		AND	x.Customer_Key_Original < 0
		AND	x.Reltio_Customer_Golden_CS = m.Source_Customer_ID_CS;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 19 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Assign Customer Keys for Orders When Not in Reltio'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_ID_Master (
			Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID, Source_Name, Effective_Date)
			SELECT
				Customer_Source_Key,
				Source_Customer_ID_CS,
				Source_Identifier_ID,
				Source_Name,
				DATAOPS.UTILITIES.INT_TO_DATE_UDF(Activity_Day_Key - 19000000)  AS Effective_Date
		FROM
				CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
		WHERE	Customer_Source_Key = 4
		AND	Customer_Key_Golden = -1
		AND	( Customer_Source_Key::VARCHAR, Source_Customer_ID_CS::VARCHAR, Source_Identifier_ID::VARCHAR, Source_Name::VARCHAR ) NOT IN (
					SELECT
						Customer_Source_Key,
						Source_Customer_ID_CS,
						Source_Identifier_ID,
						Source_Name
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key = 4
			)
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY Customer_Source_Key, Source_Customer_ID_CS,
						      Source_Identifier_ID, Source_Name
					  ORDER BY     Activity_Day_Key ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 20 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Orders not assigned through Reltio'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
				SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 4
		AND	m.Customer_Source_Key = 4
		AND	x.Customer_Key_Original < 0
		AND	x.Customer_Source_Key = m.Customer_Source_Key
		AND	x.Source_Customer_ID_CS = m.Source_Customer_ID_CS
		AND	x.Source_Identifier_ID = m.Source_Identifier_ID
		AND	x.Source_Name = m.Source_Name ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Credit Applications
		-------- 21 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Store Credit'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Activity_Day_Key, Activity_Key, Customer_Source_Key,
			Customer_Key_Golden, Customer_Key_Last, Customer_Key_Original,
			Reltio_Customer_Golden_CS, Reltio_Customer_Last_CS, Reltio_Customer_Original_CS,
			Source_Customer_ID_CS, Source_Identifier_ID, Source_Name,
			Name_Last, Use_CDI_Flag,
			DW_Source_Name_ID, DW_Record_Source_ID)
			SELECT
				c.Activity_Day_Key,
				c.Credit_Customer_Key AS Activity_Key,
				c.Customer_Source_Key,
				COALESCE(m.Customer_Key::VARCHAR, -1) AS Customer_Key_Golden,
				COALESCE(m.Customer_Key::VARCHAR, -1) AS Customer_Key_Last,
				COALESCE(m.Customer_Key::VARCHAR, -1) AS Customer_Key_Original,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Golden_CS,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Last_CS,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Original_CS,
				LEFT(LTRIM(TO_VARCHAR(c.Source_Customer_ID, ''MI9999999999'')), 20) AS Source_Customer_ID_CS,
				LEFT(LTRIM(TO_VARCHAR(c.Location_Key, ''MI9999999999'')), 6) AS Source_Identifier_ID,
				COALESCE(UPPER(TRIM(c.Name_Last))::VARCHAR, ''NA'') AS Source_Name,
				COALESCE(UPPER(r.Source_Identifier_3)::VARCHAR, ''NA'') AS Name_Last,
				''S'' AS Use_CDI_Flag,
				''S'' AS DW_Source_Name_ID,
				18 AS DW_Record_Source_ID
			FROM
				CUSTOMERS.Customers_Reserved_Views.Credit_Customers c	--changed to reserved container as part of CCPA
			LEFT OUTER
			JOIN	(
						SELECT
							Activity_Key
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
						WHERE	Customer_Source_Key = 6
				) x	ON x.Activity_Key = c.Credit_Customer_Key
			LEFT OUTER
			JOIN
					CUSTOMERS.edw_Customer.Reltio_XRef_Master r ON	r.Source_Identifier_1::VARCHAR = LEFT(LTRIM(TO_VARCHAR(c.Source_Customer_ID, ''MI9999999999'')), 15)
								AND	r.Source_Identifier_2 = LEFT(LTRIM(TO_VARCHAR(c.Location_Key, ''MI9999999999'')), 6)
								AND	r.Source_Identifier_3 = TRIM(c.Name_Last)
								AND	r.Customer_Source_Key = 16
								AND	r.Active_Flag = ''Y''
			LEFT OUTER
			JOIN
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m   ON	m.Customer_Source_Key = 3	--changed to reserved container as part of CCPA
								  AND	m.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS
			WHERE	c.Source_Record_Type_Key IN (778, 779)
			AND	c.Customer_Source_Key = 6
			AND	c.DW_Update_TS >= :Start_Time
			AND	x.Activity_Key IS NULL
			QUALIFY
				ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY c.Activity_Day_Key ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 22 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert eFinance'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Activity_Day_Key, Activity_Key, Customer_Source_Key,
			Customer_Key_Golden, Customer_Key_Last, Customer_Key_Original,
			Reltio_Customer_Golden_CS, Reltio_Customer_Last_CS, Reltio_Customer_Original_CS,
			Source_Customer_ID_CS, Source_Identifier_ID, Source_Name,
			Name_Last, Use_CDI_Flag,
			DW_Source_Name_ID, DW_Record_Source_ID)
			SELECT
				c.Activity_Day_Key,
				c.Credit_Customer_Key AS Activity_Key,
				c.Customer_Source_Key,
				COALESCE(i.Customer_Key::VARCHAR, -1) AS Customer_Key_Golden,
				COALESCE(i.Customer_Key::VARCHAR, -1) AS Customer_Key_Last,
				COALESCE(i.Customer_Key::VARCHAR, -1) AS Customer_Key_Original,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Golden_CS,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Last_CS,
				r.Reltio_Customer_ID_CS AS Reltio_Customer_Original_CS,
				LEFT(LTRIM(TO_VARCHAR(c.Source_Customer_ID, ''MI9999999999'')), 20) AS Source_Customer_ID_CS,
				''NA'' AS Source_Identifier_ID,
				COALESCE(TRIM(UPPER(c.Name_Last))::VARCHAR, ''NA'') AS Source_Name,
				''NA'' AS Name_Last,
				''S'' AS Use_CDI_Flag,
				''S'' AS DW_Source_Name_ID,
				19 AS DW_Record_Source_ID
			FROM
				CUSTOMERS.Customers_Reserved_Views.Credit_Customers c	--changed to reserved container as part of CCPA
			LEFT OUTER
			JOIN	(
						SELECT
							Activity_Key
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
						WHERE	Customer_Source_Key = 7
				) x	ON x.Activity_Key = c.Credit_Customer_Key
			LEFT OUTER
			/*JOIN	CUSTOMERS.Customers_Reserved_Views.Web_Leads_Master w 	ON  TRIM(w.Name_First) = TRIM(c.Name_First)	--changed to reserved container as part of CCPA
								AND TRIM(w.Name_Last) = TRIM(c.Name_Last)
								AND ( TRIM(w.Phone_Number_Original) = TRIM(c.Phone_Number)
								      OR TRIM(w.eMail_Address) = TRIM(c.eMail_Address) )*/
			JOIN
					SALES.EDW_Salesforce_Reserved_Views.sf_account w 	ON  	TRIM(w.First_Name) = TRIM(c.Name_First)
										AND 	TRIM(w.Last_Name) = TRIM(c.Name_Last)
										AND 	( COALESCE(TRIM(w.Unformatted_Phone::VARCHAR), ''NA'') = COALESCE(TRIM(c.Phone_Number::VARCHAR),''NA'')
										OR 	TRIM(w.person_eMail) = TRIM(c.eMail_Address) )
			LEFT OUTER JOIN
					CUSTOMERS.edw_Customer.Reltio_XRef_Master r		ON 	r.source_identifier_1::VARCHAR=TRIM(w.Account_id_cs)
										AND	r.Customer_source_key=17
			LEFT OUTER JOIN
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master i	ON	i.Source_customer_id_cs=r.reltio_customer_id_cs
										AND	i.customer_source_key=3
			WHERE	c.Source_Record_Type_Key = 787
			AND	c.DW_Update_TS >= :Start_Time
			AND	x.Activity_Key IS NULL
			QUALIFY
								ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY c.Activity_Day_Key ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		 -------- 23 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert CARS - OPUX & CheckOut'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Activity_Day_Key, Activity_Key, Customer_Source_Key,
			Customer_Key_Golden, Customer_Key_Last, Customer_Key_Original,
			Reltio_Customer_Golden_CS, Reltio_Customer_Last_CS, Reltio_Customer_Original_CS,
			Source_Customer_ID_CS, Source_Identifier_ID, Source_Name,
			Name_Last, Use_CDI_Flag,
			DW_Source_Name_ID, DW_Record_Source_ID)
			SELECT
								c.Activity_Day_Key,
								c.Credit_Customer_Key AS Activity_Key,
								c.Customer_Source_Key,
								COALESCE(i.Customer_Key::VARCHAR, -1) AS Customer_Key_Golden,
								COALESCE(i.Customer_Key::VARCHAR, -1) AS Customer_Key_Last,
								COALESCE(i.Customer_Key::VARCHAR, -1) AS Customer_Key_Original,
								r.Reltio_Customer_ID_CS AS Reltio_Customer_Golden_CS,
								r.Reltio_Customer_ID_CS AS Reltio_Customer_Last_CS,
								r.Reltio_Customer_ID_CS AS Reltio_Customer_Original_CS,
								LTRIM(RTRIM(c.Source_Customer_ID))  AS Source_Customer_ID_CS,
								''NA'' AS Source_Identifier_ID,
								COALESCE(TRIM(UPPER(c.Name_Last)::VARCHAR), ''NA'') AS Source_Name,
								''NA'' AS Name_Last,
								''S'' AS Use_CDI_Flag,
								''S'' AS DW_Source_Name_ID,
								20 AS DW_Record_Source_ID  -- NEED TO CLARIFY THIS VALUE TO BE ASSIGNED
			FROM
								CUSTOMERS.Customers_Reserved_Views.Credit_Customers c	--changed to reserved container as part of CCPA
			LEFT OUTER JOIN	(
						SELECT
							Activity_Key
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
						WHERE	Customer_Source_Key = 5
								) x	ON x.Activity_Key = c.Credit_Customer_Key
			LEFT OUTER JOIN	(
						SELECT
							buys.Customer_Buys_ID AS Source_Customer_ID,
							rel.Customer_source_key,
							rel.Reltio_Data_Source_Key,
							rel.reltio_customer_id_cs
						FROM
							CUSTOMERS.edw_Customer.Reltio_XRef_Master rel
						JOIN
							FINANCE.Credit.Credit_Application_Buys_XRef buys ON LTRIM(RTRIM(rel.source_identifier_1)) = LTRIM(RTRIM(buys.Applicant_Buys_Customer_ID))
								) r ON r.Source_Customer_ID=c.Source_Customer_ID
														AND	r.Customer_source_key=20 -- Customer Buys
														AND r.Reltio_Data_Source_Key=145 -- Crosswalk
			LEFT OUTER JOIN
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master i ON i.Source_customer_id_cs=r.reltio_customer_id_cs
														AND	i.customer_source_key=3 -- new customers loaded into Customer_ID_Master from reltio
			WHERE	c.Source_Record_Type_Key = 778 -- CARS
			AND c.Customer_Source_Key = 5 -- Picks only OPUX & CheckOut Credit customers
			AND	c.DW_Update_TS >= :Start_Time
			AND	x.Activity_Key IS NULL
			QUALIFY
								ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY c.Activity_Day_Key ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		 -------- 24 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := SUBSTR(''Set Customer Keys for Reltio Customers, already existing in Customer_ID_Master for OPUX & CheckOut Credit data'',0,100);
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 5
		AND	m.Customer_Source_Key = 3
		AND	x.Customer_Key_Original < 0
		AND	x.Reltio_Customer_Golden_CS = m.Source_Customer_ID_CS;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		 -------- 25 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Assign Customer Keys to Customer_ID_Master for Credit When Not Known / Not available in Reltio'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_ID_Master (
			Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID, Source_Name, Effective_Date)
			SELECT
								Customer_Source_Key,
								Source_Customer_ID_CS,
								Source_Identifier_ID,
								Source_Name,
								DATAOPS.UTILITIES.INT_TO_DATE_UDF(Activity_Day_Key - 19000000)  AS Effective_Date
		FROM
								CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
		WHERE	Customer_Source_Key = 5
		AND	Customer_Key_Golden = -1
		AND	( Customer_Source_Key::VARCHAR, Source_Customer_ID_CS::VARCHAR, Source_Identifier_ID::VARCHAR, Source_Name::VARCHAR ) NOT IN (
					SELECT
						Customer_Source_Key,
						Source_Customer_ID_CS,
						Source_Identifier_ID,
						Source_Name
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key = 5
			)
			QUALIFY
								ROW_NUMBER() OVER ( PARTITION BY Customer_Source_Key, Source_Customer_ID_CS,
						      Source_Identifier_ID, Source_Name
					  ORDER BY     Activity_Day_Key ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 26----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := SUBSTR(''Set Customer Keys as assigned to Customer_ID_Master for Credit When Not Known, to Customer_XRef_Master'',0,100);
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key = 5
		AND	m.Customer_Source_Key = 5
		AND	x.Customer_Key_Original < 0
		AND	x.Customer_Source_Key = m.Customer_Source_Key
		AND	x.Source_Customer_ID_CS = m.Source_Customer_ID_CS
		AND	x.Source_Identifier_ID = m.Source_Identifier_ID
		AND	x.Source_Name = m.Source_Name ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 27 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Reltio Customers assigned to Credit Customer ID'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			-- Added to support data updates only
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key IN ( 5,6,7,8,9 )
		AND	m.Customer_Source_Key = 3
		AND	x.Customer_Key_Original < 0
		AND	x.Reltio_Customer_Golden_CS = m.Source_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 28 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Assign Customer Keys for Credit When Not Known'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO CUSTOMERS.Customers.Customer_ID_Master (
			Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID, Source_Name, Effective_Date)
			SELECT
								Customer_Source_Key,
								Source_Customer_ID_CS,
								Source_Identifier_ID,
								Source_Name,
								DATAOPS.UTILITIES.INT_TO_DATE_UDF(Activity_Day_Key - 19000000)  AS Effective_Date
		FROM
								CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
		WHERE	Customer_Source_Key IN ( 6, 7 )
		AND	Customer_Key_Golden = -1
		AND	( Customer_Source_Key::VARCHAR, Source_Customer_ID_CS::VARCHAR, Source_Identifier_ID::VARCHAR, Source_Name::VARCHAR ) NOT IN (
					SELECT
						Customer_Source_Key,
						Source_Customer_ID_CS,
						Source_Identifier_ID,
						Source_Name
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master --changed to reserved container as part of CCPA
					WHERE	Customer_Source_Key IN ( 6, 7 )
			)
			QUALIFY
								ROW_NUMBER() OVER ( PARTITION BY Customer_Source_Key, Source_Customer_ID_CS,
						      Source_Identifier_ID, Source_Name
					  ORDER BY     Activity_Day_Key ) = 1 ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 29 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Credit'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Original = m.Customer_Key,
					x.Customer_Key_Last = m.Customer_Key,
					x.Customer_Key_Golden = m.Customer_Key,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	x.Customer_Source_Key IN ( 6, 7 )
		AND	m.Customer_Source_Key IN ( 6, 7 )
		AND	x.Customer_Key_Original < 0
		AND	x.Customer_Source_Key = m.Customer_Source_Key
		AND	x.Source_Customer_ID_CS = m.Source_Customer_ID_CS
		AND	x.Source_Identifier_ID = m.Source_Identifier_ID
		AND	x.Source_Name = m.Source_Name ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Store Customers Not in Reltio
		-------- 30 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Missing Store Activity Customers'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			IF (Run_Now = ''Y'') THEN
								SQL_Statement := Activity_Desc;
								INSERT INTO CUSTOMERS.Customers.Customer_XRef_Master (
								Activity_Day_Key, Activity_Key, Customer_Key_Original, Customer_Source_Key,
								Customer_Key_Golden, Name_Last,
								Source_Customer_ID_CS, Source_Identifier_ID, Source_Name,
								Use_CDI_Flag,
								DW_Source_Name_ID,
								DW_Record_Source_ID)
								SELECT
					a.Activity_Day_Key,
					a.Activity_Key,
					-1 AS Customer_Key,
					a.Customer_Source_Key,
					-1 AS Customer_Key_Golden,
					''NA'' AS Name_Last,
					LEFT(
					CAST ( a.Source_Customer_ID AS VARCHAR), 20) AS Source_Customer_ID_CS,
					LEFT(
					CAST ( a.Location_Key AS VARCHAR), 5) AS Source_Identifier_ID,
					UPPER(COALESCE(COALESCE ( c.Name_Last::VARCHAR, c.Name_Organization ), ''NA'')) AS Source_Name,
					''S'' AS Use_CDI_Flag,
					''U'' AS DW_Source_Name_ID,
					20 AS DW_Record_Source_ID
				FROM
					CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef a	--changed to reserved container as part of CCPA
				LEFT OUTER
				JOIN	(
							SELECT DISTINCT Source_Customer_ID_CS,
							Source_Identifier_ID
								FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
								WHERE	Customer_Source_Key IN ( 2, 4, 6, 16 )
					) m	ON 	m.Source_Customer_ID_CS::VARCHAR = a.Source_Customer_ID::VARCHAR
						AND	m.Source_Identifier_ID::VARCHAR = a.Source_Identifier_ID::VARCHAR
				LEFT OUTER
				JOIN
						CUSTOMERS.Customers_Reserved_Views.Customers c ON  c.Customer_Key = a.Customer_Key	--changed to reserved container as part of CCPA
				WHERE	a.Source_Record_Type_Key IN ( 481, 751, 757, 768, 778, 779, 874, 854 )
				AND	a.Customer_Source_Key IN ( 2, 4, 6, 16 )
				AND	m.Source_Customer_ID_CS::VARCHAR IS NULL
				AND	a.Customer_Key IN ( -1, -3 )
								QUALIFY
					ROW_NUMBER () OVER ( PARTITION BY a.Source_Customer_ID, a.Source_Identifier_ID
							   ORDER BY a.Activity_Day_Key ) = 1 ;
								Count_Last := COALESCE ( SQLROWCOUNT , 0 );
								Count_Target := Count_Target + Count_Last;
			END IF;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 31 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Assign Customer Keys for Activity Customers'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			IF (Run_Now = ''Y'') THEN
								INSERT INTO CUSTOMERS.Customers.Customer_ID_Master (
								Customer_Source_Key, Effective_Date, Source_Customer_ID_CS, Source_Identifier_ID, Source_Name)
								SELECT
					Customer_Source_Key,
					MIN (DATAOPS.UTILITIES.INT_TO_DATE_UDF(Activity_Day_Key - 19000000) ) AS Effective_Date,
					Source_Customer_ID_CS,
					Source_Identifier_ID,
					''NA'' AS Source_Name
				FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
				WHERE	DW_Record_Source_ID = 20
				AND	Customer_Key_Original < 0
				AND	( Customer_Source_Key::VARCHAR, Source_Customer_ID_CS::VARCHAR, Source_Identifier_ID::VARCHAR ) NOT IN (
						SELECT
							Customer_Source_Key,
							Source_Customer_ID_CS,
							Source_Identifier_ID
							FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master --changed to reserved container as part of CCPA
					)
				GROUP BY 1, 3, 4 ;
			END IF;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 32 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Customer Keys for Activities'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			IF (Run_Now = ''Y'') THEN
								UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
					SET
						x.Customer_Key_Original = m.Customer_Key,
						x.Customer_Key_Last = m.Customer_Key,
						x.Customer_Key_Golden = m.Customer_Key,
						x.DW_Update_TS = CURRENT_TIMESTAMP(0)
					FROM
						CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
			WHERE	x.DW_Record_Source_ID = 20
			AND	x.Customer_Source_Key IN ( 2, 4, 6, 16 )
			AND	x.Customer_Key_Original < 0
			AND	m.Customer_Source_Key = x.Customer_Source_Key
			AND	x.Source_Customer_ID_CS = m.Source_Customer_ID_CS
			AND	x.Source_Identifier_ID = m.Source_Identifier_ID ;
			END IF;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		-- Web Leads in Reltio
		-------- 33 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Web Leads that have matched to a Reltio ID'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;

		/*INSERT	INTO CUSTOMERS.Customers.Customer_XRef_Master (
			Customer_Key_Golden, 
			Customer_Key_Last, 
			Customer_Key_Original,
			Activity_Day_Key, 
			Customer_Source_Key,
			Name_Last,
			Source_Customer_ID_CS, 
			Source_Identifier_ID,
			Source_Name,
			Use_CDI_Flag,
			DW_Source_Name_ID,
			DW_Record_Source_ID,
			DW_Insert_TS, DW_Update_TS)
		SELECT	a.Customer_Key,
			a.Customer_Key,
			a.Customer_Key,
			d.Calendar_By_Day_Key, 
			14 AS Customer_Source_Key,
			''NA'' AS Name_Last,
			SUBSTR(a.Web_Lead_ID,0,20) AS Source_Customer_ID_CS,
			SUBSTR(a.Web_System_ID,0,6) AS Source_Identifier_ID,
			COALESCE(UPPER(a.Name_Last)::VARCHAR, ''NA'') AS Source_Name,
			''S'' AS Use_CDI_Flag, 
			''S'' AS DW_Source_Name_ID,
			21 AS DW_Record_Source_ID,
			CURRENT_TIMESTAMP(0) AS DW_Insert_TS,
			CURRENT_TIMESTAMP(0) AS DW_Update_TS
		FROM 	CUSTOMERS.Customers_Reserved_Views.Web_Leads_Master a	--changed to reserved container as part of CCPA
		JOIN	ACCOUNTING.Valid_Values_Views.Calendar_By_Day d ON d.Calendar_Date = a.Submit_Date
		WHERE	a.Reltio_Customer_ID_CS IS NOT NULL
		AND	a.Submit_TS >= :Start_Time
		AND	( a.Web_Lead_ID, a.Web_System_ID ) NOT IN (
			SELECT	Source_Customer_ID_CS, Source_Identifier_ID
			FROM	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master	--changed to reserved container as part of CCPA
			WHERE	Customer_Source_Key = 14 ) ;  

		SET	Count_Last = COALESCE ( SQLROWCOUNT , 0 ) ;
		SET	Count_Target = Count_Target + Count_Last;	

		INSERT 	INTO CUSTOMERS.Customers_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )		
		VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID ) ;*/--Commented as part of web_leads decommision

		-----------------------------------------------------------------------------------------------------------------------------
		--	Reassign records to Reltio ID''s if they were added later - Other than eFinance
		-------- 34 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Matching Reltio_XRef_Master Record'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS c
								SET
					c.Customer_Key_Last = y.Customer_Key,
					c.Customer_Key_Golden = y.Customer_Key,
					c.Customer_Key_Original = CASE
						WHEN c.Customer_Key_Original = -1
							THEN y.Customer_Key ELSE c.Customer_Key_Original
					END,
					c.Last_Merge_TS = CURRENT_TIMESTAMP(0),
					c.Reltio_Customer_Golden_CS = y.Reltio_Customer_ID_CS,
					c.Reltio_Customer_Last_CS = y.Reltio_Customer_ID_CS,
					c.Reltio_Customer_Original_CS = y.Reltio_Customer_ID_CS,
					c.Source_Name = y.Source_Identifier_3,
					c.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					(
						SELECT
							x.Customer_Source_Key,
							m.Customer_Key,
							r.Reltio_Customer_ID_CS,
							x.Source_Name,
							x.Name_Last,
							x.Source_Customer_ID_CS,
							x.Source_Identifier_ID,
							r.Source_Identifier_3
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x	--changed to reserved container as part of CCPA
						JOIN
							CUSTOMERS.edw_Customer.Reltio_XRef_Master r ON 	r.Source_Identifier_1::VARCHAR = x.Source_Customer_ID_CS
											AND	r.Source_Identifier_2 = x.Source_Identifier_ID
											AND REPLACE(r.Source_Identifier_3, '' '') = REPLACE(x.Source_Name, '' '')
											AND	r.Active_Flag = ''Y''
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m ON	m.Customer_Source_Key = 3	--changed to reserved container as part of CCPA
											AND	m.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS
						WHERE	x.Reltio_Customer_Golden_CS IS NULL
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY	x.Customer_Source_Key, x.Source_Customer_ID_CS, x.Source_Identifier_ID,
											x.Source_Name
									  ORDER BY	Activity_Day_Key ) = 1
					) y
		WHERE	c.Customer_Source_Key = y.Customer_Source_Key
		AND	c.Source_Customer_ID_CS = y.Source_Customer_ID_CS
		AND	c.Source_Identifier_ID = y.Source_Identifier_ID
		AND	c.Source_Name = y.Source_Name
		AND	c.Reltio_Customer_Golden_CS IS NULL ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-----------------------------------------------------------------------------------------------------------------------------
		--	Reassign records to Reltio ID''s if they were added later - eFinance
		-------- 35 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Matching Salesforce Records'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			-- Salesforce on Partial First Name + Last Name + Phone or eMail
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Golden = y.Customer_Key,
					x.Customer_Key_Last = x.Customer_Key_Golden,
					x.Reltio_Customer_Golden_CS = y.Reltio_Customer_ID_CS,
					x.Reltio_Customer_Last_CS = x.Reltio_Customer_Golden_CS,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0),
					x.Last_Merge_TS = CURRENT_TIMESTAMP(0)-- Added as part of Web leads decommission
								FROM
					(
						SELECT
							c.Credit_Customer_Key AS Activity_Key,
							i.Customer_Key,
							r.Reltio_Customer_ID_CS,
							s.account_id_cs AS Source_Customer_ID,
							''NA'' AS Source_Identifier_ID,
							s.first_name,
							s.last_name,
							c.Name_First,
							c.Name_Last,
							s.person_eMail,
							c.eMail_Address,
							s.unformatted_phone,
							c.Phone_Number
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master m	--changed to reserved container as part of CCPA
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Credit_Customers c 	ON  c.Credit_Customer_Key = m.Activity_Key	--changed to reserved container as part of CCPA
												AND c.Customer_Source_Key = 7
						JOIN
							SALES.EDW_Salesforce_Reserved_Views.sf_account s 	ON SUBSTRING(TRIM(s.First_Name), 1, 3) = SUBSTRING(TRIM(c.Name_First), 1, 3) --changed to reserved container as part of CCPA
											AND TRIM(s.Last_Name) = TRIM(c.Name_Last)
											AND ( COALESCE(s.Unformatted_Phone::VARCHAR, ''NA'') = COALESCE(c.Phone_Number::VARCHAR,''NA'')
											      AND s.person_eMail = c.eMail_Address )
						JOIN
							CUSTOMERS.edw_Customer.Reltio_XRef_Master r	ON  r.Source_Identifier_1::VARCHAR = TRIM(s.Account_ID_CS)
											AND r.Customer_Source_Key = 17
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master i ON i.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS	--changed to reserved container as part of CCPA
											AND i.Customer_Source_Key = 3
						WHERE	m.Reltio_Customer_Golden_CS IS NULL
						AND	m.Customer_Source_Key = 7
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY NULL ) = 1
					) y
		WHERE	x.Customer_Source_Key = 7
		AND	x.Activity_Key = y.Activity_Key
		AND	x.Reltio_Customer_Golden_CS IS NULL;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 36 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Matching Weblead Records'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;

		/*UPDATE	x	-- Web Leads Master on partial Last Name + eMail or Phone
		FROM	CUSTOMERS.Customers.Customer_XRef_Master x,
			(
			SELECT	c.Credit_Customer_Key AS Activity_Key,
				w.Customer_Key,
				w.Reltio_Customer_ID_CS,
				w.Web_Lead_ID AS Source_Customer_ID,
				w.web_System_ID AS Source_Identifier_ID
				,w.Name_Last AS Web_Name_Last, c.Name_Last AS Credit_Name_Last
			FROM	CUSTOMERS.Customers_Reserved_Views.Credit_Customers c	--changed to reserved container as part of CCPA
			JOIN	CUSTOMERS.Customers_Reserved_Views.Web_Leads_Master w	--changed to reserved container as part of CCPA 	
				ON  SUBSTRING(TRIM(w.Name_Last) FROM 1 FOR 4 ) = SUBSTRING(TRIM(c.Name_Last) FROM 1 FOR 4)
				AND ( w.Phone_Number_Original = c.Phone_Number  
				OR w.eMail_Address = c.eMail_Address )
			WHERE	w.Reltio_Customer_ID_CS IS NOT NULL
			AND	Credit_Customer_Key IN (
				SELECT	DISTINCT Activity_Key 
				FROM	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master	--changed to reserved container as part of CCPA
				WHERE	Customer_Source_Key = 7
				AND	Reltio_Customer_Golden_CS IS NULL
				)
			QUALIFY	ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY w.Submit_Date DESC ) = 1
			) y
		SET	Customer_Key_Golden = y.Customer_Key,
			Customer_Key_Last = x.Customer_Key_Golden,
			Reltio_Customer_Golden_CS = y.Reltio_Customer_ID_CS,
			Reltio_Customer_Last_CS = x.Reltio_Customer_Golden_CS,
			DW_Update_TS = CURRENT_TIMESTAMP(0)
		WHERE	x.Customer_Source_Key = 7
		AND	x.Activity_Key = y.Activity_Key
		AND	x.Reltio_Customer_Golden_CS IS NULL;

		SET	Count_Last = COALESCE ( SQLROWCOUNT , 0 ) ;

		INSERT 	INTO CUSTOMERS.Customers_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )		
		VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID ) ;*/--Commented as part of web_leads decommision

		-------- 37 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Matching Reltio Records - Partial First + Last Name'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			-- Reltio Match on Partial First + Last + eMail or phone
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Golden = y.Customer_Key,
					x.Customer_Key_Last = x.Customer_Key_Golden,
					x.Reltio_Customer_Golden_CS = y.Reltio_Customer_ID_CS,
					x.Reltio_Customer_Last_CS = x.Reltio_Customer_Golden_CS,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0),
					x.Last_Merge_TS = CURRENT_TIMESTAMP(0)-- Added as part of Web leads decommission
								FROM
					(
						SELECT
							c.Credit_Customer_Key AS Activity_Key,
							i.Customer_Key,
							r.Reltio_Customer_ID_CS,
							c.Source_Customer_ID,
							''NA'' AS Source_Identifier_ID,
							r.Name_First,
							r.Name_Last,
							e.eMail_Address,
							p.Phone_Number
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master m	--changed to reserved container as part of CCPA
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Credit_Customers c 	ON  c.Credit_Customer_Key = m.Activity_Key	--changed to reserved container as part of CCPA
												AND c.Customer_Source_Key = 7
						LEFT OUTER
						JOIN
							CUSTOMERS.edw_Customer.Reltio_Customer r	ON SUBSTRING(TRIM(r.Name_First), 1, 3) = SUBSTRING(TRIM(c.Name_First), 1, 3)
											AND TRIM(r.Name_Last) = TRIM(c.Name_Last)
						LEFT OUTER
						JOIN
							CUSTOMERS.edw_Customer.Reltio_eMails e	ON  e.Reltio_Customer_ID_CS = r.Reltio_Customer_ID_CS
											AND e.eMail_Address = c.eMail_Address
						LEFT OUTER
						JOIN
							CUSTOMERS.edw_Customer.Reltio_Phones p	ON  p.Reltio_Customer_ID_CS = r.Reltio_Customer_ID_CS
											AND p.Phone_Number = c.Phone_Number
						LEFT OUTER
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master i ON i.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS	--changed to reserved container as part of CCPA
											AND i.Customer_Source_Key = 3
						WHERE	m.Reltio_Customer_Golden_CS IS NULL
						AND	( e.eMail_Address IS NOT NULL OR p.Phone_Number IS NOT NULL )
						AND	m.Customer_Source_Key = 7
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY NULL ) = 1
					) y
		WHERE	x.Customer_Source_Key = 7
		AND	x.Activity_Key = y.Activity_Key
		AND	x.Reltio_Customer_Golden_CS IS NULL;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 38 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Matching Reltio Records - Last Name'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			-- Reltio Match on Last Name + eMail + Phone
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Golden = y.Customer_Key,
					x.Customer_Key_Last = x.Customer_Key_Golden,
					x.Reltio_Customer_Golden_CS = y.Reltio_Customer_ID_CS,
					x.Reltio_Customer_Last_CS = x.Reltio_Customer_Golden_CS,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0),
					x.Last_Merge_TS = CURRENT_TIMESTAMP(0)-- Added as part of Web leads decommission
								FROM
					(
						SELECT
							c.Credit_Customer_Key AS Activity_Key,
							i.Customer_Key,
							r.Reltio_Customer_ID_CS,
							c.Source_Customer_ID,
							''NA'' AS Source_Identifier_ID,
							r.Name_First,
							r.Name_Last,
							e.eMail_Address,
							p.Phone_Number
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master m	--changed to reserved container as part of CCPA
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Credit_Customers c 	ON  c.Credit_Customer_Key = m.Activity_Key	--changed to reserved container as part of CCPA
												AND c.Customer_Source_Key = 7
						JOIN
							CUSTOMERS.edw_Customer.Reltio_Customer r	ON  TRIM(r.Name_Last) = TRIM(c.Name_Last)
						JOIN
							CUSTOMERS.edw_Customer.Reltio_eMails e	ON  e.Reltio_Customer_ID_CS = r.Reltio_Customer_ID_CS
											AND e.eMail_Address = c.eMail_Address
						JOIN
							CUSTOMERS.edw_Customer.Reltio_Phones p	ON  p.Reltio_Customer_ID_CS = r.Reltio_Customer_ID_CS
											AND p.Phone_Number = c.Phone_Number
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master i ON i.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS	--changed to reserved container as part of CCPA
											AND i.Customer_Source_Key = 3
						WHERE	m.Reltio_Customer_Golden_CS IS NULL
						AND	e.eMail_Address IS NOT NULL
						AND 	p.Phone_Number IS NOT NULL
						AND	m.Customer_Source_Key = 7
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY NULL ) = 1
					) y
		WHERE	x.Customer_Source_Key = 7
		AND	x.Activity_Key = y.Activity_Key
		AND	x.Reltio_Customer_Golden_CS IS NULL;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-------- 39 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Matching Reltio Records - Partial First + Partial Last Name'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			-- Reltio Match on Partial First Name + Partial Last Name + eMail + Phone
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Golden = y.Customer_Key,
					x.Customer_Key_Last = x.Customer_Key_Golden,
					x.Reltio_Customer_Golden_CS = y.Reltio_Customer_ID_CS,
					x.Reltio_Customer_Last_CS = x.Reltio_Customer_Golden_CS,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0),
					x.Last_Merge_TS = CURRENT_TIMESTAMP(0)-- Added as part of Web leads decommission
								FROM
					(
						SELECT
							c.Credit_Customer_Key AS Activity_Key,
							i.Customer_Key,
							r.Reltio_Customer_ID_CS,
							c.Source_Customer_ID,
							''NA'' AS Source_Identifier_ID,
							r.Name_First,
							r.Name_Last,
							e.eMail_Address,
							p.Phone_Number
						FROM
							CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master m	--changed to reserved container as part of CCPA
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Credit_Customers c 	ON  c.Credit_Customer_Key = m.Activity_Key	--changed to reserved container as part of CCPA
											 	AND c.Customer_Source_Key = 7
						JOIN
							CUSTOMERS.edw_Customer.Reltio_Customer r	ON SUBSTRING(TRIM(r.Name_First), 1, 3) = SUBSTRING(TRIM(c.Name_First), 1, 3)
											AND SUBSTRING(TRIM(r.Name_Last), 1, 4) = SUBSTRING(TRIM(c.Name_Last), 1, 4)
						JOIN
							CUSTOMERS.edw_Customer.Reltio_eMails e	ON  e.Reltio_Customer_ID_CS = r.Reltio_Customer_ID_CS
											AND e.eMail_Address = c.eMail_Address
						JOIN
							CUSTOMERS.edw_Customer.Reltio_Phones p	ON  p.Reltio_Customer_ID_CS = r.Reltio_Customer_ID_CS
											AND p.Phone_Number = c.Phone_Number
						JOIN
							CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master i ON i.Source_Customer_ID_CS = r.Reltio_Customer_ID_CS	--changed to reserved container as part of CCPA
											AND i.Customer_Source_Key = 3
						WHERE	m.Reltio_Customer_Golden_CS IS NULL
						AND	e.eMail_Address IS NOT NULL
						AND 	p.Phone_Number IS NOT NULL
						AND	m.Customer_Source_Key = 7
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY c.Credit_Customer_Key ORDER BY NULL ) = 1
					) y
		WHERE	x.Customer_Source_Key = 7
		AND	x.Activity_Key = y.Activity_Key
		AND	x.Reltio_Customer_Golden_CS IS NULL;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-----------------------------------------------------------------------------------------------------------------------------
		--	Update Customer and Reltio ID''s
		-------- 40 ---------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Check for missing Customer Keys'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			Record_Count := 0;
			SELECT
								COUNT ( * ) INTO
								:Record_Count
		FROM
								CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
		WHERE	Customer_Key_Golden IS NULL
		OR	Customer_Key_Golden < 0
		OR	Customer_Key_Original < 0 ;
			Count_Last := COALESCE ( :Record_Count , 0 );
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			IF (Count_Last > 0) THEN
								Error_Condition := 2;
								Error_Count := Error_Count +1;
								SQL_Return_Code := SQLCODE;
								--SQL_State_Code := SQLSTATE;
								INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition, Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)
								VALUES (:Activity_Name, :Activity_Desc, :Step_ID, :Error_Condition , :Database_Stage, :SQL_Return_Code, :SQL_State_Code, :SQL_Statement);
								INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
								VALUES (:Activity_Name, :Activity_Desc || '' ERROR'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);
								Out_Error_Count := Error_Count;
								Out_Hard_Stop_Error := 1;
								Out_Records_Loaded := 0;
								CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Stop(
									:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced );

								--raise planned_exception;
			END IF;

		--------- 41 --------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Golden Reltio ID if Merged - Phase 1'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Reltio_Customer_Golden_CS = r.Reltio_Golden_Customer_ID_CS,
					x.Reltio_Customer_Last_CS = r.Reltio_Merged_Customer_ID_CS,
					x.Last_Merge_TS = r.Merge_TS,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					(
						SELECT
							m.Reltio_Golden_Customer_ID_CS,
							m.Reltio_Merged_Customer_ID_CS,
							m.Merge_TS,
							EDW_Batch_Number,
							m.Reltio_Kept_Customer_ID_CS
						FROM
							CUSTOMERS.edw_Customer.Reltio_Merge m
						WHERE	m.DW_Valid_Flag = ''Y''
						AND	DW_Update_TS >= :Start_Time
						AND	m.Reltio_Golden_Customer_ID_CS <> m.Reltio_Merged_Customer_ID_CS
						AND	m.Reltio_Kept_Customer_ID_CS <> m.Reltio_Golden_Customer_ID_CS	-- Sort Order 1
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY m.Reltio_Merged_Customer_ID_CS
									  ORDER BY m.Merge_TS DESC NULLS LAST, m.EDW_Batch_Number DESC NULLS LAST) = 1
					) r
		WHERE	x.Reltio_Customer_Golden_CS = r.Reltio_Merged_Customer_ID_CS
		AND	x.Reltio_Customer_Golden_CS <> r.Reltio_Golden_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		--------- 42 --------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Current Reltio ID if Merged - Phase 2'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Reltio_Customer_Golden_CS = r.Reltio_Golden_Customer_ID_CS,
					x.Reltio_Customer_Last_CS = r.Reltio_Merged_Customer_ID_CS,
					x.Last_Merge_TS = r.Merge_TS,
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					(
						SELECT
							m.Reltio_Golden_Customer_ID_CS,
							m.Reltio_Merged_Customer_ID_CS,
							m.Merge_TS,
							m.EDW_Batch_Number
						FROM
							CUSTOMERS.edw_Customer.Reltio_Merge m
						WHERE	m.DW_Valid_Flag = ''Y''
						AND	m.DW_Update_TS >= :Start_Time
						AND	m.Reltio_Golden_Customer_ID_CS <> m.Reltio_Merged_Customer_ID_CS
						AND	m.Reltio_Kept_Customer_ID_CS = m.Reltio_Golden_Customer_ID_CS	-- Sort Order 2
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY m.Reltio_Merged_Customer_ID_CS
									  ORDER BY m.Merge_TS DESC NULLS LAST) = 1
					) r
		WHERE	x.Reltio_Customer_Golden_CS = r.Reltio_Merged_Customer_ID_CS
		AND	x.Reltio_Customer_Golden_CS <> r.Reltio_Golden_Customer_ID_CS ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		-----------------------------------------------------------------------------------------------------------------------------
		-- Set Golden Customer_Key
		--------- 43 --------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Current Reltio ID'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
								SET
					x.Customer_Key_Golden = m.Customer_Key,
					x.Last_Merge_TS = CURRENT_TIMESTAMP(0),
					x.DW_Update_TS = CURRENT_TIMESTAMP(0)
								FROM
					CUSTOMERS.Customers_Reserved_Views.Customer_ID_Master m	--changed to reserved container as part of CCPA
		WHERE	m.Source_Customer_ID_CS = x.Reltio_Customer_Golden_CS
		AND	m.Customer_Source_Key = 3
		AND	x.Customer_Key_Golden <> m.Customer_Key ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		--------- 44 --------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update Name_Last'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			IF (Run_Now = ''Y'') THEN
								SQL_Statement := Activity_Desc;
								UPDATE CUSTOMERS.Customers.Customer_XRef_Master AS x
					SET
						x.Name_Last = SUBSTR(r.Name_Last,0,50),
						x.DW_Update_TS = CURRENT_TIMESTAMP(0)
					FROM
						(
							SELECT
							Reltio_Customer_ID_CS,
							Name_Last FROM
							CUSTOMERS.edw_Customer.Reltio_Customer
						UNION
							SELECT
							Reltio_Organization_ID_CS AS Reltio_Customer_ID_CS,
							Organization_Name AS Name_Last
						FROM
							CUSTOMERS.edw_Customer.Reltio_Organization
						) r
					WHERE	x.Name_Last <> r.Name_Last
					AND	x.Reltio_Customer_Golden_CS = r.Reltio_Customer_ID_CS ;
								Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			END IF;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

		---- 45 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls record'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key,
			Balanced_Flag,
			Destination_Database, Destination_Table_Name,
			Error_Detail_Description,
			Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_ID , CASE
								WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
								WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
								WHEN :Error_Count > 0
					THEN ''Source and Target Record Counts do not agree'' ELSE ''NA''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);

		----- 46 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target, :Step_ID);
			CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Stop(
			:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Target;

		Final_Output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);

		RETURN :Final_Output;

    
END;
';