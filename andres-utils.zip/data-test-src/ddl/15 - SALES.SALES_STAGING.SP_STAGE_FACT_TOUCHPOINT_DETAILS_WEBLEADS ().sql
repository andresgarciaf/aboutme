CREATE OR REPLACE PROCEDURE "SP_STAGE_FACT_TOUCHPOINT_DETAILS_WEBLEADS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '

DECLARE

/*****************************************************************************************************************************************************************************
	Created: 2018-11-05		By: Veena G
	Purpose: Stage Touchpoint Details

	Sample Run Command:
	call	SALES.Sales_Staging.sp_Stage_Fact_Touchpoint_Details_Webleads (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);	

   	Modified Date	Modified By	  Notes
	-------------	-----------	 ------------------------------------------------------------------------------------------------------------------------------
	2018-11-08        Vignesh S         "Insert Into Stage Table" Query Is Added
	2019-01-18	Harini 	  	"Modified the population of column Waitlist_Flag"
	2019-01-31	Veena 	  	"Modified the population of columns Waitlist_Flag and stock_num"
	2019-02-22	Veena 	  	"modified the customer_source_key population as -1 when source_customer_id is NA"
	2019-04-16	Gayathri   	"Replaced Lead_key population with Touchpoint_Attribute_Key"
	2019-05-06	Gayathri   	"Modified employee key to populate based on owner id and 
				   	splited the employee_key population in to human created and sysytem generated"
	2019-05-14	Gayathri	        "Modified the logic of employee key population for floor records"	
	2019-05-17	Veena		Modified employee_key population logic for machine generated employee_key
	2019-05-29	Veena		Added join on SALES.Sales_Staging.SF_Lead_Type_Cmb. replacing sf_lead.Lead_type with SF_Lead_Type_Cmb.Lead_type_Desc
	2019-07-15	Gayathri	         Corrected Data_entry_method datatype  mismatch issue and removed Quotes for numeric field
	2019-10-15	Aravindakshan	changed TO reserved container AS part OF CCPA
	2020-03-26	Nirmal		Added - Update Employee key when lead converted to opportunity
	2020-03-30	Nirmal		Added Associate Location Key
	2020-05-12	Matt			added additional logic for employee key
	2020-05-18	Matt			add qualify to steps 24 & 25
	2020-07-08	Matt			add final step for employee key capture on parent lead touchpoint
	2020-10-12      Vamsi       Web_leads decommission changes line 640 Step no  8
*****************************************************************************************************************************************************************************/
-- Standard Procedure Variables
	Activity_Name	VARCHAR(100) ;		-- The Name Of The Procedure Running
	Activity_Desc	VARCHAR(500) ;		-- A Description Of The Step In The Procedure Running For The Activity Log
	Batch_Number	INTEGER := 0 ;	-- Holds The Batch Key Assigned In The Landing Process
	Calendar_Key	INTEGER := 0 ;	-- Used To Hold Today''S Calendar By Day Key
	Code_Lines	SMALLINT := 0 ;	-- Count Of Lines Of Code In This Procedure For Control Purposes
	Completed_Flag	CHAR(1)  := ''N'' ;	-- Used For Updating The Activity Log
	Count_Last	INTEGER := 0 ;	-- Used Within The Procedure To Compare Record Count Today To Yesterday
	Count_Source	INTEGER := 0 ;	-- Used Within The Procedure To Reconcile Source To Stage
	Count_Stage	INTEGER := 0 ;	-- Used Within The Procedure To Reconcile Source To Stage
	Count_Target	INTEGER := 0 ;	-- Used Within The Procedure To Reconcile Stage To Target
	Database_Source	VARCHAR(100) ;		-- Used To Specify The Database Where Data Is Obtained
	Database_Stage 	VARCHAR(100) ;		-- Used To Specify The Database In Which This Procedure Runs
	Database_Target	VARCHAR(100) ;		-- Used To Specify The Public Production Database 
	Error_Condition	BYTEINT := 0 ;	-- Identifies The Last Error Condition Encountered
	Error_Count	SMALLINT := 0 ;	-- Written To Out_Error_Count
	Error_Key	SMALLINT := 0 ;	-- Written To The Error_Log
	Hard_Stop_Count	BYTEINT := 0 ;	-- Count Of Hard Stop Errors Encountered By All Called Procs
	Last_Record_Key	INTEGER := 0 ;	-- Used To Identify The Existing Vs New Records
	Process_Id	INTEGER := 0 ;	-- Identifies The Process_Control_Key This Job Process Is Related To
	Record_Count	INTEGER := 0 ;	-- Multi-Purpose
	Sql_Return_Code	INTEGER := 0 ;	-- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log
	Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also
	Sql_State_Code	VARCHAR(5) := '''' ;	-- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log
	Start_Time	TIMESTAMP(6) ;		-- Time When This Procedure Starts	
	Step_Id		SMALLINT := 0 ;	-- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)
	Table_Source	VARCHAR(100) ;		-- For Code Repeatability
	Table_Target	VARCHAR(100) ;		-- For Code Repeatability	
	Table_Stage	VARCHAR(100) ;		-- For Code Repeatability	
	Target_Balanced	CHAR ( 1 ) := ''N'' ;	-- Identifies Whether The Stage, And Target Balance
	Version		DECIMAL(6,3) := 0.00 ;-- The Version Of This Stored Procedure In Use
	Max_Amount	DECIMAL(9,2) := 0.00 ;-- The Max Amount For Fee Type 100,111,112

	Out_Error_Count SMALLINT := 0; 
	Out_Hard_Stop_Error BYTEINT := 0; 
	OUT_Records_Loaded INTEGER := 0; 

	Final_Output Object;

	Planned_Exception   Exception (-20001, ''Exception based on Error_Condition'');

	BEGIN
    Activity_Name	 :=''sp_Stage_Fact_Touchpoint_Details_Webleads'' ;    
    Code_Lines	 := 1541;
    Database_Source	 :=''Sales_Landing'' ;
    Database_Stage	 :=''Sales_Staging'' ; 
    Database_Target	 :=''Sales''  ;
    Process_Id	 := 458 ;        
    Table_Source	 :=''Web_Leads'' ;  
    Table_Stage	 :=''Fact_Touchpoint_Details'' ; 
    Table_Target	 :=''Fact_Touchpoint_Details''  ;    
    Version		 := 1.15   ;   		

	

SELECT	Calendar_By_Day_Key  INTO Calendar_Key 
FROM  	ACCOUNTING.Valid_Values_Views.Calendar_By_Day WHERE Calendar_Date = CURRENT_DATE ;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

BEGIN

----------0---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''****  Starting   ****'' ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )  	
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

	Sql_Statement  := ''Set Metadata_Controls.Run_Time_Results Record To Zero'' ;
CALL	DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start ( 
	:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target, 
	:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;

-----------1-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

	Sql_Statement  := Activity_Desc ;

SELECT	COUNT(*) INTO Record_Count  
FROM	SALES.Sales_Landing.Web_Leads;

 Count_Source  := COALESCE (:Record_Count , 0) ;

SELECT COUNT(*) INTO Record_Count  
FROM	SALES.Sales_Landing.Sf_Lead
WHERE	Lead_Source =''Web'' ;

 Count_Source  := :Count_Source + COALESCE (:Record_Count , 0) ;

SELECT  COUNT(*) INTO Record_Count 
FROM    SALES.Sales_Landing.Sf_Opportunity
WHERE	Lead_Source IN (''Floor'',''Reassignment'',''Phone'');

 Count_Source  := :Count_Source + COALESCE ( :Record_Count , 0 ) ;

IF 	(Count_Source = 0) THEN

		Activity_Desc  := ''No Records To Process'' ;
	INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
	VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source , :Step_Id ) ;

		Activity_Desc  := ''****  Complete  ****'' ;
		Completed_Flag  := ''Y'' ;
	INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
	VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source , :Step_Id ) ;
	
	CALL	DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop (
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
	
		Out_Error_Count  := Error_Count ;
		Out_Hard_Stop_Error  := 0 ;
		Out_Records_Loaded  := :Count_Source ;
		RAISE Planned_exception;
ELSE

	INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
	VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id ) ;
End If ;
-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Delete From Stage Tables '' || Database_Stage || ''.'' || Table_Stage;
	Step_Id  := Step_Id + 1 ;
	Record_Count  := 0 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

 	Sql_Statement  := Activity_Desc ;

DELETE	FROM SALES.Sales_Staging.Fact_Touchpoint_Details;

---------- 3 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Collect Record Counts Participated In Merge With Join And +/- 1 Second Wiggle'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

 Sql_Statement  := Activity_Desc ;

SELECT 	COUNT(*) INTO :Record_Count 
FROM 
(	
	SELECT Lead.Lead_Id
	FROM 
	(
 		SELECT 	Sf_Lead.Lead_Id_Cs,
			Web_Leads.Lead_Id,
			CASE WHEN        		
			(dataops.utilities.TIMESTAMP_DIFFERENCE_UDF
			(TO_TIMESTAMP(LEFT(CAST(Web_Leads.Submit_Date AS VARCHAR), 19)), 
			TO_TIMESTAMP(LEFT(CAST(Sf_Lead.Web_Lead_Submit_Date_Utc AS VARCHAR), 19)), ''MINUTE TO SECOND''))= ''0:00.000000''
         	        	THEN 1
         	        	WHEN 
			(dataops.utilities.TIMESTAMP_DIFFERENCE_UDF(
				TO_TIMESTAMP(LEFT(CAST(Web_Leads.Submit_Date AS VARCHAR), 19)), 
				TO_TIMESTAMP(LEFT(CAST(Sf_Lead.Web_Lead_Submit_Date_Utc AS VARCHAR), 19)), ''MINUTE TO SECOND'')) =''-0:01.000000''

         	        	THEN 2  
			ELSE 3 
			End AS Priority
         	FROM   	SALES.Sales_Landing.Web_Leads Web_Leads
         	LEFT 	JOIN SALES.Sales_Staging.Appt_Activities_Cmb Appt
         		ON	COALESCE(Web_Leads.Appt_Activities,Web_Leads.Lead_Type) = Appt.Appt_Key		
         	INNER 	JOIN SALES.Sales_Landing.Sf_Lead Sf_Lead
			ON	Web_Leads.Email 	= Sf_Lead.Email
         	         AND	Web_Leads.Stock_Num = Sf_Lead.Stock_Number
         	         AND	Web_Leads.Loc_Num 	= Sf_Lead.Store_Location_Number
			AND	Web_Leads.Submit_Date  
				BETWEEN  (Sf_Lead.Web_Lead_Submit_Date_Utc - INTERVAL ''1 SECOND'') 
         	         	AND	(Sf_Lead.Web_Lead_Submit_Date_Utc + INTERVAL ''1 SECOND'' )	
		LEFT 	JOIN SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
			ON 	Sf_Lead.Lead_Type =Sf_Cmb.Lead_Type_Key
		WHERE Sf_Lead.Lead_Source =''Web'' 
		AND Appt.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
		AND sf_lead.sf_update_only_flag = ''N''
         	QUALIFY ROW_NUMBER() OVER (PARTITION BY  Sf_Lead.Lead_Id_Cs
         	         ORDER BY Priority ASC) = 1
	) Lead
 	GROUP BY Lead.Lead_Id
	HAVING COUNT(*) = 1 
) Merge_Src;

	Count_Source  := :Count_Source - COALESCE ( :Record_Count , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
	VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

----------- 4 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  :=''INSERT  Pass1 INTO ''|| Database_stage || ''.'' || Table_Stage || '' FROM '' || Database_Source || ''.'' || Table_Source;

	Step_ID  := Step_ID + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID ) ;

	SQL_Statement  := Activity_Desc ;
INSERT	INTO SALES.Sales_Staging.Fact_Touchpoint_Details(
	Source_Record_Type_Key,Activity_Day_Key, Sales_code_desc, Closed_Lost_Reason_Key, 
	CUstomer_activity_key, Customer_Source_Key, emp_id, Employee_Key,Lead_owner_id_cs, email, origin, 
	origin_page, Lead_Origin_Key, Lead_type, Lead_Interests_Key, 
	Location_Key, Stock_Number_Key, UTC_Local_Offset, Activity_Date, Vehicle_Location_Key, Home_Delivery_Flag, 
	Requested_Appointment_TS_UTC, Salesforce_Opportunity_id, Stock_Number_Hold_Flag, Source_Record_ID,  Source_Customer_ID,Record_Merged, 
	Waitlist_Flag, Touchpoint_Begin_TS_UTC, Source_Insert_TS, Source_Update_TS, EDW_Update_TS, DW_Insert_TS, sf_Update_Only_Flag)
SELECT	DISTINCT 894  								AS Source_Record_Type_Key,
    	-1 										AS Activity_Day_Key,
	COALESCE(sf_Lead.closed_lost_reason,''NA'')	  					AS Sales_code_desc,
	-1			  							AS Closed_Lost_Reason_Key,
	CASE WHEN (POSITION(''carmax'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0  
	OR  POSITION (''Android'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0 
	OR  POSITION (''iOS'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0 )
	THEN 520
         ELSE 521 END 		 							AS CUstomer_activity_key,
	CASE WHEN COALESCE(sf_Lead.converted_account_id_cs,sf_lead.matched_account_id_cs,''NA'')  =''NA''
	THEN -1 
	ELSE 17	END									AS Customer_Source_Key,
	COALESCE(sf_lead.store_employee_id,web_lead.emp_id,''-1'')  				AS emp_id,
	-1  										AS Employee_Key,
	sf_Lead.owner_id_cs 								AS Lead_owner_id_cs,
	COALESCE(sf_lead.email,web_lead.email)	 					AS email,
	web_lead.origin									AS origin,
	COALESCE(web_lead.Origin_page,''NA'')							AS origin_page,
	-1										AS Lead_Origin_Key,
	COALESCE(Sf_Cmb.Lead_Type_Desc,appt_act.appt_desc)					AS Lead_type,
	-1										AS Lead_Interests_Key, 
	COALESCE(sf_lead.store_location_number,web_lead.loc_num,-1)				AS Location_Key,
	COALESCE(sf_lead.stock_number,web_lead.stock_num,-1 )					AS Stock_Number_Key,
	CASE WHEN calc.Day_Light_Saving_Time = ''On'' AND lcn.Uses_DST_Flag = ''Y'' 
	THEN COALESCE(lcn.UTC_Offset_Standard - 1, 0)    
	ELSE COALESCE(lcn.UTC_Offset_Standard , 0) 
	END                                                        				AS UTC_Local_Offset,
	dataops.utilities.UTC_to_Local_ts0(CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,
	sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0)), UTC_Local_offset)	 	AS Activity_Date,
	COALESCE(web_lead.veh_loc_num,-1)							AS Vehicle_Location_Key,
	COALESCE(TRIM(sf_lead.home_delivery),''U'')						AS Home_Delivery_Flag,
	sf_lead.web_requested_app_date_utc							AS Requested_Appointment_TS_UTC,
	COALESCE(sf_Lead.converted_opportunity_id_cs,sf_lead.matched_opportunity_id_cs)		AS Salesforce_Opportunity_id,
	COALESCE(TRIM(web_lead.has_hold),''U'')						AS Stock_Number_Hold_Flag,
	sf_lead.lead_id_cs||''|''||web_lead.Lead_id						AS Source_Record_ID,
	COALESCE(sf_Lead.converted_account_id_cs,sf_lead.matched_account_id_cs,''NA'') 
											AS Source_Customer_ID,
	''Y''										AS Record_Merged,
	SUBSTR(''U'' ,0,1)								AS Waitlist_Flag,
	CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,web_lead.submit_date,
	sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0))				AS Touchpoint_Begin_TS_UTC,
	sf_lead.ss_insert_ts_utc 								AS Source_Insert_TS,
	sf_lead.ss_lst_upd_ts_utc  							AS Source_Update_TS,
	sf_lead.lst_upd_ts  								AS EDW_Update_TS,
	CURRENT_TIMESTAMP(0) 								AS DW_Insert_TS,
	sf_lead.sf_Update_Only_Flag		AS SF_Update_only_Flag
FROM    SALES.Sales_Landing.Web_Leads  web_lead
LEFT JOIN SALES.Sales_Staging.appt_activities_cmb appt_act
ON	COALESCE(web_lead.appt_activities,web_lead.lead_type) = appt_act.appt_key
INNER JOIN SALES.Sales_Landing.Sf_Lead sf_Lead
ON	web_lead.email       = sf_Lead.email
AND	web_lead.stock_num   = sf_Lead.stock_number
AND	web_lead.submit_date =  sf_Lead.web_lead_submit_date_utc
AND	web_lead.loc_num     = sf_Lead.store_location_number
LEFT 	JOIN SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
ON 	Sf_Lead.Lead_Type 	=Sf_Cmb.Lead_Type_Key
LEFT JOIN    ACCOUNTING.Valid_values_Views.locations lcn 
ON	lcn.location_key =  sf_lead.store_location_number         
LEFT JOIN     ACCOUNTING.Valid_Values_Views.Calendar_by_Day calc 
ON	CAST(sf_Lead.web_lead_submit_date_utc AS DATE) = calc.Calendar_Date
WHERE	web_lead.email 		IS NOT NULL
AND	web_lead.stock_num 	IS NOT NULL
AND	web_lead.submit_date   	IS NOT NULL
AND	web_lead.lead_type 	IS NOT NULL
AND	web_lead.loc_num 		IS NOT NULL
AND	sf_lead.email 		IS NOT NULL
AND	sf_lead.stock_number 	IS NOT NULL
AND	sf_lead.web_lead_submit_date_utc IS NOT NULL
AND	sf_lead.lead_type 	IS NOT NULL
AND	sf_lead.store_location_number IS NOT NULL
AND	sf_lead.Lead_Source =''Web'' 
AND	Appt_act.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
AND	sf_lead.SF_Update_Only_Flag = ''N'' ;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_ID ) ;

---------- 5 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  :=''Insert  Pass2 into ''|| Database_stage || ''.'' || Table_Stage || '' from '' || Database_Source || ''.'' || Table_Source;

	Step_ID  := Step_ID + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID ) ;

INSERT INTO SALES.Sales_Staging.Fact_Touchpoint_Details
	(Source_Record_Type_Key,Activity_Day_Key, Sales_code_desc, Closed_Lost_Reason_Key, 
	CUstomer_activity_key, Customer_Source_Key, emp_id, Employee_Key,Lead_owner_id_cs, email, origin, 
	origin_page, Lead_Origin_Key, Lead_type, Lead_Interests_Key, 
	Location_Key, Stock_Number_Key, UTC_Local_Offset, Activity_Date, Vehicle_Location_Key, Home_Delivery_Flag, 
	Requested_Appointment_TS_UTC, Salesforce_Opportunity_id, Stock_Number_Hold_Flag, Source_Record_ID, Record_Merged, Source_Customer_ID, 
	Waitlist_Flag, Touchpoint_Begin_TS_UTC, Source_Insert_TS, Source_Update_TS, EDW_Update_TS, DW_Insert_TS, SF_Update_Only_Flag)
SELECT	DISTINCT 894								AS Source_Record_Type_Key,
    	-1 									AS Activity_Day_Key,
	COALESCE(sf_Lead.closed_lost_reason,''NA'')					AS Sales_code_desc,
	-1									AS Closed_Lost_Reason_Key,
	CASE WHEN (POSITION(''carmax'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0  
	OR  POSITION (''Android'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0 
	OR  POSITION (''iOS'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0 )
	THEN 520
         ELSE 521 END 		 						AS CUstomer_activity_key,  
	CASE WHEN COALESCE(sf_Lead.converted_account_id_cs,sf_lead.matched_account_id_cs,''NA'')  =''NA''
	THEN -1 
	ELSE 17	END								AS Customer_Source_Key,
	COALESCE(sf_lead.store_employee_id,web_lead.emp_id,''-1'') 			AS emp_id,
	-1  									AS Employee_Key,
	sf_Lead.owner_id_cs 							AS Lead_owner_id_cs,
	COALESCE(sf_lead.email,web_lead.email)					AS email,
	web_lead.origin								AS origin,
	COALESCE(web_lead.Origin_page,''NA'')						AS origin_page,
	-1									AS Lead_Origin_Key,
	COALESCE(Sf_Cmb.Lead_Type_Desc,appt_act.appt_desc)				AS Lead_type,
	-1 									AS Lead_Interests_Key, 
	COALESCE(sf_lead.store_location_number,web_lead.loc_num,-1)			AS Location_Key,
	COALESCE(sf_lead.stock_number,web_lead.stock_num,-1 )				AS Stock_Number_Key,
		CASE WHEN calc.Day_Light_Saving_Time = ''On'' AND lcn.Uses_DST_Flag = ''Y'' 
    	THEN COALESCE(lcn.UTC_Offset_Standard - 1, 0)    
	ELSE COALESCE(lcn.UTC_Offset_Standard , 0) 
	END                                                             		AS UTC_Local_Offset,
	dataops.utilities.UTC_to_Local_ts0(CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,
	sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0)), UTC_Local_offset) 	AS Activity_Date,
	COALESCE(web_lead.veh_loc_num,-1)						AS Vehicle_Location_Key,
	''U''                                                         			AS Home_Delivery_Flag,
	sf_lead.web_requested_app_date_utc  					AS Requested_Appointment_TS_UTC,
	COALESCE(sf_Lead.converted_opportunity_id_cs,sf_lead.matched_opportunity_id_cs)	AS Salesforce_Opportunity_id,
	COALESCE(TRIM(web_lead.has_hold),''U'')					AS Stock_Number_Hold_Flag,
	sf_lead.lead_id_cs||''|''||web_lead.Lead_id					AS Source_Record_ID, 
	''Y''									AS Record_Merged,
	COALESCE(sf_Lead.converted_account_id_cs,sf_Lead.matched_account_id_cs,''NA'') 
										AS Source_Customer_ID,
	SUBSTR(''U'' ,0,1)							AS Waitlist_Flag,
	CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,web_lead.submit_date,
	sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0)) 			AS Touchpoint_Begin_TS_UTC,
	sf_lead.ss_insert_ts_utc 							AS Source_Insert_TS,
	sf_lead.ss_lst_upd_ts_utc  						AS Source_Update_TS,
	sf_lead.lst_upd_ts  							AS EDW_Update_TS,
	CURRENT_TIMESTAMP(0)							AS DW_Insert_TS,
	sf_lead.sf_Update_Only_Flag		AS SF_Update_only_Flag
FROM    SALES.Sales_Landing.Web_Leads  web_lead
LEFT JOIN SALES.Sales_Staging.appt_activities_cmb appt_act
ON     COALESCE(web_lead.appt_activities,web_lead.lead_type) = appt_act.appt_key
INNER JOIN SALES.Sales_Landing.Sf_Lead sf_Lead
ON	web_lead.email 	   = sf_Lead.email
AND	web_lead.stock_num   = sf_Lead.stock_number
AND	web_lead.submit_date = (sf_Lead.web_lead_submit_date_utc - INTERVAL ''1 SECOND''  ) 
AND	web_lead.loc_num     = sf_Lead.store_location_number
LEFT 	JOIN SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
ON 	Sf_Lead.Lead_Type 	=Sf_Cmb.Lead_Type_Key
LEFT JOIN ACCOUNTING.Valid_values_Views.locations lcn 
ON 	lcn.location_key =  sf_lead.store_location_number         
LEFT JOIN ACCOUNTING.Valid_Values_Views.Calendar_by_Day calc 
ON 	CAST(sf_Lead.web_lead_submit_date_utc AS DATE) = calc.Calendar_Date
WHERE	web_lead.email   		IS NOT NULL
AND	web_lead.stock_num 	IS NOT NULL
AND	web_lead.submit_date 	IS NOT NULL
AND	web_lead.lead_type 	IS NOT NULL
AND	web_lead.loc_num 		IS NOT NULL
AND	sf_lead.email 		IS NOT NULL
AND	sf_lead.stock_number	IS NOT NULL
AND	sf_lead.web_lead_submit_date_utc IS NOT NULL
AND	sf_lead.lead_type 	IS NOT NULL
AND	sf_lead.store_location_number IS NOT NULL
AND	sf_lead.lead_id_cs::varchar NOT IN (SELECT SUBSTRING(Source_Record_ID ,1 ,  POSITION(''|'' IN Source_Record_ID) - 1) AS  Source_Record_ID 
				FROM SALES.Sales_Staging.Fact_Touchpoint_Details)
AND	sf_lead.Lead_Source =''Web'' 
AND	Appt_act.Appt_Desc	= Sf_Cmb.Lead_Type_Desc 
AND	sf_lead.SF_Update_Only_flag = ''N'' ;


	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_ID ) ;


---------- 6 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  :=''Insert  Pass3 into ''|| Database_stage || ''.'' || Table_Stage || '' from '' || Database_Source || ''.'' || Table_Source;

	Step_ID  := Step_ID + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID ) ;


INSERT INTO SALES.Sales_Staging.Fact_Touchpoint_Details
	(Source_Record_Type_Key,Activity_Day_Key, Sales_code_desc, Closed_Lost_Reason_Key, 
	CUstomer_activity_key, Customer_Source_Key, emp_id, Employee_Key,Lead_owner_id_cs, email, origin, 
	origin_page, Lead_Origin_Key, Lead_type, Lead_Interests_Key, 
	Location_Key, Stock_Number_Key, UTC_Local_Offset, Activity_Date, Vehicle_Location_Key, Home_Delivery_Flag, 
	Requested_Appointment_TS_UTC, Salesforce_Opportunity_id,Stock_Number_Hold_Flag, Source_Record_ID, Record_Merged, Source_Customer_ID, 
	Waitlist_Flag, Touchpoint_Begin_TS_UTC, Source_Insert_TS, Source_Update_TS, EDW_Update_TS, DW_Insert_TS, SF_Update_only_flag)
SELECT	DISTINCT 894								AS Source_Record_Type_Key,
    	-1 									AS Activity_Day_Key,
	COALESCE(sf_Lead.closed_lost_reason,''NA'') 					AS Sales_code_desc,
	-1 									AS Closed_Lost_Reason_Key,
	CASE WHEN (POSITION(''carmax'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0  
	OR  POSITION (''Android'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0 
	OR  POSITION (''iOS'' IN  COALESCE(sf_lead.origin,web_lead.origin)) >0 )
	THEN 520
         ELSE 521 END 		 						AS CUstomer_activity_key,  
	CASE WHEN COALESCE(sf_Lead.converted_account_id_cs,sf_lead.matched_account_id_cs,''NA'')  =''NA''
	THEN -1 
	ELSE 17	END								AS Customer_Source_Key,
	COALESCE(sf_lead.store_employee_id,web_lead.emp_id,''-1'')  			AS emp_id,
	-1  									AS Employee_Key,
	sf_Lead.owner_id_cs 							AS Lead_owner_id_cs,
	COALESCE(sf_lead.email,web_lead.email)					AS email,
	web_lead.origin								AS origin,
	COALESCE(web_lead.Origin_page,''NA'')						AS origin_page,
	-1									AS Lead_Origin_Key,
	COALESCE(Sf_Cmb.Lead_Type_Desc,appt_act.appt_desc)				AS Lead_type,
	-1									AS Lead_Interests_Key, 
	COALESCE(sf_lead.store_location_number,web_lead.loc_num,-1)			AS Location_Key,
	COALESCE(sf_lead.stock_number,web_lead.stock_num,-1 )				AS Stock_Number_Key,
	CASE WHEN calc.Day_Light_Saving_Time = ''On'' AND lcn.Uses_DST_Flag = ''Y'' 
    	THEN COALESCE(lcn.UTC_Offset_Standard - 1, 0)    
	ELSE COALESCE(lcn.UTC_Offset_Standard , 0)
	END                                                        			AS UTC_Local_Offset,
	dataops.utilities.UTC_to_Local_ts0(CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,
	sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0)), UTC_Local_offset) 	AS Activity_Date,	
	COALESCE(web_lead.veh_loc_num,-1)						AS Vehicle_Location_Key,
	''U''                                                         			AS Home_Delivery_Flag,
	sf_lead.web_requested_app_date_utc 						AS Requested_Appointment_TS_UTC,
	COALESCE(sf_Lead.converted_opportunity_id_cs,sf_lead.matched_opportunity_id_cs)	AS Salesforce_Opportunity_id,
	COALESCE(TRIM(web_lead.has_hold),''U'')					AS Stock_Number_Hold_Flag,
	sf_lead.lead_id_cs||''|''||web_lead.Lead_id					AS Source_Record_ID,
	''Y''									AS Record_Merged,
	COALESCE(sf_Lead.converted_account_id_cs,sf_Lead.matched_account_id_cs,''NA'') 
										AS Source_Customer_ID,
	SUBSTR(''U'' ,0,1)							AS Waitlist_Flag,
	CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,web_lead.submit_date,
	sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0))			AS Touchpoint_Begin_TS_UTC,
	sf_lead.ss_insert_ts_utc 							AS Source_Insert_TS,
	sf_lead.ss_lst_upd_ts_utc  						AS Source_Update_TS,
	sf_lead.lst_upd_ts  							AS EDW_Update_TS,
	CURRENT_TIMESTAMP(0)							AS DW_Insert_TS,
	sf_lead.sf_Update_Only_Flag		AS SF_Update_only_Flag
FROM    SALES.Sales_Landing.Web_Leads  web_lead
LEFT JOIN SALES.Sales_Staging.Appt_Activities_Cmb appt_act
ON     COALESCE(web_lead.appt_activities,web_lead.lead_type) = appt_act.appt_key
INNER JOIN SALES.Sales_Landing.Sf_Lead sf_Lead
ON	web_lead.email       = sf_Lead.email
AND	web_lead.stock_num   = sf_Lead.stock_number
AND	web_lead.submit_date = (sf_Lead.web_lead_submit_date_utc + INTERVAL ''1 SECOND''  ) 
AND	web_lead.loc_num     = sf_Lead.store_location_number
LEFT 	JOIN SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
ON 	Sf_Lead.Lead_Type =Sf_Cmb.Lead_Type_Key
LEFT JOIN    ACCOUNTING.Valid_values_Views.locations lcn 
ON	lcn.location_key =  sf_lead.store_location_number         
LEFT JOIN     ACCOUNTING.Valid_Values_Views.Calendar_by_Day calc 
ON	CAST(sf_Lead.web_lead_submit_date_utc AS DATE) = calc.Calendar_Date
WHERE	web_lead.email 		IS NOT NULL
AND	web_lead.stock_num 	IS NOT NULL
AND	web_lead.submit_date 	IS NOT NULL
AND	web_lead.lead_type 	IS NOT NULL
AND	web_lead.loc_num 		IS NOT NULL
AND	sf_lead.email 		IS NOT NULL
AND	sf_lead.stock_number 	IS NOT NULL
AND	sf_lead.web_lead_submit_date_utc IS NOT NULL
AND	sf_lead.lead_type 	IS NOT NULL
AND	sf_lead.store_location_number IS NOT NULL
AND	sf_lead.lead_id_cs::varchar NOT IN (SELECT SUBSTRING(Source_Record_ID ,1 ,  POSITION(''|'' IN Source_Record_ID) - 1) AS  Source_Record_ID 
				FROM SALES.Sales_Staging.Fact_Touchpoint_Details)
AND	sf_lead.Lead_Source =''Web'' 
AND	Appt_act.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
AND	sf_lead.sf_Update_Only_flag = ''N'' ;


	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_ID ) ;

---------- 7 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Delete duplicate lead_id records from Sales_Staging.Fact_Touchpoint_Details '' ;
	Step_ID  := Step_ID + 1 ;
	Record_Count  := 0 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID ) ;

 	SQL_Statement  := Activity_Desc ;

DELETE  FROM SALES.Sales_Staging.Fact_Touchpoint_Details
	WHERE TRIM(SUBSTRING(Source_Record_ID , POSITION(''|'' IN Source_Record_ID) + 1)) IN 
	(SELECT DEL_DUP.Source_Record_ID 
	   FROM  ( 
		    SELECT DUP_LEAD.Source_Record_ID,COUNT(1)  AS rcnt 
	        		FROM (SELECT TRIM(SUBSTRING(Source_Record_ID , POSITION(''|'' IN Source_Record_ID) + 1)) AS Source_Record_ID  
	                  FROM SALES.Sales_Staging.Fact_Touchpoint_Details
			      ) DUP_LEAD
	        	    GROUP BY DUP_LEAD.Source_Record_ID 	
		    HAVING COUNT(1)>1
		 )AS DEL_DUP
         );
	

---------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := SUBSTR(''Insert  left over Records Pass4 into ''|| Database_stage || ''.'' || Table_Stage || '' from '' || Database_Source || ''.'' || Table_Source, 1, 100);
	Step_ID  := Step_ID + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID ) ;

	SQL_Statement  := Activity_Desc ;


INSERT INTO SALES.Sales_Staging.Fact_Touchpoint_Details
	(Source_Record_Type_Key,Activity_Day_Key, Sales_code_desc, Closed_Lost_Reason_Key, 
	CUstomer_activity_key, Customer_Source_Key, emp_id, Employee_Key,Lead_owner_id_cs, email, origin, 
	origin_page, Lead_Origin_Key, Lead_type, Lead_Interests_Key, 
	Location_Key, Stock_Number_Key, Activity_Date, UTC_Local_Offset, Vehicle_Location_Key, Home_Delivery_Flag, 
	Requested_Appointment_TS_UTC, Salesforce_Opportunity_id,Stock_Number_Hold_Flag, Source_Record_ID, Record_Merged, Source_Customer_ID, 
	Waitlist_Flag, Touchpoint_Begin_TS_UTC, Source_Insert_TS, Source_Update_TS, EDW_Update_TS, DW_Insert_TS, sf_Update_Only_Flag)
SELECT  Lead.Source_Record_Type_Key,
    	-1 					AS Activity_Day_Key,
	Lead.Sales_code_desc,
	-1					AS Closed_Lost_Reason_Key,
	CASE WHEN (POSITION(''carmax'' IN  lead.origin) >0  
	OR  POSITION (''Android'' IN  lead.origin) >0 
	OR  POSITION (''iOS'' IN  lead.origin) >0 )
	THEN 520
         ELSE 521 END 		 		AS  CUstomer_activity_key,  
	CASE WHEN COALESCE(Lead.Source_Customer_ID,''NA'') =''NA''
	THEN -1
	WHEN (Lead.Source_Record_Type_Key = 894) 
	THEN 17 
         WHEN (Lead.Source_Record_Type_Key = 897) 
	THEN 14 END                                 AS Customer_Source_Key,
	COALESCE(Lead.emp_id,-1)			AS emp_id,
	Lead.Employee_Key				AS Employee_Key,
	Lead.Lead_owner_id_cs			AS Lead_owner_id_cs,
	COALESCE(Lead.Email,''NA'')			AS email,	
	substr(Lead.origin,0,20)				AS origin,
	Lead.Origin_page				AS Origin_page,	
	-1					AS Lead_Origin_Key,
	Lead_Type				AS Lead_Type,
	-1					AS Lead_Interests_Key, 
	COALESCE(Lead.Location_Key,-1)		AS Location_Key,
	COALESCE(Lead.Stock_Number_Key,-1)		AS Stock_Number_Key,
	CAST(Lead.Activity_Date AS DATE)		AS Activity_Date,
	Lead.UTC_Local_Offset AS UTC_Local_Offset,
	COALESCE(Lead.Vehicle_Location_Key,-1)	AS Vehicle_Location_Key,
	''U''                                          AS Home_Delivery_Flag,
	Lead.Requested_Appointment_TS_UTC		AS Requested_Appointment_TS_UTC,
	Lead.Salesforce_Opportunity_id		AS Salesforce_Opportunity_id,
	COALESCE(Lead.Stock_Number_Hold_Flag,''U'')	AS Stock_Number_Hold_Flag,
	Lead.Source_Record_ID			AS Source_Record_ID,
	Lead.Record_Merged			AS Record_Merged,
	COALESCE(Lead.Source_Customer_ID,''NA'')	AS Source_Customer_ID,
	COALESCE(TRIM(Lead.Waitlist_Flag),''U'')	AS Waitlist_Flag,
	Lead.Touchpoint_Begin_TS_UTC		AS Touchpoint_Begin_TS_UTC,
	Lead.Source_Insert_TS			AS Source_Insert_TS,
	Lead.Source_Update_TS			AS Source_Update_TS,
	Lead.EDW_Update_TS			AS EDW_Update_TS,
	CURRENT_TIMESTAMP(0)			AS DW_Insert_TS,
	Lead.SF_Update_Only_Flag 	AS sf_Update_Only_Flag	
FROM	(SELECT CAST(sf_Lead.store_location_number AS INT) 					AS Location_Key,
		CAST(sf_Lead.stock_number AS INT) 						AS Stock_Number_Key,
		CASE WHEN calc.Day_Light_Saving_Time = ''On'' AND lcn.Uses_DST_Flag = ''Y'' 
        		THEN COALESCE(lcn.UTC_Offset_Standard - 1, 0)        
		ELSE COALESCE(lcn.UTC_Offset_Standard , 0) 
		END                                  					AS UTC_Local_Offset,
		dataops.utilities.UTC_to_Local_ts0(CAST(SUBSTR(COALESCE(sf_lead.web_lead_submit_date_utc,
		sf_lead.ss_insert_ts_utc),0,19) AS TIMESTAMP(0)), UTC_Local_offset) 	AS Activity_Date,	    
		sf_Lead.home_delivery 							AS Home_Delivery_Flag,
		CAST(SUBSTR(sf_Lead.web_requested_app_date_utc,0,19) AS TIMESTAMP(0)) 	AS Requested_Appointment_TS_UTC,
		COALESCE(sf_Lead.converted_opportunity_id_cs,sf_lead.matched_opportunity_id_cs)	AS Salesforce_Opportunity_id,
		sf_Lead.lead_id_cs||''|''							AS Source_Record_ID,
		''N''									AS Record_Merged,
		SUBSTR(''U'' ,0,1)							AS Waitlist_Flag,
		NULL 									AS Vehicle_Location_Key,
		SUBSTR(NULL,0,10) 						AS Stock_Number_Hold_Flag,
		894 									AS Source_Record_Type_Key,
		COALESCE(sf_Lead.closed_lost_reason,''NA'') 					AS Sales_code_desc,
		CAST(sf_Lead.store_employee_id AS INTEGER) 					AS emp_id,
		-1  									AS Employee_Key,
		sf_Lead.owner_id_cs 							AS Lead_owner_id_cs,
		SUBSTR(COALESCE(sf_Lead.converted_account_id_cs,
		sf_Lead.matched_account_id_cs) ,0,50) 				AS Source_Customer_ID,
		SUBSTR(sf_Lead.email,0,80)						AS email,
		SUBSTR(NULL,0,100)						AS lead_name,
		COALESCE(sf_Lead.origin,substr(''NA'',0,20))       AS Origin,
		substr(''NA'' ,0,20)							AS Origin_page , 
		COALESCE(Sf_Cmb.Lead_Type_Desc,''NA'')					AS Lead_Type, 
		COALESCE(CAST(SUBSTR(sf_lead.web_lead_submit_date_utc,0,19) AS TIMESTAMP(0)),
		CAST(SUBSTR(sf_lead.ss_insert_ts_utc,0,19) AS TIMESTAMP(0)))            AS Touchpoint_Begin_TS_UTC, 
		CAST(SUBSTR(sf_Lead.ss_insert_ts_utc,0,19) AS TIMESTAMP(0))		AS Source_Insert_TS,
		CAST(SUBSTR(sf_Lead.ss_lst_upd_ts_utc,0,19) AS TIMESTAMP(0))		AS Source_Update_TS,
		CAST(SUBSTR(sf_Lead.lst_upd_ts,0,19) AS TIMESTAMP(0))			AS EDW_Update_TS,
		sf_lead.SF_Update_Only_Flag AS sf_Update_Only_Flag
	FROM  SALES.Sales_Landing.Sf_Lead sf_Lead
	LEFT 	JOIN SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
	ON 	Sf_Lead.Lead_Type =Sf_Cmb.Lead_Type_Key
	LEFT  JOIN ACCOUNTING.Valid_values_Views.locations lcn 
    	ON    lcn.location_key =  sf_lead.store_location_number         
    	LEFT  JOIN ACCOUNTING.Valid_Values_Views.Calendar_by_Day calc 
    	ON    CAST(sf_Lead.web_lead_submit_date_utc AS DATE) = calc.Calendar_Date
	WHERE Lead_ID_CS::varchar NOT IN (SELECT SUBSTRING(Source_Record_ID ,1 ,  POSITION(''|'' IN Source_Record_ID) - 1) AS  Source_Record_ID 
    				FROM SALES.Sales_Staging.Fact_Touchpoint_Details)
	AND	sf_lead.Lead_Source =''Web'' 
	UNION ALL
	SELECT CAST(web_Lead.loc_num AS INT) 							AS Location_Key,
		CAST(web_Lead.stock_num AS INT)							AS Stock_Number_Key,
		CASE WHEN calc.Day_Light_Saving_Time = ''On'' AND lcn.Uses_DST_Flag = ''Y'' 
        		THEN COALESCE(lcn.UTC_Offset_Standard - 1, 0)        
		ELSE COALESCE(lcn.UTC_Offset_Standard , 0) 
		END                                  						AS UTC_Local_Offset,
		dataops.utilities.UTC_to_Local_ts0(CAST(SUBSTR(COALESCE(web_Lead.submit_date,
		web_lead.ss_insert_ts),0,19)AS TIMESTAMP(0)), UTC_Local_offset) 		AS Activity_Date,		
		NULL										AS Home_Delivery_Flag, 
		CAST(NULL AS TIMESTAMP(0))							AS Requested_Appointment_TS_UTC,
		''NA''										AS Salesforce_Opportunity_id,
		SUBSTR(web_Lead.lead_id||''|'' ,0,18)						AS Source_Record_ID,
		''N''										AS Record_Merged,
		SUBSTR(''U'' ,0,1)								AS Waitlist_Flag,
		web_Lead.veh_loc_num								AS Vehicle_Location_Key,
		SUBSTR(TRIM(web_Lead.has_hold),0,10)					AS Stock_Number_Hold_Flag,
		897										AS Source_Record_Type_Key,
		substr(''NA'' ,0,225)							AS Sales_code_desc,
		web_Lead.emp_id									AS emp_id,
		-1										AS Employee_Key,
		''NA'' 										AS Lead_owner_id_cs,
		SUBSTR(web_Lead.lead_id,0,40)						AS Source_Customer_ID,
		web_Lead.email									AS email,
		web_Lead.lead_name								AS lead_name,
		web_Lead.Origin									AS origin,
		COALESCE(web_Lead.Origin_page,''NA'')							AS origin_page,
		COALESCE(c.appt_desc,''NA'')								AS Lead_Type,
		COALESCE(CAST(SUBSTR(web_Lead.submit_date,0,19) AS TIMESTAMP(0)),
		CAST(SUBSTR(web_Lead.ss_insert_ts,0,19) AS TIMESTAMP(0))) 			AS Touchpoint_Begin_TS_UTC,
		CAST(SUBSTR(web_Lead.ss_insert_ts,0,19) AS TIMESTAMP(0))			AS Source_Insert_TS,
		CAST(SUBSTR(web_Lead.ss_lst_upd_ts,0,19) AS TIMESTAMP(0))			AS Source_Update_TS,
		CAST(SUBSTR(web_Lead.lst_upd_ts,0,19) AS TIMESTAMP(0))			AS EDW_Update_TS,
		''N'' AS Sf_Update_Only_Flag
	FROM	SALES.Sales_Landing.Web_Leads web_Lead
	LEFT    JOIN SALES.Sales_Staging.appt_activities_cmb c
	ON	COALESCE(web_Lead.appt_activities,web_Lead.lead_type) = c.appt_key
	LEFT    JOIN ACCOUNTING.Valid_values_Views.locations lcn
	ON       lcn.location_key=web_Lead.Loc_Num
	LEFT    JOIN ACCOUNTING.Valid_Values_Views.Calendar_by_Day calc 
   	ON       CAST(web_Lead.submit_date AS DATE) = calc.Calendar_Date
	WHERE	TRIM(Lead_ID) NOT IN (SELECT TRIM(SUBSTRING(Source_Record_ID , POSITION(''|'' IN Source_Record_ID) + 1)) AS Source_Record_ID
				     FROM SALES.Sales_Staging.Fact_Touchpoint_Details)
	) Lead;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_ID ) ;


---------- 9 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Insert Walkins into  ''|| Database_stage || ''.'' || Table_Stage || '' from Sales_Landing.Sf_Opportunity'' ;
	Step_ID  := Step_ID + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID ) ;

	SQL_Statement  := Activity_Desc ;

INSERT INTO SALES.Sales_Staging.Fact_Touchpoint_Details
	(Source_Record_Type_Key,Activity_Day_Key, Sales_code_desc, Closed_Lost_Reason_Key, 
	CUstomer_activity_key, Customer_Source_Key, emp_id, Employee_Key,opp_created_by_id_cs, email, origin, 
	origin_page, Lead_Origin_Key, Lead_type, Lead_Interests_Key, 
	Location_Key, Stock_Number_Key, UTC_Local_Offset, Activity_Date, Vehicle_Location_Key, Home_Delivery_Flag, 
	Requested_Appointment_TS_UTC, Salesforce_Opportunity_id, Stock_Number_Hold_Flag, Source_Record_ID, Record_Merged, Source_Customer_ID, 
	Waitlist_Flag, Touchpoint_Begin_TS_UTC,Source_Insert_TS, Source_Update_TS, EDW_Update_TS, DW_Insert_TS, sf_update_only_flag)
SELECT  900 								AS Source_Record_Type_Key,
    	-1 								AS Activity_Day_Key,
         COALESCE(sf_opp.closed_reason,''NA'') 				AS Sales_code_desc,
	-1								AS Closed_Lost_Reason_Key,
	CASE WHEN sf_opp.Lead_source IN (''Floor'',''Reassignment'') THEN 510 
	WHEN sf_opp.Lead_source IN (''Phone'') THEN 511 END			AS Customer_activity_key,
	CASE WHEN COALESCE(SUBSTR(sf_opp.account_id_cs,0,50),''NA'')=''NA''
	THEN -1
	ELSE 17 END							AS Customer_Source_Key,
	-1				 				AS emp_id,
	-1  								AS Employee_Key,
	CASE WHEN Data_entry_method=''Enter Customer''
	      THEN sf_opp.Created_by_id_cs::varchar
	      WHEN ( sf_opp.Data_entry_method IS NULL)   -- sf_opp.Data_entry_method=''0''  OR
	      THEN CASE WHEN (sf_opp.Store_employee_id <> 0 OR sf_opp.Store_employee_id IS NOT NULL)
	    	        THEN  sf_opp.Store_employee_id::varchar
	                 ELSE  sf_lead.Owner_id_Cs::varchar
		   END
	END 								AS opp_created_by_id_cs,
	''NA''								AS email,
	substr(''NA'',0,20)						AS Origin,
	substr(''NA'',0,20)						AS Origin_page ,
	-1								AS Lead_Origin_Key,
	COALESCE(sf_opp.Lead_Type,''NA'')					AS Lead_Type,
	-1								AS Lead_Interests_Key, 
     	COALESCE(CAST(sf_opp.store_location_number AS INT),-1)		AS Location_Key,
	COALESCE(CAST(sf_opp.stock_number AS INT),-1) 			AS Stock_Number_Key,
	CASE WHEN calc.Day_Light_Saving_Time = ''On'' AND lcn.Uses_DST_Flag = ''Y'' 
    	THEN COALESCE(lcn.UTC_Offset_Standard - 1, 0)
    	ELSE COALESCE(lcn.UTC_Offset_Standard , 0) 
	END                        					AS UTC_Local_Offset,
	dataops.utilities.UTC_to_Local_ts0(CAST(SUBSTR(COALESCE(sf_opp.lead_web_submit_date_utc,
	sf_opp.ss_insert_ts_utc),0,19) AS TIMESTAMP(0)),
	UTC_Local_offset) 						AS Activity_Date,	
	-1								AS Vehicle_Location_Key,
	''U''				 				AS Home_Delivery_Flag,
	sf_opp.lead_requested_app_date_utc  				AS Requested_Appointment_TS_UTC,
	sf_opp.opportunity_id_cs 						AS Salesforce_Opportunity_id,
	''U''  								AS Stock_Number_Hold_Flag,
	sf_opp.opportunity_id_cs||''|'' 					AS Source_Record_ID,
	''N''								AS Record_Merged,
	COALESCE(SUBSTR(sf_opp.account_id_cs,0,50),''NA'')	 	AS Source_Customer_ID, 
	''U''				  				AS Waitlist_Flag,
	COALESCE(CAST(SUBSTR(sf_opp.lead_web_submit_date_utc 
	,0,19) AS TIMESTAMP(0)),sf_opp.ss_insert_ts_utc) 		AS Touchpoint_Begin_TS_UTC,
	CAST(SUBSTR(sf_opp.ss_insert_ts_utc,0,19) AS TIMESTAMP(0))	AS Source_Insert_TS,
	CAST(SUBSTR(sf_opp.ss_lst_upd_ts_utc,0,19) AS TIMESTAMP(0))	AS Source_Update_TS,
	CAST(SUBSTR(sf_opp.lst_upd_ts,0,19) AS TIMESTAMP(0))	  	AS EDW_Update_TS,
	CURRENT_TIMESTAMP(0)						AS DW_Insert_TS,
	''N''		 	AS sf_update_only_flag
FROM	SALES.Sales_Landing.Sf_Opportunity sf_opp
LEFT    JOIN ACCOUNTING.Valid_values_Views.locations lcn 
ON	lcn.location_key =  sf_opp.store_location_number         
LEFT    JOIN ACCOUNTING.Valid_Values_Views.Calendar_by_Day calc 
ON	CAST(sf_opp.lead_web_submit_date_utc AS DATE) = calc.Calendar_Date
LEFT    JOIN (SELECT  Converted_opportunity_id_cs,matched_opportunity_id_cs,Lead_Source,Owner_id_Cs
		FROM SALES.Sales_Landing.Sf_Lead sf_lead
	       	QUALIFY ROW_NUMBER() OVER (PARTITION BY COALESCE(sf_lead.Converted_opportunity_id_cs,sf_lead.matched_opportunity_id_cs)
	       	ORDER BY COALESCE(web_lead_submit_date_utc,ss_insert_ts_utc) ASC) = 1)sf_lead
ON       COALESCE(sf_lead.Converted_opportunity_id_cs,sf_lead.matched_opportunity_id_cs) = sf_opp.Opportunity_id_cs
AND 	sf_lead.Lead_Source IN (''phone'',''web'' )
WHERE	sf_opp.Lead_Source IN (''Floor'',''Reassignment'',''Phone'');

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID ) ;



---------- 10 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;

	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Sql_Statement  := Activity_Desc;
	Record_Count  := 0 ;

--LOCK ROW FOR ACCESS
SELECT 	COUNT ( * ) INTO Record_Count 
FROM 	SALES.Sales_Staging.Fact_Touchpoint_Details ;

	Count_Stage  := COALESCE ( :Record_Count , 0 ) ;

IF ( Count_Source <> Count_Stage ) THEN

               Sql_Statement  := ''Source ''||SUBSTR(Count_Source,0,10)||'' Stage ''||SUBSTR(Count_Stage,0,10);
		Error_Condition  := 4 ;
		Error_Count  := Error_Count +1 ;
		Sql_Return_Code  := SQLCODE ;
		--Sql_State_Code  := SQLSTATE ;
	
	INSERT 	INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition , Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
	VALUES 	(:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement ) ;
	
	INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Condition , Error_Count, Record_Count, Step_Id )	
	VALUES 	( :Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id ) ;
	
		Sql_Statement  := Activity_Desc ;
	INSERT	INTO DATAOPS.Metadata_Controls.Table_Controls (
		Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
		Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
		Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
		Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
		Source_Aggregate_Amount, Source_Record_Count )
	VALUES	( :Batch_Number, :Calendar_Key , :Process_Id , 
		CASE WHEN :Error_Count = 0 THEN 4 ELSE 5 End ,
		CASE WHEN :Error_Count = 0 THEN ''Y'' ELSE ''N'' End ,
		:Database_Target , :Table_Target ,
		CASE WHEN :Error_Count > 0 THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA'' End ,
		''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source ) ;
	
		Out_Error_Count  := Error_Count ;
		Out_Hard_Stop_Error  := 1 ;
		Out_Records_Loaded  := 0 ;

	CALL	DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop (
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
	
	RAISE Planned_exception;

ELSE

	INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
	VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

End If ;

---------- 11 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Stock_Number_Key '';

    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id );

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details
SET	Stock_Number_Key  = -1
WHERE	Stock_Number_Key = 0 ;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;



---------- 12 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Closed_Lost_Reason_Key '' ;
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Views.Lead_Lost_Reason_Codes Sales_Code
set	Closed_Lost_Reason_Key =Sales_Code.Sales_Code
WHERE	Sales_Code.Sales_Code_Desc=Fct.Sales_Code_Desc;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 13 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Lead_Origin_Key '' ;
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Views.Lead_Origin_Codes Origin
set	Lead_Origin_Key = Origin.Lead_Origin_Key
WHERE	Origin.Lead_Origin=Fct.Origin
AND	Origin.Lead_Origin_Page =Fct.Origin_Page;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 14 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := substr(''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Touchpoint Attribute Key based on lead_id and record_merged '', 1, 100) ;
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Reserved_Views.Leads Leads	--changed to reserved container as part of CCPA
set	Touchpoint_Attribute_Key = Leads.Lead_Key
WHERE	TRIM(SUBSTRING(Fct.Source_Record_Id ,1 ,  POSITION(''|'' IN Fct.Source_Record_Id) - 1)) = Leads.Salesforce_Record_Id          
AND	Fct.Record_Merged = Leads.Record_Merged
AND	Fct.Source_Record_Type_Key <> 900;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 15 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Touchpoint Attribute Key and source_record_id'' ;
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Reserved_Views.Leads Leads	--changed to reserved container as part of CCPA 
SET	Touchpoint_Attribute_Key = Leads.Lead_Key,
	Source_Record_Id = Leads.Salesforce_Record_Id||''|''||Leads.Web_Lead_Id
WHERE	TRIM(SUBSTRING(Fct.Source_Record_Id ,1 ,  POSITION(''|'' IN Fct.Source_Record_Id) - 1)) <> Leads.Salesforce_Record_Id          
AND	Fct.Record_Merged = Leads.Record_Merged
AND	TRIM(SUBSTRING(Fct.Source_Record_Id , POSITION(''|'' IN Fct.Source_Record_Id) + 1)) = SUBSTR(Leads.Web_Lead_Id,0,20)
AND	Leads.Salesforce_Record_Id <> ''NA''
AND	Leads.Web_Lead_Id <> -1
AND 	FCT.Touchpoint_Attribute_Key = -1
AND 	FCT.Record_Merged = ''Y''
AND	Fct.Source_Record_Type_Key <> 900;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;



---------- 16 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Touchpoint Attribute Key for web_lead records'' ;
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Reserved_Views.Leads Leads	--changed to reserved container as part of CCPA
SET	Touchpoint_Attribute_Key = Leads.Lead_Key
WHERE	TRIM(SUBSTRING(Fct.Source_Record_Id ,1 ,  POSITION(''|'' IN Fct.Source_Record_Id) - 1)) = SUBSTR(Leads.Web_Lead_Id,0,20)
AND	Fct.Record_Merged = Leads.Record_Merged
AND 	Fct.Touchpoint_Attribute_Key= -1
AND	Fct.Source_Record_Type_Key <> 900;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 17 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Calendar Key '';
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	ACCOUNTING.Valid_Values_Views.Calendar_By_Day Dy
SET	Activity_Day_Key  = Dy.Calendar_By_Day_Key
WHERE	Dy.Calendar_Date=Fct.Activity_Date;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 18 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee created by key and associate location key when human for sf_lead records'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details a
FROM	SALES.Sales_Landing.sf_user u,
	ASSOCIATES.hr_non_cci_views.associate_names n
SET	Employee_Key  = n.Employee_Key, associate_location_Key = COALESCE(u.storenum,-1)
WHERE	a.Lead_owner_id_cs = u.user_id_cs
AND	n.employee_ID = u.employee_number	
AND	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'') 	
AND 	a.Lead_owner_id_cs<>''NA''
AND 	a.Source_Record_Type_Key=894;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;



---------- 19 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee created by key when human for floor records based on created_by_id_cs'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details a
FROM	SALES.Sales_Landing.sf_user u,
	ASSOCIATES.hr_non_cci_views.associate_names n
SET	Employee_Key  = n.Employee_Key	
WHERE	a.opp_created_by_id_cs = u.user_id_cs	
AND	n.employee_ID = u.employee_number	
AND	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'')
AND	a.opp_created_by_id_cs IS NOT NULL
AND 	a.Source_Record_Type_Key=900;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;

---------- 20 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee created by key when human for floor records based on employee_number'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details a
FROM	ASSOCIATES.hr_non_cci_views.associate_names n
SET	Employee_Key  = n.Employee_Key	
WHERE	a.opp_created_by_id_cs = n.employee_ID 
AND	a.opp_created_by_id_cs::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'')
AND	a.opp_created_by_id_cs IS NOT NULL
AND 	a.Source_Record_Type_Key=900
AND 	a.Employee_Key = -1;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;


----------- 21 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee key and associate location key when leads converted to opportunity'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE 	 SALES.Sales_Staging.fact_touchpoint_details a
FROM     SALES.EDW_Salesforce_Reserved_Views.sf_opportunity o,
         SALES.Sales_Landing.sf_user u,
         ASSOCIATES.hr_non_cci_views.associate_names n
 set     Employee_Key  = n.Employee_Key, associate_location_Key = COALESCE(u.storenum,-1)
WHERE    n.employee_ID = u.employee_number         
AND      a.Salesforce_Opportunity_id::varchar = o.opportunity_id_cs
AND      o.owner_id_cs = u.user_id_cs
AND      u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'')
AND      o.owner_id_cs<>''NA''
AND      a.Source_Record_Type_Key=894
AND 	a.employee_key=-1;   
           
	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;



----------- 22 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee key and associate location key from Nice when no other emp id identified'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.sales_staging.fact_touchpoint_Details s
FROM	SALES.Sales_Views.Leads l,
		ASSOCIATES.hr_non_cci_views.associate_names n,
		SALES.sales_landing.sf_user u
SET		Employee_key = n.Employee_Key, 
		associate_location_key = COALESCE(u.storenum, -1)	
WHERE	s.Touchpoint_Attribute_key = l.Lead_key
AND	l.Nice_Agent_Employee_ID = n.Employee_Key
AND	n.employee_Id = u.employee_number
AND	s.source_record_type_key IN (894,897) 
AND      	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'')
AND	u.is_active = 1
AND	s.Employee_Key = -1	;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;

----------- 23 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee key and associate location key from parent lead when no other emp id identified'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.sales_staging.Fact_Touchpoint_Details s
FROM	( 
		SELECT 	l.lead_id_cs, n.Employee_key, u.storenum
		FROM	SALES.edw_salesforce.sf_lead l
		JOIN	SALES.edw_salesforce.sf_lead pl
		ON		l.parent_lead::varchar = pl.lead_id_cs::varchar
		JOIN	SALES.sales_landing.sf_user u
		ON		pl.owner_id_cs = u.user_id_cs
		JOIN	ASSOCIATES.hr_non_cci_views.associate_names n
		ON		n.employee_id = u.employee_number
		) x
SET		Employee_Key  = x.Employee_Key,
		Associate_Location_Key = COALESCE(x.storenum, -1)
WHERE	TRIM(SUBSTRING(s.Source_Record_Id::varchar ,1 ,  POSITION(''|'' IN s.Source_Record_Id::varchar) - 1)) = x.lead_id_cs
AND	s.employee_key = -1
AND 	s.source_record_type_key IN (894, 897) ; 

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;


----------- 24 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee key and associate location key from related task record based on opp ID'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details s
FROM	(
		SELECT	f.Salesforce_opportunity_id, n.Employee_Key , u.storenum, f.source_record_id
		FROM	SALES.sales_staging.Fact_Touchpoint_Details f
		JOIN	SALES.Edw_Salesforce.sf_task t
		ON		f.salesforce_opportunity_id::varchar = t.what_id_cs::varchar
		JOIN	SALES.sales_landing.sf_user u
		ON		t.owner_id_cs = u.user_id_cs
		JOIN	ASSOCIATES.hr_non_cci_views.associate_names n
		ON		n.employee_id = u.employee_number
		WHERE  	t.ss_insert_ts_utc BETWEEN 	f.Source_Insert_TS - INTERVAL ''5 SECOND''  
								AND 	f.Source_Insert_TS + INTERVAL ''5 SECOND'' 
		AND	f.salesforce_opportunity_id <> ''NA''						
		QUALIFY ROW_NUMBER() OVER (PARTITION BY f.Salesforce_opportunity_id, f.source_record_id
									ORDER BY t.ss_insert_ts_utc ASC) = 1				
		) x
SET		Employee_key  = x.Employee_Key,
		Associate_Location_Key = COALESCE(x.storenum, -1)
WHERE	s.Source_Record_id = x.Source_Record_Id
AND	s.salesforce_opportunity_id = x.Salesforce_Opportunity_Id
AND	s.employee_key = -1 
AND 	s.source_record_type_key IN (894, 897) ; 

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;

----------- 25 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee key and associate location key from related task record based on account ID'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details s
FROM	(
		SELECT	f.Source_Customer_ID, n.Employee_Key , u.storenum, f.source_record_id
		FROM	SALES.sales_staging.Fact_Touchpoint_Details f
		JOIN	SALES.Edw_Salesforce.sf_task t
		ON		f.Source_Customer_ID::varchar = t.account_id_cs::varchar
		JOIN	SALES.sales_landing.sf_user u
		ON		t.owner_id_cs = u.user_id_cs
		JOIN	ASSOCIATES.hr_non_cci_views.associate_names n
		ON		n.employee_id = u.employee_number
		WHERE  	t.ss_insert_ts_utc BETWEEN 	f.Source_Insert_TS - INTERVAL ''5 SECOND''  
								AND 	f.Source_Insert_TS + INTERVAL ''5 SECOND'' 
		AND	f.source_customer_id <> ''NA''						
		QUALIFY ROW_NUMBER() OVER (PARTITION BY f.Source_Customer_id, f.source_record_id
									ORDER BY t.ss_insert_ts_utc ASC) = 1						
		) x
SET		Employee_key  = x.Employee_Key,
		Associate_Location_Key = COALESCE(x.storenum, -1)
WHERE	s.Source_Record_ID = x.Source_Record_ID
AND	s.Source_Customer_ID = x.Source_Customer_ID
AND	s.employee_key = -1 
AND 	s.source_record_type_key IN (894, 897) ; 

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;


----------- 25 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee key and associate location key from parent touchpoint if still missing'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_staging.Fact_Touchpoint_Details s
FROM	(
		SELECT 	f.Source_Record_ID, f2.Employee_key AS Parent_Employee_Key, f2.Associate_Location_Key AS Parent_Location_Key, 
				TRIM(SUBSTRING(f.source_record_id ,1 ,  POSITION(''|'' IN f.source_record_id) - 1)) AS child_lead_id,
				TRIM(SUBSTRING(f2.source_record_id ,1 ,  POSITION(''|'' IN f2.source_record_id) - 1)) AS parent_lead_id
		FROM	SALES.sales_staging.Fact_Touchpoint_Details f
		JOIN	SALES.edw_salesforce.sf_lead l
		ON		l.lead_id_cs::varchar = child_lead_id::varchar
		JOIN	SALES.sales_staging.Fact_Touchpoint_Details f2
		ON		l.parent_lead = parent_lead_id
		WHERE	f.employee_key = -1
		AND	f2.employee_key <> -1
		) x
SET		Employee_Key  = x.Parent_Employee_Key,
		Associate_location_key = x.Parent_Location_Key
WHERE	s.Source_Record_ID = x.Source_Record_ID
AND	s.employee_key = -1 
AND 	s.source_record_type_key IN (894, 897) ; 

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;

----------- 26 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee created by key when System generated for sf_lead records'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_staging.Fact_Touchpoint_Details a
FROM	SALES.Sales_Landing.sf_user u,
	SALES.Sales_Views.SF_Integration_Accounts s
SET	Employee_Key  =  COALESCE(SF_Integration_Employee_key,-1), associate_location_Key = COALESCE(u.storenum,-1)
WHERE	u.user_id_cs = a.Lead_owner_id_cs
AND	u.user_name = s.SF_Integration_Employee_desc
AND 	u.employee_number IS NULL
AND 	a.Lead_owner_id_cs<>''NA''
AND 	a.Source_Record_Type_Key=894
AND	a.Employee_Key = -1 ;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;

----------- 27 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Update employee created by key when System generated for floor records'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_staging.Fact_Touchpoint_Details a
FROM	SALES.Sales_Landing.sf_user u,
	SALES.Sales_Views.SF_Integration_Accounts s
SET	Employee_Key  = COALESCE(SF_Integration_Employee_key,-1)
WHERE	u.user_id_cs = a.opp_created_by_id_cs
AND 	u.user_name = s.SF_Integration_Employee_desc
AND 	u.employee_number IS NULL
AND	a.opp_created_by_id_cs IS NOT NULL
AND 	a.Source_Record_Type_Key=900
AND	a.Employee_Key = -1 ;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )		
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id ) ;

--------- 28 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Minute Key '';
    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id ) ;

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	ACCOUNTING.Valid_Values_Views.Time_By_Minute Tm
SET	Activity_Minute_Key  = Tm.Time_By_Minute_Key
WHERE	Tm.Minute_Number = EXTRACT(MINUTE FROM (dataops.utilities.UTC_to_Local_ts0(FCT.Touchpoint_Begin_TS_UTC,Fct.UTC_Local_offset)))
AND	Tm.Hour_Number = EXTRACT(HOUR FROM (dataops.utilities.UTC_to_Local_ts0(FCT.Touchpoint_Begin_TS_UTC,Fct.UTC_Local_offset))) ;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 29 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Vechicle Key '';

    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id );

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Views.Stock_Number_Master Snm
SET	Vehicle_Key  = Snm.Vehicle_Key
WHERE	Snm.Stock_Number_Key=Fct.Stock_Number_Key
AND	Snm.Stock_Number_Valid_Flag=''Y''
AND	Snm.Stock_Number_Key <> -1;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;



---------- 30 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Lead Interest Key '';

    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id );

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.Sales_Staging.Fact_Touchpoint_Details Fct
FROM	SALES.Sales_Views.Lead_Interests Li
SET	Lead_Interests_Key  = Li.Lead_Interest_Key
WHERE	Fct.Lead_Type=Li.Lead_Interest_Desc;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

---------- 31 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Touchpoint_end_Ts_utc for SF leads'';

    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id );

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

UPDATE	SALES.sales_staging.Fact_Touchpoint_Details s
FROM	(	
		SELECT	COALESCE(l.converted_date_time_utc, o.time_accepted_utc, CAST(l.converted_date AS TIMESTAMP(0)), l.closed_time_utc) AS end_timestamp,
				l.lead_id_cs
		FROM	SALES.sales_landing.sf_lead l
		LEFT JOIN	SALES.sales_landing.sf_opportunity o
		ON  COALESCE(l.Converted_opportunity_id_cs,l.matched_opportunity_id_cs) = o.opportunity_id_cs
		) x
SET		Touchpoint_End_TS_UTC  = x.end_timestamp		
WHERE	SUBSTRING(s.source_record_id::varchar ,1 ,  POSITION(''|'' IN s.source_record_id) - 1) = x.lead_id_cs
AND 	s.source_record_type_key = 894 ;

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;


---------- 32 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    	Activity_Desc  := ''Deleting from '' || Database_Stage || ''.'' || Table_Stage ||'' having Touchpoint_Attribute_Key as -1 '';

    	Step_Id  := Step_Id + 1 ;
INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id );

	Count_Last  := 0 ;
	Sql_Statement  := Activity_Desc ;

DELETE FROM SALES.Sales_Staging.Fact_Touchpoint_Details WHERE Touchpoint_Attribute_Key=-1 AND Source_Record_Type_Key IN (897,894);

	Count_Last  := COALESCE ( :SQLROWCOUNT , 0 ) ;
 	Count_Stage  := Count_Stage - Count_Last;

INSERT   INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc,Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES   ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id ) ;

-----------33-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Validating All The Key Columns Are Not Having Null Value In '' || Database_Stage || ''.'' || Table_Stage;  
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id ) ;

	Sql_Statement  := ''Select Count(*) Into Record_Count From Sales_Staging.Fact_Touchpoint_Details '' ;
	Record_Count  := 0 ;

	Sql_Statement  := Activity_Desc ;
--LOCK ROW FOR ACCESS
SELECT	COUNT(*) INTO Record_Count 
FROM	SALES.Sales_Staging.Fact_Touchpoint_Details 
WHERE	Touchpoint_Detail_Key 			IS NULL 
	OR Source_Record_Type_Key 		IS NULL 
	OR Activity_Day_Key 			IS NULL 
	OR Activity_Minute_Key 			IS NULL 
	OR Closed_Lost_Reason_Key 		IS NULL 
	OR Customer_Activity_Key 			IS NULL 
	OR Customer_Source_Key 			IS NULL 
	OR Employee_Key 				IS NULL 
	OR Lead_Origin_Key 			IS NULL 
	OR Touchpoint_Attribute_Key 		IS NULL 
	OR Lead_Interests_Key 			IS NULL 
	OR Location_Key 				IS NULL 
	OR Stock_Number_Key 			IS NULL 
	OR Touchpoint_Begin_Ts_Utc 		IS NULL
	OR Vehicle_Key 				IS NULL 
	OR Vehicle_Location_Key 			IS NULL 
	OR Source_Record_Id 			IS NULL 
	OR Source_Customer_Id 			IS NULL ;

 Record_Count  := COALESCE ( :Record_Count , 0 ) ;

IF (( Record_Count > 0 ) OR ( Error_Count > 0 )) THEN

	 	Error_Condition  := 6 ;
 	 	Error_Count  := Error_Count +1 ;
 	 	Sql_Return_Code  := SQLCODE ;
 	 	--Sql_State_Code  := SQLSTATE ;
 
	INSERT  INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition , Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
	VALUES  (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement ) ;
	 
	INSERT  INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Condition , Error_Count, Record_Count, Step_Id ) 
	VALUES  ( :Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id ) ;

	 	Out_Error_Count  := Error_Count ;
	 	Out_Hard_Stop_Error  := 1 ;
	 	Out_Records_Loaded  := 0 ;

	CALL 	DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop (
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
	
	RAISE Planned_exception;
	
End If;


------------34------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''Insert Metadata Table_Controls Record'' ;
	Step_Id  := Step_Id + 1 ;

	Sql_Statement  := Activity_Desc ;
INSERT	INTO DATAOPS.Metadata_Controls.Table_Controls (
	Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
	Process_Status_Key, 
	Balanced_Flag, 
	Destination_Database, Destination_Table_Name,
	Error_Detail_Description, 
	Source_Server, Source_Database, Source_Table_Name,
	Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
	Source_Aggregate_Amount, Source_Record_Count )
VALUES	( :Batch_Number, :Calendar_Key , :Process_Id , 
	CASE WHEN :Error_Count = 0 THEN 4 ELSE 5 End ,
	CASE WHEN :Error_Count = 0 THEN ''Y'' ELSE ''N'' End ,
	:Database_Target , :Table_Target ,
	CASE WHEN :Error_Count > 0 THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''NA'' End ,
	''Teradata'', :Database_Source , :Table_Source , 
	0 , :Count_Target , :Error_Count , 
	0 , :Count_Source ) ;

	Record_Count  := COALESCE ( :SQLROWCOUNT , 0 ) ;

INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage, :Step_Id ) ;
	
------------35------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc  := ''****  Complete  ****'' ;
	Completed_Flag  := ''Y'' ;
	Step_Id  := Step_Id + 1 ;
INSERT 	INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id )
VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id ) ;

CALL	DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop (
	:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;

	Out_Error_Count  := Error_Count ;
	Out_Hard_Stop_Error  := 0 ;
	Out_Records_Loaded  := Count_Stage ;

End;

Final_Output := object_construct(''OUT_ERROR_COUNT'',:OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',:OUT_RECORDS_LOADED) ;
return :Final_Output; 

Exception
WHEN Planned_Exception THEN 
        
    INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
    VALUES  (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
    
    RETURN object_construct(''OUT_ERROR_COUNT'',:OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',:OUT_RECORDS_LOADED) ;
    
WHEN OTHER THEN 

    Error_Count := Error_Count +1 ;
    Error_Condition := 9999 ;
    Out_Error_Count := Error_Count ;
    Out_Hard_Stop_Error := 1 ;
    Out_Records_Loaded := Count_Last ;
    
    INSERT INTO sales.sales_staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )   
    VALUES  ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ;

    INSERT  INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
    VALUES  (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
    
    RETURN object_construct(''OUT_ERROR_COUNT'',:OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',:OUT_RECORDS_LOADED) ;

END;
';