CREATE OR REPLACE PROCEDURE "SP_LAND_SF_OPPORTUNITY"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE
	--Declare output variables
        Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 
		Final_output OBJECT;
		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-05		By: Harini Nagarajan
		Purpose: Landing table for sf_opportunity

		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------
		2019-11-20	vganesh		removing columns Converted_From_Css_Lead,Converted_From_Rsc_Lead
		2019-12-05	Dhanalakshmi	changed to reserved container as part of CCPA

	*****************************************************************************************************************************************************************************/

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100) := ''''; -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500) := ''''; -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	BEGIN

		Activity_Name := ''sp_Land_Sf_Opportunity'';
		Code_Lines := 384;
		Database_Source := ''Edw_Salesforce_Reserved_Views''; --changed to reserved container as part of CCPA
		Database_Stage := ''Sales_Landing'';
		Database_Target := ''Sales_Landing'';
		Process_Id := 458;
		Table_Source := ''Sf_Opportunity'';
		Table_Stage := ''Sf_Opportunity'';
		Table_Target := ''Sf_Opportunity'';
		Version := 1.2;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

	---------------------- 0 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set METADATA_CONTROLS.Run_Time_Results Record To Zero'';
			CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;
			Sql_Statement := ''Get Parameters'';

			Start_Time  := (SELECT
				CASE
					WHEN (
						SELECT
							CAST(TRUNC( Parameter_Value) AS INTEGER) 
							FROM
							DATAOPS.METADATA_VIEWS.Parameters_Sales
							WHERE	Parameter_Name IN (''Leads_Origin_Start_Days'' )) = 9999
						THEN TO_TIMESTAMP(''1980-01-01 13:52:22'')
		ELSE (
						SELECT
							TO_TIMESTAMP(TO_DATE(DATEADD(''DAY'',-CAST(TRUNC( Parameter_Value) AS INTEGER),CURRENT_TIMESTAMP(0))))
			FROM
							DATAOPS.METADATA_VIEWS.Parameters_Sales
			WHERE	Parameter_Name IN (''Leads_Origin_Start_Days'' ) )
				END);

	---------------------- 1 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.EDW_SALESFORCE_RESERVED_VIEWS.Sf_Opportunity --changed to reserved container as part of CCPA
		WHERE   Ss_Insert_Ts_Utc >= :Start_Time ;
			Count_Source := COALESCE (:Record_Count , 0);
			IF (Count_Source = 0) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;

				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;

	---------------------- 2 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.SALES_LANDING.Sf_Opportunity;

	---------------------- 3 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert Into '' ||Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.SALES_LANDING.Sf_Opportunity (Opportunity_Id_Cs,Is_Deleted,Account_Id_Cs,Is_Private,Name_Text,
				Description,Stage_Name,Amount,Probability,Expected_Revenue,Total_Opportunity_Quantity,
				Close_Date,Type_Text,Next_Step,Lead_Source,Is_Closed,Is_Won,
				Forecast_Category,Forecast_Category_Name,Campaign_Id_Cs,Has_Opportunity_Line_Item,
				Pricebook2_Id_Cs,Owner_Id_Cs,Created_By_Id_Cs,Last_Modified_By_Id_Cs,
				Last_Updated_Ts_Utc,Last_Activity_Date,Fiscal_Quarter,Fiscal_Year,
				Fiscal_Period,Last_Viewed_Ts_Utc,Last_Referenced_Ts_Utc,Synced_Quote_Id_Cs,
				Contract_Id_Cs,Closed_Reason,Finance_First_Link,Home_Delivery_Flag,
				Home_Delivery_Stage_Reason,Home_Delivery_Stage,Lead_Type,Opportunity_Customer_Name,
				Progression_Event_Count,Recycle_Count,Status,Storenum,Store_Location_Number,
				Web_Lead_Id,X_Open_Closed,Visit_Purpose_Appraisal,Visit_Purpose_Browse,
				Visit_Purpose_Financing,Visit_Purpose_Specific_Vehicle,Merged,
				Origin_Store_Location,User_Division,User_Region,User_Store,First_Call_Response_Hhmm,
				First_Call_Response,First_Called_Utc,First_Email_Response_Hhmm,
				First_Email_Response,First_Emailed_Utc,First_Response_Hhmm,First_Response,
				Has_Appointment,Has_Followup,Has_Note,Note_Length,Time_Accepted_Utc,
				Vehicle_Specific_Application,User_Active_At_Origin_Store,Is_Late_Response,
				Belongs_To_My_Team,Is_Currently_Multistore,Is_Was_Ever_Multistore,
				Store_Num_List_Sales_Team_Actv,Store_Num_List_Sales_Team_Hist,
				Lead_Origin,Situation_Notes,Comments,Lead_Customer_Question,
				Lead_Requested_App_Date_Utc,Lead_Web_Submit_Date_Utc,Lead_Status,
				Stock_Number,Contact_Preference,Do_Not_Email,Oe_Contact_Id,Oe_Customer_Id,
				Store_Employee_Id,Established_Dialog,Established_Dialog_Due_By,
				Appraisal_Any_Cust_Concerns,Appraisal_Name_On_Title,Appraisal_Reason_Sell_Vehicle,
				Appraisal_Replacement_Plans,Appraisal_Research_Performed,Appraisal_Veh_Lien_Or_Lease,
				Connection_Cues,Delivery_Experience,Discovery_Any_Cust_Concerns,
				Document_Center_Customer_Link,Financing_Any_Cust_Concerns,Financing_Desired_Down_Payment,
				Financing_Desired_Month_Pymnt,Financing_Maxcare_Discussed,Financing_Payment_Type,
				Financing_Total_Budget,Shopping_Any_Customer_Concerns,Shopping_Primary_Use,
				Shopping_Specific_Vehicle,Shopping_Timeframe_To_Purchase,Shopping_Vehicle_Features,
				Transacted_With_Carmax_Before,Vehicle_Additional_Notes,Vehicle_Prep_Completed,
				Auto_Closed,Auto_Close_Base_Date,Auto_Close_Date,Close_Status,
				Converted_From_Css_Lead,Converted_From_Rsc_Lead,Data_Entry_Method,
				First_Responded,First_Response_All_Hhmm,First_Response_All,First_Texted,
				First_Text_Response_Hhmm,First_Text_Response,Has_Open_Activity,
				Has_Overdue_Task,Has_Ever_Been_Part_Of_My_Team,Has_Open_Orders,
				Has_Transfer,Has_Walkaround,Is_Late_Response_With_Text,Last_Modified_By_User,
				Merge_Master_Ci_Cs,Next_Appointment_When_Text,Next_Appointment_When,
				Next_Followup_When_Date,Next_Followup_When_Text,Next_Followup_When,
				Primary_Salesforce_Contact_Cs,Record_Type_Id_Cs,Rstk_Current_Generators,
				Rstk_Delivery_Install_Status,Rstk_Main_Competitors,Rstk_Order_Number,
				Rstk_Rs_So_Contract_Cs,Rstk_Tracking_Number,Sales_Team_Member_Count,
				User_Timezone_Offset,Ss_Insert_Ts_Utc,Ss_Lst_Upd_Ts_Utc,Db_Source,
				Ss_Db_Status,Insert_Ts,Lst_Upd_Ts)
			SELECT
				Opportunity_Id_Cs,
				Is_Deleted,
				Account_Id_Cs,
				Is_Private,
				Name_Text,
				Description,
				Stage_Name,
				Amount,
				Probability,
				Expected_Revenue,
				Total_Opportunity_Quantity,
				Close_Date,
				Type_Text,
				Next_Step,
				Lead_Source,
				Is_Closed,
				Is_Won,
				Forecast_Category,
				Forecast_Category_Name,
				Campaign_Id_Cs,
				Has_Opportunity_Line_Item,
				Pricebook2_Id_Cs,
				Owner_Id_Cs,
				Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,
				Last_Updated_Ts_Utc,
				Last_Activity_Date,
				Fiscal_Quarter,
				Fiscal_Year,
				Fiscal_Period,
				Last_Viewed_Ts_Utc,
				Last_Referenced_Ts_Utc,
				Synced_Quote_Id_Cs,
				Contract_Id_Cs,
				Closed_Reason,
				Finance_First_Link,
				Home_Delivery_Flag,
				Home_Delivery_Stage_Reason,
				Home_Delivery_Stage,
				Lead_Type,
				Opportunity_Customer_Name,
				Progression_Event_Count,
				Recycle_Count,
				Status,
				Storenum,
				Store_Location_Number,
				Web_Lead_Id,
				X_Open_Closed,
				Visit_Purpose_Appraisal,
				Visit_Purpose_Browse,
				Visit_Purpose_Financing,
				Visit_Purpose_Specific_Vehicle,
				Merged,
				Origin_Store_Location,
				User_Division,
				User_Region,
				User_Store,
				First_Call_Response_Hhmm,
				First_Call_Response,
				First_Called_Utc,
				First_Email_Response_Hhmm,
				First_Email_Response,
				First_Emailed_Utc,
				First_Response_Hhmm,
				First_Response,
				Has_Appointment,
				Has_Followup,
				Has_Note,
				Note_Length,
				Time_Accepted_Utc,
				Vehicle_Specific_Application,
				User_Active_At_Origin_Store,
				Is_Late_Response,
				Belongs_To_My_Team,
				Is_Currently_Multistore,
				Is_Was_Ever_Multistore,
				Store_Num_List_Sales_Team_Actv,
				Store_Num_List_Sales_Team_Hist,
				Lead_Origin,
				Situation_Notes,
				Comments,
				Lead_Customer_Question,
				Lead_Requested_App_Date_Utc,
				Lead_Web_Submit_Date_Utc,
				Lead_Status,
				Stock_Number,
				Contact_Preference,
				Do_Not_Email,
				Oe_Contact_Id,
				Oe_Customer_Id,
				Store_Employee_Id,
				Established_Dialog,
				Established_Dialog_Due_By,
				Appraisal_Any_Cust_Concerns,
				Appraisal_Name_On_Title,
				Appraisal_Reason_Sell_Vehicle,
				Appraisal_Replacement_Plans,
				Appraisal_Research_Performed,
				Appraisal_Veh_Lien_Or_Lease,
				Connection_Cues,
				Delivery_Experience,
				Discovery_Any_Cust_Concerns,
				Document_Center_Customer_Link,
				Financing_Any_Cust_Concerns,
				Financing_Desired_Down_Payment,
				Financing_Desired_Month_Pymnt,
				Financing_Maxcare_Discussed,
				Financing_Payment_Type,
				Financing_Total_Budget,
				Shopping_Any_Customer_Concerns,
				Shopping_Primary_Use,
				Shopping_Specific_Vehicle,
				Shopping_Timeframe_To_Purchase,
				Shopping_Vehicle_Features,
				Transacted_With_Carmax_Before,
				Vehicle_Additional_Notes,
				Vehicle_Prep_Completed,
				Auto_Closed,
				Auto_Close_Base_Date,
				Auto_Close_Date,
				Close_Status,
				NULL,
				NULL,
				Data_Entry_Method,
				First_Responded,
				First_Response_All_Hhmm,
				First_Response_All,
				First_Texted,
				First_Text_Response_Hhmm,
				First_Text_Response,
				Has_Open_Activity,
				Has_Overdue_Task,
				Has_Ever_Been_Part_Of_My_Team,
				Has_Open_Orders,
				Has_Transfer,
				Has_Walkaround,
				Is_Late_Response_With_Text,
				Last_Modified_By_User,
				Merge_Master_Ci_Cs,
				Next_Appointment_When_Text,
				Next_Appointment_When,
				Next_Followup_When_Date,
				Next_Followup_When_Text,
				Next_Followup_When,
				Primary_Salesforce_Contact_Cs,
				Record_Type_Id_Cs,
				Rstk_Current_Generators,
				Rstk_Delivery_Install_Status,
				Rstk_Main_Competitors,
				Rstk_Order_Number,
				Rstk_Rs_So_Contract_Cs,
				Rstk_Tracking_Number,
				Sales_Team_Member_Count,
				User_Timezone_Offset,
				Ss_Insert_Ts_Utc,
				Ss_Lst_Upd_Ts_Utc,
				Db_Source,
				Ss_Db_Status,
				Insert_Ts,
				Lst_Upd_Ts
			FROM
				SALES.EDW_SALESFORCE_RESERVED_VIEWS.Sf_Opportunity --changed to reserved container as part of CCPA
			WHERE   Ss_Insert_Ts_Utc >= :Start_Time;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 4 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := substr(''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage, 1, 100);
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;

			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.SALES_LANDING.Sf_Opportunity;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF ( Count_Source <> Count_Stage ) THEN
				Sql_Statement :=''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.METADATA_CONTROLS.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;

				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	---------------------------- 5 ---------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
			Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Stage , :Error_Count ,
			0 , :Count_Source);

	----------------------------- 6 -------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id);
			CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Stage, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Stage;
		
			Final_output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
			RETURN :Final_output;
	EXCEPTION 
	When Planned_Exception then 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	When OTHER then 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.SALES_STAGING.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )         
		VALUES         ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT         INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES         (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

    		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

END;
';