CREATE OR REPLACE PROCEDURE "SP_STAGE_CUSTOMER_ACTIVITY_XREF"("IN_SOURCE_TYPE" FLOAT)
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

	-- Unique Variables for this procedure:
		 Batch_ID		SMALLINT DEFAULT 0; -- Used to identify the partition of data in use

		 Current_Month_Key	INTEGER DEFAULT 0; -- Used to set the Year_Month_Key for the current month

		 Count_Customers	INTEGER DEFAULT 0; -- Used in various steps to track the count of customer records

		 First_Month_Key	INTEGER DEFAULT 0; -- Used to set the earliest Year_Month_Key for data selected

		 Index_Exists	BYTEINT DEFAULT 0; -- Used to signal whether an index needs to be dropped

		 Phone_Start_Time TIMESTAMP(0); -- Time when this procedure starts	

		 Run_Now		CHAR(1) DEFAULT ''N''; -- Defines whether to do updates during the day or at night

		 Source_Type_Key	INTEGER DEFAULT 0; -- Identifies the Sales Code Key to use for Fact_Order_Details

		 Source_Version_Key INTEGER DEFAULT 0; -- Version Number in Activity to Customer Today XRef

	-- Standard Procedure Variables
		 Activity_Name	VARCHAR(100); -- The name of the procedure running

		 Activity_Desc	VARCHAR(500); -- A description of the step in the procedure running for the Activity Log

		 Batch_Number	INTEGER DEFAULT 0; -- Holds the Batch Key assigned in the Landing process

		 Cache_Record_Key	INTEGER DEFAULT 0; -- Record_Key in Metadata_Controls.Table_Update_Codes for this table

		 Calendar_Key	INTEGER DEFAULT 0; -- Used to hold today''s Calendar By Day Key

		 Code_Lines	SMALLINT DEFAULT 0; -- Count of lines of code in this procedure for control purposes

		 Completed_Flag	CHAR(1)  DEFAULT ''N''; -- Used for updating the Activity Log

		 Count_Last	INTEGER DEFAULT 0; -- Used within the procedure to compare record count today to yesterday

		 Count_Source	INTEGER DEFAULT 0; -- Used within the procedure to reconcile source to Stage

		 Count_Stage	INTEGER DEFAULT 0; -- Used within the procedure to reconcile source to Stage

		 Count_Target	INTEGER DEFAULT 0; -- Used within the procedure to reconcile Stage to Target

		 Database_Source	VARCHAR(100); -- Used to specify the database where data is obtained

		 Database_Stage 	VARCHAR(100); -- Used to specify the database in which this procedure runs

		 Database_Target	VARCHAR(100); -- Used to specify the public production database 

		 Error_Condition	BYTEINT DEFAULT 0; -- Identifies the last error condition encountered

		 Error_Count	SMALLINT DEFAULT 0; -- Written to Out_Error_Count

		 Error_Key	SMALLINT DEFAULT 0; -- Written to the Error_Log

		 Hard_Stop_Count	BYTEINT DEFAULT 0; -- Count of hard stop errors encountered by all called procs

		 Last_Record_Key	INTEGER DEFAULT 0; -- Used to identify the existing vs new records

		 Process_ID	INTEGER DEFAULT 0; -- Identifies the Process_Control_Key this Job Process is related to

		 Record_Count	INTEGER DEFAULT 0; -- Multi-purpose

		 SQL_Return_Code	INTEGER DEFAULT 0; -- Holds the SQLCODE reported by Teradata when an error occurs - Written to the Error_Log

		 SQL_Statement	VARCHAR(5000) DEFAULT ''''; -- Hold Dynamic SQL - May be written to Error Log also

		 SQL_State_Code	VARCHAR(5) DEFAULT ''''; -- Holds the value reported for SQLSTATE when an error occurs - Written to the Error_Log

		 Start_Time TIMESTAMP(0); -- Time when this procedure starts	

		 Step_ID		SMALLINT DEFAULT 0; -- The Step Number in the procedure that runs next (reflected in the Activity Log)

		 Table_Source	VARCHAR(100); -- Source Table Name

		 Table_Stage	VARCHAR(100); -- Stage Table Name

		 Table_Target	VARCHAR(100); -- Target Table Name

		 Target_Balanced	CHAR ( 1 ) DEFAULT ''N''; -- Identifies whether the Stage, and Target balance

		 Version		DECIMAL(6,3) DEFAULT 0.00; -- The version of this stored procedure in use

                Out_Error_Count SMALLINT := 0; 
                Out_Hard_Stop_Error BYTEINT := 0; 
                Out_Records_Loaded INTEGER := 0; 

		Planned_Exception   Exception (-20001, ''Any Exception '');

		Final_Output Object;

	BEGIN

	/******************************************************************************************************************************************************************************
		Created: 2018-10-21		BY: Michael
		Purpose: This procedure builds and loads Activity Customer XRef

	call	CUSTOMERS.Customers_Staging.sp_Stage_Customer_Activity_XRef (10, Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		Modified Date	Modified By	Notes 
		-------------	------------	---------------------------------------------------------------------------------------------------------------------------------------------
		2019-06-26	Michael		Rework all steps used to assign Customer Keys
		2019-07-05	Michael		Changed method for Suspect Relationship for Orders
						Added oreplace to suspect check
		2019-07-10	Michael		Added Activity_Key to Step 16 and 17
		2019-07-23	Michael		Set Activity_TS_UTC for Credit to CARS TS for accuracy
						Set Activity_TS_UTC for Appraisal to Completed TS to align with Activity Date
		2019-08-27	Michael		Reset Customer_Interaction_Key to -1 when Customer_Key has changed
		2019-09-06	Michael		Reset Originated_Journey_Flag to ''N'' when Customer_Key has changed.
						Added DW_Update_TS in a few places.
		2019-11-05	Dhanalakshmi	changed to reserved container as part of CCPA
		2019-11-27	Krishna		Added Filter on Fact_Repair_Order_Details pull only Service - Retail (874) Records
		2019-02-06        Krishna		Updating Para 47 with DW_UPDATE_TS instead of DW_Insert_TS
		2020-09-14	Matt			changes to P8, P23, P48 for OTM source record type key
		2021-02-17	Vamshi			updated logic for test_Drive_Records to mask source record type key 1000 to 768.
		2021-10-08	Sofia		Changes made in P13 & P29 to assign customer for credit OPUx &checkout data
	*****************************************************************************************************************************************************************************/

		Activity_Name := ''sp_Stage_Customer_Activity_XRef'';
		Code_Lines := 2231;
		Database_Source := ''Multiple'';
		Database_Stage := ''Customers_Staging'';
		Database_Target := ''Customers'';
		Process_ID := 418;
		Table_Source := ''Multiple'';
		Table_Stage := ''Activity_Customer_XRef'';
		Table_Target := ''Activity_Customer_XRef'';
		Version := 4.11;
		SELECT
			Calendar_By_Day_Key,
			Year_Month INTO
			:Calendar_Key,
			:Current_Month_Key
	FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE() ;
		
		SELECT
			CASE
				WHEN CURRENT_TIME() BETWEEN TIME ''00:00:01'' AND TIME ''07:00:00''
					THEN ''Y''
				WHEN CURRENT_TIME() >= TIME ''18:00:00''
					THEN ''Y''
		     ELSE ''N''
			END
		INTO
			:Run_Now;

		-- Start of Procedural Steps with Exception Handler
		BEGIN
			 

	----- 0 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SQL_Statement := ''Set Metadata_Controls.Run_Time_Results record to zero'';
			CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_ID , :Process_ID , ''Teradata'' , :Table_Target, :Version ) ;

	----- 1 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Confirm data exists in the source tables'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			SQL_Statement := ''Get Start_Days parameter value and convert to zero hour-minutes-seconds'';

			Start_Time := (SELECT
				CASE
					WHEN (
						SELECT
							Parameter_value
						    FROM
							DATAOPS.Metadata_Views.Parameters_Customer
						    WHERE  Parameter_Name = ''Activity_Customer_XRef_Days'' ) = ''9999''
						THEN TO_TIMESTAMP(''1980-01-01 00:00:01'')

		     ELSE (
						SELECT
							TO_TIMESTAMP(TO_DATE(DATEADD(''DAY'',-CAST(TRUNC(Parameter_Value) AS INTEGER),CURRENT_TIMESTAMP(0))))
			    FROM
							DATAOPS.Metadata_Views.Parameters_Customer
			    WHERE   Parameter_Name =''Activity_Customer_XRef_Days'' )
				END);

			SQL_Statement := ''Get First_Month_Key'';
			SELECT
				Calendar_By_Month_Key INTO
				:First_Month_Key
		FROM
				ACCOUNTING.Valid_Values_Views.Calendar_By_Month
		WHERE	Year_Month_Dash = RPAD(TO_CHAR(:Start_Time), 7);
			Activity_Desc :=''First_Month_Key = '' || LEFT(LTRIM(TO_VARCHAR(First_Month_Key, ''MI9999999999'')), 10);
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);

			Phone_Start_Time := (SELECT
				CASE
					WHEN (
						SELECT
							Parameter_value
						    FROM
							DATAOPS.Metadata_Views.Parameters_Customer
						    WHERE  Parameter_Name = ''Customer_Phone_XRef_Pool_Days'' ) = ''9999''
						THEN TO_TIMESTAMP(''1980-01-01 00:00:01'')

		     ELSE (
						SELECT
							TO_TIMESTAMP(TO_DATE(DATEADD(''DAY'',-CAST(TRUNC(Parameter_Value) AS INTEGER),CURRENT_TIMESTAMP(0))))
			    FROM
							DATAOPS.Metadata_Views.Parameters_Customer
			    WHERE   Parameter_Name =''Customer_Phone_XRef_Pool_Days'' )
				END);

	----- 2 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Set Batch_ID'';
			Step_ID := Step_ID + 1;
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			Batch_ID := In_Source_Type;

			/*	1 = Everything
				2 = 863 through 873, 894, 897, 	Touchpoints - Leads, Walkins
				    900, 918, 924
				3 = 895, 898, 899 		Touchpoints - Phone Systems
				4 = 481				Orders
				5 = 751				Appraisals
				6 = 757				Transfers
				7 = 767				Test Drives With Customer
				8 = 778, 779, 787, 788, 789	Credit History (All)
				9 = 874				Service
				10 = 481, 751, 757, 767, 874	Orders, Appraisals, Transfers, Test Drives and Service
			*/
			Activity_Desc := Activity_Desc || '' = '' || LEFT(LTRIM(TO_VARCHAR(:Batch_ID, ''MI99999'')), 5);
			INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc,
				  :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);

	----- 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Remove existing Credit records not in Fact Credit Activities any longer'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
				SQL_Statement := Activity_Desc;
				IF (Batch_ID IN ( 1, 8)) THEN

				DELETE						
				FROM	CUSTOMERS.Customers.Activity_Customer_XRef
				WHERE	( Source_Record_Type_Key, Source_Record_Key ) IN (
					SELECT	x.Source_Record_Type_Key, x.Source_Record_Key
					FROM 	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
					LEFT OUTER
					JOIN	FINANCE.Credit_Views.Fact_Credit_Activities c ON	c.Source_Record_Type_Key = x.Source_Record_Type_Key
										 AND	c.Source_Record_Key = x.Source_Record_Key
					WHERE	c.Source_Record_Key IS NULL
					AND	x.Source_Record_Type_Key IN ( 778, 779, 787, 788, 789 )
					) ;
				Count_Source := COALESCE ( :Record_Count , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);

	----- 4 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Remove existing Service records not in Fact Service Activities any longer'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
				SQL_Statement := Activity_Desc;
				IF (Batch_ID IN ( 1, 9 )) THEN

				DELETE						
				FROM	CUSTOMERS.Customers.Activity_Customer_XRef
				WHERE	( Source_Record_Type_Key, Source_Record_Key ) IN (
					SELECT	x.Source_Record_Type_Key, x.Source_Record_Key
					FROM 	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
					LEFT OUTER
					JOIN	SALES.Sales_Views.Fact_Repair_Order_Details c ON	c.Source_Record_Type_Key = x.Source_Record_Type_Key
										    AND	c.Source_Record_Key = x.Source_Record_Key
					WHERE	c.Source_Record_Key IS NULL
					AND	x.Source_Record_Type_Key IN ( 874 )
					) ;
				Count_Source := COALESCE ( :Record_Count , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);

	----- 5 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Source Record Counts'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
				SQL_Statement := ''Get count of fact records into Count_Source'';
				SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.Sales_Views.Fact_Retail_Activities
		WHERE	Activity_Year_Month_Key BETWEEN :First_Month_Key AND :Current_Month_Key
		AND	DW_Insert_TS >= :Start_Time ;
				Count_Source := COALESCE ( :Record_Count , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);

	----- 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Insert Activities into Staging table
	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Appraisal_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := ''Delete existing temp data'';
				DELETE FROM
				CUSTOMERS.Customers_Staging.Activity_Customer_XRef
				WHERE
				batch_Key = :Batch_ID;
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 5, 10 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key, Activity_Day_Key, Customer_Source_Key,
				Location_Key, Activity_TS_UTC, Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					Activity_Day_Key,
					16 AS Customer_Source_Key,
					Location_Appraisal_Key AS Location_Key,
					CASE
						WHEN Appraisal_Completed_TS IS NOT NULL
							THEN Appraisal_Completed_TS
						WHEN Appraisal_Began_TS IS NOT NULL
							THEN Appraisal_Began_TS
						ELSE TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' 00:00:01'')
					END AS Activity_TS_UTC,
					LEFT(
					CAST ( Location_Appraisal_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					Appraisal_Detail_Key AS Source_Record_Key,
					751 AS Source_Record_Type_Key,
					''Y'' AS Primary_Customer_Flag,
					TRIM(LEFT(CAST ( Customer_ID AS VARCHAR), 18)) AS Source_Customer_ID,
					6 AS DW_Step_ID
				FROM
					SALES.Sales_Views.Fact_Appraisal_Details
				WHERE	DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Order_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 4, 10 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key, Activity_Key, Activity_Day_Key, Customer_Source_Key,
				Location_Key, Activity_TS_UTC, Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					COALESCE ( o.Order_Customer_Key , -1 ) AS Activity_Key,
					f.Tender_Day_Key AS Activity_Day_Key,
					4 AS Customer_Source_Key,
					f.Location_Key,
					TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' 00:00:01'') AS Activity_TS_UTC,
					LEFT(
					CAST ( f.Location_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					f.Order_Detail_Key AS Source_Record_Key,
					481 AS Source_Record_Type_Key,
					COALESCE ( o.Primary_Order_Customer_Flag , ''Y'' ) AS Primary_Order_Customer_Flag,
					TRIM(LEFT(CAST ( o.Order_Customer_ID AS VARCHAR), 18)) AS Source_Customer_ID,
					7 AS DW_Step_ID
				FROM
					SALES.Sales_Views.Fact_Order_Details f
				LEFT OUTER
				JOIN
						CUSTOMERS.Customers_Reserved_Views.Order_Customers o   ON  o.Location_Key = f.Location_Key --changed to reserved container as part of CCPA
									AND o.Order_Number = f.Order_Number
				WHERE	f.DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 8 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Transfer_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 6, 10 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key, Activity_Day_Key, Customer_Source_Key,
				Location_Key, Activity_TS_UTC,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag, Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					Activity_Day_Key,
					16 AS Customer_Source_Key,
					Location_To_Key AS Location_Key,
					CASE
						WHEN Transfer_1_Requested_TS_UTC IS NOT NULL
							THEN Transfer_1_Requested_TS_UTC
						ELSE TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' 00:00:01'')
					END AS Activity_TS_UTC,
					LEFT(
					CAST ( Location_To_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					Transfer_Detail_Key AS Source_Record_Key,
					--757,854
					Source_Record_Type_Key,
					''Y'' AS Primary_Customer_Flag,
					TRIM(LEFT(CAST ( Customer_ID AS VARCHAR), 18) ) AS Source_Customer_ID,
					8 AS DW_Step_ID
				FROM
					SALES.Sales_Views.Fact_Transfer_Details
				WHERE	Customer_Activity_Key <> -1
				AND	DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 9 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Repair_Order_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 9, 10 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key, Activity_Day_Key, Customer_Source_Key,
				Location_Key, Activity_TS_UTC,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag, Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					f.Activity_Day_Key,
					16 AS Customer_Source_Key,
					f.Location_Key,
					TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' 00:00:01'') AS Activity_TS_UTC,
					LEFT(
					CAST ( f.Location_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					f.Repair_Order_Detail_Key AS Source_Record_Key,
					f.Source_Record_Type_Key,
					''Y'' AS Primary_Customer_Flag,
					TRIM(LEFT(CAST ( r.Source_Customer_ID AS VARCHAR), 18)) AS Source_Customer_ID,
					9 AS DW_Step_ID
				FROM
					SALES.Sales_Views.Fact_Repair_Order_Details f
				JOIN
						SALES.Sales_Views.Repair_Orders r ON  r.Repair_Order_Key = f.Repair_Order_Key
								     AND r.Source_Record_Type_Key = 874
				WHERE	f.Source_Record_Type_Key=874
				AND	f.DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 10 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Test_Drive_Details - With Customer Record'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 7, 10 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key,
				Activity_Day_Key,
				Customer_Source_Key,
				Location_Key, Activity_TS,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					f.Activity_Day_Key,
					16 AS Customer_Source_Key,
					Location_Key,
					TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' '' || t.Clock_24_Hour_Desc) AS Activity_TS,
					LEFT(
					CAST ( f.Location_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					f.Source_Record_Key,
					f.Source_Record_Type_Key,
					''Y'' AS Primary_Customer_Flag,
					TRIM(LEFT(CAST ( m.Customer_ID AS VARCHAR), 18) ) AS Source_Customer_ID,
					10 AS DW_Step_ID
				FROM
					SALES.Sales_Views.Fact_Retail_Activities f
				JOIN
						ACCOUNTING.Valid_Values_Views.Time_By_Minute t ON t.Time_By_Minute_Key = f.Activity_Minute_Key
				JOIN
						SALES.Sales_Views.Test_Drive_Master m	ON  (CASE
							WHEN m.Source_Record_Type_Key=1000
								THEN 768 ELSE m.Source_Record_Type_Key
						END) = f.Source_Record_Type_Key
									AND m.Test_Drive_Master_Key = f.Source_Record_Key
									AND m.Customer_ID <> -1
									AND (CASE
							WHEN m.Source_Record_Type_Key=1000
								THEN 768 ELSE m.Source_Record_Type_Key
						END) = 768
				WHERE	f.Source_Record_Type_Key = 768
				AND	f.DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 11 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Test_Drive_Details - With Co Customer Record'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 7, 10 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key,
				Activity_Day_Key,
				Customer_Source_Key,
				Location_Key,
				Activity_TS,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					f.Activity_Day_Key,
					16 AS Customer_Source_Key,
					f.Location_Key,
					TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' '' || t.Clock_24_Hour_Desc) AS Activity_TS,
					LEFT(
					CAST ( f.Location_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					f.Source_Record_Key,
					f.Source_Record_Type_Key,
					''N'' AS Primary_Customer_Flag,
					TRIM(LEFT(CAST ( m.Customer_2_ID AS VARCHAR), 18) ) AS Source_Customer_ID,
					11 AS DW_Step_ID
				FROM
					SALES.Sales_Views.Fact_Retail_Activities f
				JOIN
						ACCOUNTING.Valid_Values_Views.Time_By_Minute t ON t.Time_By_Minute_Key = f.Activity_Minute_Key
				JOIN
						SALES.Sales_Views.Test_Drive_Master m	ON  (CASE
							WHEN m.Source_Record_Type_Key=1000
								THEN 768 ELSE m.Source_Record_Type_Key
						END)  = f.Source_Record_Type_Key
									AND m.Test_Drive_Master_Key = f.Source_Record_Key
									AND (CASE
							WHEN m.Source_Record_Type_Key=1000
								THEN 768 ELSE m.Source_Record_Type_Key
						END) = 768
									AND m.Customer_2_ID <> m.Customer_ID
									AND m.Customer_2_ID <> -1
				WHERE	f.Source_Record_Type_Key = 768
				AND	f.DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 12 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Test_Drive_Details - With Lead Customer Record'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				/*
				IF Batch_ID IN ( 1, ****** ) THEN	

					INSERT	INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
						Batch_Key,
						Activity_Day_Key, Customer_Source_Key,
						Source_Customer_ID_2, 
						Source_Record_Key, Source_Record_Type_Key, 
						Primary_Customer_Flag , Source_Customer_ID. DW_Step_ID )
					SELECT	:Batch_ID,
						f.Activity_Day_Key,
						2 AS Customer_Source_Key,
						SUBSTR(f.Location_Key,0,18) AS Source_Customer_ID_2, 
						f.Source_Record_Key,
						f.Source_Record_Type_Key,
						''Y'' AS Primary_Customer_Flag,
						TRIM(SUBSTR(m.Customer_ID,0,18) ) AS Source_Customer_ID,
						12 as DW_Step_ID
					FROM	SALES.Sales_Views.Fact_Retail_Activities f	
					JOIN	SALES.Sales_Views.Test_Drive_Master m	ON  m.Source_Record_Type_Key = f.Source_Record_Type_Key
										AND m.Test_Drive_Master_Key = f.Source_Record_Key
										AND m.Source_Record_Type_Key = 767
										--AND m.Customer_ID <> -1
					WHERE	f.Source_Record_Type_Key = 767
					AND	f.DW_Insert_TS >= :Start_Time ;

					SET	Count_Last = COALESCE ( SQLROWCOUNT , 0 ) ;
					SET	Count_Stage = Count_Stage + Count_Last ;

				end if
				*/
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 13 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Credit_Activities'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 8 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key,
				Activity_Key,
				Activity_Day_Key,
				Customer_Source_Key,
				Location_Key,
				Activity_TS,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					COALESCE ( c.Credit_Customer_Key , -1 ) AS Activity_Key,
					f.Application_Day_Key AS Activity_Day_Key,
					f.Customer_Source_Key,
					f.Location_Key,
					CASE
						WHEN f.Credit_2_CARS_Received_TS IS NOT NULL
							THEN f.Credit_2_CARS_Received_TS
						ELSE TO_TIMESTAMP(RPAD(SUBSTR(Activity_Date,0,10), 10) || '' 00:00:01'')
					END AS Activity_TS,
					LEFT(
					CAST ( f.Location_Key AS VARCHAR), 18) AS Source_Identifier_ID,
					f.Credit_Activity_Detail_Key AS Source_Record_Key,
					f.Source_Record_Type_Key AS Source_Record_Type_Key,
					COALESCE ( c.Primary_Customer_Flag , ''Y''),
					CASE
						WHEN c.Customer_Source_Key IN (5,6)
							THEN TRIM(LEFT(CAST ( c.Source_Customer_ID AS VARCHAR), 18))
						ELSE TRIM(LEFT(CAST ( c.Credit_Customer_Key AS VARCHAR), 18) )
					END AS Source_Customer_ID,
					13 AS DW_Step_ID
				FROM
					FINANCE.Credit_Views.Fact_Credit_Activities f
				LEFT OUTER
				JOIN
						CUSTOMERS.Customers_Reserved_Views.Credit_Customers c   ON  c.Source_Record_Type_Key = f.Source_Record_Type_Key --changed to reserved container as part of CCPA
									 AND c.Application_Key = f.Application_Key
				WHERE	f.DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 14 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Touchpoint_Details - Not Phone'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 2 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key,
				Activity_Day_Key,
				Customer_Source_Key,
				Location_Key,
				Activity_TS_UTC,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					f.Activity_Day_Key,
					f.Customer_Source_Key,
					f.Location_Key,
					Touchpoint_Begin_TS_UTC AS Activity_TS_UTC,
					''NA'' AS Source_Identifier_ID,
					f.Touchpoint_Detail_Key AS Source_Record_Key,
					f.Source_Record_Type_Key AS Source_Record_Type_Key,
					''Y'' AS Primary_Customer_Flag,
					TRIM(f.Source_Customer_ID),
					14 AS DW_Step_ID
				FROM
					SALES.Sales_Reserved_Views.Fact_Touchpoint_Details f --changed to reserved container as part of CCPA
				WHERE	f.Source_Record_Type_Key NOT IN ( 895, 898, 899 )
				AND	f.DW_Insert_TS >= :Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 15 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Insert new Records into target from Fact_Touchpoint_Details - Phone Leads'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				IF (Batch_ID IN ( 1, 3 )) THEN
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (
				Batch_Key,
				Activity_Day_Key,
				Customer_Source_Key,
				Location_Key,
				Activity_TS_UTC,
				Source_Identifier_ID,
				Source_Record_Key, Source_Record_Type_Key,
				Primary_Customer_Flag , Source_Customer_ID, DW_Step_ID)
				SELECT
					:Batch_ID,
					f.Activity_Day_Key,
					f.Customer_Source_Key,
					f.Location_Key,
					Touchpoint_Begin_TS_UTC AS Activity_TS_UTC,
					''NA'' AS Source_Identifier_ID,
					f.Touchpoint_Detail_Key AS Source_Record_Key,
					f.Source_Record_Type_Key AS Source_Record_Type_Key,
					''Y'' AS Primary_Customer_Flag,
					TRIM(f.Source_Customer_ID),
					15 AS DW_Step_ID
				FROM
					SALES.Sales_Reserved_Views.Fact_Touchpoint_Details f --changed to reserved container as part of CCPA
				WHERE	f.Source_Record_Type_Key IN ( 895, 898, 899 )
				AND	f.DW_Insert_TS >= :Phone_Start_Time ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				Count_Stage := Count_Stage + Count_Last;
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	---- 16 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Replace blank with NA in Source_Customer_ID'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef
	SET	Source_Customer_ID = ''NA'',
		Customer_Key = -2
	WHERE	Batch_Key = :Batch_ID
	AND   (	TRIM(Source_Customer_ID) = ''''
	OR	Source_Customer_ID IS NULL
	OR	Source_Customer_ID IN (''-1'',''0'' ) );
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------ 17 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Add to the pool where the Golden Customer key has recently changed
	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Add Customers where Golden Customer Key changed -- and not Salesforce'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;

	INSERT	INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef ( 
		Batch_Key, Activity_Key, Activity_Day_Key, 
		Customer_Key, Customer_Key_Original, Customer_Interaction_Key, Customer_Source_Key,
		Location_Key, Activity_TS_UTC, Source_Identifier_ID, 
		Source_Record_Key, Source_Record_Type_Key, 
		Originated_Journey_Flag, Primary_Customer_Flag, Source_Customer_ID, 
		Uses_DST_Flag, UTC_Offset_Standard, DW_Step_ID )
	SELECT	:Batch_ID AS Batch_Key,
		x.Activity_Key,
		x.Activity_Day_Key,
		x.Customer_Key AS Customer_Key,
		x.Customer_Key AS Customer_Key_Original,
		x.Customer_Interaction_Key,
		x.Customer_Source_Key, 
		x.Location_Key,
		x.Activity_TS_UTC,
		x.Source_Identifier_ID, 
		x.Source_Record_Key,
		x.Source_Record_Type_Key,
		x.Originated_Journey_Flag,
		x.Primary_Customer_Flag,
		x.Source_Customer_ID,
		x.Uses_DST_Flag, 
		x.UTC_Offset_Standard, 
		16 AS Step_ID
	FROM	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
	WHERE	x.Source_Customer_ID NOT IN (''0'',''-1'',''NA'')
	AND	x.Source_Record_Type_Key NOT IN ( 866, 894, 897, 900, 918, 924 )
	AND	x.Customer_Source_Key <> -1
	AND	x.Source_Record_Type_Key IN ( SELECT DISTINCT Source_Record_Type_Key 
					   FROM 	 CUSTOMERS.Customers_Staging.Activity_Customer_XRef )
	AND	( Customer_Source_Key::VARCHAR, Source_Customer_ID::VARCHAR, Source_Identifier_ID::VARCHAR ) IN (
		SELECT	Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID
		FROM	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
		WHERE	Last_Merge_TS >= :Start_Time )
	AND	( x.Source_Record_Type_Key, x.Source_Record_Key, TRIM(x.Source_Customer_ID) ) NOT IN (
		SELECT	Source_Record_Type_Key, Source_Record_Key, COALESCE(TRIM(Source_Customer_ID),'' '') AS Source_Customer_ID
		FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef s ) ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 18 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Add Customers where Golden Customer Key changed -- and in Salesforce'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;

	INSERT	INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef ( 
		Batch_Key, Activity_Key, Activity_Day_Key, 
		Customer_Key, Customer_Key_Original, Customer_Interaction_Key, Customer_Source_Key,
		Location_Key, Activity_TS_UTC, Source_Identifier_ID, 
		Source_Record_Key, Source_Record_Type_Key, 
		Originated_Journey_Flag, Primary_Customer_Flag, Source_Customer_ID, 
		Uses_DST_Flag, UTC_Offset_Standard, DW_Step_ID )
	SELECT	:Batch_ID AS Batch_Key,
		x.Activity_Key,
		x.Activity_Day_Key,
		x.Customer_Key AS Customer_Key,
		x.Customer_Key AS Customer_Key_Original,
		x.Customer_Interaction_Key,
		x.Customer_Source_Key, 
		x.Location_Key,
		x.Activity_TS_UTC,
		x.Source_Identifier_ID, 
		x.Source_Record_Key,
		x.Source_Record_Type_Key,
		x.Originated_Journey_Flag,
		x.Primary_Customer_Flag,
		x.Source_Customer_ID,
		x.Uses_DST_Flag, 
		x.UTC_Offset_Standard, 
		17 AS Step_ID
	FROM	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
	WHERE	x.Source_Customer_ID NOT IN (''0'',''-1'',''NA'')
	AND	x.Source_Record_Type_Key IN ( 866, 894, 897, 900, 918, 924 )
	AND	x.Customer_Source_Key <> -1
	AND	x.Source_Record_Type_Key IN ( SELECT DISTINCT Source_Record_Type_Key 
					   FROM 	 CUSTOMERS.Customers_Staging.Activity_Customer_XRef )
	AND	( Customer_Source_Key::VARCHAR, Source_Customer_ID::VARCHAR, Source_Identifier_ID::VARCHAR ) IN (
		SELECT	Customer_Source_Key, Source_Customer_ID_CS, Source_Identifier_ID
		FROM	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master --changed to reserved container as part of CCPA
		WHERE	Last_Merge_TS >= :Start_Time )
	AND	( x.Source_Record_Type_Key, x.Source_Record_Key ) NOT IN (
		SELECT	Source_Record_Type_Key, Source_Record_Key
		FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef s ) ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------ 19 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Add to the pool where the Customer Key was previously not found
	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Add customers not found previously'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				IF (Run_Now = ''Y'') THEN

				INSERT	INTO CUSTOMERS.Customers_Staging.Activity_Customer_XRef (	
					Batch_Key, Activity_Key, Activity_Day_Key, 
					Customer_Key, Customer_Key_Original, Customer_Interaction_Key, Customer_Source_Key, 
					Location_Key, Activity_TS_UTC, Source_Identifier_ID, 
					Source_Record_Key, Source_Record_Type_Key, 
					Originated_Journey_Flag, Primary_Customer_Flag, Source_Customer_ID, 
					Uses_DST_Flag, UTC_Offset_Standard, DW_Step_ID )
				SELECT	:Batch_ID AS Batch_Key,
					x.Activity_Key,
					x.Activity_Day_Key,
					x.Customer_Key AS Customer_Key,
					x.Customer_Key AS Customer_Key_Original,
					x.Customer_Interaction_Key,
					x.Customer_Source_Key, 
					x.Location_Key,
					x.Activity_TS_UTC,
					x.Source_Identifier_ID, 
					x.Source_Record_Key,
					x.Source_Record_Type_Key,
					x.Originated_Journey_Flag,
					x.Primary_Customer_Flag,
					TRIM(x.Source_Customer_ID),
					x.Uses_DST_Flag, 
					x.UTC_Offset_Standard, 
					18 AS DW_Step_ID
				FROM	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
				WHERE	x.Customer_Key < 0
				AND	x.Customer_Source_Key <> -1
				AND	x.Source_Customer_ID NOT IN (''0'',''-1'',''NA'')
				AND	( x.Source_Record_Type_Key, x.Source_Record_Key, TRIM(x.Source_Customer_ID) ) NOT IN (
					SELECT	Source_Record_Type_Key, Source_Record_Key, COALESCE(TRIM(Source_Customer_ID),'' '') AS Source_Customer_ID
					FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef s ) ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 20 -------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Update Time Zone
	--------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update Time Zones'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS x
				SET
					x.Uses_DST_Flag = l.Uses_DST_Flag,
					x.UTC_Offset_Standard = l.UTC_Offset_Standard
				FROM
					ACCOUNTING.Valid_Values_Views.Locations l
	WHERE	l.Location_Key = x.Location_Key
	AND	x.UTC_Offset_Standard = 0
	AND	x.Batch_Key = :Batch_ID ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	-------- 21 ------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update Time Zones'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS x
				SET
					x.Activity_TS_UTC = CASE
						WHEN d.Day_Light_Saving_Time = ''Off''
							THEN DATEADD(''HOUR'', UTC_Offset_Standard * -1, x.Activity_TS)
				     ELSE DATEADD(''HOUR'', ( UTC_Offset_Standard -1 ) * -1, x.Activity_TS)
					END
				FROM
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d
	WHERE	x.Activity_Day_Key = d.Calendar_By_Day_Key
	AND	x.Activity_TS_UTC IS NULL
	AND	x.Activity_TS IS NOT NULL
	AND	x.Batch_Key = :Batch_ID ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 22 -------------------------------------------------------------------------------------------------------------------------------------------------------
	-- Assign Customer Key
	--------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for Order Customers based on Activity_Key'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := ''Delete records in Customer_XRef_Assignments'';
				DELETE FROM
				CUSTOMERS.Customers_Staging.Customer_Assignments
				WHERE
				Batch_Key = :Batch_ID ;
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				INSERT INTO CUSTOMERS.Customers_Staging.Customer_Assignments (
				Activity_Key,
				Batch_Key,
				Record_Key,
				Activity_Day_Key,
				Customer_Key,
				Customer_Source_Key,
				Reltio_Customer_ID_CS,
				Source_Customer_ID,
				Source_Identifier_ID)
				SELECT
				a.Activity_Key,
				:Batch_ID,
				a.Record_Key,
				a.Activity_Day_Key,
				COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
				a.Customer_Source_Key,
				COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
				a.Source_Customer_ID,
				a.Source_Identifier_ID
			FROM
				CUSTOMERS.Customers_Staging.Activity_Customer_XRef a
			JOIN
					CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x ON	x.Activity_Key = a.Activity_Key --changed to reserved container as part of CCPA
								   AND	x.Customer_Source_Key = 4
			WHERE	a.Source_Record_Type_Key = 481
			AND	a.Customer_Key <> -2
			AND	a.Batch_Key = :Batch_ID
				QUALIFY
				ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key DESC NULLS LAST) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	--------- 23 -----------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for Store Customers based on Last Start Date Before event'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

	INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
		Batch_Key,
		Record_Key, 
		Activity_Day_Key,
		Customer_Key,
		Customer_Source_Key,
		Reltio_Customer_ID_CS, 
		Source_Customer_ID, 
		Source_Identifier_ID)
	SELECT	:Batch_ID,
		a.Record_Key, 
		a.Activity_Day_Key,
		COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
		a.Customer_Source_Key,
		COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
		a.Source_Customer_ID,
		a.Source_Identifier_ID 
	FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
	JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x    ON	x.Source_Customer_ID_CS::VARCHAR = a.Source_Customer_ID::VARCHAR --changed to reserved container as part of CCPA
					   	   AND	x.Source_Identifier_ID::VARCHAR = a.Source_Identifier_ID::VARCHAR
						   AND	x.Customer_Source_Key IN ( 2, 4, 6, 12, 16 )
					   	   AND	x.Activity_Day_Key <= a.Activity_Day_Key
	WHERE	a.Source_Record_Type_Key IN ( 751, 757, 768, 874, 854 )
	AND	a.Customer_Key <> -2
	AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
	AND	a.Batch_Key = :Batch_ID
	QUALIFY 	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key 
				   ORDER BY x.Activity_Day_Key DESC, 
				   CASE 	WHEN x.Customer_Source_Key = 4 THEN 1
				   	WHEN x.Customer_Source_Key = 6 THEN 2
					WHEN x.Customer_Source_Key = 16 THEN 3
				   	WHEN x.Customer_Source_Key = 2 THEN 4
					WHEN x.Customer_Source_Key = 12 THEN 5
					ELSE 9 END  ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	--------- 23 -----------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for Store Customers based on First Start Date after event'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

	INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
		Batch_Key,
		Record_Key, 
		Activity_Day_Key,
		Customer_Key,
		Customer_Source_Key,
		Reltio_Customer_ID_CS, 
		Source_Customer_ID, 
		Source_Identifier_ID)
	SELECT	:Batch_ID,
		a.Record_Key, 
		a.Activity_Day_Key,
		COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
		a.Customer_Source_Key,
		COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
		a.Source_Customer_ID,
		a.Source_Identifier_ID 
	FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
	JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x    ON	x.Source_Customer_ID_CS::VARCHAR = a.Source_Customer_ID::VARCHAR --changed to reserved container as part of CCPA
					   	   AND	x.Source_Identifier_ID::VARCHAR = a.Source_Identifier_ID::VARCHAR
						   AND	x.Customer_Source_Key IN ( 2, 4, 6, 12, 16 )
					   	   AND	x.Activity_Day_Key > a.Activity_Day_Key
	WHERE	a.Source_Record_Type_Key IN ( 751, 757, 768, 874, 854 )
	AND	a.Customer_Key <> -2
	AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
	AND	a.Batch_Key = :Batch_ID
	QUALIFY 	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key 
				   ORDER BY x.Activity_Day_Key, 
				   CASE 	WHEN x.Customer_Source_Key = 4 THEN 1
				   	WHEN x.Customer_Source_Key = 6 THEN 2
					WHEN x.Customer_Source_Key = 16 THEN 3
				   	WHEN x.Customer_Source_Key = 2 THEN 4
					WHEN x.Customer_Source_Key = 12 THEN 5
					ELSE 9 END  ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 24 ---------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer_Key for Salesforce'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 2, 3 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

				INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID)
				SELECT	:Batch_ID,
					a.Record_Key, 
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x	  ON	x.Source_Customer_ID_CS::VARCHAR = a.Source_Customer_ID::VARCHAR --changed to reserved container as part of CCPA
									  AND	x.Customer_Source_Key = 17
				WHERE	a.Source_Record_Type_Key IN ( 894, 896, 900, 918, 924 )
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key DESC ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 25 ---------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer_Key for Web Leads'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 2, 3 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

				INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID,
					Source_Identifier_ID)
				SELECT	:Batch_ID,
					a.Record_Key, 
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID, a.Source_Identifier_ID
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x ON	x.Source_Customer_ID_CS::VARCHAR = a.Source_Customer_ID::VARCHAR --changed to reserved container as part of CCPA
									  AND	x.Customer_Source_Key = 14
				WHERE	a.Source_Record_Type_Key = 897
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY a.Activity_Day_Key DESC ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 26 ---------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer_Key for Phone - Salesforce'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 2, 3 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

				INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID)
				SELECT	:Batch_ID,
					a.Record_Key, 
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef	a
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_Phone_XRef p	ON	p.Phone_Number = a.Source_Customer_ID --changed to reserved container as part of CCPA
										AND	p.Customer_Source_Key = 17
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x    	ON	x.Source_Customer_ID_CS::VARCHAR = p.Source_Customer_ID::VARCHAR --changed to reserved container as part of CCPA
								   	   AND	x.Customer_Source_Key = 17
				WHERE	a.Source_Record_Type_Key IN ( 895, 898, 899 )
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key DESC ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 27 ---------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer_Key for Phone - Web Leads'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				/*
				IF Batch_ID IN ( 1, 2, 3 ) THEN

					SET	SQL_Statement = Activity_Desc ;
					SET	Count_Last = 0;

					INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
						Batch_Key,
						Record_Key, 
						Activity_Day_Key,
						Customer_Key,
						Customer_Source_Key,
						Reltio_Customer_ID_CS, 
						Source_Customer_ID)
					SELECT	:Batch_ID,
						a.Record_Key, 
						a.Activity_Day_Key,
						COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
						a.Customer_Source_Key,
						COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
						a.Source_Customer_ID
					FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef	a
					JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_Phone_XRef p   ON	p.Phone_Number = a.Source_Customer_ID --changed to reserved container as part of CCPA
										    AND	p.Customer_Source_Key = 14
					JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x	    ON	x.Source_Customer_ID_CS = a.Source_Customer_ID --changed to reserved container as part of CCPA
										    AND	x.Customer_Source_Key = 14
					WHERE	a.Source_Record_Type_Key IN ( 895, 898, 899 )
					AND	a.Customer_Key <> -2
					AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
					AND	a.Batch_Key = :Batch_ID
					QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY a.Activity_Day_Key ) = 1 ;

					SET	Count_Last = COALESCE ( SQLROWCOUNT , 0 ) ;

				END IF;*/--Commented as part of web leads decommision
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 28 -------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Key for Phone - Fact Retail Activities   '';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 2, 3 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				INSERT INTO CUSTOMERS.Customers_Staging.Customer_Assignments (
				Batch_Key,
				Record_Key,
				Activity_Day_Key,
				Customer_Key,
				Customer_Source_Key,
				Reltio_Customer_ID_CS,
				Source_Customer_ID,
				Source_Identifier_ID)
				SELECT
					:Batch_ID,
					a.Record_Key,
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID,
					a.Source_Identifier_ID
				FROM
					CUSTOMERS.Customers_Staging.Activity_Customer_XRef a
				JOIN
						CUSTOMERS.Customers_Reserved_Views.Customer_Phone_XRef p	ON	p.Phone_Number = a.Source_Customer_ID --changed to reserved container as part of CCPA
										AND	p.Customer_Source_Key IN ( 2, 4, 6, 12, 16 )
				JOIN
						CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x    	ON	x.Source_Customer_ID_CS::VARCHAR = p.Source_Customer_ID::VARCHAR --changed to reserved container as part of CCPA
									   	AND	x.Source_Identifier_ID = p.Source_Identifier_ID
										AND	x.Customer_Source_Key IN ( 2, 4, 6, 12, 16 )
				WHERE	a.Source_Record_Type_Key IN ( 895, 898, 899 )
				AND	a.Customer_Key <> -2
				AND	a.Batch_Key = :Batch_ID
				QUALIFY
					ROW_NUMBER () OVER ( PARTITION BY a.Record_Key
							   ORDER BY x.Activity_Day_Key DESC NULLS LAST, CASE
						WHEN x.Customer_Source_Key = 4
							THEN 1
						WHEN x.Customer_Source_Key = 6
							THEN 2
						WHEN x.Customer_Source_Key = 16
							THEN 3
						WHEN x.Customer_Source_Key = 2
							THEN 4
						WHEN x.Customer_Source_Key = 12
							THEN 5
							ELSE 9
					END) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 29 -------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for Store and CARS Credit Customers'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 8 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

				INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Activity_Key,
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID, 
					Source_Identifier_ID)
				SELECT	a.Activity_Key,
					:Batch_ID AS Batch_Key,
					a.Record_Key,
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID,
					a.Source_Identifier_ID 
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x  	ON  x.Activity_Key = a.Activity_Key --changed to reserved container as part of CCPA
									   	AND x.Customer_Source_Key IN (5,6)
				WHERE	a.Source_Record_Type_Key IN ( 778, 779 )
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 30 -------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for eFinance Customers'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 8 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

			INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Activity_Key,
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID, 
					Source_Identifier_ID)
				SELECT	a.Activity_Key,
					:Batch_ID AS Batch_Key,
					a.Record_Key,
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID,
					a.Source_Identifier_ID 
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x  ON	x.Activity_Key = a.Activity_Key --changed to reserved container as part of CCPA
									   AND	x.Customer_Source_Key = 7
				WHERE	a.Source_Record_Type_Key = 787
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 31 -------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for Finance First Customers'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 8 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

				INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Activity_Key,
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID, 
					Source_Identifier_ID)
				SELECT	a.Activity_Key,
					:Batch_ID AS Batch_Key,
					a.Record_Key,
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID,
					a.Source_Identifier_ID 
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x  ON	x.Activity_Key = a.Activity_Key --changed to reserved container as part of CCPA
									   AND	x.Customer_Source_Key = 8
				WHERE	a.Source_Record_Type_Key = 788
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	------- 32 -------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Customer Assignments for Easy Shop Customers'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				IF (Batch_ID IN ( 1, 8 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;

				INSERT	INTO CUSTOMERS.Customers_Staging.Customer_Assignments ( 
					Activity_Key,
					Batch_Key,
					Record_Key, 
					Activity_Day_Key,
					Customer_Key,
					Customer_Source_Key,
					Reltio_Customer_ID_CS, 
					Source_Customer_ID, 
					Source_Identifier_ID)
				SELECT	a.Activity_Key,
					:Batch_ID AS Batch_Key,
					a.Record_Key,
					a.Activity_Day_Key,
					COALESCE(x.Customer_Key_Golden, -1) AS Customer_Key,
					a.Customer_Source_Key,
					COALESCE(x.Reltio_Customer_Golden_CS, ''NA'' ) AS Reltio_Customer_ID_CS,
					a.Source_Customer_ID,
					a.Source_Identifier_ID 
				FROM	CUSTOMERS.Customers_Staging.Activity_Customer_XRef a 
				JOIN	CUSTOMERS.Customers_Reserved_Views.Customer_XRef_Master x  	ON	x.Activity_Key = a.Activity_Key --changed to reserved container as part of CCPA
									   	AND	x.Customer_Source_Key = 9
				WHERE	a.Source_Record_Type_Key IN (778,789)
				AND	a.Customer_Key <> -2
				AND	a.Record_Key NOT IN ( SELECT Record_Key FROM CUSTOMERS.Customers_Staging.Customer_Assignments )
				AND	a.Batch_Key = :Batch_ID
				QUALIFY	ROW_NUMBER () OVER ( PARTITION BY a.Record_Key ORDER BY x.Activity_Day_Key ) = 1 ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 33 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update with Customer_Key from Customer_Assignments'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS a
				SET
					a.Customer_Key = x.Customer_Key,
					a.Customer_Source_Key = x.Customer_Source_Key
				FROM
					CUSTOMERS.Customers_Staging.Customer_Assignments x
	WHERE	a.Record_Key = x.Record_Key
	AND	a.Batch_Key = :Batch_ID
	AND	x.Batch_Key = :Batch_ID;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 33 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update Customer_Key_Original - Non-Salesforce'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS a
				SET
					a.Customer_Key_Original = x.Customer_Key,
					a.Customer_Interaction_Key = x.Customer_Interaction_Key,
					a.Originated_Journey_Flag = x.Originated_Journey_Flag
				FROM
					CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
	WHERE	a.Batch_Key = :Batch_ID
	AND	a.Customer_Key_Original = -1
	AND	a.Source_Record_Type_Key NOT IN ( 866, 894, 897, 900, 918, 924 )
	AND	a.Source_Record_Type_Key = x.Source_Record_Type_Key
	AND	a.Source_Record_Key = x.Source_Record_Key
	AND	a.Source_Customer_ID = x.Source_Customer_ID
	AND	a.Source_Identifier_ID = x.Source_Identifier_ID;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 33 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update Customer_Key_Original - Non-Salesforce'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS a
				SET
					a.Customer_Key_Original = x.Customer_Key,
					a.Customer_Interaction_Key = x.Customer_Interaction_Key,
					a.Originated_Journey_Flag = x.Originated_Journey_Flag
				FROM
					CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef x --changed to reserved container as part of CCPA
	WHERE	a.Batch_Key = :Batch_ID
	AND	a.Customer_Key_Original = -1
	AND	a.Source_Record_Type_Key IN ( 866, 894, 897, 900, 918, 924 )
	AND	a.Source_Record_Type_Key = x.Source_Record_Type_Key
	AND	a.Source_Record_Key = x.Source_Record_Key;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	--====== 34 ===================================================================================================================================================
	-- Set other attributes
	--------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update Target with Address_Key for Activity Date'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS c
				SET
					c.Activity_Date_Household_Key = a.Customer_Household_Key,
					c.Activity_Date_Residence_Key = a.Customer_Residence_Key,
					c.Possible_Business_Flag = a.Possible_Business_Flag
				FROM
					(
						SELECT
							x.Customer_Key,
							a.Customer_Residence_Key,
							a.Customer_Household_Key,
							CASE
								WHEN a.Customer_Type_Key = 68
									THEN ''Y'' ELSE ''N''
							END AS Possible_Business_Flag
						FROM
							CUSTOMERS.Customers_Staging.Activity_Customer_XRef x
						JOIN
								CUSTOMERS.Customers_Reserved_Views.Customer_Address_XRef a  ON	a.Customer_Key = x.Customer_Key --changed to reserved container as part of CCPA
						WHERE	a.Effective_Date <= DATAOPS.UTILITIES.INT_TO_DATE_UDF(x.Activity_Day_Key - 19000000) 
						AND	x.Batch_Key = :Batch_ID
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY	x.Customer_Key
								  	  ORDER BY 	a.Effective_Date, Source_Update_TS DESC NULLS LAST) = 1
					) a
	WHERE	c.Customer_Key = a.Customer_Key
	AND	c.Batch_Key = :Batch_ID
	AND	c.Activity_Date_Residence_Key <> a.Customer_Residence_Key ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 35 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Suspect_Relationship_Flag - Credit'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				IF (Batch_ID IN ( 1, 8)) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS a
					SET
						a.Suspect_Relationship_Flag = ''Y''
					FROM
						(
							SELECT
								x.Source_Record_Type_Key,
								x.Source_Record_Key,
								x.Activity_Key
									--x.Suspect_Relationship_Flag,
									--x.Customer_Key, c.Name_First, c.Name_Last, 
									--o.Name_First AS Order_Name_First, o.Name_Last AS Order_Name_Last
								FROM
								CUSTOMERS.Customers_Staging.Activity_Customer_XRef x
								JOIN
									CUSTOMERS.Customers_Reserved_Views.Customers c	   	ON  c.Customer_Key = x.Customer_Key --changed to reserved container as part of CCPA
														AND x.Customer_Key > 0
								JOIN
									CUSTOMERS.Customers_Reserved_Views.Credit_Customers o	ON  o.Credit_Customer_Key = x.Activity_Key --changed to reserved container as part of CCPA
								WHERE	x.Customer_Source_Key = 6
								AND	x.Source_Record_Type_Key IN (778,779)
								AND REPLACE(o.Name_Last, '' '') <> REPLACE(c.Name_Last, '' '')
								AND SUBSTRING(c.Name_Last, 1, 3) <> SUBSTRING(TRIM(o.Name_Last), 1, 3)
								AND SUBSTRING(c.Name_First, 1, 3) <> SUBSTRING(TRIM(o.Name_First), 1, 3)
								AND	TRIM(o.Name_First) <> c.Name_Last
								AND	TRIM(o.Name_Last) <> c.Name_First
								AND	POSITION(TRIM(o.Name_Last) IN (c.Name_Last)) = 0
								AND	POSITION(c.Name_Last IN (TRIM(o.Name_Last))) = 0
									QUALIFY
								ROW_NUMBER() OVER ( PARTITION BY x.Source_Record_Type_Key, x.Source_Record_Key, x.Activity_Key
												  ORDER BY NULL ) = 1
						) s
					WHERE	a.Source_Record_Type_Key IN (778,779)
					AND	a.Source_Record_Type_Key = s.Source_Record_Type_Key
					AND	a.Source_Record_Key = s.Source_Record_Key
					AND	a.Activity_Key = s.Activity_Key
					AND	a.Suspect_Relationship_Flag <> ''Y''
					AND 	a.Batch_Key = :Batch_ID;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 36 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Suspect_Relationship_Flag - Orders'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				IF (Batch_ID IN ( 1, 4, 10 )) THEN
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS a
					SET
						a.Suspect_Relationship_Flag = ''Y''
					FROM
						(
									SELECT
								x.Source_Record_Type_Key,
								x.Source_Record_Key,
								x.Activity_Key
											--x.Suspect_Relationship_Flag,
											--x.Customer_Key, c.Name_First, c.Name_Last, 
											--o.Name_First AS Order_Name_First, o.Name_Last AS Order_Name_Last
										FROM
								CUSTOMERS.Customers_Staging.Activity_Customer_XRef x
										JOIN
									CUSTOMERS.Customers_Reserved_Views.Customers c	   	ON  c.Customer_Key = x.Customer_Key --changed to reserved container as part of CCPA
																AND x.Customer_Key > 0
										JOIN
									CUSTOMERS.Customers_Reserved_Views.Order_Customers o	ON  o.Order_Customer_Key = x.Activity_Key --changed to reserved container as part of CCPA
										WHERE	x.Customer_Source_Key = 4
										AND	x.Source_Record_Type_Key = 481
										AND REPLACE(o.Name_Last, '' '') <> REPLACE(c.Name_Last, '' '')
										AND SUBSTRING(c.Name_Last, 1, 3) <> SUBSTRING(TRIM(o.Name_Last), 1, 3)
										AND SUBSTRING(c.Name_First, 1, 3) <> SUBSTRING(TRIM(o.Name_First), 1, 3)
										AND	TRIM(o.Name_First) <> c.Name_Last
										AND	TRIM(o.Name_Last) <> c.Name_First
										AND	POSITION(TRIM(o.Name_Last) IN (c.Name_Last)) = 0
										AND	POSITION(c.Name_Last IN (TRIM(o.Name_Last))) = 0
									QUALIFY
								ROW_NUMBER() OVER ( PARTITION BY x.Source_Record_Type_Key, x.Source_Record_Key, x.Activity_Key
												  ORDER BY NULL ) = 1
						) s
					WHERE	a.Source_Record_Type_Key = 481
					AND	a.Source_Record_Type_Key = s.Source_Record_Type_Key
					AND	a.Source_Record_Key = s.Source_Record_Key
					AND	a.Activity_Key = s.Activity_Key
					AND	a.Suspect_Relationship_Flag <> ''Y''
					AND 	a.Batch_Key = :Batch_ID;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 37 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Confirm that no column is null'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				CUSTOMERS.Customers_Staging.Activity_Customer_XRef
		WHERE (	Activity_Key IS NULL
		OR	Activity_Date_Household_Key IS NULL
		OR	Activity_Date_Residence_Key IS NULL
		OR	Activity_Day_Key IS NULL
		OR	Customer_Key IS NULL
		OR	Customer_Source_Key IS NULL
		OR	Location_Key IS NULL
		OR	Source_Record_Key IS NULL
		OR	Source_Record_Type_Key IS NULL
		OR	Todays_Household_Key IS NULL
		OR	Todays_Residence_Key IS NULL
		OR	Activity_TS_UTC IS NULL
		OR	Originated_Journey_Flag IS NULL
		OR	Possible_Business_Flag IS NULL
		OR	Primary_Customer_Flag IS NULL
		OR	Source_Customer_ID IS NULL
		OR	Source_Identifier_ID IS NULL
		OR	Suspect_Relationship_Flag IS NULL
		OR	Uses_DST_Flag IS NULL
		OR	UTC_Offset_Standard IS NULL )
		AND	Batch_Key = :Batch_ID ;
				Count_Last := COALESCE ( :Record_Count , 0 );
				IF (Count_Last > 0) THEN
				Error_Condition := 2;
				Error_Count := Error_Count +1;
				SQL_Return_Code := SQLCODE;
				--SQL_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition, Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_ID, :Error_Condition , :Database_Stage, :SQL_Return_Code, :SQL_State_Code, :SQL_Statement);
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc || '' ERROR'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced );
				RAISE Planned_Exception;
				END IF;

	----- 38 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Get Target Count'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				CUSTOMERS.Customers_Staging.Activity_Customer_XRef
		WHERE	Batch_Key = :Batch_ID ;
				Count_Target := COALESCE ( :Record_Count, 0 );
				IF (Count_Target = 0) THEN
				Error_Count := Error_Count + 1;
				END IF;

	----- 39 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Customer Key when customer is not known'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS c
				SET
					c.Customer_Key = -2
	WHERE	TRIM(Source_Customer_ID) IN ( ''-1'', ''0'', '''', ''NA'' )
	AND	Customer_Key <> -2
	AND	Batch_Key = :Batch_ID ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 40 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Customer Key when New Activity and customer is known'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS c
				SET
					c.Customer_Key = -3
				FROM
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d
	WHERE	c.Customer_Key = -1
	AND	d.Calendar_Date >= CURRENT_DATE() -1
	AND	c.Activity_Day_Key = d.Calendar_By_Day_Key
	AND	c.Batch_Key = :Batch_ID ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 41 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Customer Key when customer is a Phone Number'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers_Staging.Activity_Customer_XRef AS c
				SET
					c.Customer_Key = -4
	WHERE	Customer_Key <> -4
	AND	Customer_Source_Key = 19
	AND	POSITION(''-'' IN (Source_Customer_ID)) > 0
	AND	Batch_Key = :Batch_ID ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 42-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Merge records with a Source Customer ID for non-Salesforce sources'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				Count_Last := 0;
				IF (Error_Count = 0) THEN
				SQL_Statement := ACtivity_Desc;
				MERGE INTO CUSTOMERS.Customers.Activity_Customer_XRef AS t
				USING (
					SELECT
						Activity_Key,
						Activity_Date_Household_Key,
						Activity_Date_Residence_Key,
						Activity_Day_Key,
						Customer_Key,
						CASE
									WHEN Customer_Key = Customer_Key_Original
								THEN Customer_Interaction_Key
						     ELSE -1
						END AS Customer_Interaction_Key,
						Customer_Source_Key,
						Location_Key,
						Source_Record_Key,
						Source_Record_Type_Key,
						Todays_Household_Key,
						Todays_Residence_Key,
						Activity_TS,
						Activity_TS_UTC,
						CASE
									WHEN Customer_Key = Customer_Key_Original
								THEN Originated_Journey_Flag
						     ELSE ''N''
						END AS Originated_Journey_Flag,
						Possible_Business_Flag,
						Primary_Customer_Flag,
						Source_Customer_ID,
						Source_Identifier_ID,
						Suspect_Relationship_Flag,
						Uses_DST_Flag,
						UTC_Offset_Standard
					FROM
						CUSTOMERS.Customers_Staging.Activity_Customer_XRef
					WHERE	Batch_Key = :Batch_ID
					AND	Source_Record_Type_Key NOT IN ( 866, 894, 897, 900, 918, 924 )
					) AS s ON s.Source_Record_Type_Key = t.Source_Record_Type_Key
				AND	s.Source_Record_Key = t.Source_Record_Key
				AND	s.Source_Customer_ID = t.Source_Customer_ID
				AND	s.Source_Identifier_ID = t.Source_Identifier_ID
				WHEN	MATCHED THEN UPDATE
				SET	Activity_Date_Household_Key = s.Activity_Date_Household_Key,
					Activity_Date_Residence_Key = s.Activity_Date_Residence_Key,
					Activity_Day_Key = s.Activity_Day_Key,
					Customer_Key = s.Customer_Key,
					Customer_Interaction_Key = s.Customer_Interaction_Key,
					Activity_TS_UTC = s.Activity_TS_UTC,
					Customer_Source_Key = s.Customer_Source_Key,
					Location_Key = s.Location_Key,
					Todays_Household_Key = s.Todays_Household_Key,
					Todays_Residence_Key = s.Todays_Residence_Key,
					Originated_Journey_Flag = s.Originated_Journey_Flag,
					Possible_Business_Flag = s.Possible_Business_Flag,
					Primary_Customer_Flag = s.Primary_Customer_Flag,
					Suspect_Relationship_Flag = COALESCE(s.Suspect_Relationship_Flag, ''N''),
					Uses_DST_Flag = s.Uses_DST_Flag,
					UTC_Offset_Standard = s.UTC_Offset_Standard,
					DW_Update_TS = CURRENT_TIMESTAMP ( 0 )
				WHEN	NOT MATCHED THEN
					INSERT
					( Activity_Key, Activity_Date_Household_Key, Activity_Date_Residence_Key,
					Activity_Day_Key, Customer_Key, Customer_Interaction_Key, Customer_Source_Key,
					Location_Key, Source_Record_Key, Source_Record_Type_Key,
					Todays_Household_Key, Todays_Residence_Key, Activity_TS_UTC,
					Possible_Business_Flag, Primary_Customer_Flag,
					Source_Customer_ID, Source_Identifier_ID, Suspect_Relationship_Flag,
					Uses_DST_Flag, UTC_Offset_Standard,
					DW_Insert_TS, DW_Update_TS )
					VALUES (s.Activity_Key, s.Activity_Date_Household_Key, s.Activity_Date_Residence_Key,
					s.Activity_Day_Key, s.Customer_Key, s.Customer_Interaction_Key, s.Customer_Source_Key,
					s.Location_Key, s.Source_Record_Key, s.Source_Record_Type_Key,
					s.Todays_Household_Key, s.Todays_Residence_Key, s.Activity_TS_UTC,
					s.Possible_Business_Flag, s.Primary_Customer_Flag,
					s.Source_Customer_ID, s.Source_Identifier_ID, COALESCE(s.Suspect_Relationship_Flag,''N''),
					s.Uses_DST_Flag, s.UTC_Offset_Standard,
					CURRENT_TIMESTAMP(0), CURRENT_TIMESTAMP(0));
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 43-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Merge records with a Source Customer ID for Salesforce Sources'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				Count_Last := 0;
				IF (Error_Count = 0) THEN
				SQL_Statement := ACtivity_Desc;
				MERGE INTO CUSTOMERS.Customers.Activity_Customer_XRef AS t
				USING (
					SELECT
						Activity_Key,
						Activity_Date_Household_Key,
						Activity_Date_Residence_Key,
						Activity_Day_Key,
						Customer_Key,
						CASE
									WHEN Customer_Key = Customer_Key_Original
								THEN Customer_Interaction_Key
						     ELSE -1
						END AS Customer_Interaction_Key,
						Customer_Source_Key,
						Location_Key,
						Source_Record_Key,
						Source_Record_Type_Key,
						Todays_Household_Key,
						Todays_Residence_Key,
						Activity_TS,
						Activity_TS_UTC,
						CASE
									WHEN Customer_Key = Customer_Key_Original
								THEN Originated_Journey_Flag
						     ELSE ''N''
						END AS Originated_Journey_Flag,
						Possible_Business_Flag,
						Primary_Customer_Flag,
						Source_Customer_ID,
						Source_Identifier_ID,
						Suspect_Relationship_Flag,
						Uses_DST_Flag,
						UTC_Offset_Standard
					FROM
						CUSTOMERS.Customers_Staging.Activity_Customer_XRef
					WHERE	Batch_Key = :Batch_ID
					AND	Source_Record_Type_Key IN ( 866, 894, 897, 900, 918, 924 )
					) AS s ON s.Source_Record_Type_Key = t.Source_Record_Type_Key
				AND	s.Source_Record_Key = t.Source_Record_Key
				WHEN	MATCHED THEN UPDATE
				SET	Activity_Date_Household_Key = s.Activity_Date_Household_Key,
					Activity_Date_Residence_Key = s.Activity_Date_Residence_Key,
					Activity_Day_Key = s.Activity_Day_Key,
					Customer_Key = s.Customer_Key,
					Customer_Interaction_Key = s.Customer_Interaction_Key,
					Activity_TS_UTC = s.Activity_TS_UTC,
					Customer_Source_Key = s.Customer_Source_Key,
					Location_Key = s.Location_Key,
					Todays_Household_Key = s.Todays_Household_Key,
					Todays_Residence_Key = s.Todays_Residence_Key,
					Originated_Journey_Flag = s.Originated_Journey_Flag,
					Possible_Business_Flag = s.Possible_Business_Flag,
					Primary_Customer_Flag = s.Primary_Customer_Flag,
					Source_Customer_ID = s.Source_Customer_ID,
					Source_Identifier_ID = s.Source_Identifier_ID,
					Suspect_Relationship_Flag = COALESCE(s.Suspect_Relationship_Flag, ''N''),
					Uses_DST_Flag = s.Uses_DST_Flag,
					UTC_Offset_Standard = s.UTC_Offset_Standard,
					DW_Update_TS = CURRENT_TIMESTAMP ( 0 )
				WHEN	NOT MATCHED THEN
					INSERT
					( Activity_Key, Activity_Date_Household_Key, Activity_Date_Residence_Key,
					Activity_Day_Key, Customer_Key, Customer_Interaction_Key, Customer_Source_Key,
					Location_Key, Source_Record_Key, Source_Record_Type_Key,
					Todays_Household_Key, Todays_Residence_Key, Activity_TS_UTC,
					Possible_Business_Flag, Primary_Customer_Flag,
					Source_Customer_ID, Source_Identifier_ID, Suspect_Relationship_Flag,
					Uses_DST_Flag, UTC_Offset_Standard,
					DW_Insert_TS, DW_Update_TS )
					VALUES (s.Activity_Key, s.Activity_Date_Household_Key, s.Activity_Date_Residence_Key,
					s.Activity_Day_Key, s.Customer_Key, s.Customer_Interaction_Key, s.Customer_Source_Key,
					s.Location_Key, s.Source_Record_Key, s.Source_Record_Type_Key,
					s.Todays_Household_Key, s.Todays_Residence_Key, s.Activity_TS_UTC,
					s.Possible_Business_Flag, s.Primary_Customer_Flag,
					s.Source_Customer_ID, s.Source_Identifier_ID, COALESCE(s.Suspect_Relationship_Flag,''N''),
					s.Uses_DST_Flag, s.UTC_Offset_Standard,
					CURRENT_TIMESTAMP(0), CURRENT_TIMESTAMP(0));
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 44 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Customer Key when Customer Key is not known and no longer new'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers.Activity_Customer_XRef AS c
				SET
					c.Customer_Key = -1,
					c.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d
	WHERE	c.Customer_Key = -3
	AND	d.Calendar_Date < CURRENT_DATE() -1
	AND	c.Activity_Day_Key = d.Calendar_By_Day_Key
	AND	c.Customer_Key <> -1 ;

	----- 45 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Customer Key when new customer today not yet received'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers.Activity_Customer_XRef AS c
				SET
					c.Customer_Key = -3,
					c.DW_Update_TS = CURRENT_TIMESTAMP(0)
				FROM
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d
	WHERE	c.Customer_Key = -1
	AND	d.Calendar_Date >= CURRENT_DATE() -1
	AND	c.Activity_Day_Key = d.Calendar_By_Day_Key
	AND	c.Customer_Key <> -3 ;

	----- 46 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Set Customer Key when new customer today not yet received'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				UPDATE CUSTOMERS.Customers.Activity_Customer_XRef AS c
				SET
					c.Customer_Key = -2,
					c.DW_Update_TS = CURRENT_TIMESTAMP(0)
	WHERE	TRIM(Source_Customer_ID) IN ( ''-1'', ''0'', '''', ''NA'' )
	AND	Customer_Key <> -2 ;

	------- 47 -------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Update Target with Todays_Address_Key'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
				SQL_Statement := Activity_Desc;
				Count_Last := 0;
				UPDATE CUSTOMERS.Customers.Activity_Customer_XRef AS x
				SET
					x.Todays_Residence_Key = a.Customer_Residence_Key,
					x.Todays_Household_Key = a.Customer_Household_Key,
					x.DW_UPDATE_TS = CURRENT_TIMESTAMP(0)
				FROM
					CUSTOMERS.CUSTOMERS.Customer_Address_Today a --changed to reserved container as part of CCPA
	WHERE	x.Customer_Key = a.Customer_Key
	AND	x.Todays_Residence_Key <> a.Customer_Residence_Key ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 48 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Delete Transfers that are now Invalid'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				IF (Run_Now = ''Y'') THEN
				SQL_Statement := Activity_Desc;
				DELETE	
				FROM	CUSTOMERS.Customers.Activity_Customer_XRef c
				WHERE	Source_Record_Type_Key IN ( 757, 854 )
				AND	Source_Record_Key IN (
					SELECT	Transfer_Master_Key
					FROM	SALES.Sales_Views.Transfer_ID_Master
					WHERE	Invalid_Transfer_Flag = ''Y'' ) ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 49 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Mark Customers Inactive'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				IF (Run_Now = ''Y'') THEN
				SQL_Statement := Activity_Desc;

				UPDATE	CUSTOMERS.Customers.Customers c
				SET	Active_Flag = ''N'',
					DW_Update_TS = CURRENT_TIMESTAMP(0)
				WHERE	Active_Flag = ''Y''
				AND	Customer_Key NOT IN ( 
					SELECT	Customer_Key
					FROM	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef --changed to reserved container as part of CCPA
					) ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 50 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Mark Customers Active'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				IF (Run_Now = ''Y'') THEN
				SQL_Statement := Activity_Desc;

				UPDATE	CUSTOMERS.Customers.Customers c
				SET	Active_Flag = ''Y'',
					DW_Update_TS = CURRENT_TIMESTAMP(0)
				WHERE	Active_Flag = ''N''
				AND	Customer_Key IN (
					SELECT	Customer_Key
					FROM	CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef --changed to reserved container as part of CCPA
					) ;
				Count_Last := COALESCE ( SQLROWCOUNT , 0 );
				END IF;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);

	----- 51 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Delete the duplicate records created by Logistics/Transfers DM'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				DELETE FROM
				CUSTOMERS.Customers.Activity_Customer_XRef
				WHERE
				source_customer_id = ''NA''
			AND (source_record_key, source_record_type_key)
		                                                IN
	(	SELECT source_Record_Key,source_record_type_key
	FROM CUSTOMERS.Customers_Reserved_Views.Activity_Customer_XRef
	WHERE Primary_Customer_Flag = ''Y''
	AND source_record_type_key = 854
	GROUP BY 1,2 HAVING COUNT(*) > 1

     );
	INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
	----- 52 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	IF (Error_Count = 0) THEN
				Activity_Desc := ''Delete staging records'';
				Step_ID := Step_ID + 1;
				INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := ''DELETE FROM
   Customer_Assignments'';
				DELETE FROM
					CUSTOMERS.Customers_Staging.Customer_Assignments
				WHERE
					Batch_Key = :Batch_ID;
				SQL_Statement := ''DELETE FROM
   Activity_Customer_XRef'';
				DELETE FROM
					CUSTOMERS.Customers_Staging.Activity_Customer_XRef
				WHERE
					Batch_Key = :Batch_ID;
	END IF;

	----- 53 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Insert Metadata Table_Controls record'';
	Step_ID := Step_ID + 1;
	INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
	SQL_Statement := Activity_Desc;
	INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
	Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
	Process_Status_Key,
	Balanced_Flag,
	Destination_Database, Destination_Table_Name,
	Error_Detail_Description,
	Source_Server, Source_Database, Source_Table_Name,
	Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
	Source_Aggregate_Amount, Source_Record_Count)
	VALUES (:Batch_Number, :Calendar_Key , :Process_ID , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
	END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
	END,
	:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Source and Target Record Counts do not agree'' ELSE ''NA''
	END,
	''Teradata'', :Database_Source , :Table_Source ,
	0 , :Count_Target , :Error_Count ,
	0 , :Count_Source);

	----- 54 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''****  Complete  ****'';
	Completed_Flag := ''Y'';
	Step_ID := Step_ID + 1;
	INSERT INTO CUSTOMERS.Customers_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target, :Step_ID);
	CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced );
	Out_Error_Count := Error_Count;
	Out_Hard_Stop_Error := 0;
	Out_Records_Loaded := Count_Target;
		END;

		Final_Output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
		RETURN :Final_Output;
	EXCEPTION
	When Planned_Exception then
		
		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
		VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
		
		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED);
    
	When OTHER then

		Error_Count := Error_Count +1 ;
		Error_Condition := 9999 ;
		Out_Error_Count := Error_Count ;
		Out_Hard_Stop_Error := 1 ;
		Out_Records_Loaded := Count_Last ;
		
		INSERT INTO sales.Edw_Stage.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	
		VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ;

		INSERT 	INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
		VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
		
		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED);
    
END;
';