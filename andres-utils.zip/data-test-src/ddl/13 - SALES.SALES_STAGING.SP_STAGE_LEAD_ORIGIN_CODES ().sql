CREATE OR REPLACE PROCEDURE "SP_STAGE_LEAD_ORIGIN_CODES"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-02		By: Gbalasundaram
		Purpose: Stage Lead Origins

	call	sales.Sales_Staging.sp_Stage_Lead_Origin_Codes (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------
		2020-10-09		prasanna	web leads decommisioning changes in lines 145 - 149 and 206 - 211 

	*****************************************************************************************************************************************************************************/
	--Output parameters
        Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 
Final_output OBJECT;
Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

-- Custom Procedure Variables
		Count_Exceptions		SMALLINT := 0; -- Number Of Surrogate Key Exceptions Encountered

		Record_Type_Key		SMALLINT := 0; -- Holder For Source_Record_Type_Key

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	BEGIN

		Activity_Name := ''sp_Stage_Lead_Origin_Codes'';
		Code_Lines := 453;
		Database_Source := ''Sales_Landing'';
		Database_Stage := ''Sales_Staging'';
		Database_Target := ''Sales'';
		Process_Id := 458;
		Record_Type_Key := 0;
		Table_Source := ''Web_Leads'';
		Table_Stage := ''Lead_Origin_Codes'';
		Table_Target := ''Lead_Origin_Codes'';
		Version := 1.1;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;


--	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	P1:
		-- Start Of Procedural Steps With Exception Handler
		BEGIN
	--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL dataops.Metadata_Controls.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;

	---------- 1 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
		(
					SELECT DISTINCT Origin,
						Origin_Page
					FROM
						sales.Sales_Landing.Web_Leads
					WHERE	Origin IS NOT NULL
			UNION
					SELECT DISTINCT Origin,
						SUBSTR(''NA'' ,0,20)    AS Origin_page
					FROM
						sales.Sales_Landing.sf_Lead
					WHERE	Origin IS NOT NULL
		)A ;
			Count_Source := COALESCE ( :Record_Count , 0 );
			IF (Count_Source = 0) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL dataops.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;
				RAISE Planned_Exception ;
			ELSE
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				sales.Sales_Staging.Lead_Origin_Codes;

	----------- 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO sales.Sales_Staging.Lead_Origin_Codes (Lead_Origin,
				Lead_Origin_Page,
				Dw_Insert_Ts)
			SELECT DISTINCT SUBSTR(Origin,0,40),
				COALESCE( Origin_Page , ''NA''),
				CURRENT_TIMESTAMP(0)
			FROM
				sales.Sales_Landing.Web_Leads
			WHERE	Origin IS NOT NULL
	UNION
			SELECT DISTINCT SUBSTR(Origin,0,40),
				SUBSTR(''NA'' ,0,20)    AS Origin_page,
				CURRENT_TIMESTAMP(0)
			FROM
				sales.Sales_Landing.Sf_lead
			WHERE	Origin IS NOT NULL;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------- 4 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			Record_Count := 0;


--	LOCK ROW FOR ACCESS
			SELECT
				COUNT (*) INTO
				:Record_Count
		FROM
				sales.Sales_Staging.Lead_Origin_Codes;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF (( Count_Source <> Count_Stage )) THEN
				Sql_Statement :=
 				                
 				                ''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO dataops.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO dataops.Metadata_Controls.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''Na''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL dataops.Metadata_Controls.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				RAISE Planned_Exception ;
			ELSE
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	----------- 5 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Records That Already Exist In The Target'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE sales.Sales_Staging.Lead_Origin_Codes AS S
				SET
					S.Lead_Origin_Key = T.Lead_Origin_Key
				FROM
					sales.Sales_Views.Lead_Origin_Codes T
	WHERE 	S.Lead_Origin = T.Lead_Origin
	AND 	S.Lead_Origin_Page = T.Lead_Origin_Page;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	------ 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Identify Max Lead_Interest_Key In ''|| Database_Target || ''.'' || Table_Target;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;


--	LOCK ROW FOR ACCESS
			SELECT
				MAX ( Lead_Origin_Key ) INTO
				:Last_Record_Key
		FROM
				sales.Sales_Views.Lead_Origin_Codes;
			Last_Record_Key := COALESCE ( :Last_Record_Key , 0 );
			IF (Last_Record_Key = 0) THEN
				Activity_Desc :=
 				                
 				                ''Insert Default Record Into ''|| Database_Target || ''.'' || Table_Target;
				Step_Id := Step_Id + 1;
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				INSERT INTO sales.Sales.Lead_Origin_Codes (Lead_Origin_Key, Lead_Origin, Lead_Origin_Page, Dw_Insert_Ts)
				VALUES (-1, ''NA'', ''NA'', CURRENT_TIMESTAMP(0));
				Count_Target := COALESCE ( SQLROWCOUNT , 0 );
			END IF;

	------ 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Insert  Into ''|| Database_Target || ''.'' || Table_Target || '' From '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			INSERT INTO sales.sales.Lead_Origin_Codes (Lead_Origin_Key,
				Lead_Origin,
				Lead_Origin_Page,
				Dw_Insert_Ts)
			SELECT
				:Last_Record_Key + ROW_NUMBER ( ) OVER ( ORDER BY NULL ) AS Lead_Origin_Key,
				Lead_Origin,
				Lead_Origin_Page,
				Dw_Insert_Ts
			FROM
				sales.Sales_Staging.Lead_Origin_Codes
			WHERE 	Lead_Origin_Key = -1;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	--------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Confirm All Rows Were Copied From '' || Database_Stage || ''.'' || Table_Stage || '' To '' || Database_Target || ''.'' || Table_Target;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Record_Count := 0;
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
		(
					SELECT
						S.Lead_Origin,
						S.Lead_Origin_Page
						FROM
						sales.Sales_Staging.Lead_Origin_Codes S
						LEFT  OUTER JOIN
							sales.Sales_Views.Lead_Origin_Codes T
						ON    T.Lead_Origin = S.Lead_Origin
						AND   T.Lead_Origin_Page = S.Lead_Origin_Page
					         WHERE T.Lead_Origin_Key IS NULL
		) Rec_Cnt;
			Count_Last := COALESCE ( :Record_Count , 0 );
			IF (Count_Last > 0) THEN
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO dataops.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Last, :Step_Id);
			ELSE
				Target_Balanced := ''Y'';
			END IF;

	---------- 9 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=
 			                
 			                ''Delete Staged Data If No Errors'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			IF (Target_Balanced = ''Y'' AND COALESCE ( Error_Count, 0 ) = 0) THEN
				Sql_Statement := Activity_Desc;
				DELETE FROM
					sales.Sales_Staging.Lead_Origin_Codes;
			ELSE
				INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, ''Target_Balanced = '' || :Target_Balanced, :Completed_Flag, :Error_Count, :Error_Count, :Step_Id);
			END IF;

	---- 10 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO dataops.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key,
			Balanced_Flag,
			Destination_Database, Destination_Table_Name,
			Error_Detail_Description,
			Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);

	----- 11 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_Id);
			CALL dataops.Metadata_Controls.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Target;
		END;
		RETURN OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
	
	EXCEPTION
    
    WHEN Planned_Exception THEN 
    BEGIN

        INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
        VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
        Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED);
    END;
    
    WHEN OTHER THEN
    BEGIN
        Error_Count := Error_Count +1 ; 
        Error_Condition := 9999 ; 
        Out_Error_Count := Error_Count ; 
        Out_Hard_Stop_Error := 1 ; 
        Out_Records_Loaded := Count_Last ; 
        INSERT INTO SALES.SALES_STAGING.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	 
        VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 
        INSERT 	INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
        VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
        Return object_construct( ''OUT_ERROR_COUNT'', OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', OUT_RECORDS_LOADED); 
    END;

END;
';