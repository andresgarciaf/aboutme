CREATE OR REPLACE PROCEDURE "SP_STAGE_FACT_TOUCHPOINT_DETAILS_APPOINTMENTS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

		/*****************************************************************************************************************************************************************************
			Created: 2019-02-28		By: Veena G
			Purpose: Stage Touchpoint Details for Appointments

			Sample Run Command:
			call	Sales_Staging.sp_Stage_Fact_Touchpoint_Details_Appointments (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		   Modified Date	Modified By	  Notes
			-------------	-----------	 ------------------------------------------------------------------------------------------------------------------------------
			2019-03-18	Maithili N	Modified Customer Activity Code to 530
			2019-04-16	Gayathri   	Replaced Appointment_key population with Touchpoint_Attribute_Key
			2019-05-14	Vignesh S	To Exclude the events which is schedu0led for future
			2019-05-17	Veena		Modified employee_key population logic for machine generated employee_key
			2019-06-14	Veena		Change in Stock_number_key logic
			2019-06-19	Raja		Changed activity_ts_utc date rnage to 6 from 5 years
			2019-10-15	Aravindakshan	changed to reserved container as part of CCPA
			2019-10-06	Veena		Logic change for requested_appointment_ts_utc
			2021-04-22	Vpetluru	Added filter condition to exclude "Home Delivery" appointments in the "Store Appointment" (customer_activity_key = 530)
									at line numbers 145,257
		*****************************************************************************************************************************************************************************/
		-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs
		--DECLARE Database_Temp	VARCHAR(100) ;      	 -- Used To Specify The Database In Temp Table
		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(6); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

		Out_Error_Count SMALLINT := 0; 
		Out_Hard_Stop_Error BYTEINT := 0; 
		Out_Records_Loaded INTEGER := 0; 
		
		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

		Final_Output Object;

	BEGIN

		Activity_Name := ''sp_Stage_Fact_Touchpoint_Details_Appointments'';
		Code_Lines := 595;
		Database_Source := ''Sales_Landing'';
		Database_Stage := ''Sales_Staging'';
		--SET    Database_Temp	=''Sales_Staging'' ;
		Database_Target := ''Sales'';
		Process_Id := 458;
		Table_Source := ''Sf_Event'';
		Table_Stage := ''Fact_Touchpoint_Details_Appointments'';
		Table_Target := ''Fact_Touchpoint_Details_Appointments'';
		Version := 1.8;
		SELECT
			Calendar_By_Day_Key  INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

		-- Start Of Procedural Steps With Exception Handler
		BEGIN
			 

		----------0---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting   ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
			:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
			:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;

		-----------1-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*)	INTO
				:Record_Count
	FROM
				SALES.Sales_Landing.sf_event s
	INNER JOIN
					SALES.edw_salesforce_Reserved_Views.sf_opportunity o --changed to reserved container as part of CCPA
		ON 	s.what_id_cs = o.opportunity_id_cs
	WHERE	s.what_id_cs LIKE ''006%''
		AND	CAST(s.activity_ts_utc AS DATE) - CAST(s.ss_insert_ts_utc AS DATE) <= 6 * 365
		AND	s.what_id_cs IS NOT NULL
		AND COALESCE(s.appointment_type,''NA'') not LIKE ''%Home Delivery%'';
			Count_Source := COALESCE (:Record_Count , 0);
			IF (Count_Source = 0 /*OR SQLSTATE = ''02000''*/) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;
				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;
		-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage Tables'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments;

		----------- 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''INSERT  INTO ''|| Database_stage || ''.'' || Table_Stage || '' FROM '' || Database_Source || ''.'' || Table_Source;
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments (
			Activity_Day_Key,Activity_Minute_Key,
			Appointment_Interests_Key,Customer_Activity_Key,
			Customer_Source_Key,Location_Key,
			Source_Record_Type_Key,Stock_Number_Key,Vehicle_Key,Vehicle_Location_Key,Appointment_Type,
			Activity_Date,Requested_Appointment_TS_UTC,Stock_Number_Hold_Flag,Source_Record_ID,
			Source_Customer_ID,Touchpoint_Begin_TS_UTC,Touchpoint_End_TS_UTC,UTC_Local_Offset,
			Waitlist_Flag,Owner_sf_user_id_cs,Duration_Seconds,
			Source_Insert_TS,Source_Update_TS,EDW_Update_TS,DW_Insert_TS)
			SELECT
				-1 						AS Activity_Day_Key,
				-1 						AS Activity_Minute_Key,
				-1						AS Appointment_Interests_Key,
				530						AS Customer_Activity_Key,
				        17 						AS Customer_Source_key,
				   	CAST(TRUNC(COALESCE(Loc.store_Number,e.Hold_Vehicle_Store_Location,e.store_number ,-1)) AS INTEGER) 
				       							AS location_key,
				        918  						AS Source_Record_Type_Key,
				CAST(TRUNC(COALESCE(CASE
					WHEN e.stock_number = ''None''
						THEN NULL
						ELSE e.stock_number
				END, CASE
					WHEN e.hold_vehicle_stock_number = ''None''
						THEN NULL
						ELSE e.hold_vehicle_stock_number
				END,
					''-1'')) AS INTEGER)  			AS Stock_number_key,
				-1 						AS Vehicle_Key,
				CAST(TRUNC(COALESCE(e.hold_vehicle_store_location,-1))
					AS INTEGER) 				AS Vehicle_Location_Key,
				Appointment_Type					AS Appointment_Type,
				CAST(
				     DATAOPS.UTILITIES.UTC_TO_LOCAL_TS0(e.Activity_Ts_Utc, CASE
					WHEN d.Day_Light_Saving_Time = ''On''
						AND l.Uses_DST_Flag = ''Y''
						THEN COALESCE(l.UTC_Offset_Standard - 1, 0)
				        	ELSE COALESCE(l.UTC_Offset_Standard, 0)
				END)
					AS DATE)				AS Activity_date,
				        NULL						AS Requested_Appointment_TS_UTC,
				        CASE
					WHEN (e.hold_vehicle_stock_number IS NOT NULL)
						OR (e.hold_order_number IS NOT NULL)
						THEN ''Y''
					ELSE ''N''
				        END AS Stock_Number_Hold_Flag,
				        e.event_id_cs					AS Source_Record_ID,
				        COALESCE(e.account_id_cs,''NA'')			AS Source_Customer_ID,
				        CAST(e.start_ts_utc AS TIMESTAMP(0))		AS Touchpoint_begin_ts_utc,
				        CAST(e.end_ts_utc AS TIMESTAMP(0))			AS touchpoint_end_ts_utc,
				        CASE
					WHEN d.Day_Light_Saving_Time = ''On''
						AND l.Uses_DST_Flag = ''Y''
						THEN COALESCE(l.UTC_Offset_Standard - 1, 0)
				        	ELSE COALESCE(l.UTC_Offset_Standard, 0)
				        END AS UTC_Local_Offset_1,
				''U''						AS Waitlist_Flag,
				e.owner_id_cs 					AS Owner_sf_user_id_cs,
				        e.duration_in_minutes * 60 			AS Duration_Seconds,
				        e.ss_insert_ts_utc 				AS Source_Insert_TS,
				        e.ss_lst_upd_ts_utc 				AS Source_Update_TS,
				        e.lst_upd_ts 					AS EDW_Update_TS,
				        CURRENT_TIMESTAMP(0) 				AS DW_Insert_TS
			FROM
				        SALES.Sales_Landing.sf_event e
			INNER JOIN
					SALES.edw_salesforce_Reserved_Views.sf_opportunity o --changed to reserved container as part of CCPA
				ON 	e.what_id_cs = o.opportunity_id_cs
			LEFT OUTER JOIN
					SALES.Sales_Landing.Sf_Location Loc
				ON	Loc.location_id_cs=e.Assigned_Store_Id_Cs
			LEFT OUTER JOIN
					ACCOUNTING.Valid_Values_Views.Locations l
				ON	COALESCE(Loc.store_Number,e.Hold_Vehicle_Store_Location,e.store_number,-1) = l.Location_Key
			LEFT OUTER JOIN
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d
				ON 	CAST(e.Activity_Ts_Utc AS DATE) = d.Calendar_Date
			WHERE	e.what_id_cs LIKE ''006%''
				AND	CAST(e.activity_ts_utc AS DATE) - CAST(e.ss_insert_ts_utc AS DATE) <= 6 * 365
				AND	e.what_id_cs IS NOT NULL
				AND COALESCE(e.appointment_type,''NA'') not LIKE ''%Home Delivery%'';
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_ID);

		-----------4----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when human'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS a
				        SET
					a.Employee_Key = n.Employee_Key
				        FROM
					SALES.Sales_Landing.sf_user u,
					ASSOCIATES.hr_non_cci_views.associate_names n
		WHERE	a.Owner_sf_user_id_cs = u.user_id_cs
		AND	n.employee_ID = u.employee_number
		AND	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'') ;
		Count_Last := COALESCE ( SQLROWCOUNT , 0 );
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);


		----------- 5 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when System generated'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS a
				        SET
					a.Employee_Key = COALESCE(SF_Integration_Employee_key,-1)
				        FROM
					SALES.Sales_Landing.sf_user u,
					SALES.Sales_Views.SF_Integration_Accounts s
		WHERE	u.user_id_cs = a.Owner_sf_user_id_cs
			AND	u.user_name = s.SF_Integration_Employee_desc
			AND 	u.employee_number IS NULL
			AND	a.Employee_Key = -1 ;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

		--------- 6 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := SUBSTR(''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage,0,100);
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Sql_Statement := Activity_Desc;
			Record_Count := 0;

			SELECT
				        COUNT ( * ) INTO
				        :Record_Count
		FROM
				        SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF (( Count_Source <> Count_Stage ) /*OR ( SQLSTATE = ''02000'' )*/) THEN
				        Sql_Statement := ''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				        Error_Condition := 4;
				        Error_Count := Error_Count +1;
				        Sql_Return_Code := SQLCODE;
				        --Sql_State_Code := SQLSTATE;
				        INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc,Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				        VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				        INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				        VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				        Sql_Statement := Activity_Desc;
				        INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
				        Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				        Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				        Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				        Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				        Source_Aggregate_Amount, Source_Record_Count)
				        VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				        END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				        END,
				        	:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				        END,
				        	''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				        Out_Error_Count := Error_Count;
				        Out_Hard_Stop_Error := 1;
				        Out_Records_Loaded := 0;
				        CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
				    :Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
						RAISE Planned_Exception;
			ELSE
				        INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				        VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

		---------- 7--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Activity_Day_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Fct
				        SET
					Fct.Activity_Day_Key = Dy.Calendar_By_Day_Key
				        FROM
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day Dy
		WHERE	Dy.Calendar_Date	= Fct.Activity_Date;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);

		---------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Activity_Minute_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Fct
				        SET
					Fct.Activity_Minute_Key = Tm.Time_By_Minute_Key
				        FROM
					ACCOUNTING.Valid_Values_Views.Time_By_Minute Tm
		WHERE	Tm.Minute_Number 		= EXTRACT(MINUTE FROM (
		     	                 		                      DATAOPS.UTILITIES.UTC_TO_LOCAL_TS0(FCT.Touchpoint_Begin_TS_UTC,UTC_Local_offset)))
			AND	Tm.Hour_Number 	= EXTRACT(HOUR FROM (
			   	               	                    DATAOPS.UTILITIES.UTC_TO_LOCAL_TS0(FCT.Touchpoint_Begin_TS_UTC,UTC_Local_offset))) ;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);
		---------- 9--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Touchpoint_Attribute_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Fct
				        SET
			Fct.Touchpoint_Attribute_Key = Appointments.Appointment_Key
				        FROM
			SALES.Sales_Views.Appointments Appointments
		WHERE	Fct.Source_Record_ID = Appointments.Salesforce_Appointment_ID;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);

		---------- 10--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Requested_Appointment_Ts_Utc '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Fct
				        SET
			Fct.Requested_Appointment_Ts_Utc = Fct_lead.Requested_Appointment_Ts_Utc
				        FROM
			SALES.Sales_Views.Appointments Appointments,
			Sales_Reserved_Views.Fact_Touchpoint_Details Fct_lead	--changed to reserved container as part of CCPA	
		WHERE	Fct.Source_Record_ID = Appointments.Salesforce_Appointment_ID
		AND	Appointments.Associated_Lead_Id= Fct_lead.Source_Record_Id;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);

		---------- 11 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Appointment Interest Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Fct
				        SET
			Fct.Appointment_Interests_Key = Li.Appointment_Interest_Key
				        FROM
			SALES.Sales_Views.Appointment_Interests Li
		WHERE	Fct.Appointment_Type=Li.Appointment_Interest_Desc;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);

		---------- 12 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Vehicle Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments AS Fct
				        SET
			Fct.Vehicle_Key = Snm.Vehicle_Key
				        FROM
			SALES.Sales_Views.Stock_Number_Master Snm
		WHERE	Snm.Stock_Number_Key=Fct.Stock_Number_Key
			AND	Snm.Stock_Number_Valid_Flag=''Y''
			AND 	Snm.Stock_Number_Key <> -1;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);

		-----------13------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := SUBSTR(''Validating All The Key Columns Are Not Having Null Value In '' || Database_Stage || ''.'' || Table_Stage,0,100);
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''SELECT
   Count(*) Into Record_Count From
   '' || Database_Stage || ''.'' || Table_Stage;
			Record_Count := 0;
			Sql_Statement := Activity_Desc;

			SELECT
				        COUNT(*) INTO
				        :Record_Count
		FROM
				        SALES.Sales_Staging.Fact_Touchpoint_Details_Appointments
		WHERE	Touchpoint_Detail_Key 			IS NULL
			OR Source_Record_Type_Key 		IS NULL
			OR Activity_Day_Key 			IS NULL
			OR Activity_Minute_Key 			IS NULL
			OR Touchpoint_Attribute_Key 		IS NULL
			OR Appointment_Interests_Key 		IS NULL
			OR Customer_Activity_Key 			IS NULL
			OR Customer_Source_Key 			IS NULL
			OR Employee_Key 				IS NULL
			OR Location_Key 				IS NULL
			OR Stock_Number_Key 			IS NULL
			OR Touchpoint_Begin_Ts_Utc 		IS NULL
			OR Vehicle_Key 				IS NULL
			OR Vehicle_Location_Key 			IS NULL
			OR Source_Record_Id 			IS NULL
			OR Source_Customer_Id 			IS NULL ;
			Record_Count := COALESCE ( :Record_Count , 0 );
			IF (( Record_Count > 0 ) /*OR ( SQLSTATE = ''02000'' )*/ OR ( Error_Count > 0 )) THEN
				        Error_Condition := 6;
				        Error_Count := Error_Count +1;
				        Sql_Return_Code := SQLCODE;
				       --Sql_State_Code := SQLSTATE;
				        INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc,Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				        VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				        INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				        VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				        Out_Error_Count := Error_Count;
				        Out_Hard_Stop_Error := 1;
				        Out_Records_Loaded := 0;
				        CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
				        	:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
						RAISE Planned_Exception;
			END IF;

		------------14------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key,
			Balanced_Flag,
			Destination_Database, Destination_Table_Name,
			Error_Detail_Description,
			Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				        WHEN :Error_Count = 0
			THEN 4 ELSE 5
			END, CASE
				        WHEN :Error_Count = 0
			THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				        WHEN :Error_Count > 0
			THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''NA''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);
			Record_Count := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage, :Step_Id);

		------------15------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id);
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
			:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Stage;
		END;
		Final_Output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
		RETURN :Final_Output;
	EXCEPTION
		When Planned_Exception then 
	
		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
		Return OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
	
	When OTHER then 

		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	 
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
	END;
';