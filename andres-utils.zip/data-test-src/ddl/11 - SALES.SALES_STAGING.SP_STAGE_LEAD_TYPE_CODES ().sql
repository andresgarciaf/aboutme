CREATE OR REPLACE PROCEDURE "SP_STAGE_LEAD_TYPE_CODES"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-02		By: Vsekar
		Purpose: Sp_Stage_Lead_Interests

	call	Sales_Staging.sp_Stage_Lead_Type_Codes (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------
		2020-05-26		Matt		extend v_lead_desc and v_new_desc length

	*****************************************************************************************************************************************************************************/
	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

                Out_Error_Count SMALLINT := 0; 
                Out_Hard_Stop_Error BYTEINT := 0; 
                Out_Records_Loaded INTEGER := 0; 

		Final_Output Object;

		Planned_Exception   Exception (-20001, ''Exception based on Error_Condition'');

		V_Lead_Desc   	VARCHAR(200);
		V_New_Desc   	VARCHAR(200);
		V_Desc    	VARCHAR(4000);
		Pos 		INTEGER;
		Cur_Desc CURSOR
		FOR
	(
		SELECT DISTINCT Lead_Interest_Desc FROM
			SALES.Sales_Views.Lead_Interests
		WHERE Lead_Interest_Desc IS NOT NULL AND
		Lead_Interest_Key <> -1);

	BEGIN

			Activity_Name := ''sp_Stage_Lead_Type_Codes'';
			Code_Lines := 466;
			Database_Source := ''Sales'';
			Database_Stage := ''Sales_Staging'';
			Database_Target := ''Sales'';
			Process_Id := 458;
			Table_Source := ''Lead_Interests'';
			Table_Stage := ''Lead_Type_Codes'';
			Table_Target := ''Lead_Type_Codes'';
			Version := 1.1;

			-- Start Of Procedural Steps With Exception Handler
			BEGIN	 

	--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''****  Starting  ****'';
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
	CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;

	---------- 1 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := Activity_Desc;
	V_Desc := '';'';
	OPEN Cur_Desc;

	FOR c IN Cur_Desc DO
		V_Lead_Desc := c.Lead_Interest_Desc;

		V_New_Desc := '''';
		V_Lead_Desc := V_Lead_Desc || '';'';

		LOOP
			Pos := POSITION('';'' IN (V_Lead_Desc));
			IF (Pos = 0) THEN
				BREAK LABEL2;
			END IF;
			V_New_Desc := SUBSTRING(V_Lead_Desc, 1, Pos- 1);
			V_Lead_Desc := SUBSTRING(V_Lead_Desc, Pos+ 1);
			IF (POSITION('';''||V_New_Desc||'';'' IN (V_Desc)) =0) THEN
				Record_Count := Record_Count+1;
				V_Desc := V_Desc||V_New_Desc||'';'';
			END IF;
		END LOOP LABEL2;
	END FOR;

	CLOSE  Cur_Desc;
	
	Count_Source := COALESCE ( :Record_Count , 0 );
	IF (Count_Source = 0) THEN
		Activity_Desc := ''No Records To Process'';
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
		Activity_Desc := ''****  Complete  ****'';
		Completed_Flag := ''Y'';
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
		CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
			:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
		Out_Error_Count := Error_Count;
		Out_Hard_Stop_Error := 0;
		Out_Records_Loaded := Count_Source;
		RAISE Planned_exception;
	ELSE
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	END IF;

	-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
	Step_Id := Step_Id + 1;
	Record_Count := 0;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := Activity_Desc;
	DELETE FROM
		SALES.Sales_Staging.Lead_Type_Codes;

	----------- 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc :=''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := Activity_Desc;

	
	OPEN Cur_Desc;

	FOR c IN Cur_Desc DO
		V_Lead_Desc := c.Lead_Interest_Desc;

		V_New_Desc := '''';
		V_Lead_Desc := V_Lead_Desc || '';'';
		LOOP
			Pos := POSITION('';'' IN (V_Lead_Desc));
			IF (Pos = 0) THEN
				BREAK Label2;
			END IF;
			V_New_Desc := SUBSTRING(V_Lead_Desc, 1, Pos- 1);
			V_Lead_Desc := SUBSTRING(V_Lead_Desc, Pos+ 1);
			INSERT INTO SALES.Sales_Staging.Lead_Type_Codes (Lead_Type_Description)
			SELECT
							:V_New_Desc WHERE (:V_New_Desc) NOT IN (
								SELECT
									Lead_Type_Description FROM
									SALES.Sales_Staging.Lead_Type_Codes
							);
		END LOOP Label2;
	END FOR;
	CLOSE    Cur_Desc;
	
	Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------- 4 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := Activity_Desc;
	Record_Count := 0;

	SELECT
		COUNT (*) INTO
		:Record_Count
FROM
		SALES.Sales_Staging.Lead_Type_Codes;
	Count_Stage := COALESCE ( :Record_Count , 0 );
	IF (( Count_Source <> Count_Stage ) /*OR ( SQLSTATE = ''02000'' )*/) THEN
		Sql_Statement :=''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
		Error_Condition := 4;
		Error_Count := Error_Count +1;
		Sql_Return_Code := SQLCODE;
		--Sql_State_Code := SQLSTATE;
		INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
		VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
		Sql_Statement := Activity_Desc;
		INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
		Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
		Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
		Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
		Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
		Source_Aggregate_Amount, Source_Record_Count)
		VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
			WHEN :Error_Count = 0
							THEN 4 ELSE 5
		END, CASE
			WHEN :Error_Count = 0
							THEN ''Y'' ELSE ''N''
		END,
			:Database_Target , :Table_Target , CASE
			WHEN :Error_Count > 0
							THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''Na''
		END,
			''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
		Out_Error_Count := Error_Count;
		Out_Hard_Stop_Error := 1;
		Out_Records_Loaded := 0;
		CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
		RAISE Planned_Exception;
	ELSE
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	END IF;

	----------- 5 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Find Records That Already Exist In The Target'';
	Step_Id := Step_Id + 1;
	Record_Count := 0;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := Activity_Desc;
	UPDATE SALES.Sales_Staging.Lead_Type_Codes AS S
		SET
			S.Lead_Type_Key = T.Lead_Type_Key
		FROM
			SALES.Sales_Views.Lead_Type_Codes T
	WHERE 	S.Lead_Type_Description = T.Lead_Type_Description;
	Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	------ 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc :=''Identify Max Lead_Interest_Key In ''|| Database_Target || ''.'' || Table_Target;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_Id);
	Count_Last := 0;
	Sql_Statement := Activity_Desc;

	SELECT
		MAX (Lead_Type_Key) INTO
		:Last_Record_Key
FROM
		SALES.Sales_Views.Lead_Type_Codes;
	Last_Record_Key := COALESCE ( :Last_Record_Key , 0 );
	IF (Last_Record_Key = 0) THEN
		Activity_Desc := ''Insert Default Record Into ''|| Database_Target || ''.'' || Table_Target;
		Step_Id := Step_Id + 1;
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
		INSERT INTO SALES.Sales.Lead_Type_Codes (Lead_Type_Key,Lead_Type_Description, Dw_Insert_Ts)
		VALUES (-1, ''Unknown'', CURRENT_TIMESTAMP(0));
		Count_Target := COALESCE ( :SQLROWCOUNT , 0 );
	END IF;
	------ 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Insert  Into ''|| Database_Target || ''.'' || Table_Target || '' From '' || Database_Stage || ''.'' || Table_Stage;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	Count_Last := 0;
	Sql_Statement := Activity_Desc;
	INSERT INTO SALES.Sales.Lead_Type_Codes (Lead_Type_Key, Lead_Type_Description, Dw_Insert_Ts)
	SELECT
		:Last_Record_Key + ROW_NUMBER ( ) OVER ( ORDER BY NULL ) AS Lead_Type_Key,
		S.Lead_Type_Description 	AS Lead_Type_Description,
		CURRENT_TIMESTAMP(0) 	AS Dw_Insert_Ts
	FROM
		SALES.Sales_Staging.Lead_Type_Codes S
	WHERE 	S.Lead_Type_Key = -1;
	Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
	Count_Target := Count_Target + Count_Last;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	--------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Confirm All Rows Were Copied From '' || Database_Stage || ''.'' || Table_Stage || '' To '' || Database_Target || ''.'' || Table_Target;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	Record_Count := 0;
	Sql_Statement := Activity_Desc;
	SELECT
		COUNT ( * ) INTO
		:Record_Count
FROM
(
			SELECT
							S.Lead_Type_Key,
							S.Lead_Type_Description
						FROM
							SALES.Sales_Staging.Lead_Type_Codes S
						INNER JOIN
								SALES.Sales_Views.Lead_Type_Codes T
						ON     S.Lead_Type_Description=T.Lead_Type_Description
						WHERE  T.Lead_Type_Key IS  NULL
) X;
	Count_Last := COALESCE ( :Record_Count , 0 );
	IF (Count_Last > 0) THEN
		Error_Condition := 4;
		Error_Count := Error_Count +1;
		Sql_Return_Code := SQLCODE;
		--Sql_State_Code := SQLSTATE;
		INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
		VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Last, :Step_Id);
	ELSE
		Target_Balanced := ''Y'';
	END IF;

	---------- 9 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc :=''Delete Staged Data If No Errors'' || Database_Stage || ''.'' || Table_Stage;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	IF (Target_Balanced = ''Y'' AND COALESCE ( Error_Count, 0 ) = 0) THEN
		Sql_Statement := Activity_Desc;
		DELETE FROM
			SALES.Sales_Staging.Lead_Type_Codes;
	ELSE
		INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
		VALUES (:Activity_Name, ''Target_Balanced = '' || :Target_Balanced, :Completed_Flag, :Error_Count, :Error_Count, :Step_Id);
	END IF;

	---- 10 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Insert Metadata Table_Controls Record'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	Sql_Statement := Activity_Desc;
	INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
	Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
	Process_Status_Key,
	Balanced_Flag,
	Destination_Database, Destination_Table_Name,
	Error_Detail_Description,
	Source_Server, Source_Database, Source_Table_Name,
	Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
	Source_Aggregate_Amount, Source_Record_Count)
	VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
		WHEN :Error_Count = 0
			THEN 4 ELSE 5
	END, CASE
		WHEN :Error_Count = 0
			THEN ''Y'' ELSE ''N''
	END,
	:Database_Target , :Table_Target , CASE
		WHEN :Error_Count > 0
			THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
	END,
	''Teradata'', :Database_Source , :Table_Source ,
	0 , :Count_Target , :Error_Count ,
	0 , :Count_Source);

	----- 11 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''****  Complete  ****'';
	Completed_Flag := ''Y'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_Id);
	CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
	Out_Error_Count := Error_Count;
	Out_Hard_Stop_Error := 0;
	Out_Records_Loaded := Count_Target;
			END;

			Final_Output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
			RETURN :Final_Output;
	EXCEPTION 
	When Planned_Exception then 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	When OTHER then 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.ESP_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )         
		VALUES         ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT         INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES         (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	END;
';