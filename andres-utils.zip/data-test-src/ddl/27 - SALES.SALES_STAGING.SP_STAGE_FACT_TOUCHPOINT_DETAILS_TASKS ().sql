CREATE OR REPLACE PROCEDURE "SP_STAGE_FACT_TOUCHPOINT_DETAILS_TASKS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

		/*****************************************************************************************************************************************************************************
			Created: 2019-03-29		By: Vignesh S
			Purpose: Stage Touchpoint Details for Task Data
			Sample Run Command:
			call	Sales_Staging.sp_Stage_Fact_Touchpoint_Details_Tasks (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		   Modified Date	Modified By	  Notes
			-------------	-----------	 ------------------------------------------------------------------------------------------------------------------------------
			2019-04-16	Gayathri   	Replaced Task_key population with Touchpoint_Attribute_Key
			2019-04-23	Veena   	Renaming procedure and stage table
			2019-05-07	Matt		adjust code for task_type_Codes and task_outcome_codes views
			2019-05-17	Veena		Modified employee_key population logic for machine generated employee_key
			2019-06-14	Veena		Change in Stock_number_key logic and UTC_Local_offset to 0
			2019-06-19	Raja		Changed activity_date date rnage to 6 from 5 years
			2019-07-04	Gayathri	Removed is_deleted filter from source fetch
			2019-10-15	Aravindakshan	changed TO reserved container AS part OF CCPA
		*****************************************************************************************************************************************************************************/
		-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Temp	VARCHAR(100); -- Used To Specify The Database In Temp Table

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(6); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

		Out_Error_Count SMALLINT := 0; 
		Out_Hard_Stop_Error BYTEINT := 0; 
		Out_Records_Loaded INTEGER := 0;

		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

		Final_Output Object;

	BEGIN

		Activity_Name := ''sp_Stage_Fact_Touchpoint_Details_Tasks'';
		Code_Lines := 586;
		Database_Source := ''sales_Landing'';
		Database_Stage := ''Sales_Staging'';
		Database_Temp := ''Sales_Staging'';
		Database_Target := ''Sales'';
		Process_Id := 458;
		Table_Source := ''Sf_Task'';
		Table_Stage := ''Fact_Touchpoint_Details_Tasks'';
		Table_Target := ''Fact_Touchpoint_Details_Tasks'';
		Version := 1.3;
		SELECT
			Calendar_By_Day_Key  INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

		-- Start Of Procedural Steps With Exception Handler
		BEGIN

		----------0---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting   ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
			:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
			:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;
		-----------1-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
	FROM
				SALES.Sales_landing.sf_task sf
	INNER JOIN
					SALES.EDW_Salesforce_reserved_views.sf_opportunity o	--changed to reserved container as part of CCPA
		ON sf.what_id_cs=o.opportunity_id_cs
	WHERE 	sf.what_id_cs IS NOT NULL
	AND	sf.What_Id_CS LIKE ''006%''
	AND 	sf.Activity_Date IS NOT NULL
	AND	sf.activity_date - CAST(sf.ss_insert_ts_utc AS DATE) <= 6 * 365;
			Count_Source := COALESCE (:Record_Count , 0);
			IF (Count_Source = 0 /*OR SQLSTATE = ''02000''*/) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;
				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;
		-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage Tables'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks;

		----------- 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''INSERT  INTO ''|| Database_stage || ''.'' || Table_Stage || '' FROM '' || Database_Source || ''.'' || Table_Source;
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks (
			Activity_Day_Key,Activity_Minute_Key,
			Customer_Activity_Key,
			Customer_Source_Key,Task_Owner_Id_Cs,Outcome,Type_text,Location_Key,
			Source_Record_Type_Key,Stock_Number_Key,Task_Outcome_key,Task_Type_Key,Vehicle_Key,Vehicle_Location_Key,
			Activity_Date,Home_Delivery_Flag,Requested_Appointment_TS_UTC,Salesforce_opportunity_id,
			Stock_Number_Hold_Flag,Source_Record_ID,Source_Customer_ID,Touchpoint_Begin_TS_UTC,Touchpoint_End_TS_UTC,UTC_Local_Offset,
			Duration_Seconds,Source_Insert_TS,Source_Update_TS,EDW_Update_TS,DW_Insert_TS)
			SELECT
				-1 								AS Activity_Day_Key,
				-1 								AS Activity_Minute_Key,
				540                                                                	AS Customer_Activity_Key,
				        17                                      				AS Customer_Source_Key,
				sf.owner_id_cs 							AS Task_Owner_Id_Cs,
				sf.Outcome 							AS Outcome,
				sf.Type_text 							AS Type_text,
				        CAST(TRUNC(COALESCE (Loc.store_Number,sf.hold_vehicle_store_location,
				sf.store_number,-1)) AS INTEGER) 					AS Location_Key,
				        918                                   				AS Source_Record_Type_Key,
				CAST(TRUNC(COALESCE(CASE
					WHEN sf.stock_number = ''None''
						THEN NULL
						ELSE sf.stock_number
				END, CASE
					WHEN sf.hold_vehicle_stock_number = ''None''
						THEN NULL
						ELSE sf.hold_vehicle_stock_number
				END,
					''-1'')) AS INTEGER)  					AS Stock_Number_Key,
				-1 								AS Task_Outcome_key,
				-1 								AS Task_Type_Key,
				-1 								AS Vehicle_Key,
				        COALESCE(sf.hold_vehicle_store_location,-1)                      	AS Vehicle_Location_Key,
				       	CAST(
				       	     DATAOPS.UTILITIES.UTC_TO_LOCAL_TS0(CAST(sf.activity_date AS TIMESTAMP(0)),
				        0) AS DATE )       				AS Activity_Date,
				''U''                                             			AS Home_Delivery_Flag,
				        f.Requested_Appointment_TS_UTC                     			AS Requested_Appointment_TS_UTC,
				        sf.what_id_cs                                            	 	AS Salesforce_opportunity_id,
				CASE
					WHEN (sf.hold_vehicle_stock_number IS NOT NULL
					                 OR sf.hold_order_number IS NOT NULL)
						THEN ''Y''
				                 ELSE ''N''
				END AS Stock_Number_Hold_Flag,
				        sf.task_id_cs                                          		AS Source_Record_ID,
				        COALESCE(sf.account_id_cs,''NA'')                                    	AS Source_Customer_ID,
				        CAST(sf.Activity_Date AS TIMESTAMP(0))				AS Touchpoint_Begin_TS_UTC,
				        sf.completed_date                 					AS Touchpoint_End_TS_UTC,
				        0								AS UTC_Local_Offset1,
				COALESCE(EXTRACT(SECOND FROM sf.completed_date) -
				EXTRACT(SECOND FROM (CAST(sf.Activity_Date AS TIMESTAMP(0)))),0)	AS Duration_Seconds,
				        sf.ss_insert_ts_utc                					AS Source_Insert_TS,
				        sf.ss_lst_upd_ts_utc                   				AS Source_Update_TS,
				        sf.lst_upd_ts                        				AS EDW_Update_TS,
				        CURRENT_TIMESTAMP(0)                  				AS DW_Insert_TS
			FROM
				SALES.Sales_landing.sf_task sf
			INNER	JOIN
					SALES.EDW_Salesforce_reserved_views.sf_opportunity o	--changed to reserved container as part of CCPA
				ON sf.what_id_cs::VARCHAR =o.opportunity_id_cs
			LEFT	JOIN
					SALES.Sales_Reserved_Views.fact_touchpoint_details f	--changed to reserved container as part of CCPA
				ON sf.who_id_cs::VARCHAR =f.source_record_id
				AND f.source_record_type_key =894
			LEFT	JOIN
					SALES.Sales_landing.Sf_Location Loc
				        ON Loc.location_id_cs::VARCHAR =sf.Assigned_Store_Id_Cs
			LEFT	JOIN
					ACCOUNTING.Valid_Values_Views.Locations l
				        ON COALESCE(Loc.store_Number,sf.Hold_Vehicle_Store_Location,sf.store_number,-1) =l.Location_Key
			LEFT	JOIN
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day d
				        ON CAST(sf.Activity_Date AS DATE) =d.Calendar_Date
			WHERE  	sf.what_id_cs IS NOT NULL
			AND	sf.What_Id_CS LIKE ''006%''
			AND 	sf.Activity_Date IS NOT NULL
			AND	sf.activity_date - CAST(sf.ss_insert_ts_utc AS DATE) <= 6 * 365;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_ID);

		-----------4----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=SUBSTR(''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage,0,100);
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Sql_Statement := Activity_Desc;
			Record_Count := 0;

			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF (( Count_Source <> Count_Stage ) /*OR ( SQLSTATE = ''02000'' )*/) THEN
				Sql_Statement := ''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
				:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;
		---------- 5--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when human'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS a
				SET
					a.Employee_Key = n.Employee_Key
				FROM
					SALES.Sales_landing.sf_user u,
					ASSOCIATES.hr_non_cci_views.associate_names n
		WHERE	a.Task_Owner_Id_Cs = u.user_id_cs
		AND	n.employee_ID = u.employee_number
		AND	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'') ;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

		----------- 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when System generated'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS a
				SET
					a.Employee_Key = COALESCE(SF_Integration_Employee_key,-1)
				FROM
					SALES.Sales_landing.sf_user u,
					SALES.Sales_Views.SF_Integration_Accounts s
		WHERE	u.user_id_cs = a.Task_Owner_Id_Cs
		AND	u.user_name = s.SF_Integration_Employee_desc
		AND 	u.employee_number IS NULL
		AND	a.Employee_Key = -1 ;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

		--------- 7 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Activity_Day_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS Fct
				SET
					Fct.Activity_Day_Key = Dy.Calendar_By_Day_Key
				FROM
					ACCOUNTING.Valid_Values_Views.Calendar_By_Day Dy
		WHERE	Dy.Calendar_Date	= Fct.Activity_Date;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);

		---------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage || '' Activity_Minute_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS Fct
				SET
					Fct.Activity_Minute_Key = Tm.Time_By_Minute_Key
				FROM
					ACCOUNTING.Valid_Values_Views.Time_By_Minute Tm
		WHERE	Tm.Minute_Number 		= EXTRACT(MINUTE FROM (
		     	                 		                       DATAOPS.UTILITIES.UTC_TO_LOCAL_TS0(FCT.Touchpoint_Begin_TS_UTC,UTC_Local_offset)))
			AND	Tm.Hour_Number 	= EXTRACT(HOUR FROM (
			   	               	                     DATAOPS.UTILITIES.UTC_TO_LOCAL_TS0(FCT.Touchpoint_Begin_TS_UTC,UTC_Local_offset))) ;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);
		---------- 9--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Touchpoint_Attribute_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS Fct
				SET
			Fct.Touchpoint_Attribute_Key = Tasks.Task_Key
				FROM
			SALES.Sales_Views.Tasks Tasks
		WHERE	TRIM(Tasks.Salesforce_Task_ID)=TRIM(Fct.Source_Record_ID);
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);
		-----------10------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Task_Outcome_key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS Fct
				SET
			Fct.Task_Outcome_key = Ts.Task_Outcome_Key
				FROM
			SALES.Sales_Views.Task_Outcome_Codes Ts
		WHERE	Ts.task_outcome_desc=Fct.Outcome;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);
		-----------11------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Task_Type_Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS Fct
				SET
			Fct.Task_Type_Key = Tt.Task_Type_Key
				FROM
			SALES.Sales_Views.Task_Type_Codes Tt
		WHERE	Tt.Task_Type_desc=Fct.Type_text;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);
		-----------12------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Updating '' || Database_Stage || ''.'' || Table_Stage ||'' Vehicle Key '';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks AS Fct
				SET
			Fct.Vehicle_Key = Snm.Vehicle_Key
				FROM
			SALES.Sales_Views.Stock_Number_Master Snm
		WHERE	Snm.Stock_Number_Key=Fct.Stock_Number_Key
			AND	Snm.Stock_Number_Valid_Flag=''Y''
			AND 	Snm.Stock_Number_Key <> -1;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count,:Count_Last, :Step_Id);
		-----------13------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := SUBSTR(''Validating All The Key Columns Are Not Having Null Value In '' || Database_Stage || ''.'' || Table_Stage,0,100);
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''SELECT
   Count(*) Into Record_Count From
   '' || Database_Stage || ''.'' || Table_Stage;
			Record_Count := 0;
			Sql_Statement := Activity_Desc;

			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Fact_Touchpoint_Details_Tasks
		WHERE	Touchpoint_Detail_Key 			IS NULL
			OR Source_Record_Type_Key 		IS NULL
			OR Activity_Day_Key 			IS NULL
			OR Activity_Minute_Key 			IS NULL
			OR Customer_Activity_Key 			IS NULL
			OR Customer_Source_Key 			IS NULL
			OR Touchpoint_Attribute_Key		IS NULL
			OR Employee_Key 				IS NULL
			OR Location_Key 				IS NULL
			OR Stock_Number_Key 			IS NULL
			OR Task_Outcome_key			IS NULL
			OR Task_Type_Key				IS NULL
			OR Touchpoint_Begin_Ts_Utc 		IS NULL
			OR Vehicle_Key 				IS NULL
			OR Source_Record_Id 			IS NULL
			OR Source_Customer_Id 			IS NULL ;
			Record_Count := COALESCE ( :Record_Count , 0 );
			IF (( Record_Count > 0 ) /*OR ( SQLSTATE = ''02000'' )*/ OR ( Error_Count > 0 )) THEN
				Error_Condition := 6;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				RAISE Planned_Exception;
			END IF;

		------------14------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key,
			Balanced_Flag,
			Destination_Database, Destination_Table_Name,
			Error_Detail_Description,
			Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
			THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
			THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
			THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''NA''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);
			Record_Count := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage, :Step_Id);

		------------15------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id);
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
			:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Stage;
		END;

		Final_Output:= OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);

		RETURN :Final_Output;
	EXCEPTION
		When Planned_Exception then 
	
		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
		Return OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
	
	When OTHER then 

		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	 
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
		
	END;
';