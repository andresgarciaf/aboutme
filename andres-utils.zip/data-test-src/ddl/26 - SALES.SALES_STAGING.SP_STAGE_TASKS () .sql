CREATE OR REPLACE PROCEDURE "SP_STAGE_TASKS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE
	--OUTPUT PARAMETERS
		OUT_ERROR_COUNT SMALLINT := 0;
		OUT_HARD_STOP_ERROR BYTEINT := 0;
		OUT_RECORDS_LOADED INTEGER := 0;
		Final_Output Object;
		Planned_Exception   Exception (-20001, ''Exception based on Error_Condition'');

	/*****************************************************************************************************************************************************************************
		Created: 2019-04-03		By: Harini H
		Purpose: sp_Stage_Tasks
		Sample Run Command:
		call	SALES.Sales_Staging.sp_Stage_Tasks (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);
		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------
		2019-04-16	Gayathri   	Added population for the new column Associated_lead_id		
		2019-05-17	Veena		Modified employee_key population logic for machine generated employee_key
		2019-06-24	Gayathri		Added activity_date date rnage to 6 Years
		2019-07-04	Gayathri		Removed is_deleted filter from source fetch
		2019-12-04	Aravindakshan	changed to reserved container as part of CCPA
	*****************************************************************************************************************************************************************************/
	-- Custom Procedure Variables
		Index_Exists	BYTEINT := 0; -- Used To Signal Whether An Index Needs To Be Dropped

		Index_Limit	INTEGER := 0; -- Used to determine Whether An Index Needs To Be Dropped

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	BEGIN

		Activity_Name := ''sp_Stage_Tasks'';
		Code_Lines := 719;
		Database_Source := ''Sales_Landing'';
		Database_Stage := ''Sales_Staging'';
		Database_Target := ''Sales'';
		Process_Id := 458;
		Table_Source := ''Sf_Task'';
		Table_Stage := ''Tasks'';
		Table_Target := ''Tasks'';
		Version := 1.2;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

--	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	P1:
		-- Start Of Procedural Steps With Exception Handler
		BEGIN
	---------------------- 0 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;

	---------- 1 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				SUM(Cnt_Src) INTO
				:Record_Count
		FROM (
					SELECT
						COUNT(*) AS Cnt_Src
				FROM
						SALES.Sales_Landing.Sf_Task t
				INNER 	JOIN
							SALES.EDW_Salesforce_reserved_views.sf_opportunity o	--changed to reserved container as part of CCPA
				ON 	t.What_Id_CS::VARCHAR = o.opportunity_id_cs
				WHERE	t.What_Id_CS LIKE ''006%''
				AND	t.What_Id_CS IS NOT NULL
				AND 	t.Activity_Date IS NOT NULL
				AND	t.activity_date - CAST(t.ss_insert_ts_utc AS DATE) <= 6 * 365
		UNION ALL
					SELECT
						COUNT(*) AS Cnt_Src
				FROM
						SALES.Sales_Landing.Sf_Task s
				INNER 	JOIN
							SALES.Sales_Views.Tasks tsk
				ON	s.Task_ID_CS::VARCHAR =tsk.Salesforce_Task_ID
				WHERE	s.What_Id_CS IS NULL
				AND 	s.Is_Deleted=1
				AND 	tsk.Is_Deleted_Flag=''N''
				AND 	s.Activity_Date IS NOT NULL
		)Cnt_Tot_Src;
			Count_Source := COALESCE ( :Record_Count , 0 );
			IF (Count_Source = 0 ) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;
				RAISE Planned_exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO Sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				Sales.Sales_Staging.Tasks;

	----------- 3 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO Sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO Sales.Sales_Staging.Tasks (
			Associated_Lead_ID,
			Is_Reminder_Set,
			Salesforce_Task_ID ,
			Task_Status,
			Web_Listing_Desc,
			Is_Deleted_Flag,
			Created_By_Id_Cs,
			DW_Insert_TS ,
			DW_Update_TS)
			SELECT
				Who_ID_Cs 			AS Associated_Lead_ID,
				CASE
					WHEN t.Is_Reminder_Set=1
						THEN ''Y''
						ELSE ''N''
				END AS Is_Reminder_Set,
					Task_ID_CS 			AS Salesforce_Task_ID,
					t.Status 			AS Task_Status,
					Carmax_Com_Listing 		AS Web_Listing_Desc,
				CASE
					WHEN t.Is_Deleted=1
						THEN ''Y''
						ELSE ''N''
				END AS Is_Deleted_Flag,
					t.Created_By_Id_Cs 		AS Created_By_Id_Cs,
					CURRENT_TIMESTAMP(0) 		AS DW_Insert_TS,
					CURRENT_TIMESTAMP(0) 		AS DW_Update_TS
				FROM
				SALES.Sales_Landing.Sf_Task t
				INNER JOIN
					Sales.EDW_Salesforce_reserved_views.Sf_Opportunity o	--changed to reserved container as part of CCPA
					ON 	t.What_Id_CS::VARCHAR = o.Opportunity_ID_CS
				WHERE	t.What_Id_CS LIKE ''006%''
				AND	t.What_Id_CS IS NOT NULL
				AND 	t.Activity_Date IS NOT NULL
				AND	t.activity_date - CAST(t.ss_insert_ts_utc AS DATE) <= 6 * 365;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO Sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	----------- 4 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert deleted records Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO Sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO Sales.Sales_Staging.Tasks (
			Associated_Lead_ID,
			Is_Reminder_Set,
			Salesforce_Task_ID ,
			Task_Status,
			Web_Listing_Desc,
			Is_Deleted_Flag,
			Created_By_Id_Cs,
			DW_Insert_TS ,
			DW_Update_TS)
			SELECT
				Who_ID_Cs 			AS Associated_Lead_ID,
				CASE
					WHEN t.Is_Reminder_Set=1
						THEN ''Y''
						ELSE ''N''
				END AS Is_Reminder_Set,
					Task_ID_CS 			AS Salesforce_Task_ID,
					t.Status 			AS Task_Status,
					Carmax_Com_Listing 		AS Web_Listing_Desc,
				CASE
					WHEN t.Is_Deleted=1
						THEN ''Y''
						ELSE ''N''
				END AS Is_Deleted_Flag,
					t.Created_By_Id_Cs 		AS Created_By_Id_Cs,
					CURRENT_TIMESTAMP(0) 		AS DW_Insert_TS,
					CURRENT_TIMESTAMP(0) 		AS DW_Update_TS
				FROM
				SALES.Sales_Landing.Sf_Task t
				INNER 	JOIN
					Sales.Sales_Views.Tasks tsk
					  ON	t.Task_ID_CS::VARCHAR =tsk.Salesforce_Task_ID
				WHERE	t.what_id_cs IS NULL
				AND 	t.Is_Deleted=1
				AND 	tsk.Is_Deleted_Flag=''N''
				AND 	t.Activity_Date IS NOT NULL;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO Sales.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	----------- 5 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when human'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Tasks AS t
				SET
					t.Employee_Created_By_Key = n.Employee_Key
				FROM
					SALES.Sales_Landing.sf_user u,
					ASSOCIATES.hr_non_cci_views.associate_names n
	WHERE	t.Created_By_Id_Cs = u.user_id_cs
	AND	n.employee_ID = u.employee_number
	AND	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'') ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	----------- 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when System generated'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Tasks AS t
				SET
					t.Employee_Created_by_Key = COALESCE(SF_Integration_Employee_key,-1)
				FROM
					SALES.Sales_Landing.sf_user u,
					SALES.Sales_Views.SF_Integration_Accounts s
	WHERE	u.user_id_cs = t.Created_By_Id_Cs
	AND	u.user_name = s.SF_Integration_Employee_desc
	AND 	u.employee_number IS NULL
	AND	t.Employee_Created_by_Key = -1 ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------- 7 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			Record_Count := 0;

			SELECT
				COUNT (*) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Tasks;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF (( Count_Source <> Count_Stage ) ) THEN
				Sql_Statement :=''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				
				INSERT INTO DATAOPS.Metadata_Controls.error_log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
	:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				RAISE Planned_exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	----------- 8 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Records That Already Exist In The Target'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Tasks AS S
				SET
					S.Task_Key = T.Task_Key
				FROM
					SALES.Sales_Views.Tasks T
	WHERE 	S.Salesforce_Task_ID = T.Salesforce_Task_ID;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	------ 9 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Drop target indexes if the number of staged records > Index_Limit'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			Count_Last := 0;
			SQL_Statement := ''Determine count of records that will change'';
			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Tasks
		WHERE	Task_Key = -1;
			Count_Last := COALESCE ( :Record_Count , 0 );
			SELECT
				CAST(TRUNC( Parameter_Value) AS INTEGER)  INTO
				:Index_Limit
		FROM
				DATAOPS.Metadata_Views.Parameters_Sales
		WHERE 	Parameter_Name =''Web_Lead_Index_Limit'';
			IF (Count_Last > Index_Limit) THEN

			---------10---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If idx_Salesforce_Task_Id Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
				/*SELECT
					
					CASE
						WHEN (
							SELECT DISTINCT
--								 Indexname
									   	   FROM 	 Dbc.Indicesv
									 	   WHERE
								TABLE_SCHEMA = ''Sales''
										   AND TABLE_NAME = ''Tasks''
										   AND
--										       	 Indexname
										       	           = ''idx_Salesforce_Task_Id'' )
							IS NOT NULL
							THEN 1 ELSE 0
					END
				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary idx_Salesforce_Task_Id'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index idx_Salesforce_Task_Id'';
--						DROP 	INDEX idx_Salesforce_Task_Id ON SALES.Tasks;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;*/
			END IF;
	---------11--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Identify Max Task_Key In ''|| Database_Target || ''.'' || Table_Target;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;

			SELECT
				MAX ( Task_Key ) INTO
				:Last_Record_Key
		FROM
				SALES.Sales_Views.Tasks;
			Last_Record_Key := COALESCE ( :Last_Record_Key , 0 );
			IF (Last_Record_Key = 0) THEN
				Activity_Desc :=''Insert Default Record Into ''|| Database_Target || ''.'' || Table_Target;
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				INSERT INTO SALES.Sales.Tasks (Task_Key,
						Employee_Created_By_Key,
						Associated_Lead_ID,
						Is_Reminder_Set,
						Salesforce_Task_ID,
						Task_Status,
						Web_Listing_Desc,
						Is_Deleted_Flag,
						DW_Insert_TS,
						DW_Update_TS)
				VALUES (-1, -1, ''NA'', ''N'', ''Unknown'', ''NA'', ''NA'', ''N'', CURRENT_TIMESTAMP(0),CURRENT_TIMESTAMP(0));
				Count_Target := COALESCE (  :SQLROWCOUNT , 0 );
			END IF;
			------ 12------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Last_Record_Key > 0) THEN
				Activity_Desc :=''Update existing records in '' || Database_Target || ''.'' || Table_Target;
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_Id);
				Count_Last := 0;
				Sql_Statement := Activity_Desc;
				UPDATE SALES.Sales.Tasks AS FNL
					SET
						FNL.Employee_Created_By_Key = STG.Employee_Created_By_Key,
						FNL.Associated_Lead_ID = STG.Associated_Lead_ID,
						FNL.Is_Reminder_Set = STG.Is_Reminder_Set,
						FNL.Salesforce_Task_ID = STG.Salesforce_Task_ID,
						FNL.Task_Status = STG.Task_Status,
						FNL.Web_Listing_Desc = STG.Web_Listing_Desc,
						FNL.Is_Deleted_Flag = STG.Is_Deleted_Flag,
						FNL.DW_Update_TS = CURRENT_TIMESTAMP(0)
					FROM
						SALES.Sales_Staging.Tasks STG
			WHERE 	FNL.Task_Key 		= STG.Task_Key
				AND 	STG.Task_Key				<> -1
				AND 	(FNL.Employee_Created_By_Key 		<> STG.Employee_Created_By_Key
				OR	COALESCE(FNL.Associated_Lead_ID, ''NA'')	<> STG.Associated_Lead_ID
				OR	COALESCE(FNL.Is_Reminder_Set, ''N'')		<> COALESCE(STG.Is_Reminder_Set, ''N'')
				OR	FNL.Salesforce_Task_ID 			<> STG.Salesforce_Task_ID
				OR	COALESCE(FNL.Task_Status, ''NA'')		<> COALESCE(STG.Task_Status, ''NA'')
				OR	FNL.Web_Listing_Desc 			<> STG.Web_Listing_Desc
				OR	COALESCE(FNL.Is_Deleted_Flag, ''N'')		<> COALESCE(STG.Is_Deleted_Flag, ''N''));
				Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);
			END IF;
	------ 13-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert  Into ''|| Database_Target || ''.'' || Table_Target || '' From '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales.Tasks (Employee_Created_By_Key,
				Associated_Lead_ID,
				Is_Reminder_Set,
				Salesforce_Task_ID,
				Task_Status,
				Web_Listing_Desc,
				Is_Deleted_Flag,
				DW_Insert_TS,
				DW_Update_TS)
			SELECT
				Employee_Created_By_Key,
				Associated_Lead_ID,
				Is_Reminder_Set,
				Salesforce_Task_ID,
				Task_Status,
				Web_Listing_Desc,
				Is_Deleted_Flag,
				CURRENT_TIMESTAMP(0),
				CURRENT_TIMESTAMP(0)
			FROM
				SALES.Sales_Staging.Tasks
			WHERE 	Task_Key = -1;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			Count_Target := Count_Target + Count_Last;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	--------- 14 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm All Rows Were Copied From '' || Database_Stage || ''.'' || Table_Stage || '' To '' || Database_Target || ''.'' || Table_Target;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Record_Count := 0;
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
		(
					SELECT
						S.Salesforce_Task_ID
					FROM
						SALES.Sales_Staging.Tasks S
					LEFT  	OUTER JOIN
							SALES.Sales_Views.Tasks T
					ON    	T.Salesforce_Task_ID = S.Salesforce_Task_ID
					WHERE 	T.Task_Key IS NULL
		) Rec_Cnt;
			Count_Last := COALESCE ( :Record_Count , 0 );
			IF (Count_Last > 0) THEN
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				
				INSERT INTO DATAOPS.Metadata_Controls.error_log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Last, :Step_Id);
			ELSE
				Target_Balanced := ''Y'';
			END IF;

	---------- 15 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Create Target Indexes If They Were Dropped'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);

	-----------16--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine If idx_Salesforce_Task_Id Index Exists'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Index_Exists := 0;
			Sql_Statement := Activity_Desc;
			/*SELECT
				
				CASE
					WHEN (
						SELECT DISTINCT
--							 Indexname
								   	   FROM Dbc.Indicesv
								 	   WHERE
							TABLE_SCHEMA = ''Sales''
									   	AND TABLE_NAME = ''Tasks''
									   	AND
--									   	    Indexname
									   	              = ''idx_Salesforce_Task_Id'' )
						IS NOT NULL
						THEN 1 ELSE 0
				END
			INTO :Index_Exists ;
			IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index idx_Salesforce_Task_Id'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create idx_Salesforce_Task_Id'';
--					CREATE 	INDEX idx_Salesforce_Task_Id ( Salesforce_Task_Id )
--					ON SALES.Tasks ;
			ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			END IF;*/
	-----------17--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			Activity_Desc :=''Delete Staged Data If No Errors'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			IF (Target_Balanced = ''Y'' AND COALESCE ( Error_Count, 0 ) = 0) THEN
				Sql_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Tasks;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, ''Target_Balanced = '' || :Target_Balanced, :Completed_Flag, :Error_Count, :Error_Count, :Step_Id);
			END IF;

	---- 18-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key,
			Balanced_Flag,
			Destination_Database, Destination_Table_Name,
			Error_Detail_Description,
			Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''NA''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);

	----- 19 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_Id);
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Target;
		END;
		
        Final_Output := object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED );
		return :Final_Output;

	EXCEPTION
	When Planned_Exception then 
		INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
		VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
		Return object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED );

	When OTHER then 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 
		INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	 
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 
		INSERT 	INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
		VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
		Return object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED );
	END; 
';