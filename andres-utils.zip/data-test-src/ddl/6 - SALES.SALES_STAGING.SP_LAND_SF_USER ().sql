CREATE OR REPLACE PROCEDURE "SP_LAND_SF_USER"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE
	--Declare output variables
        Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 
		Final_output OBJECT;
		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-05		By: Harini Nagarajan
		Purpose: Landing table for sf_user

	call SALES.SALES_STAGING.sp_Land_Sf_User(Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------


	*****************************************************************************************************************************************************************************/

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	BEGIN

		Activity_Name := ''sp_Land_Sf_User'';
		Code_Lines := 377;
		Database_Source := ''Edw_Salesforce'';
		Database_Stage := ''Sales_Landing'';
		Database_Target := ''Sales_Landing'';
		Process_Id := 458;
		Table_Source := ''Sf_User'';
		Table_Stage := ''Sf_User'';
		Table_Target := ''Sf_User'';
		Version := 1.0;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

	---------------------- 0 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set METADATA_CONTROLS.Run_Time_Results Record To Zero'';
			CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;
			Sql_Statement := ''Get Parameters'';

			Start_Time := (SELECT
				CASE
					WHEN (
						SELECT
							CAST(TRUNC( Parameter_Value) AS INTEGER) 
							FROM
							DATAOPS.METADATA_VIEWS.Parameters_Sales
							WHERE	Parameter_Name IN (''Leads_Origin_Start_Days'' )) = 9999
						THEN TO_TIMESTAMP(''1980-01-01 13:52:22'')
		ELSE (
						SELECT
							TO_TIMESTAMP(TO_DATE(DATEADD(''DAY'',-CAST(TRUNC( Parameter_Value) AS INTEGER),CURRENT_TIMESTAMP(0))))
			FROM
							DATAOPS.METADATA_VIEWS.Parameters_Sales
			WHERE	Parameter_Name IN (''Leads_Origin_Start_Days'' ) )
				END);

	---------------------- 1 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.EDW_SALESFORCE.Sf_User;
			Count_Source := COALESCE (:Record_Count , 0);
			IF (Count_Source = 0) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;

				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;

	---------------------- 2 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.SALES_LANDING.Sf_User;

	---------------------- 3 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Insert Into '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.SALES_LANDING.Sf_User (User_Id_Cs,User_Name,Last_Name,First_Name,Middle_Name,Suffix,Name_Text,
				Company_Name,Division,Department,Title_Text,Street,City,State,
				Postal_Code,Country,State_Code,Country_Code,Latitude,Longitude,
				Email,Email_Prefs_Auto_Bcc,Email_Prefs_Aut_Bcc_Sty_In_Tch,Email_Prefs_St_In_Touch_Remind,
				Sender_Email,Sender_Name,Signature,Stay_In_Touch_Subject,Stay_In_Touch_Signature,
				Stay_In_Touch_Note,Phone,Fax,Mobile_Phone,Alias_Text,Community_Nickname,
				Badge_Text,Is_Active,Time_Zone_Sid_Key,User_Role_Id_Cs,Locale_Sid_Key,
				Receives_Info_Emails,Receives_Admin_Info_Emails,Email_Encoding_Key,
				Profile_Id_Cs,User_Type,Language_Locale_Key,Employee_Number,
				Delegated_Approver_Id_Cs,Manager_Id_Cs,Last_Login_Ts_Utc,Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,Last_Updated_Ts_Utc,Offline_Trial_Expire_Ts_Utc,
				Offline_Pda_Trial_Expire_Ts_Utc,Perms_Marketinguser,Perms_Offline_User,
				Perms_Avantgo_User,Perms_Call_Center_Auto_Login,Perms_Mobile_User,
				Perms_Sf_Content_User,Perms_Knowledge_User,Perms_Interaction_User,
				Perms_Support_User,Perms_Chatter_Answers_User,Forecast_Enabled,
				Prefs_Activity_Remind_Popup,Prefs_Event_Remind_Ckbox_Dflt,Prefs_Task_Remind_Ckbox_Dflt,
				Prefs_Reminder_Soundoff,Prefs_Disable_All_Feeds_Email,Prefs_Disable_Followers_Email,
				Prefs_Disable_Prfl_Post_Email,Prefs_Disable_Change_Cmt_Email,
				Prefs_Disable_Later_Cmt_Email,Prefs_Dis_Prof_Post_Cmt_Email,
				Prefs_Cont_No_Email,Prefs_Cont_Email_As_And_When,Prefs_Apex_Pages_Dev_Mode,
				Prefs_Hide_Csn_Chat_Mobl_Task,Prefs_Disbl_Mention_Post_Email,
				Prefs_Dis_Mention_Cmt_Email,Prefs_Hide_Csn_Desktop_Task,Prefs_Hide_Chat_Onboard_Splash,
				Prefs_Hide_Sec_Chat_Ob_Splash,Prefs_Dis_Cmt_After_Like_Email,
				Prefs_Disable_Like_Email,Prefs_Sort_Feed_By_Comment,Prefs_Disable_Message_Email,
				Prefs_Disable_Bookmark_Email,Prefs_Disable_Share_Post_Email,
				Prefs_Enable_Aut_Sub_For_Feeds,Prefs_Dis_File_Shr_Nfn_For_Api,
				Prefs_Show_Title_To_Ext_Users,Prefs_Show_Mgr_To_Ext_Users,Prefs_Show_Email_To_Ext_Users,
				Prefs_Show_Wk_Phn_To_Ext_Users,Prefs_Show_Mb_Phn_To_Ext_Users,
				Prefs_Show_Fax_To_Ext_Users,Prefs_Show_St_Adr_To_Ext_Users,Prefs_Show_City_To_Ext_Users,
				Prefs_Show_State_To_Ext_Users,Prefs_Show_Postcd_To_Ext_Users,
				Prefs_Show_Cntry_To_Ext_Users,Prefs_Show_Prfpic_To_Gst_Users,
				Prefs_Show_Title_To_Gst_Users,Prefs_Show_City_To_Gst_Users,Prefs_Show_State_To_Gst_Users,
				Prefs_Show_Postcd_To_Gst_Users,Prefs_Show_Cntry_To_Gst_Users,
				Prefs_Disable_Endorsemnt_Email,Prefs_Path_Assistant_Collapsed,
				Prefs_Preview_Lightning,Contact_Id_Cs,Account_Id_Cs,Call_Center_Id_Cs,
				Extension,Federation_Identifier,About_Me,Full_Photo_Url,Small_Photo_Url,
				Digest_Frequency,Default_Group_Notif_Frequency,Last_Viewed_Ts_Utc,
				Last_Referenced_Ts_Utc,Status,Storenum,Store_Employee_Id,Ups_List_Rank,
				Ups_List_Time_Utc,Current_Status_Time_Utc,Last_Web_Lead_Suggested_Utc,
				Division_C,Region,Ss_Insert_Ts_Utc,Ss_Lst_Upd_Ts_Utc,Db_Source,
				Ss_Db_Status,Insert_Ts,Lst_Upd_Ts)
			SELECT
				User_Id_Cs,
				User_Name,
				Last_Name,
				First_Name,
				Middle_Name,
				Suffix,
				Name_Text,
				Company_Name,
				Division,
				Department,
				Title_Text,
				Street,
				City,
				State,
				Postal_Code,
				Country,
				State_Code,
				Country_Code,
				Latitude,
				Longitude,
				Email,
				Email_Prefs_Auto_Bcc,
				Email_Prefs_Aut_Bcc_Sty_In_Tch,
				Email_Prefs_St_In_Touch_Remind,
				Sender_Email,
				Sender_Name,
				Signature,
				Stay_In_Touch_Subject,
				Stay_In_Touch_Signature,
				Stay_In_Touch_Note,
				Phone,
				Fax,
				Mobile_Phone,
				Alias_Text,
				Community_Nickname,
				Badge_Text,
				Is_Active,
				Time_Zone_Sid_Key,
				User_Role_Id_Cs,
				Locale_Sid_Key,
				Receives_Info_Emails,
				Receives_Admin_Info_Emails,
				Email_Encoding_Key,
				Profile_Id_Cs,
				User_Type,
				Language_Locale_Key,
				Employee_Number,
				Delegated_Approver_Id_Cs,
				Manager_Id_Cs,
				Last_Login_Ts_Utc,
				Created_By_Id_Cs,
				Last_Modified_By_Id_Cs,
				Last_Updated_Ts_Utc,
				Offline_Trial_Expire_Ts_Utc,
				Offline_Pda_Trial_Expire_Ts_Utc,
				Perms_Marketinguser,
				Perms_Offline_User,
				Perms_Avantgo_User,
				Perms_Call_Center_Auto_Login,
				Perms_Mobile_User,
				Perms_Sf_Content_User,
				Perms_Knowledge_User,
				Perms_Interaction_User,
				Perms_Support_User,
				Perms_Chatter_Answers_User,
				Forecast_Enabled,
				Prefs_Activity_Remind_Popup,
				Prefs_Event_Remind_Ckbox_Dflt,
				Prefs_Task_Remind_Ckbox_Dflt,
				Prefs_Reminder_Soundoff,
				Prefs_Disable_All_Feeds_Email,
				Prefs_Disable_Followers_Email,
				Prefs_Disable_Prfl_Post_Email,
				Prefs_Disable_Change_Cmt_Email,
				Prefs_Disable_Later_Cmt_Email,
				Prefs_Dis_Prof_Post_Cmt_Email,
				Prefs_Cont_No_Email,
				Prefs_Cont_Email_As_And_When,
				Prefs_Apex_Pages_Dev_Mode,
				Prefs_Hide_Csn_Chat_Mobl_Task,
				Prefs_Disbl_Mention_Post_Email,
				Prefs_Dis_Mention_Cmt_Email,
				Prefs_Hide_Csn_Desktop_Task,
				Prefs_Hide_Chat_Onboard_Splash,
				Prefs_Hide_Sec_Chat_Ob_Splash,
				Prefs_Dis_Cmt_After_Like_Email,
				Prefs_Disable_Like_Email,
				Prefs_Sort_Feed_By_Comment,
				Prefs_Disable_Message_Email,
				Prefs_Disable_Bookmark_Email,
				Prefs_Disable_Share_Post_Email,
				Prefs_Enable_Aut_Sub_For_Feeds,
				Prefs_Dis_File_Shr_Nfn_For_Api,
				Prefs_Show_Title_To_Ext_Users,
				Prefs_Show_Mgr_To_Ext_Users,
				Prefs_Show_Email_To_Ext_Users,
				Prefs_Show_Wk_Phn_To_Ext_Users,
				Prefs_Show_Mb_Phn_To_Ext_Users,
				Prefs_Show_Fax_To_Ext_Users,
				Prefs_Show_St_Adr_To_Ext_Users,
				Prefs_Show_City_To_Ext_Users,
				Prefs_Show_State_To_Ext_Users,
				Prefs_Show_Postcd_To_Ext_Users,
				Prefs_Show_Cntry_To_Ext_Users,
				Prefs_Show_Prfpic_To_Gst_Users,
				Prefs_Show_Title_To_Gst_Users,
				Prefs_Show_City_To_Gst_Users,
				Prefs_Show_State_To_Gst_Users,
				Prefs_Show_Postcd_To_Gst_Users,
				Prefs_Show_Cntry_To_Gst_Users,
				Prefs_Disable_Endorsemnt_Email,
				Prefs_Path_Assistant_Collapsed,
				Prefs_Preview_Lightning,
				Contact_Id_Cs,
				Account_Id_Cs,
				Call_Center_Id_Cs,
				Extension,
				Federation_Identifier,
				About_Me,
				Full_Photo_Url,
				Small_Photo_Url,
				Digest_Frequency,
				Default_Group_Notif_Frequency,
				Last_Viewed_Ts_Utc,
				Last_Referenced_Ts_Utc,
				Status,
				Storenum,
				Store_Employee_Id,
				Ups_List_Rank,
				Ups_List_Time_Utc,
				Current_Status_Time_Utc,
				Last_Web_Lead_Suggested_Utc,
				Division_C,
				Region,
				Ss_Insert_Ts_Utc,
				Ss_Lst_Upd_Ts_Utc,
				Db_Source,
				Ss_Db_Status,
				Insert_Ts,
				Lst_Upd_Ts
			FROM
				SALES.EDW_SALESFORCE.Sf_User;
			Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 4 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc :=''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;

			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.SALES_LANDING.Sf_User;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF (Count_Source <> Count_Stage) THEN
				Sql_Statement :=''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.METADATA_CONTROLS.Error_Log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;

				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	---------------------------- 5 ---------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
			Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Stage , :Error_Count ,
			0 , :Count_Source);

	----------------------------- 6 -------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.SALES_STAGING.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id);
			CALL DATAOPS.METADATA_CONTROLS.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Stage, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Stage;
		
			Final_output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
			RETURN :Final_output;
	EXCEPTION 
	When Planned_Exception then 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	When OTHER then 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.SALES_STAGING.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )         
		VALUES         ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT         INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES         (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

    		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

END;
';