CREATE OR REPLACE PROCEDURE "SP_STAGE_SF_LEAD_TYPE_CMBS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE

	/*****************************************************************************************************************************************************************************
		Created: 2019-05-29		By: Veena G
		Purpose: Stage Sp_Stage_SF_Lead_Type_Cmbs

		Sample Run Command:
		call	Sales_Staging.sp_Stage_SF_Lead_Type_Cmbs (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------

		06/30/2022      Vpetluru    Fix the Spool space issue raised by step 5
	*****************************************************************************************************************************************************************************/

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running

		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log

		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process

		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log

		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday

		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage

		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target

		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained

		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs

		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 

		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered

		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written To The Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs

		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records

		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To

		Record_Count	INTEGER := 0; -- Multi-Purpose

		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log

		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also

		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log

		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	

		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)

		Table_Source	VARCHAR(100); -- For Code Repeatability

		Table_Target	VARCHAR(100); -- For Code Repeatability	

		Table_Stage	VARCHAR(100); -- For Code Repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance

		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use

		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	-- Custom Procedure Variable 
		Lead_Type 		VARCHAR(200); -- Distinct Lead_Type From sf_Lead Table

		Lead_Type_Split 		VARCHAR(200); -- Split Lead_Type

		Strt_Loc 		INTEGER := 1; -- Start Location For Splitting Lead_Type In Cursor

		Len 			INTEGER := 1; -- Length Of Split Lead_Type In Cursor

		Pos 			INTEGER := 1; -- Position Of Split Lead_Type In Cursor
	--DECLARE Cursor_Lead_Type 		CURSOR FOR		-- Name Of Cursor
	--(
	--SELECT DISTINCT Lead_Type FROM edw_salesforce.sf_lead WHERE  Lead_Type IS NOT NULL AND Lead_Source =''Web'' ORDER BY Lead_Type
	--) ;
        Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 

		Final_Output Object;

     Planned_Exception   Exception (-20001, ''Exception based on Error_Condition'');


	BEGIN

		Activity_Name := ''sp_Stage_SF_Lead_Type_Cmbs'';
		Code_Lines := 475;
		Database_Source := ''edw_salesforce'';
		Database_Stage := ''Sales_Staging'';
		Database_Target := ''Sales_Staging'';
		Process_Id := 458;
		Table_Source := ''sf_lead'';
		Table_Stage := ''SF_Lead_Type_Cmb'';
		Table_Target := ''SF_Lead_Type_Cmb'';
		Version := 2.0;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
	FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
	WHERE Calendar_Date = CURRENT_DATE ;

--	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	P1:
		-- Start Of Procedural Steps With Exception Handler
		BEGIN			 

	--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;
			Sql_Statement := ''Get Parameters'';

	---------- 1 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
		(
					SELECT DISTINCT
						Lead_Type
					FROM
						SALES.edw_salesforce.sf_lead
					WHERE
						Lead_Type IS NOT NULL AND Lead_Source =''Web''
		) Cnt_Lead ;
			Count_Source := COALESCE ( :Record_Count , 0 );
			IF (Count_Source = 0) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;
				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;
	-----------2-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Delete From Stage Table SF_Lead_Type_Cmb_Split_Tmp_1 and SF_Lead_Type_Cmb_Split_Tmp_0'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0;
			DELETE FROM
				SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1;
	-----------3-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage "Table"'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.Sales_Staging.SF_Lead_Type_Cmb;

	-----------4-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Split Records Into Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0
			SELECT
				ROW_NUMBER () OVER (ORDER BY Lead_Type) as Lead_Type_Rn,
				Lead_Type
			FROM
			(
					SELECT DISTINCT
						Lead_Type
					FROM
						SALES.edw_salesforce.sf_lead
					WHERE
						Lead_Type IS NOT NULL AND Lead_Source =''Web'' ) ot;
			Record_Count := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);

	-----------5-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Split Records Into Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Record_Count := 0;
			Count_Last := 0;
			Sql_Statement := Activity_Desc;

			/*OPEN Cursor_Lead_Type;

			Label1:LOOP
			FETCH Cursor_Lead_Type INTO Lead_Type;

			IF (SQLSTATE = ''02000'') THEN
			 LEAVE Label1;
			End If;

			SET Strt_Loc = 1 ;

			WHILE ( Strt_Loc <= CHARACTER_LENGTH(Lead_Type) ) DO
			BEGIN

			SELECT CASE WHEN POSITION( '';'' IN SUBSTR(Lead_Type, Strt_Loc)) = 0
				THEN 0
				ELSE POSITION( '';'' IN SUBSTR(Lead_Type, Strt_Loc))  + Strt_Loc - 1 
				End 
			INTO Pos ;

			SELECT CASE WHEN Pos = 0 
				THEN CHARACTER_LENGTH(SUBSTR(Lead_Type, Strt_Loc)) 
				ELSE Pos - Strt_Loc
				End 
			INTO Len ;

			SELECT SUBSTR(Lead_Type, Strt_Loc , Len ) INTO Lead_Type_Split;

			INSERT INTO Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1 
				(Lead_Type, 
				Lead_Type_Split)
			SELECT  Lead_Type, 
				Lead_Type_Split ;

			SET	Count_Last = Count_Last + COALESCE ( ACTIVITY_COUNT , 0 ) ;

			SELECT CASE WHEN Pos = 0 
				THEN CHARACTER_LENGTH(Lead_Type) + 1 
				ELSE Pos + 1
				End 
			INTO Strt_Loc ;

			End ;
			End While ;

			WHILE ( Lead_Type IS NULL AND Strt_Loc = 1 ) DO
			BEGIN
			INSERT INTO Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1 
				(Lead_Type, 
				Lead_Type_Split)
			SELECT  Lead_Type, 
				NULL ;
			SET 	Strt_Loc = Strt_Loc + 1 ; 
			END;
			END WHILE;

			End Loop Label1;
			CLOSE Cursor_Lead_Type;*/
			INSERT INTO SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1 (Lead_Type, Lead_Type_Split)
			SELECT DISTINCT ltcs.Lead_Type,
				strtk.Lead_Type
			FROM
			(
					SELECT
						CAST(SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0.Lead_Type_Rn AS INTEGER) AS outkey,
						outkey as Lead_Type_Rn,
						CAST(d.VALUE AS VARCHAR) as Lead_Type
					FROM
						SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0,
						TABLE  (STRTOK_SPLIT_TO_TABLE(SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0.Lead_Type, '';'')) as d WHERE
						CAST( d.VALUE AS VARCHAR) IS NOT NULL AND outkey <> -1 ) strtk ,
				SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0 ltcs
			WHERE ltcs.Lead_Type_Rn = strtk.Lead_Type_Rn ;
			Count_Last := Count_Last + COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc , :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	----------- 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1 With Row_Number'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1
	SET 	Rn =Tmp.Rn
				FROM
					(
						SELECT
							Lead_Type,
							Lead_Type_Split,
							ROW_NUMBER() OVER(PARTITION BY
								Lead_Type
							ORDER BY Lead_Type_Split ASC NULLS FIRST) AS Rn
						FROM
							SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1
					)Tmp
	WHERE 	COALESCE(Tmp.Lead_Type,''NULL'')= COALESCE(SF_Lead_Type_Cmb_Split_Tmp_1.Lead_Type,''NULL'')
	AND      COALESCE(Tmp.Lead_Type_Split,''NULL'')=COALESCE(SF_Lead_Type_Cmb_Split_Tmp_1.Lead_Type_Split,''NULL'');
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	----------- 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Into ''|| Database_Stage || ''.'' || Table_Target;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.SF_Lead_Type_Cmb (Lead_Type_Key, Lead_Type_Desc)
			WITH RECURSIVE Rec_Lead_Type(Lead_Type,Lead_Type_Split, Lvl) AS
			(
				SELECT
					LEFT(Lead_Type, 200),
					LEFT(Lead_Type_Split, 200),
					1
					  	FROM
					SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1
					  	WHERE Rn = 1
				   	UNION ALL
				SELECT
					Tmp.Lead_Type,
					TRIM(Rec_Lead_Type.Lead_Type_Split) || '';'' || Tmp.Lead_Type_Split,
					  		Lvl+1
					  	FROM
					SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1 Tmp
				INNER JOIN Rec_Lead_Type
					  		ON Tmp.Lead_Type	= Rec_Lead_Type.Lead_Type
					 		AND Tmp.Rn 	= Rec_Lead_Type.Lvl+1
			)
			SELECT
				Lead_Type AS Lead_Type_Key,
				Lead_Type_Split AS Lead_Type_Desc
	FROM Rec_Lead_Type
			QUALIFY
				RANK() OVER(PARTITION BY
					Lead_Type
				ORDER BY Lvl DESC NULLS LAST) = 1;
			Count_Last := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			Record_Count := 0;

			SELECT
				COUNT (*) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.SF_Lead_Type_Cmb;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF ( Count_Source <> Count_Stage) THEN
				Sql_Statement := ''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				--Sql_State_Code := SQLSTATE;
				INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition, Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''Na''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				RAISE Planned_Exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
				Target_Balanced := ''Y'';
				
			END IF;

	-- 9 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Delete Staged Data If No Errors From SF_Lead_Type_Cmb_Split_Tmp_1 and SF_Lead_Type_Cmb_Split_Tmp_0'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			IF (Target_Balanced = ''Y'' AND COALESCE ( Error_Count, 0 ) = 0) THEN
				Sql_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_0;
				DELETE FROM
					SALES.Sales_Staging.SF_Lead_Type_Cmb_Split_Tmp_1;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, ''Target_Balanced = '' || :Target_Balanced, :Completed_Flag, :Error_Count, :Error_Count, :Step_Id);
			END IF;

	---- 10 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Metadata Table_Controls Record'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
			Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Stage , :Error_Count ,
			0 , :Count_Source);

	----- 10 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage , :Step_Id);
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Stage, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Stage;
		END;
		
		Final_Output := object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
		return :Final_Output;
	
	EXCEPTION 
	When Planned_Exception then 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	When OTHER then 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )         
		VALUES         ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT         INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES         (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

    		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

END;
';