CREATE OR REPLACE PROCEDURE "SP_STAGE_LEADS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
OUT_ERROR_COUNT SMALLINT := 0;
OUT_HARD_STOP_ERROR BYTEINT := 0;
OUT_RECORDS_LOADED INTEGER := 0;
Final_Output Object;
Planned_Exception   Exception (-20001, ''Exception based on Error_Condition'');

	/*****************************************************************************************************************************************************************************
		Created: 2018-11-05		By: Harini Nagarajan
		Purpose: Stage Leads

		Sample Run Command:
		call	SALES.Sales_Staging.sp_Stage_Leads (Out_Error_Count, Out_Hard_Stop_Error, Out_Records_Loaded);

		  	Modified Date	Modified By	Notes
		-------------	-----------	------------------------------------------------------------------------------------------------------------------------------
		5-6-2019		Harini		Added Employee_Created_By_Key in Leads dimension
		2019-05-17	Veena		Modified employee_key population logic for machine generated employee_key
		2019-05-29	Veena		Added join on SALES.Sales_Staging.SF_Lead_Type_Cmb. replacing sf_lead.Lead_type with SF_Lead_Type_Cmb.Lead_type_Desc
		2019-10-15	Aravindakshan	Changed to reserved container as part of CCPA - Phase 1
		2019-12-16	Harini		Changed to reserved container as part of CCPA - Phase 2
		2020-04-29	Matt			adding new fields for leads enhancement
		2020-05-18	Matt			correct DB to sales_staging in step 21
		2020-06-15	Matt			add new logic for nice work item ID due to sf_lead changes
		2020-07-08	Matt			add partition conditions to NICE agent job step
		2020-07-21	Matt			Remove agent name
		2020-07-27	Matt			add filter on step 30
		2020-08-05	Matt			remove join to calendar on steps 23-26
		2020-08-07  Vamsi			adding new field for leads enhancement lead_data_entry_method
		2020-10-08  Vamsi			Web_leads Decommission changes at lines 516, 517 to 519 ,529 ,530
		2021-02-19  Vamsi			Add filter at step 18 to pick only Big int values from SALES.edw_salesforce.sf_nice_work_item_status LENGTH(work_item_id_cs) <= 20 
		2022-09-26 Vamsi			Updated  section 22 to pick latest ntLoginName for a given Agent number
	*****************************************************************************************************************************************************************************/

	-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The Name Of The Procedure Running
		Activity_Desc	VARCHAR(500); -- A Description Of The Step In The Procedure Running For The Activity Log
		Batch_Number	INTEGER := 0; -- Holds The Batch Key Assigned In The Landing Process
		Calendar_Key	INTEGER := 0; -- Used To Hold Today''S Calendar By Day Key
		Code_Lines	SMALLINT := 0; -- Count Of Lines Of Code In This Procedure For Control Purposes
		Completed_Flag	CHAR(1)  := ''N''; -- Used For Updating The Activity Log
		Count_Last	INTEGER := 0; -- Used Within The Procedure To Compare Record Count Today To Yesterday
		Count_Source	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage
		Count_Stage	INTEGER := 0; -- Used Within The Procedure To Reconcile Source To Stage
		Count_Target	INTEGER := 0; -- Used Within The Procedure To Reconcile Stage To Target
		Database_Source	VARCHAR(100); -- Used To Specify The Database Where Data Is Obtained
		Database_Stage 	VARCHAR(100); -- Used To Specify The Database In Which This Procedure Runs
		Database_Target	VARCHAR(100); -- Used To Specify The Public Production Database 
		Error_Condition	BYTEINT := 0; -- Identifies The Last Error Condition Encountered
		Error_Count	SMALLINT := 0; -- Written To Out_Error_Count
		Error_Key	SMALLINT := 0; -- Written To The Error_Log
		Hard_Stop_Count	BYTEINT := 0; -- Count Of Hard Stop Errors Encountered By All Called Procs
		Last_Record_Key	INTEGER := 0; -- Used To Identify The Existing Vs New Records
		Process_Id	INTEGER := 0; -- Identifies The Process_Control_Key This Job Process Is Related To
		Record_Count	INTEGER := 0; -- Multi-Purpose
		Sql_Return_Code	INTEGER := 0; -- Holds The Sqlcode Reported By Teradata When An Error Occurs - Written To The Error_Log
		Sql_Statement	VARCHAR(5000) := ''''; -- Hold Dynamic Sql - May Be Written To Error Log Also
		Sql_State_Code	VARCHAR(5) := ''''; -- Holds The Value Reported For Sqlstate When An Error Occurs - Written To The Error_Log
		Start_Time TIMESTAMP(0); -- Time When This Procedure Starts	
		Step_Id		SMALLINT := 0; -- The Step Number In The Procedure That Runs Next (Reflected In The Activity Log)
		Table_Source	VARCHAR(100); -- For Code Repeatability
		Table_Target	VARCHAR(100); -- For Code Repeatability	
		Table_Stage	VARCHAR(100); -- For Code Repeatability	
		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies Whether The Stage, And Target Balance
		Version		DECIMAL(6,3) := 0.00; -- The Version Of This Stored Procedure In Use
		Max_Amount	DECIMAL(9,2) := 0.00; -- The Max Amount For Fee Type 100,111,112

	-- Custom Procedure Variables
		Index_Exists	BYTEINT := 0; -- Used To Signal Whether An Index Needs To Be Dropped
		Index_Limit	INTEGER := 0; -- Used to determine Whether An Index Needs To Be Dropped

	BEGIN

		Activity_Name := ''sp_Stage_Leads'';
		Code_Lines := 1781;
		Database_Source := ''Sales_Landing'';
		Database_Stage := ''Sales_Staging'';
		Database_Target := ''Sales'';
		Process_Id := 458;
		Table_Source := ''Web_Leads'';
		Table_Stage := ''Leads'';
		Table_Target := ''Leads'';
		Version := 1.14;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE() ;

--	------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--	P1:
		-- Start Of Procedural Steps With Exception Handler
		BEGIN

	---------------------- 0 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Set Metadata_Controls.Run_Time_Results Record To Zero'';
			CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_Id , :Process_Id , ''Teradata'' , :Table_Target, :Version ) ;
	---------------------- 1 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Confirm Data Exists In The Source Table '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.sales_landing.Web_Leads;
			Count_Source := COALESCE (:Record_Count , 0);
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.sales_landing.Sf_Lead
		WHERE 	Lead_Source =''Web'' ;
			Count_Source := Count_Source + COALESCE (:Record_Count , 0);
			IF (Count_Source = 0 ) THEN
				Activity_Desc := ''No Records To Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
					:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := Count_Source;
				RAISE Planned_exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);
			END IF;

	---------------------- 2 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE FROM
   Stage Tables'' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.Sales_Staging.Leads;

	---------------------- 3 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Collect Record Counts Participated In Merge With Join And +/- 1 Second Wiggle'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
		(
					SELECT
						Lead.Lead_Id
					FROM
					(
							SELECT
								Sf_Lead.Lead_Id_Cs,
								Web_Leads.Lead_Id,
								CASE
									WHEN
									(
									
									DATAOPS.UTILITIES.TIMESTAMP_DIFFERENCE_UDF(TO_TIMESTAMP(LEFT(CAST(Web_Leads.Submit_Date AS VARCHAR), 19)), TO_TIMESTAMP(LEFT(CAST(Sf_Lead.Web_Lead_Submit_Date_Utc AS VARCHAR), 19)), ''MINUTE TO SECOND''))= ''0:00.000000''
										THEN 1
									WHEN
									(
									
									DATAOPS.UTILITIES.TIMESTAMP_DIFFERENCE_UDF(TO_TIMESTAMP(LEFT(CAST(Web_Leads.Submit_Date AS VARCHAR), 19)), TO_TIMESTAMP(LEFT(CAST(Sf_Lead.Web_Lead_Submit_Date_Utc AS VARCHAR), 19)), ''MINUTE TO SECOND'')) =''-0:01.000000''
										THEN 2
								ELSE 3
								END AS Priority
								      	FROM
								SALES.sales_landing.Web_Leads Web_Leads
								      	LEFT 	JOIN
									SALES.Sales_Staging.Appt_Activities_Cmb Appt
								      		ON	COALESCE(Web_Leads.Appt_Activities,Web_Leads.Lead_Type) = Appt.Appt_Key
								      	INNER 	JOIN
									SALES.sales_landing.Sf_Lead Sf_Lead
								ON	Web_Leads.Email 	= Sf_Lead.Email
								      	         AND	Web_Leads.Stock_Num = Sf_Lead.Stock_Number
								      	         AND	Web_Leads.Loc_Num 	= Sf_Lead.Store_Location_Number
								AND	Web_Leads.Submit_Date
									BETWEEN  (Sf_Lead.Web_Lead_Submit_Date_Utc - INTERVAL ''1 SECOND'')
								      	         AND	(Sf_Lead.Web_Lead_Submit_Date_Utc + INTERVAL ''1 SECOND'')
							LEFT 	JOIN
									SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
								ON 	Sf_Lead.Lead_Type =Sf_Cmb.Lead_Type_Key
							WHERE Sf_Lead.Lead_Source =''Web''
							AND Appt.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
							AND sf_lead.sf_update_only_flag = ''N''
							QUALIFY
								ROW_NUMBER() OVER (PARTITION BY  Sf_Lead.Lead_Id_Cs
								      	         ORDER BY Priority ASC NULLS FIRST) = 1
					) Lead
						GROUP BY Lead.Lead_Id
					HAVING COUNT(*) = 1
		)Mer;
			Count_Source := Count_Source - COALESCE ( :Record_Count , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_Id);

	---------------------- 4 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Leads (
			Advertising_Code, Advertising_Code_Date, Lead_Email_Address,
			Lead_Full_Name, Lead_Phone_Number,Lead_Visit_Purpose, Mykmx_Id,
			Store_Customer_Id, Smw_Contact_Id, Salesforce_Record_Id,
			Salesforce_Web_Lead_Id, Source_Session_Id, Source_Visitor_Id,
			Web_Lead_Id, Created_By_Id_Cs, Record_Merged, Dw_Insert_Ts)
			SELECT DISTINCT Web_Leads.Advertising_Code  			AS Advertising_Code,
				TO_DATE(SUBSTR(LEFT(CAST(Web_Leads.Advertising_Code_Date
					AS VARCHAR), 19), 1, 10), ''YYYY-MM-DD'')  AS Advertising_Code_Date,
				Sf_Lead.Email 						AS Lead_Email_Address,
				COALESCE(Sf_Lead.Name_Text,Web_Leads.Lead_Name,''NA'')
											AS Lead_Full_Name,
				Sf_Lead.Phone	    					AS Lead_Phone_Number,
				Web_Leads.Lead_Type 					AS Lead_Visit_Purpose,
				''NA''					 		AS Mykmx_Id,
				LEFT(
				CAST( Sf_Lead.Oe_Customer_Id AS VARCHAR), 10) 		AS Store_Customer_Id,
				Sf_Lead.Oe_Contact_Id		 			AS Smw_Contact_Id,
				Sf_Lead.Lead_Id_Cs 					AS Salesforce_Record_Id,
				Sf_Lead.Web_Lead_Id 					AS Salesforce_Web_Lead_Id,
				Web_Leads.Session_Id  					AS Source_Session_Id,
				Web_Leads.Visitor_Id 					AS Source_Visitor_Id,
				Web_Leads.Lead_Id						AS Web_Lead_Id,
				Sf_Lead.Created_By_Id_Cs					AS Created_By_Id_Cs,
				''Y''							AS Record_Merged,
				CURRENT_TIMESTAMP(0) 					AS Dw_Insert_Ts
			FROM
				SALES.sales_landing.Web_Leads Web_Leads
			LEFT JOIN
					SALES.Sales_Staging.Appt_Activities_Cmb Appt
			ON 	COALESCE(Web_Leads.Appt_Activities,Web_Leads.Lead_Type) = Appt.Appt_Key
			INNER JOIN
					SALES.sales_landing.Sf_Lead Sf_Lead
			ON	Web_Leads.Email 	= Sf_Lead.Email
			AND 	Web_Leads.Stock_Num = Sf_Lead.Stock_Number
			AND 	Web_Leads.Loc_Num 	= Sf_Lead.Store_Location_Number
			AND 	Web_Leads.Submit_Date  =  Sf_Lead.Web_Lead_Submit_Date_Utc
			LEFT 	JOIN
					SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
			ON 	Sf_Lead.Lead_Type =Sf_Cmb.Lead_Type_Key
			WHERE	Web_Leads.Email 		IS NOT NULL
			AND	Web_Leads.Stock_Num 	IS NOT NULL
			AND	Web_Leads.Submit_Date 	IS NOT NULL
			AND	Web_Leads.Lead_Type 	IS NOT NULL
			AND 	Web_Leads.Loc_Num 	IS NOT NULL
			AND	Sf_Lead.Email 		IS NOT NULL
			AND	Sf_Lead.Stock_Number 	IS NOT NULL
			AND 	Sf_Lead.Store_Location_Number IS NOT NULL
			AND	Sf_Lead.Web_Lead_Submit_Date_Utc IS NOT NULL
			AND	Sf_Lead.Lead_Type 	IS NOT NULL
			AND	Sf_Lead.Lead_Source =''Web''
			AND 	Appt.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
			AND	sf_Lead.SF_Update_Only_Flag = ''N'';
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 5 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Leads (
			Advertising_Code, Advertising_Code_Date,  Lead_Email_Address,
			Lead_Full_Name, Lead_Phone_Number,Lead_Visit_Purpose, Mykmx_Id,
			Store_Customer_Id, Smw_Contact_Id, Salesforce_Record_Id,
			Salesforce_Web_Lead_Id, Source_Session_Id, Source_Visitor_Id,
			Web_Lead_Id, Created_By_Id_Cs, Record_Merged, Dw_Insert_Ts)
			SELECT DISTINCT Web_Leads.Advertising_Code  			AS Advertising_Code,
				TO_DATE(SUBSTR(LEFT(CAST(Web_Leads.Advertising_Code_Date
					AS VARCHAR), 19), 1, 10), ''YYYY-MM-DD'')  AS Advertising_Code_Date,
				Sf_Lead.Email 						AS Lead_Email_Address,
				COALESCE(Sf_Lead.Name_Text,Web_Leads.Lead_Name,''NA'')		AS Lead_Full_Name,
				Sf_Lead.Phone	    					AS Lead_Phone_Number,
				Web_Leads.Lead_Type 					AS Lead_Visit_Purpose,
				''NA''					 		AS Mykmx_Id,
				LEFT(
				CAST(Sf_Lead.Oe_Customer_Id AS VARCHAR), 10) 		AS Store_Customer_Id,
				Sf_Lead.Oe_Contact_Id		 			AS Smw_Contact_Id,
				Sf_Lead.Lead_Id_Cs					AS Salesforce_Record_Id,
				Sf_Lead.Web_Lead_Id					AS Salesforce_Web_Lead_Id,
				Web_Leads.Session_Id					AS Source_Session_Id,
				Web_Leads.Visitor_Id					AS Source_Visitor_Id,
				Web_Leads.Lead_Id						AS Web_Lead_Id,
				Sf_Lead.Created_By_Id_Cs					AS Created_By_Id_Cs,
				''Y''							AS Record_Merged,
				CURRENT_TIMESTAMP(0) 					AS Dw_Insert_Ts
			FROM
				SALES.sales_landing.Web_Leads Web_Leads
			LEFT JOIN
					SALES.Sales_Staging.Appt_Activities_Cmb Appt
			ON 	COALESCE(Web_Leads.Appt_Activities,Web_Leads.Lead_Type) = Appt.Appt_Key
			INNER JOIN
					SALES.sales_landing.Sf_Lead Sf_Lead
			ON	Web_Leads.Email 	= Sf_Lead.Email
			AND 	Web_Leads.Stock_Num = Sf_Lead.Stock_Number
			AND 	Web_Leads.Loc_Num 	= Sf_Lead.Store_Location_Number
			AND 	Web_Leads.Submit_Date  = (Sf_Lead.Web_Lead_Submit_Date_Utc - INTERVAL ''1 SECOND'')
			LEFT 	JOIN
					SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
			ON 	Sf_Lead.Lead_Type = Sf_Cmb.Lead_Type_Key
			WHERE	Web_Leads.Email 		IS NOT NULL
			AND	Web_Leads.Stock_Num 	IS NOT NULL
			AND	Web_Leads.Submit_Date 	IS NOT NULL
			AND	Web_Leads.Lead_Type 	IS NOT NULL
			AND 	Web_Leads.Loc_Num 	IS NOT NULL
			AND	Sf_Lead.Email 		IS NOT NULL
			AND	Sf_Lead.Stock_Number 	IS NOT NULL
			AND	Sf_Lead.Lead_Type 	IS NOT NULL
			AND	Sf_Lead.Web_Lead_Submit_Date_Utc IS NOT NULL
			AND 	Sf_Lead.Store_Location_Number IS NOT NULL
			AND  	NOT(Sf_Lead.Lead_Id_Cs::VARCHAR IN (
					SELECT
						Salesforce_Record_Id
					FROM
						SALES.Sales_Staging.Leads
				))
			AND	Sf_Lead.Lead_Source =''Web''
			AND 	Appt.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
			AND	sf_Lead.SF_Update_Only_Flag = ''N'';
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 6 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From '' || Database_Source || ''.'' || Table_Source || ''For 1 Sec Difference'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Leads (
			Advertising_Code, Advertising_Code_Date,  Lead_Email_Address,
			Lead_Full_Name, Lead_Phone_Number,Lead_Visit_Purpose, Mykmx_Id,
			Store_Customer_Id, Smw_Contact_Id, Salesforce_Record_Id,
			Salesforce_Web_Lead_Id, Source_Session_Id, Source_Visitor_Id,
			Web_Lead_Id, Created_By_Id_Cs, Record_Merged, Dw_Insert_Ts)
			SELECT DISTINCT Web_Leads.Advertising_Code  			AS Advertising_Code,
				TO_DATE(SUBSTR(LEFT(CAST(Web_Leads.Advertising_Code_Date
					AS VARCHAR), 19), 1, 10), ''YYYY-MM-DD'')  AS Advertising_Code_Date,
				Sf_Lead.Email 						AS Lead_Email_Address,
				COALESCE(Sf_Lead.Name_Text,Web_Leads.Lead_Name,''NA'') 		AS Lead_Full_Name,
				Sf_Lead.Phone	 	   				AS Lead_Phone_Number,
				Web_Leads.Lead_Type 					AS Lead_Visit_Purpose,
				''NA''					 		AS Mykmx_Id,
				LEFT(
				CAST(Sf_Lead.Oe_Customer_Id AS VARCHAR), 10) 		AS Store_Customer_Id,
				Sf_Lead.Oe_Contact_Id		 			AS Smw_Contact_Id,
				Sf_Lead.Lead_Id_Cs					AS Salesforce_Record_Id,
				Sf_Lead.Web_Lead_Id 					AS Salesforce_Web_Lead_Id,
				Web_Leads.Session_Id					AS Source_Session_Id,
				Web_Leads.Visitor_Id					AS Source_Visitor_Id,
				Web_Leads.Lead_Id						AS Web_Lead_Id,
				Sf_Lead.Created_By_Id_Cs					AS Created_By_Id_Cs,
				''Y''							AS Record_Merged,
				CURRENT_TIMESTAMP(0) 					AS Dw_Insert_Ts
			FROM
				SALES.sales_landing.Web_Leads Web_Leads
			LEFT 	JOIN
					SALES.Sales_Staging.Appt_Activities_Cmb Appt
			ON 	COALESCE(Web_Leads.Appt_Activities,Web_Leads.Lead_Type) = Appt.Appt_Key
			INNER 	JOIN
					SALES.sales_landing.Sf_Lead Sf_Lead
			ON	Web_Leads.Email 		= Sf_Lead.Email
			AND 	Web_Leads.Stock_Num 	= Sf_Lead.Stock_Number
			AND 	Web_Leads.Submit_Date  	= (Sf_Lead.Web_Lead_Submit_Date_Utc + INTERVAL ''1 SECOND'')
			AND 	Web_Leads.Loc_Num 	= Sf_Lead.Store_Location_Number
			LEFT 	JOIN
					SALES.Sales_Staging.SF_Lead_Type_Cmb Sf_Cmb
			ON 	Sf_Lead.Lead_Type =Sf_Cmb.Lead_Type_Key
			WHERE	Web_Leads.Email 		IS NOT NULL
			AND	Web_Leads.Stock_Num 	IS NOT NULL
			AND	Web_Leads.Submit_Date 	IS NOT NULL
			AND	Web_Leads.Lead_Type 	IS NOT NULL
			AND 	Web_Leads.Loc_Num 	IS NOT NULL
			AND	Sf_Lead.Email 		IS NOT NULL
			AND	Sf_Lead.Stock_Number 	IS NOT NULL
			AND	Sf_Lead.Web_Lead_Submit_Date_Utc IS NOT NULL
			AND	Sf_Lead.Lead_Type 	IS NOT NULL
			AND 	Sf_Lead.Store_Location_Number IS NOT NULL
			AND  	NOT(Sf_Lead.Lead_Id_Cs::VARCHAR IN (
					SELECT
						Salesforce_Record_Id
					FROM
						SALES.Sales_Staging.Leads
				))
			AND	Sf_Lead.Lead_Source =''Web''
			AND	Appt.Appt_Desc	= Sf_Cmb.Lead_Type_Desc
			AND	sf_Lead.SF_Update_Only_Flag = ''N'';
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 7 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Delete Duplicate Lead_Id Records From Sales_Staging.Leads '';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			DELETE FROM
				SALES.Sales_Staging.Leads
			WHERE
				Web_Lead_Id IN
				(
					SELECT
						Web_Lead_Id
					FROM	(
							SELECT
								Web_Lead_Id,
								COUNT(1) AS Rcnt
								FROM
								SALES.Sales_Staging.Leads
								GROUP BY Web_Lead_Id
								HAVING COUNT(1) > 1
						)AS Dup_Lead
				);
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 8 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From sales_landing.Web_Leads'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Leads (
			Advertising_Code, Advertising_Code_Date,  Lead_Email_Address,
			Lead_Full_Name, Lead_Phone_Number,Lead_Visit_Purpose, Mykmx_Id,
			Store_Customer_Id, Smw_Contact_Id, Salesforce_Record_Id,
			Salesforce_Web_Lead_Id, Source_Session_Id, Source_Visitor_Id,
			Web_Lead_Id, Created_By_Id_Cs, Record_Merged, Dw_Insert_Ts)
			SELECT DISTINCT
				LEFT( CAST(Web.Advertising_Code AS VARCHAR), 25) 		AS Advertising_Code,
				TO_DATE(SUBSTR(LEFT(CAST(Web.Advertising_Code_Date
						AS VARCHAR), 19), 1, 10), ''YYYY-MM-DD'')  AS Advertising_Code_Date,
				LEFT(
				CAST(Web.Email AS VARCHAR), 255)				AS Lead_Email_Address,
				COALESCE(LEFT(CAST(Web.Lead_Name AS VARCHAR), 175),''NA'')  		AS Lead_Full_Name,
				NULL 							AS Lead_Phone_Number,
				LEFT(
				CAST(Web.Lead_Type AS VARCHAR), 25)				AS Lead_Visit_Purpose,
				''NA''					 		AS Mykmx_Id,
				LEFT(
				CAST(NULL AS VARCHAR), 10) 				AS Store_Customer_Id,
				CAST(NULL AS INTEGER) 					AS Smw_Contact_Id,
				''NA''				 			AS Salesforce_Record_Id,
				LEFT(
				CAST(NULL AS VARCHAR), 40) 				AS Salesforce_Web_Lead_Id,
				LEFT(
				CAST(Web.Session_Id AS VARCHAR), 40) 			AS Source_Session_Id,
				LEFT(
				CAST(Web.Visitor_Id AS VARCHAR), 40)			AS Source_Visitor_Id,
				Web.Lead_Id						AS Web_Lead_Id,
				RPAD(
				SUBSTR(NULL,0,18), 18)					AS Created_By_Id_Cs,
				''N''							AS Record_Merged,
				CURRENT_TIMESTAMP(0) 					AS Dw_Insert_Ts
			FROM
				SALES.sales_landing.Web_Leads Web
			WHERE	NOT(Web.Lead_Id
			IN  (
					SELECT
						COALESCE(
						Web_Lead_Id,''-1'') FROM
						SALES.Sales_Staging.Leads
				));
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 9 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert  Into ''|| Database_Stage || ''.'' || Table_Stage || '' From sales_landing.Sf_Lead'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			INSERT INTO SALES.Sales_Staging.Leads (
			Advertising_Code, Advertising_Code_Date,  Lead_Email_Address,
			Lead_Full_Name, Lead_Phone_Number,Lead_Visit_Purpose, Mykmx_Id,
			Store_Customer_Id, Smw_Contact_Id, Salesforce_Record_Id,
			Salesforce_Web_Lead_Id, Source_Session_Id, Source_Visitor_Id,
			Web_Lead_Id, Created_By_Id_Cs, Record_Merged, SF_Update_Only_Flag, Dw_Insert_Ts)
			SELECT DISTINCT SUBSTR(COALESCE(Sf.adcode, LEFT(CAST(NULL AS VARCHAR), 25)),0,25)			AS Advertising_Code,
				COALESCE(TO_DATE(SUBSTR(LEFT(CAST(sf.adcode_datetime
				         AS VARCHAR), 19), 1, 10), ''YYYY-MM-DD'') , CAST(NULL AS DATE) ) 			AS Advertising_Code_Date,
				Sf.Email 						AS Lead_Email_Address,
				COALESCE(Sf.Name_Text,''NA'') 				AS Lead_Full_Name,
				SUBSTR(Sf.Phone,0,12)		     					AS Lead_Phone_Number,
				''NA''							AS Lead_Visit_Purpose,
				''NA''			 				AS Mykmx_Id,
				Sf.Oe_Customer_Id 					AS Store_Customer_Id,
				Sf.Oe_Contact_Id 						AS Smw_Contact_Id,
				Sf.Lead_Id_Cs 						AS Salesforce_Record_Id,
				Sf.Web_Lead_Id 						AS Salesforce_Web_Lead_Id,
				COALESCE(Sf.sessionid, LEFT(CAST(NULL AS VARCHAR), 40)) 				AS Source_Session_Id,
				COALESCE(SUBSTR(Sf.visitorid,0,40), LEFT(CAST(NULL AS VARCHAR), 40)) 				AS Source_Visitor_Id,
				-1							AS Web_Lead_Id,
				Sf.Created_By_Id_Cs					AS Created_By_Id_Cs,
				''N''							AS Record_Merged,
				sf.SF_Update_Only_Flag				AS SF_Update_Only_Flag,
				CURRENT_TIMESTAMP(0) 					AS Dw_Insert_Ts
			FROM
				SALES.sales_landing.Sf_Lead Sf
			WHERE	NOT(Sf.Lead_Id_Cs::VARCHAR
			IN  (
					SELECT
						Salesforce_Record_Id
					FROM
						SALES.Sales_Staging.Leads
					WHERE
						Salesforce_Record_Id <> ''Na'' ))
			AND	Sf.Lead_Source =''Web'' ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 10 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Clean Up Phone Numbers ''|| Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			Sql_Statement := ''Remove Spaces'';
			Record_Count := 0;
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = TRIM(Lead_Phone_Number)				;
			Sql_Statement := ''Remove Braces'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 2)
	WHERE	POSITION(''('' IN (Lead_Phone_Number)) = 1 ;
			Record_Count := COALESCE (  :SQLROWCOUNT , 0 );
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION('')'' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION('')'' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION('')'' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove First Hyphen'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION(''-'' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION(''-'' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION(''-'' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove Second Hyphen'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION(''-'' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION(''-'' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION(''-'' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove Third Hyphen'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION(''-'' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION(''-'' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION(''-'' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove First Space'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION('' '' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION('' '' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION('' '' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove Second Space'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION('' '' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION('' '' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION('' '' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove Third Space'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, POSITION('' '' IN (Lead_Phone_Number)) - 1) || SUBSTRING(Lead_Phone_Number, POSITION('' '' IN (Lead_Phone_Number)) + 1)
	WHERE	POSITION('' '' IN (Lead_Phone_Number)) > 0 ;
			Record_Count := Record_Count + COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Remove Invalid Phone Numbers And Leading 1'';
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = CASE
						WHEN LEN(TRIM(Lead_Phone_Number)) = 11
					AND POSITION(''1'' IN (Lead_Phone_Number)) = 1
							THEN SUBSTRING(Lead_Phone_Number, 2, 10)
						WHEN POSITION(''****'' IN (Lead_Phone_Number)) > 0
							THEN NULL
						WHEN LEN(TRIM(Lead_Phone_Number)) > 11
							THEN NULL
						WHEN SUBSTRING(Lead_Phone_Number, 1, 3) IN (''000'',''999'', ''888'' )
							THEN NULL
						WHEN LEN(TRIM(Lead_Phone_Number)) = 10
							THEN Lead_Phone_Number
					ELSE NULL
					END;
			UPDATE SALES.Sales_Staging.Leads
	SET	Lead_Phone_Number = SUBSTRING(Lead_Phone_Number, 1, 3) || ''-'' || SUBSTRING(Lead_Phone_Number, 4, 3) || ''-'' || SUBSTRING(Lead_Phone_Number, 7, 4);
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 11 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update Mykmxid In ''|| Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS Ls
				SET
					Ls.Mykmx_Id = Kmx_Id.User_Id
				FROM
					(
						SELECT
							User_Id,
							Email_Address,
							Ss_Insert_Ts
						FROM
							SALES.edw_stockroom_reserved_views.Mykmx2_User --changed to reserved container as part of CCPA
						QUALIFY
							ROW_NUMBER() OVER ( PARTITION BY Email_Address ORDER BY Ss_Insert_Ts DESC NULLS LAST) = 1 ) Kmx_Id
	WHERE	Ls.Lead_Email_Address =Kmx_Id.Email_Address ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 12 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when human'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS Ls
				SET
					Ls.Employee_Created_By_Key = n.Employee_Key
				FROM
					SALES.sales_landing.sf_user u,
					ASSOCIATES.hr_non_cci_views.associate_names n
	WHERE	Ls.Created_By_Id_Cs = u.user_id_cs
	AND	n.employee_ID = u.employee_number
	AND	u.employee_number::VARCHAR ILIKE ANY (''0%'', ''1%'', ''2%'', ''3%'', ''4%'', ''5%'', ''6%'', ''7%'', ''8%'', ''9%'') ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 13 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update employee created by key when System generated'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS Ls
				SET
					Ls.Employee_Created_by_Key = COALESCE(SF_Integration_Employee_key,-1)
				FROM
					SALES.sales_landing.sf_user u,
					SALES.Sales_Views.SF_Integration_Accounts s
	WHERE	u.user_id_cs = Ls.Created_By_Id_Cs
	AND	u.user_name = s.SF_Integration_Employee_desc
	AND 	u.employee_number IS NULL
	AND	Ls.Employee_Created_by_Key = -1 ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 14 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Confirm All Rows Were Copied From '' || Database_Source || ''.'' || Table_Source || '' To '' || Database_Stage || ''.'' || Table_Stage;
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;

			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Leads;
			Count_Stage := COALESCE ( :Record_Count , 0 );
			IF (( Count_Source <> Count_Stage ) ) THEN
				Sql_Statement := ''Source ''|| LEFT(LTRIM(TO_VARCHAR(Count_Source, ''MI9999999999'')), 10) ||'' Stage ''|| LEFT(LTRIM(TO_VARCHAR(Count_Stage, ''MI9999999999'')), 10);
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				
				INSERT INTO DATAOPS.Metadata_Controls.error_log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Source - :Count_Stage, :Step_Id);
				Sql_Statement := Activity_Desc;
				INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
				Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
				Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
				Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
				Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
				Source_Aggregate_Amount, Source_Record_Count)
				VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
					WHEN :Error_Count = 0
						THEN 4 ELSE 5
				END, CASE
					WHEN :Error_Count = 0
						THEN ''Y'' ELSE ''N''
				END,
					:Database_Target , :Table_Target , CASE
					WHEN :Error_Count > 0
						THEN ''Source And Target Record Counts Do Not Agree'' ELSE ''NA''
				END,
					''Teradata'', :Database_Source , :Table_Source , 0 , :Count_Stage , :Error_Count , 0 , :Count_Source);
				Out_Error_Count := Error_Count;
				Out_Hard_Stop_Error := 1;
				Out_Records_Loaded := 0;
				CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				RAISE Planned_exception;
			ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			END IF;

	------------------------ 15 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Find Records That Already Exists In The Target'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := ''Updating existing Salesforce_Record_Id'';
			UPDATE SALES.Sales_Staging.Leads AS S
				SET
					S.Lead_Key = T.Lead_Key
				FROM
					SALES.Sales_Reserved_Views.Leads T	--changed to reserved container as part of CCPA
	WHERE 	S.Salesforce_Record_Id  = T.Salesforce_Record_Id
	AND	T.Salesforce_Record_Id  <> ''NA'';
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Updating changed Salesforce_Record_Id having same web_lead_id'';
			UPDATE SALES.Sales_Staging.Leads AS S
				SET
					S.Lead_Key = T.Lead_Key,
					S.Salesforce_Record_Id = T.Salesforce_Record_Id
				FROM
					SALES.Sales_Reserved_Views.Leads T	--changed to reserved container as part of CCPA
	WHERE 	S.Web_Lead_Id  = T.Web_Lead_Id
	AND	S.Salesforce_Record_Id  <> T.Salesforce_Record_Id
	AND	S.Salesforce_Record_Id  <> ''NA''
	AND	T.Salesforce_Record_Id  <> ''NA''
	AND	T.Web_Lead_Id           <> -1
	AND	T.Record_Merged 	= ''Y''
	AND	S.Record_Merged 	= ''Y'';
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			Sql_Statement := ''Updating existing Web_Lead_Id'';
			UPDATE SALES.Sales_Staging.Leads AS S
				SET
					S.Lead_Key = T.Lead_Key
				FROM
					SALES.Sales_Reserved_Views.Leads T	--changed to reserved container as part of CCPA
	WHERE 	S.Web_Lead_Id          = T.Web_Lead_Id
	AND	T.Web_Lead_Id          <> -1
	AND 	s.Lead_key	     =  -1;
			Count_Last := Count_Last + COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	------------------------ 16 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''delete any duplicate lead keys if one is SF update only'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			DELETE FROM
				SALES.Sales_Staging.Leads
			WHERE
				Lead_Key IN	(
					SELECT
						Lead_Key
									FROM
						SALES.Sales_Staging.Leads
									WHERE 	Lead_Key <> -1
									GROUP BY 1
									HAVING COUNT(*) > 1
								)
			AND	sf_update_only_flag = ''Y''
			AND	Lead_Key <> -1 ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 17 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice work item id from sf_lead'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Work_Item_ID = CASE
						WHEN l.nice_work_item_id_cs IN (9, 99, 999, 1, 9999, 0)
							THEN NULL
							ELSE l.nice_work_item_id_cs
					END
				FROM
					SALES.sales_landing.sf_lead l
	WHERE	s.Salesforce_Record_ID::VARCHAR = l.lead_id_cs::VARCHAR
	AND	l.nice_work_item_id_cs IS NOT NULL ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 18 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice work item id from nice_work_item_status if still missing'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Work_Item_ID = x.work_item_id_cs
				FROM
					(
						SELECT
							related_to_id_cs,
							work_item_id_cs
							FROM
							SALES.edw_salesforce.sf_nice_work_item_status
							WHERE 	work_item_type = ''lead''
							AND LENGTH(work_item_id_cs) <= 20
						QUALIFY
							ROW_NUMBER() OVER(PARTITION BY related_to_id_cs ORDER BY is_deleted ASC NULLS FIRST, ss_insert_ts_utc DESC NULLS LAST) = 1
					) x
	WHERE 	s.Salesforce_Record_ID::VARCHAR = x.related_to_id_cs::VARCHAR
	AND	s.nice_work_item_id IS NULL ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 19 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice work item id from nice_contacts if still missing'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Work_Item_ID = x.contact_id
				FROM
					(
						SELECT
							data_value,
							contact_id
						       	FROM
							SALES.edw_stockroom.nice_contacts
							WHERE 	data_name = ''salesforceID''
						QUALIFY
							ROW_NUMBER() OVER(PARTITION BY data_value ORDER BY insert_ts DESC NULLS LAST) = 1
					) x
	WHERE 	s.Salesforce_Record_ID = x.data_value
	AND	s.Nice_Work_Item_ID IS NULL ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 20 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update additional data points from sf_lead'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.lead_status = l.status,
					s.lead_source = l.lead_source,
					s.System_Closed_Reason = l.System_Closed_Reason,
					s.Parent_Lead_ID = l.parent_lead,
					s.Is_Subsequent_Lead = l.subsequent_web_lead,
					s.Is_Exclude_Closed = CASE
						WHEN l.status = ''closed'' AND l.system_closed_reason IS NOT NULL
							THEN 1 ELSE 0
					END,
					s.Lead_Origin_Queue = l.origin_queue,
					s.Lead_Data_Entry_Method = l.data_entry_method
				FROM
					SALES.sales_landing.sf_lead l
	WHERE 	s.salesforce_record_id::VARCHAR = l.lead_id_cs::VARCHAR ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 21 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice skill and agent data'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Skill_Number = d.Skill_no,
					s.Nice_Skill_Name = d.Skill_Name,
					s.Nice_Agent_Number = d.Agent_no
				FROM
					SALES.edw_stockroom.nice_call_detail d
	WHERE	s.Nice_Work_Item_ID = d.contact_id ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 22 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice agent emp ID'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Agent_Employee_ID = x.owner_emp_id
				FROM
					(
						SELECT
							a.ntLoginName AS owner_emp_id,
							l.salesforce_record_id,
							l.nice_agent_number
									FROM
							SALES.edw_stockroom.nice_agent_list_extended a
									JOIN
								SALES.Sales_Staging.leads l
									ON a.agent_no = l.nice_agent_number
									WHERE   owner_emp_id IS NOT NULL
						QUALIFY
							ROW_NUMBER() OVER (PARTITION BY l.salesforce_record_id,l.nice_agent_number ORDER BY a.lst_upd_ts DESC NULLS LAST) = 1
					) x
	WHERE	s.Salesforce_Record_ID = x.salesforce_record_id
	AND	s.Nice_Agent_Number = x.Nice_agent_number ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 23 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice answered TS'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Contact_Answered_TS_UTC = x.Contact_Answered_Time,
					s.Answered_Time_Zone = x.Time_Zone
				FROM
					(
						SELECT
							z.contact_id,
							CASE
								WHEN z.contactansweredtime IS NOT NULL AND POSITION(''/'' IN (z.contactansweredtime)) = 2
									THEN TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(''0''||z.contactansweredtime), ''mm/dd/yyyy hh12:mi:ss AM'') AS VARCHAR), 19))
												ELSE TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(z.contactansweredtime), ''mm/dd/yyyy hh12:mi:ss AM'')  AS VARCHAR), 19))
							END AS Contact_Answered_time,
											z.time_zone
									FROM (
								SELECT
									c.contact_Id,
									SUBSTRING(data_value, 1, LEN(TRIM(data_value)) - 3) AS	contactansweredtime,
									SUBSTRING(data_value, LEN(TRIM(data_value)) - 2, 3) AS Time_Zone
										FROM
									SALES.edw_stockroom.nice_contacts c
										JOIN
										SALES.Sales_Staging.Leads l
										ON		l.Nice_Work_Item_Id = c.contact_id
										WHERE 	c.data_name = ''contactansweredtime''
										) z
					--JOIN	ACCOUNTING.valid_Values_Views.calendar_by_day d
					--ON		d.Calendar_date = CAST(Contact_Answered_time AS DATE)
					) x
	WHERE 	s.Nice_Work_Item_ID = x.contact_ID ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 24 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice complete TS'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.leads AS s
				SET
					s.Nice_Contact_Complete_TS_UTC = x.Contact_Complete_time,
					s.Complete_Time_Zone = x.Time_Zone
				FROM
					(
						SELECT
							z.contact_id,
							CASE
								WHEN z.contactcompletetime IS NOT NULL AND POSITION(''/'' IN (z.contactcompletetime)) = 2
									THEN TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(''0''||z.contactcompletetime), ''mm/dd/yyyy hh12:mi:ss AM'') AS VARCHAR), 19))
												ELSE TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(z.contactcompletetime), ''mm/dd/yyyy hh12:mi:ss AM'')  AS VARCHAR), 19))
							END AS Contact_Complete_time,
											z.time_zone
									FROM (
								SELECT
									c.contact_Id,
									SUBSTRING(data_value, 1, LEN(TRIM(data_value)) - 3) AS	contactcompletetime,
									SUBSTRING(data_value, LEN(TRIM(data_value)) - 2, 3) AS Time_Zone
										FROM
									SALES.edw_stockroom.nice_contacts c
										JOIN
										SALES.Sales_Staging.Leads l
										ON		l.Nice_Work_Item_Id = c.contact_id
										WHERE 	c.data_name = ''contactcompletetime''
										) z
					--JOIN	ACCOUNTING.valid_Values_Views.calendar_by_day d
					--ON		d.Calendar_date = CAST(Contact_complete_time AS DATE)
					) x
	WHERE 	s.Nice_Work_Item_ID = x.contact_ID ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 25 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice enter in queue TS'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.leads AS s
				SET
					s.Nice_Enter_In_Queue_TS_UTC = x.enter_in_queue_time,
					s.Enter_Time_Zone = x.Time_Zone
				FROM
					(
						SELECT
							z.contact_id,
							CASE
								WHEN z.enterinqueuetime IS NOT NULL AND POSITION(''/'' IN (z.enterinqueuetime)) = 2
									THEN TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(''0''||z.enterinqueuetime), ''mm/dd/yyyy hh12:mi:ss AM'') AS VARCHAR), 19))
												ELSE TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(z.enterinqueuetime), ''mm/dd/yyyy hh12:mi:ss AM'')  AS VARCHAR), 19))
							END AS enter_in_queue_time,
											z.time_zone
									FROM (
								SELECT
									c.contact_Id,
									SUBSTRING(data_value, 1, LEN(TRIM(data_value)) - 3) AS	enterinqueuetime,
									SUBSTRING(data_value, LEN(TRIM(data_value)) - 2, 3) AS Time_Zone
										FROM
									SALES.edw_stockroom.nice_contacts c
										JOIN
										SALES.Sales_Staging.Leads l
										ON		l.Nice_Work_Item_Id = c.contact_id
										WHERE 	c.data_name = ''enterinqueuetime''
										) z
					--JOIN	ACCOUNTING.valid_Values_Views.calendar_by_day d
					--ON		d.Calendar_date = CAST(enter_in_queue_time AS DATE)
					) x
	WHERE 	s.Nice_Work_Item_ID = x.contact_ID ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 26 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update nice create TS'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.leads AS s
				SET
					s.Nice_Work_Item_Create_TS_UTC = x.Work_Item_Create_Time,
					s.Create_Time_Zone = x.Time_Zone
				FROM
					(
						SELECT
							z.contact_id,
							CASE
								WHEN z.workitemcreatetime IS NOT NULL AND POSITION(''/'' IN (z.workitemcreatetime)) = 2
									THEN TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(''0''||z.workitemcreatetime), ''mm/dd/yyyy hh12:mi:ss AM'') AS VARCHAR), 19))
												ELSE TO_TIMESTAMP(LEFT(CAST(TO_TIMESTAMP(TRIM(z.workitemcreatetime), ''mm/dd/yyyy hh12:mi:ss AM'')  AS VARCHAR), 19))
							END AS Work_Item_Create_Time,
											z.time_zone
									FROM (
								SELECT
									c.contact_Id,
									SUBSTRING(data_value, 1, LEN(TRIM(data_value)) - 3) AS	workitemcreatetime,
									SUBSTRING(data_value, LEN(TRIM(data_value)) - 2, 3) AS Time_Zone
										FROM
									SALES.edw_stockroom.nice_contacts c
										JOIN
										SALES.Sales_Staging.Leads l
										ON		l.Nice_Work_Item_Id = c.contact_id
										WHERE 	c.data_name = ''workitemcreatetime''
										) z
					--JOIN	ACCOUNTING.valid_Values_Views.calendar_by_day d
					--ON		d.Calendar_date = CAST(Work_Item_Create_Time AS DATE)
					) x
	WHERE 	s.Nice_Work_Item_ID = x.contact_ID ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 27 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Convert Timestamps to UTC'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Contact_Answered_TS_UTC = x.Answered_UTC,
					s.Nice_Contact_Complete_TS_UTC = x.Complete_UTC,
					s.Nice_Enter_In_Queue_TS_UTC = x.Enter_UTC,
					s.Nice_Work_Item_Create_TS_UTC = x.Create_UTC
				FROM
					(
						SELECT
							CASE
								WHEN c1.Day_Light_Saving_Time = ''On''
									THEN
 									    
 									    DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Contact_Answered_TS_UTC, 4.00 )
					        				ELSE
 					        				     DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Contact_Answered_TS_UTC, 5.00 )
							END AS Answered_UTC,
							CASE
								WHEN c2.Day_Light_Saving_Time = ''On''
									THEN
 									    
 									    DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Contact_Complete_TS_UTC, 4.00 )
					        				ELSE
 					        				     DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Contact_Complete_TS_UTC, 5.00 )
							END AS Complete_UTC,
							CASE
								WHEN c3.Day_Light_Saving_Time = ''On''
									THEN
 									    
 									    DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Enter_In_Queue_TS_UTC, 4.00 )
					        				ELSE
 					        				     DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Enter_In_Queue_TS_UTC, 5.00 )
							END AS Enter_UTC,
							CASE
								WHEN c4.Day_Light_Saving_Time = ''On''
									THEN
 									    
 									    DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Work_Item_Create_TS_UTC, 4.00 )
					        				ELSE
 					        				     DATAOPS.UTILITIES.LOCAL_TO_UTC_TS0( Nice_Work_Item_Create_TS_UTC, 5.00 )
							END AS Create_UTC,
							l.Nice_Work_item_ID
					FROM
							SALES.Sales_Staging.Leads l
					LEFT JOIN
								ACCOUNTING.valid_Values_Views.calendar_by_day c1
					ON	CAST(l.Nice_Contact_Answered_ts_UTC AS DATE) = c1.calendar_date
					LEFT JOIN
								ACCOUNTING.valid_Values_Views.calendar_by_day c2
					ON	CAST(l.Nice_Contact_complete_ts_UTC AS DATE) = c2.calendar_date
					LEFT JOIN
								ACCOUNTING.valid_Values_Views.calendar_by_day c3
					ON	CAST(l.Nice_enter_in_queue_ts_UTC AS DATE) = c3.calendar_date
					LEFT JOIN
								ACCOUNTING.valid_Values_Views.calendar_by_day c4
					ON	CAST(Nice_Work_item_Create_ts_UTC AS DATE) = c4.calendar_date
					WHERE	l.nice_work_item_id IS NOT NULL
					) x
	WHERE	s.Nice_Work_Item_ID = x.Nice_Work_Item_ID ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------------------- 28 -----------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update job information for Nice Agent'';
			Step_Id := Step_Id + 1;
			Record_Count := 0;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Nice_Agent_Job_Code = x.job_code,
					s.Nice_Agent_Job_Desc = x.job_name
				FROM
					(
						SELECT
							j.job_code,
							j.job_name,
							l.Nice_Agent_employee_id,
							l.salesforce_record_id,
							l.web_lead_id
							FROM
							SALES.Sales_Staging.Leads l
							JOIN
								ASSOCIATES.hr_non_cci_views.Fact_Associate_Events f
							ON		l.nice_agent_employee_Id = f.employee_Key
							JOIN
								ASSOCIATES.hr_non_cci_views.job_codes j
							ON		f.job_key = j.job_key
							JOIN
								SALES.sales_landing.sf_Lead s
							ON		l.salesforce_record_id::VARCHAR = s.lead_id_cs::VARCHAR
							LEFT JOIN
								SALES.edw_salesforce.sf_opportunity o
							ON		COALESCE(s.matched_opportunity_id_cs, s.converted_opportunity_id_cs) = o.opportunity_id_cs
							WHERE	CAST(COALESCE(s.converted_date_time_utc, o.time_accepted_utc, CAST(s.converted_date AS TIMESTAMP(0)), s.closed_time_utc) AS DATE)
								BETWEEN DATAOPS.UTILITIES.INT_TO_DATE_UDF(f.job_entry_day_key - 19000000) 
								AND DATAOPS.UTILITIES.INT_TO_DATE_UDF(f.end_day_job_key - 19000000) 
						QUALIFY
							ROW_NUMBER() OVER (PARTITION BY l.nice_agent_employee_Id, l.salesforce_record_id, l.web_lead_id ORDER BY f.effective_day_key DESC NULLS LAST) = 1
					) x
	WHERE	s.Nice_Agent_Employee_id = x.Nice_Agent_Employee_ID
	AND	s.Salesforce_Record_Id::VARCHAR = x.Salesforce_Record_Id::VARCHAR
	AND	s.Web_Lead_Id = x.Web_Lead_Id;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	---------- 29 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Updating is_web_lead_object'';
			Step_Id := Step_Id + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_Id);
			Count_Last := 0;
			Sql_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.Is_Web_Lead_Object = 1
				FROM
					(
						SELECT
							lead_id_cs AS lead_id_cs
							FROM
							SALES.edw_salesforce.sf_lead AS sfl
							WHERE 	lead_source IN (''web'')
							AND 	subsequent_web_lead = 0
							AND 	created_by_id_cs <> ''00515000006ygUGAAY''
							AND 	(parent_lead IS NULL
								         OR 	(
										(parent_lead IN (
								SELECT
									lead_id_cs::VARCHAR  FROM
									SALES.edw_salesforce.sf_lead AS sfl
													  		WHERE lead_source IN (''web'',''Reassignment'') AND created_by_id_cs = ''00515000006ygUGAAY''))
										AND lead_type::VARCHAR ILIKE ANY (''%online appraisal%'',''%hold%'')
										)
									)
					) x
	WHERE	Salesforce_Record_Id::VARCHAR = x.lead_id_cs::VARCHAR ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	------------------------30 -------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Identify records for update of additional fields'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			Count_Last := 0;
			SQL_Statement := Activity_Desc;
			UPDATE SALES.Sales_Staging.Leads AS s
				SET
					s.DW_Record_Updated = ''Y''
				FROM
					SALES.Sales_Reserved_Views.Leads t
	WHERE 	s.Lead_Key = t.Lead_Key
	AND		s.lead_key <> -1
	AND (	COALESCE(	s.Is_Subsequent_Lead, -1)	                           <>    COALESCE(	t.Is_Subsequent_Lead, -1)
		OR COALESCE(	s.Is_Exclude_Closed , -1)                               <>    COALESCE(	t.Is_Exclude_Closed , -1)
		OR COALESCE(	s.Lead_Origin_Queue , ''NA'')                          <>    COALESCE(	t.Lead_Origin_Queue , ''NA'')
		OR COALESCE(	s.Lead_Status , ''NA'')                                      <>    COALESCE(	t.Lead_Status , ''NA'')
		OR COALESCE(	s.Lead_Data_Entry_Method , ''NA'')                                      <>    COALESCE(	t.Lead_Data_Entry_Method , ''NA'')
		OR COALESCE(	s.Nice_Agent_Employee_ID , -1)                    <>    COALESCE(	t.Nice_Agent_Employee_ID , -1)
		OR COALESCE(	s.Nice_Agent_Job_Desc , ''NA'')                      <>    COALESCE(	t.Nice_Agent_Job_Desc , ''NA'')
		OR COALESCE(	s.Nice_Agent_Job_Code , ''NA'')                      <>    COALESCE(	t.Nice_Agent_Job_Code , ''NA'')
		OR COALESCE(	s.Nice_Agent_Number , -1)                             <>    COALESCE(	t.Nice_Agent_Number , -1)
		OR COALESCE(	s.Nice_Work_Item_ID , -1)                               <>    COALESCE(	t.Nice_Work_Item_ID , -1)
		OR COALESCE(	s.Nice_Contact_Answered_TS_UTC, TIMESTAMP ''1900-01-01 00:00:00'' )    <>    COALESCE(	t.Nice_Contact_Answered_TS_UTC,TIMESTAMP ''1900-01-01 00:00:00'')
		OR COALESCE(	s.Nice_Contact_Complete_TS_UTC, TIMESTAMP ''1900-01-01 00:00:00'')    <>    COALESCE(	t.Nice_Contact_Complete_TS_UTC, TIMESTAMP ''1900-01-01 00:00:00'')
		OR COALESCE(	s.Nice_Enter_In_Queue_TS_UTC , TIMESTAMP ''1900-01-01 00:00:00'')     <>    COALESCE(	t.Nice_Enter_In_Queue_TS_UTC , TIMESTAMP ''1900-01-01 00:00:00'' )
		OR COALESCE(	s.Nice_Work_Item_Create_TS_UTC , TIMESTAMP ''1900-01-01 00:00:00'')   <>    COALESCE(	t.Nice_Work_Item_Create_TS_UTC , TIMESTAMP ''1900-01-01 00:00:00'')
		OR COALESCE(	s.Nice_Skill_Name , ''NA'')                                <>    COALESCE(	t.Nice_Skill_Name , ''NA'')
		OR COALESCE(	s.Nice_Skill_Number , -1)                                <>    COALESCE(	t.Nice_Skill_Number , -1)
		OR COALESCE(	s.Parent_Lead_ID , ''NA'')                                 <>    COALESCE(	t.Parent_Lead_ID , ''NA'')
		OR COALESCE(	s.System_Closed_Reason , ''NA'')                   <>    COALESCE(	t.System_Closed_Reason , ''NA'')
		OR COALESCE(	s.Is_Web_Lead_Object, -1)				<> 	COALESCE(	t.Is_Web_Lead_Object, -1)) ;
			Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

/*	------------------------31 ------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Drop target indexes if the number of staged records > Index_Limit'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			Count_Last := 0;
			SQL_Statement := ''Determine count of records that will change'';
			SELECT
				COUNT ( * ) INTO
				:Record_Count
		FROM
				SALES.Sales_Staging.Leads
		WHERE	DW_Record_Updated = ''Y''
		OR		(Lead_Key = -1 AND sf_update_only_flag = ''N'') ;
			Count_Last := COALESCE ( :Record_Count , 0 );
			SELECT
				CAST(TRUNC( Parameter_Value) AS INTEGER)  INTO
				:Index_Limit
		FROM
				DATAOPS.Metadata_Views.Parameters_Sales
		WHERE 	Parameter_Name =''Web_Lead_Index_Limit'';
			IF (Count_Last > Index_Limit) THEN
 				-------------------------32-------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If idx_Salesforce_Record_Id Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
				SELECT
					
					CASE
						WHEN (
							SELECT DISTINCT
--								 Indexname
									   	   FROM 	 Dbc.Indicesv
									 	   WHERE
								TABLE_SCHEMA = ''Sales''
										   AND TABLE_NAME = ''Leads''
										   AND
--										       	 Indexname
										       	           = ''idx_Salesforce_Record_Id'' )
							IS NOT NULL
							THEN 1 ELSE 0
					END
				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary idx_Salesforce_Record_Id'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index idx_Salesforce_Record_Id'';
--						DROP 	INDEX idx_Salesforce_Record_Id ON SALES.Sales.Leads;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;

				--------------------------33------------------------------------------------------------------------------------------------------------------------
				Activity_Desc := ''Determine If idx_Web_Lead_ID Index Exists'';
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Index_Exists := 0;
				Sql_Statement := Activity_Desc;
				SELECT
					
					CASE
						WHEN (
							SELECT DISTINCT
--								 Indexname
									   	   FROM 	 Dbc.Indicesv
									 	   WHERE
								TABLE_SCHEMA = ''Sales''
										   AND TABLE_NAME = ''Leads''
										   AND
--										       	 Indexname
										       	           = ''idx_Web_Lead_ID'' )
							IS NOT NULL
							THEN 1 ELSE 0
					END
				INTO :Index_Exists ;
				IF (Index_Exists = 1) THEN
					Activity_Desc := ''Drop Secondary idx_Web_Lead_ID'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
					Sql_Statement := ''Drop Index idx_Web_Lead_ID'';
--						DROP 	INDEX idx_Web_Lead_ID ON SALES.Sales.Leads;
				ELSE
					Activity_Desc := ''No Indexes To Drop'';
					INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
					VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				END IF;
			END IF;


*/	------  34------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Default Record Into ''|| Database_Target || ''.'' || Table_Target;

	SELECT
				MAX ( Lead_Key ) INTO
				:Last_Record_Key
FROM
				SALES.Sales_Reserved_Views.Leads;	--changed to reserved container as part of CCPA 
	Last_Record_Key := COALESCE ( :Last_Record_Key , 0 );
	IF (Last_Record_Key = 0) THEN
				Step_Id := Step_Id + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				INSERT INTO SALES.Sales.Leads (Lead_Key, Advertising_Code, Advertising_Code_Date, Lead_Email_Address, Lead_Full_Name, Lead_Phone_Number,
				      Lead_Visit_Purpose, Mykmx_Id, Store_Customer_Id, Smw_Contact_Id, Salesforce_Record_Id, Salesforce_Web_Lead_Id, Source_Session_Id,
				      Source_Visitor_Id, Web_Lead_Id, Employee_Created_By_Key, Dw_Insert_Ts)
				VALUES (-1, ''NA'', ''1980-01-01'', ''NA'', ''Unknown'', ''NA'', ''NA'', ''NA'', ''NA'', -1,  ''NA'', ''NA'', ''NA'', ''NA'', -1, -1, CURRENT_TIMESTAMP(0));
				Count_Target := 1;
	END IF;
	IF (Last_Record_Key > 0) THEN
				SQL_Statement := ''Update attributes in existing dimension records'';
				UPDATE SALES.Sales.Leads AS T
					SET
						T.Advertising_Code = S.Advertising_Code,
						T.Advertising_Code_Date = S.Advertising_Code_Date,
						T.Lead_Email_Address = S.Lead_Email_Address,
						T.Lead_Full_Name = S.Lead_Full_Name,
						T.Lead_Phone_Number = S.Lead_Phone_Number,
						T.Lead_Visit_Purpose = S.Lead_Visit_Purpose,
						T.Mykmx_Id = S.Mykmx_Id,
						T.Store_Customer_Id = S.Store_Customer_Id,
						T.Smw_Contact_Id = S.Smw_Contact_Id,
						T.Salesforce_Record_Id = S.Salesforce_Record_Id,
						T.Salesforce_Web_Lead_Id = S.Salesforce_Web_Lead_Id,
						T.Source_Session_Id = S.Source_Session_Id,
						T.Source_Visitor_Id = S.Source_Visitor_Id,
						T.Record_Merged = S.Record_Merged,
						T.Employee_Created_By_Key = S.Employee_Created_By_Key,
						T.Dw_Insert_Ts = CURRENT_TIMESTAMP(0)
					FROM
						SALES.Sales_Staging.Leads S
					WHERE	S.Web_Lead_Id     	=T.Web_Lead_Id
						AND S.Lead_key         	=T.Lead_key
						AND T.Salesforce_record_id = ''NA''
						AND S.Salesforce_record_id <> ''NA''
						AND S.Lead_key 		<> ''-1''
						AND S.SF_Update_Only_Flag = ''N'' ;
				Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
				Count_Target := Count_Last;
				UPDATE SALES.Sales.Leads AS T
					SET
						T.Advertising_Code = S.Advertising_Code,
						T.Advertising_Code_Date = S.Advertising_Code_Date,
						T.Lead_Email_Address = S.Lead_Email_Address,
						T.Lead_Full_Name = S.Lead_Full_Name,
						T.Lead_Phone_Number = S.Lead_Phone_Number,
						T.Lead_Visit_Purpose = S.Lead_Visit_Purpose,
						T.Mykmx_Id = S.Mykmx_Id,
						T.Store_Customer_Id = S.Store_Customer_Id,
						T.Smw_Contact_Id = S.Smw_Contact_Id,
						T.Salesforce_Record_Id = S.Salesforce_Record_Id,
						T.Salesforce_Web_Lead_Id = S.Salesforce_Web_Lead_Id,
						T.Source_Session_Id = S.Source_Session_Id,
						T.Source_Visitor_Id = S.Source_Visitor_Id,
						T.web_lead_id = s.web_lead_id,
						T.Record_Merged = S.Record_Merged,
						T.Employee_Created_By_Key = S.Employee_Created_By_Key,
						T.Dw_Insert_Ts = CURRENT_TIMESTAMP(0)
					FROM
						SALES.Sales_Staging.Leads S
					WHERE	S.Salesforce_record_id     = T.Salesforce_record_id
						AND s.Lead_key         	= T.Lead_key
						AND T.Web_Lead_Id 	= ''-1''
						AND s.Web_Lead_Id 	<> ''-1''
						AND s.Lead_key	 	<> ''-1''
						AND s.sf_Update_Only_Flag = ''N'' ;
				Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records staged that were Updated'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_ID);
				Step_ID := Step_ID + 1;
				Activity_Desc := ''Update attributes in existing dimension records for select fields only'';
				SQL_Statement := Activity_Desc;
				UPDATE SALES.Sales.Leads AS t
					SET
						t.Is_Subsequent_Lead = s.Is_Subsequent_Lead,
						t.Is_Exclude_Closed = s.Is_Exclude_Closed,
						t.Lead_Origin_Queue = s.Lead_Origin_Queue,
						t.Lead_Status = s.Lead_Status,
						t.Lead_Data_Entry_Method = s.Lead_Data_Entry_Method,
						t.Nice_Agent_Employee_ID = s.Nice_Agent_Employee_ID,
						t.Nice_Agent_Job_Desc = s.Nice_Agent_Job_Desc,
						t.Nice_Agent_Job_Code = s.Nice_Agent_Job_Code,
						t.Nice_Agent_Number = s.Nice_Agent_Number,
						t.Nice_Work_Item_ID = s.Nice_Work_Item_ID,
						t.Nice_Contact_Answered_TS_UTC = s.Nice_Contact_Answered_TS_UTC,
						t.Nice_Contact_Complete_TS_UTC = s.Nice_Contact_Complete_TS_UTC,
						t.Nice_Enter_In_Queue_TS_UTC = s.Nice_Enter_In_Queue_TS_UTC,
						t.Nice_Work_Item_Create_TS_UTC = s.Nice_Work_Item_Create_TS_UTC,
						t.Nice_Skill_Name = s.Nice_Skill_Name,
						t.Nice_Skill_Number = s.Nice_Skill_Number,
						t.Parent_Lead_ID = s.Parent_Lead_ID,
						t.System_Closed_Reason = s.System_Closed_Reason,
						t.Is_Web_Lead_Object = s.Is_Web_Lead_Object,
						t.DW_Update_TS = CURRENT_TIMESTAMP(0)
					FROM
						SALES.Sales_Staging.Leads s
					WHERE
						s.Lead_Key = t.Lead_key
					AND s.salesforce_record_id = t.salesforce_record_id
					AND s.DW_Record_Updated = ''Y''
					AND	t.Lead_key <> -1 ;
				Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
				Count_Target := Count_Last;
				Activity_Desc := ''Count of records staged that were Updated - select fields only'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_ID);
	END IF;

	------------------------ 35  ---------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Insert  Into ''|| Database_Target || ''.'' || Table_Target || '' From '' || Database_Stage || ''.'' || Table_Stage;
	Step_Id := Step_Id + 1;
	Count_Last := 0;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_Id);
	Sql_Statement := Activity_Desc;
	INSERT INTO SALES.Sales.Leads (
	Advertising_Code, Advertising_Code_Date, Is_Subsequent_Lead,
	Is_Exclude_Closed, Lead_eMail_Address, Lead_Full_Name, Lead_Origin_Queue,
	Lead_Phone_Number, Lead_Source, Lead_Status, Lead_Visit_Purpose,Lead_Data_Entry_Method,
	MyKMX_ID, Nice_Agent_Employee_ID, Nice_Agent_Job_Desc, Nice_Agent_Job_Code,
	Nice_Agent_Number, Nice_Work_Item_ID, Nice_Contact_Answered_TS_UTC,
	Nice_Contact_Complete_TS_UTC, Nice_Enter_In_Queue_TS_UTC, Nice_Work_Item_Create_TS_UTC,
	Nice_Skill_Name, Nice_Skill_Number, Parent_Lead_ID, Record_Merged,
	Salesforce_Record_Id, Salesforce_Web_Lead_Id, Store_Customer_ID,
	SMW_Contact_ID, Source_Session_ID, Source_Visitor_ID, System_Closed_Reason,
	Web_Lead_ID, Employee_Created_By_Key, DW_Insert_TS, DW_Update_TS, Is_Web_Lead_Object)
	SELECT
				Advertising_Code,
				Advertising_Code_Date,
				Is_Subsequent_Lead,
				Is_Exclude_Closed,
				Lead_eMail_Address,
				Lead_Full_Name,
				Lead_Origin_Queue,
				Lead_Phone_Number,
				Lead_Source,
				Lead_Status,
				Lead_Visit_Purpose,
				Lead_Data_Entry_Method,
				MyKMX_ID,
				Nice_Agent_Employee_ID,
				Nice_Agent_Job_Desc,
				Nice_Agent_Job_Code,
				Nice_Agent_Number,
				Nice_Work_Item_ID,
				Nice_Contact_Answered_TS_UTC,
				Nice_Contact_Complete_TS_UTC,
				Nice_Enter_In_Queue_TS_UTC,
				Nice_Work_Item_Create_TS_UTC,
				Nice_Skill_Name,
				Nice_Skill_Number,
				Parent_Lead_ID,
				Record_Merged,
				Salesforce_Record_Id,
				Salesforce_Web_Lead_Id,
				Store_Customer_ID,
				SMW_Contact_ID,
				Source_Session_ID,
				Source_Visitor_ID,
				System_Closed_Reason,
				Web_Lead_ID,
				Employee_Created_By_Key,
				CURRENT_TIMESTAMP(0),
				CURRENT_TIMESTAMP(0),
				Is_Web_Lead_Object
		FROM
				SALES.Sales_Staging.Leads
		WHERE	Lead_Key = -1
		AND	SF_Update_Only_Flag = ''N'';
	Count_Last := COALESCE (  :SQLROWCOUNT , 0 );
	Count_Target := Count_Target + Count_Last;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_Id);

	-------------------------- 36 --------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Confirm All Rows Were Copied From '' || Database_Stage || ''.'' || Table_Stage || '' To '' || Database_Target || ''.'' || Table_Target;
	Step_Id := Step_Id + 1;
	Record_Count := 0;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);
	Sql_Statement := Activity_Desc;
	SELECT
				COUNT( * ) INTO
				:Record_Count
FROM 	(
					SELECT
						S.Salesforce_Record_Id,
						S.Web_Lead_Id
FROM
						SALES.Sales_Staging.Leads S
LEFT OUTER JOIN
							SALES.Sales_Reserved_Views.Leads T	--changed to reserved container as part of CCPA
ON 	S.Salesforce_Record_Id  = T.Salesforce_Record_Id
WHERE 	T.Lead_Key IS NULL
AND S.Salesforce_Record_Id <>''NA''
AND s.SF_update_only_flag = ''N''
	      	) X;
	Count_Last := COALESCE ( :Record_Count , 0 );
	SELECT
				COUNT( * ) INTO
				:Record_Count
FROM 	(
					SELECT
						S.Salesforce_Record_Id,
						S.Web_Lead_Id
FROM
						SALES.Sales_Staging.Leads S
LEFT OUTER JOIN
							SALES.Sales_Reserved_Views.Leads T 	--changed to reserved container as part of CCPA
ON 	S.Web_Lead_Id          = T.Web_Lead_Id
WHERE 	T.Lead_Key IS NULL
AND S.web_lead_id <> ''-1''
	        ) X;
	Count_Last := Count_Last + COALESCE ( :Record_Count , 0 );
	IF (Count_Last > 0) THEN
				Error_Condition := 4;
				Error_Count := Error_Count +1;
				Sql_Return_Code := SQLCODE;
				
				INSERT INTO DATAOPS.Metadata_Controls.error_log (Activity_Name, Activity_Desc, Activity_Step_Id, Error_Condition, Name_Database, Sql_Return_Code, Sql_State_Code, Sql_Statement)
				VALUES (:Activity_Name, :Activity_Desc, :Step_Id, :Error_Condition , :Database_Stage, :Sql_Return_Code, :Sql_State_Code, :Sql_Statement);
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc || '' Error'' , :Completed_Flag, :Error_Condition , :Error_Count, :Count_Last, :Step_Id);
	ELSE
				Target_Balanced := ''Y'';
	END IF;

	---------- 37 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Create Target Indexes If They Were Dropped'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_Id);

/*		------------------------------38----------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Determine If idx_Salesforce_Record_Id Index Exists'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	Index_Exists := 0;
	Sql_Statement := Activity_Desc;
	SELECT
				
				CASE
					WHEN (
						SELECT DISTINCT
--							 Indexname
								   	   FROM Dbc.Indicesv
								 	   WHERE
							TABLE_SCHEMA = ''Sales''
									   	AND TABLE_NAME = ''Leads''
									   	AND
--									   	    Indexname
									   	              = ''idx_Salesforce_Record_Id'' )
						IS NOT NULL
						THEN 1 ELSE 0
				END
	INTO :Index_Exists ;
	IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index idx_Salesforce_Record_Id'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create idx_Salesforce_Record_Id'';
--					CREATE 	INDEX idx_Salesforce_Record_Id ( Salesforce_Record_Id )
--					ON SALES.Sales.Leads ;
	ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	END IF;

		-----------------------------39-----------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Determine If idx_Web_Lead_ID Index Exists'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	Index_Exists := 0;
	Sql_Statement := Activity_Desc;
	SELECT
				
				CASE
					WHEN (
						SELECT DISTINCT
--							 Indexname
								   	   FROM 	 Dbc.Indicesv
								 	   WHERE
							TABLE_SCHEMA = ''Sales''
									   AND TABLE_NAME = ''Leads''
									   AND
--									       	 Indexname
									       	           = ''idx_Web_Lead_ID'' )
						IS NOT NULL
						THEN 1 ELSE 0
				END
	INTO :Index_Exists ;
	IF (Index_Exists = 0) THEN
				Activity_Desc := ''Create Secondary Index idx_Web_Lead_ID'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
				Sql_Statement := ''Create idx_Web_Lead_ID'';
--					CREATE 	INDEX idx_Web_Lead_ID ( Web_Lead_ID )
--					ON SALES.Sales.Leads ;
	ELSE
				Activity_Desc := ''No Indexes To Create'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	END IF;

*/	---------------------------- 40 ---------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Insert Metadata Table_Controls Record'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	Sql_Statement := Activity_Desc;
	INSERT INTO DATAOPS.Metadata_Controls.Table_Controls (
	Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
	Process_Status_Key, Balanced_Flag, Destination_Database, Destination_Table_Name,
	Error_Detail_Description, Source_Server, Source_Database, Source_Table_Name,
	Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
	Source_Aggregate_Amount, Source_Record_Count)
	VALUES (:Batch_Number, :Calendar_Key , :Process_Id , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
	END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
	END,
	:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''Some Records Are Missing Surrogate Keys'' ELSE ''Na''
	END,
	''Teradata'', :Database_Source , :Table_Source ,
	0 , :Count_Target , :Error_Count ,
	0 , :Count_Source);

	---------------------------- 41 -------------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''Delete Staged Data If No Errors'' || Database_Stage || ''.'' || Table_Stage;
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1, :Step_Id);
	IF (Target_Balanced = ''Y'' AND COALESCE ( Error_Count, 0 ) = 0) THEN
				Sql_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Leads;
	ELSE
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
				VALUES (:Activity_Name, ''Target_Balanced = '' || :Target_Balanced, :Completed_Flag, :Error_Count, :Error_Count, :Step_Id);
	END IF;
	----------------------------- 42 -------------------------------------------------------------------------------------------------------------------
	Activity_Desc := ''****  Complete  ****'';
	Completed_Flag := ''Y'';
	Step_Id := Step_Id + 1;
	INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_Id)
	VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_Id);
	CALL DATAOPS.Metadata_Controls.Sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
	Out_Error_Count := Error_Count;
	Out_Hard_Stop_Error := 0;
	Out_Records_Loaded := Count_Target;
		END;
		
        Final_Output := object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED );
		return :Final_Output;

	EXCEPTION
      WHEN Planned_Exception THEN
                        INSERT INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
                        VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 
                        Return object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED );

      WHEN OTHER THEN 
                        Error_Count := Error_Count +1 ; 
                        Error_Condition := 9999 ; 
                        Out_Error_Count := Error_Count ; 
                        Out_Hard_Stop_Error := 1 ; 
                        Out_Records_Loaded := Count_Last ; 
                        INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	 
                        VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 
                        INSERT 	INTO DATAOPS.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
                        VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
                        Return object_construct(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED );
END; 
';