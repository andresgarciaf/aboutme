CREATE OR REPLACE PROCEDURE "SP_DELETE_INVALID_LEADS"()
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '
	DECLARE
	--Declare output variables
        Out_Error_Count SMALLINT := 0; 
        Out_Hard_Stop_Error BYTEINT := 0; 
        Out_Records_Loaded INTEGER := 0; 
		Final_output OBJECT;
		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

	/*****************************************************************************************************************************************************************************
		Created: 2019-12-09		By: Veena
		Sample call : 
			call SALES.Sales_Staging.sp_Delete_Invalid_Leads (Out_Error_Count,Out_Hard_Stop_Error,Out_Records_Loaded);
		Purpose: Delete all Leads that changed

		Modified Date	Modified By		Notes
		---------------	----------------	-----------------------------------------------------------
		2020-02-27	Venkatesh	 Added task related things to delete invalid tasks 

	*****************************************************************************************************************************************************************************/
	--- CustomProcedure Variables
		Count_Exceptions		SMALLINT := 0; -- Number of surrogate key exceptions encountered

	-- Standard Procedure Variables
		Activity_Name		VARCHAR(100); -- The name of the procedure running

		Activity_Desc		VARCHAR(500); -- A description of the step in the procedure running for the Activity Log

		Batch_Number		INTEGER := 0; -- Holds the Batch Key assigned in the Landing process

		Calendar_Key		INTEGER := 0; -- Used to hold today''s Calendar By Day Key

		Code_Lines		SMALLINT := 0; -- Count of lines of code in this procedure for control purposes

		Completed_Flag		CHAR(1)  := ''N''; -- Used for updating the Activity Log

		Count_Last		INTEGER := 0; -- Used within the procedure to compare record count today to yesterday

		Count_Source		INTEGER := 0; -- Used within the procedure to reconcile source to Stage

		Count_Source_Insert	INTEGER := 0; -- Used within the procedure to reconcile source to target insert

		Count_Source_update	INTEGER := 0; -- Used within the procedure to reconcile source to target update

		Count_Stage		INTEGER := 0; -- Used within the procedure to reconcile source to Stage

		Count_Target		INTEGER := 0; -- Used within the procedure to reconcile Stage to Target

		Count_Target_Insert	INTEGER := 0; -- Used within the procedure to reconcile Source to Target Insert

		Count_Target_Update	INTEGER := 0; -- Used within the procedure to reconcile Source to Target Update

		Database_Source		VARCHAR(100); -- Used to specify the database where data is obtained

		Database_Stage 		VARCHAR(100); -- Used to specify the database in which this procedure runs

		Database_Target		VARCHAR(100); -- Used to specify the public production database 

		Error_Condition		BYTEINT := 0; -- Identifies the last error condition encountered

		Error_Count		SMALLINT := 0; -- Written to Out_Error_Count

		Error_Key		SMALLINT := 0; -- Written to the Error_Log

		Hard_Stop_Count		BYTEINT := 0; -- Count of hard stop errors encountered by all called procs

		Last_Record_Key		INTEGER := 0; -- Used to identify the existing vs new records

		Process_ID		INTEGER := 0; -- Identifies the Process_Control_Key this Job Process is related to

		Record_Count		INTEGER := 0; -- Multi-purpose

		SQL_Return_Code		INTEGER := 0; -- Holds the SQLCODE reported by Teradata when an error occurs - Written to the Error_Log

		SQL_Statement		VARCHAR(5000) := ''''; -- Hold Dynamic SQL - May be written to Error Log also

		SQL_State_Code		VARCHAR(5) := ''''; -- Holds the value reported for SQLSTATE when an error occurs - Written to the Error_Log

		Start_Time TIMESTAMP(6); -- Time when this procedure starts	

		Step_ID			SMALLINT := 0; -- The Step Number in the procedure that runs next (reflected in the Activity Log)

		Table_Source		VARCHAR(100); -- For code repeatability

		Table_Target		VARCHAR(100); -- For code repeatability	

		Table_Stage		VARCHAR(100); -- For code repeatability	

		Target_Balanced		CHAR ( 1 ) := ''N''; -- Identifies whether the Stage, and Target balance

		Version			DECIMAL(6,3) := 0.00; -- The version of this stored procedure in use

	BEGIN

		Activity_Name := ''sp_Delete_Invalid_Leads'';
		Code_Lines := 577;
		Database_Source := ''Sales'';
		Database_Stage := ''Sales_Staging'';
		Database_Target := ''Sales'';
		Process_ID := 458;
		Table_Source := ''sf_lead'';
		Table_Stage := ''fact_touchpoint_details'';
		Table_Target := ''fact_touchpoint_details'';
		Version := 1.1;
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

	--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SQL_Statement := ''Set Metadata_Controls.Run_Time_Results record to zero'';
			CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Start(
		:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
		:Process_ID , :Process_ID , ''Teradata'' , :Table_Target, :Version ) ;

	---------- 1 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine if Invalid fsl are in use'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.edw_salesforce.fsl_service_appointments sa
		INNER JOIN
					SALES.sales_views.appointments fsl_d
			ON fsl_d.salesforce_appointment_id::varchar=sa.service_appointment_id_cs
		INNER JOIN
					SALES.Sales_Reserved_Views.fact_touchpoint_details fsl_f
			ON fsl_f.source_record_id=fsl_d.Salesforce_Appointment_ID::varchar
			AND fsl_f.Touchpoint_Attribute_Key=fsl_d.Appointment_Key
		INNER JOIN
					SALES.edw_salesforce.fsl_work_order_line_items woli
			ON sa.parent_record_id_cs = woli.work_order_line_Item_id_cs
		INNER JOIN
					SALES.edw_salesforce.fsl_work_orders wo
			ON wo.work_order_Id_cs = woli.work_order_id_cs
		INNER JOIN
					SALES.edw_salesforce.fsl_work_types wt
			ON wt.work_type_Id_cs = woli.work_type_id_cs
		WHERE 	(wt.name_text   <> ''home delivery'' OR wo.work_order_type <> ''home delivery'')
			AND COALESCE(sa.arrival_window_start_time_utc,
			sa.actual_start_time_utc, sa.sched_start_time_utc,sa.created_date_utc)  IS NOT NULL
			AND wo.assigned_store_id_cs IS NOT NULL
			AND Web_Listing_Desc IS NULL AND appointment_key<>-1 ;
			Count_Source := COALESCE ( :Record_Count , 0 );
			Activity_Desc := ''Count of Invalid Home Deliveries in Leads DM'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);
			IF (Count_Source  = 0 ) THEN
				Activity_Desc := ''No INVALID fsl Records to Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc || '' ERROR'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);
				
			END IF;
			----------- 2 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete records in staging tables'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Tmp_Invalid_Leads;
			END IF;
			----------- 3 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			IF (Count_Source  > 0) THEN
				Activity_Desc :=
 				                 				                ''Insert the invalid fsl into tmp_Invalid_Leads which are present in '' || Database_Target || ''.'' || Table_Target;
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Inserting records in tmp_Invalid_Leads'';
				INSERT INTO SALES.Sales_Staging.Tmp_Invalid_Leads (Source_Record_ID,Source_Record_Type_Key,Customer_Activity_Key,DW_Insert_TS)
				SELECT
					fsl_d.Salesforce_Appointment_ID,
					fsl_f.Source_Record_Type_Key,
					fsl_f.Customer_Activity_Key,
					CURRENT_TIMESTAMP(0)
				FROM
					SALES.edw_salesforce.fsl_service_appointments sa
				INNER JOIN
						SALES.sales_views.appointments fsl_d
					ON fsl_d.salesforce_appointment_id::varchar=sa.service_appointment_id_cs
				INNER JOIN
						SALES.Sales_Reserved_Views.fact_touchpoint_details fsl_f
					ON fsl_f.source_record_id=fsl_d.Salesforce_Appointment_ID::varchar
					AND fsl_f.Touchpoint_Attribute_Key=fsl_d.Appointment_Key
				INNER JOIN
						SALES.edw_salesforce.fsl_work_order_line_items woli
					ON sa.parent_record_id_cs = woli.work_order_line_Item_id_cs
				INNER JOIN
						SALES.edw_salesforce.fsl_work_orders wo
					ON wo.work_order_Id_cs = woli.work_order_id_cs
				INNER JOIN
						SALES.edw_salesforce.fsl_work_types wt
				ON wt.work_type_Id_cs = woli.work_type_id_cs
				WHERE 	(wt.name_text   <> ''home delivery'' OR wo.work_order_type <> ''home delivery'')
					AND COALESCE(sa.arrival_window_start_time_utc,
					sa.actual_start_time_utc, sa.sched_start_time_utc,sa.created_date_utc)  IS NOT NULL
					AND wo.assigned_store_id_cs IS NOT NULL
					AND Web_Listing_Desc IS NULL AND appointment_key<>-1 ;
			END IF;
			----------- 4 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid fsl from appointments'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from appointments '';
				DELETE FROM
					SALES.Sales.Appointments a
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = a.Salesforce_Appointment_Id;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Last;
				Activity_Desc := ''Count of records deleted from appointments'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;
			----------- 5 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid fsl from Fact_Touchpoint_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from Fact_Touchpoint_Details '';
				DELETE FROM
					SALES.Sales.Fact_Touchpoint_Details f
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = f.Source_Record_ID
					AND 	t.Source_Record_Type_Key = f.Source_Record_Type_Key
					AND 	t.Customer_Activity_Key = f.Customer_Activity_Key;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records deleted from Fact_Touchpoint_Details'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;
	----------- 6 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			Activity_Desc := ''Determine if Invalid Appointments are in use'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.edw_salesforce.sf_event s
		INNER JOIN
					SALES.sales_views.appointments
			ON s.event_id_cs=salesforce_appointment_id::varchar
		INNER  JOIN
					SALES.Sales_Reserved_Views.fact_touchpoint_details
			ON source_record_id=salesforce_appointment_id::varchar
			AND touchpoint_attribute_key = appointment_key
		INNER JOIN
					SALES.EDW_Salesforce_Reserved_Views.sf_opportunity o
			        ON s.what_id_cs = o.opportunity_id_cs
		WHERE	s.what_id_cs LIKE ''006%''
			        AND s.what_id_cs IS NOT NULL
			        AND CAST(s.activity_ts_utc AS DATE) - CAST(s.ss_insert_ts_utc AS DATE) > 6 * 365
			        AND s.ss_lst_upd_ts_utc>=''2018-03-01 00:00:00''
			        AND s.ss_lst_upd_ts_utc<=(
					SELECT
						MAX(ss_lst_upd_ts_utc) FROM
						SALES.sales_landing.sf_event
				)
			AND Is_Deleted_Flag=''N'' AND Web_Listing_Desc IS NOT NULL AND appointment_key<>-1;
			Count_Source := COALESCE ( :Record_Count , 0 );
			Activity_Desc := ''Count of Invalid appointments in Leads DM'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);
			IF (Count_Source  = 0) THEN
				Activity_Desc := ''No INVALID appointments Records to Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc || '' ERROR'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);

			END IF;
			----------- 7 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete records in staging tables'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Tmp_Invalid_Leads;
			END IF;
			----------- 8 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			IF (Count_Source  > 0) THEN
				Activity_Desc :=
 				                 				                ''Insert the invalid appointments into tmp_Invalid_Leads which are present in '' || Database_Target || ''.'' || Table_Target;
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Inserting records in tmp_Invalid_Leads'';
				INSERT INTO SALES.Sales_Staging.Tmp_Invalid_Leads (Source_Record_ID,Source_Record_Type_Key,Customer_Activity_Key,DW_Insert_TS)
				SELECT
					salesforce_appointment_id,
					source_record_type_key,
					customer_activity_key,
					CURRENT_TIMESTAMP (0)
					FROM
					SALES.edw_salesforce.sf_event s
					INNER JOIN
						SALES.sales_views.appointments
						ON s.event_id_cs=salesforce_appointment_id::varchar
					INNER  JOIN
						SALES.Sales_Reserved_Views.fact_touchpoint_details
						ON source_record_id=salesforce_appointment_id::varchar
						AND touchpoint_attribute_key = appointment_key
					INNER JOIN
						SALES.EDW_Salesforce_Reserved_Views.sf_opportunity o
					         ON s.what_id_cs = o.opportunity_id_cs
					WHERE	s.what_id_cs LIKE ''006%''
				         AND s.what_id_cs IS NOT NULL
				         AND CAST(s.activity_ts_utc AS DATE) - CAST(s.ss_insert_ts_utc AS DATE) > 6 * 365
				         AND s.ss_lst_upd_ts_utc>=''2018-03-01 00:00:00''
				         AND s.ss_lst_upd_ts_utc<=(
						SELECT
							MAX(ss_lst_upd_ts_utc) FROM
							SALES.sales_landing.sf_event
					)
					AND Is_Deleted_Flag=''N'' AND Web_Listing_Desc IS NOT NULL AND appointment_key<>-1;
			END IF;
			----------- 9 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid appointments from appointments'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from appointments '';
				DELETE FROM
					SALES.Sales.Appointments a
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = a.Salesforce_Appointment_Id;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records deleted from appointments'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;
			----------- 10 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid appointments from Fact_Touchpoint_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from Fact_Touchpoint_Details '';
				DELETE FROM
					SALES.Sales.Fact_Touchpoint_Details f
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = f.Source_Record_ID
					AND 	t.Source_Record_Type_Key = f.Source_Record_Type_Key
					AND 	t.Customer_Activity_Key = f.Customer_Activity_Key;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records deleted from Fact_Touchpoint_Details'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;

	----------- 11 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			Activity_Desc := ''Determine if Invalid Tasks are in use'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0 , :Step_ID);
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.edw_salesforce.sf_task t
		INNER JOIN
					SALES.sales_views.tasks tsk
			ON t.Task_ID_CS=tsk.Salesforce_Task_ID::varchar
		INNER  JOIN
					SALES.Sales_Reserved_Views.fact_touchpoint_details
			ON source_record_id=salesforce_task_id
			AND touchpoint_attribute_key = task_key
		INNER JOIN
					SALES.EDW_Salesforce_Reserved_Views.sf_opportunity o
			ON t.what_id_cs = o.opportunity_id_cs
			        WHERE 	 t.What_Id_CS LIKE ''006%''
			        AND      t.What_Id_CS IS NOT NULL
			        AND      t.ss_lst_upd_ts_utc<=(
					SELECT
						MAX(ss_lst_upd_ts_utc) FROM
						SALES.sales_landing.sf_task
				)
			        AND 	t.Activity_Date IS NOT NULL and t.activity_date - CAST(t.ss_insert_ts_utc AS DATE) > 6 * 365
			        AND     task_key<>-1;
			Count_Source := COALESCE ( :Record_Count , 0 );
			Activity_Desc := ''Count of Invalid tasks in Leads DM'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);
			IF (Count_Source  = 0) THEN
				Activity_Desc := ''No INVALID tasks Records to Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc || '' ERROR'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);

			END IF;
			----------- 12 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete records in staging tables'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Tmp_Invalid_Leads;
			END IF;
			----------- 13 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			IF (Count_Source  > 0) THEN
				Activity_Desc :=
 				                 				                ''Insert the invalid tasks into tmp_Invalid_Leads which are present in '' || Database_Target || ''.'' || Table_Target;
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Inserting records in tmp_Invalid_Leads'';
				INSERT INTO SALES.Sales_Staging.Tmp_Invalid_Leads (Source_Record_ID,Source_Record_Type_Key,Customer_Activity_Key,DW_Insert_TS)
				SELECT
					salesforce_task_id,
					source_record_type_key,
					customer_activity_key,
					CURRENT_TIMESTAMP (0)
					FROM
					SALES.edw_salesforce.sf_task t
				         INNER JOIN
						SALES.sales_views.tasks tsk
					         ON t.Task_ID_CS=tsk.Salesforce_Task_ID::varchar
				         INNER  JOIN
						SALES.Sales_Reserved_Views.fact_touchpoint_details
						ON source_record_id=salesforce_task_id
						AND touchpoint_attribute_key = task_key
					INNER JOIN
						SALES.EDW_Salesforce_Reserved_Views.sf_opportunity o
					         ON t.what_id_cs = o.opportunity_id_cs
				         WHERE 	 t.What_Id_CS LIKE ''006%''
				         AND      t.What_Id_CS IS NOT NULL
				         AND      t.ss_lst_upd_ts_utc<=(
						SELECT
							MAX(ss_lst_upd_ts_utc) FROM
							SALES.sales_landing.sf_task
					)
				         AND 	t.Activity_Date IS NOT NULL and t.activity_date - CAST(t.ss_insert_ts_utc AS DATE) > 6 * 365
				         AND     task_key<>-1;
			END IF;
			----------- 14 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid tasks from tasks'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from tasks '';
				DELETE FROM
					SALES.Sales.Tasks a
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = a.Salesforce_Task_Id;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records deleted from tasks'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;
			----------- 15 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid tasks from Fact_Touchpoint_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from Fact_Touchpoint_Details '';
				DELETE FROM
					SALES.Sales.Fact_Touchpoint_Details f
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = f.Source_Record_ID
					AND 	t.Source_Record_Type_Key = f.Source_Record_Type_Key
					AND 	t.Customer_Activity_Key = f.Customer_Activity_Key;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records deleted from Fact_Touchpoint_Details'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;

	----------- 16 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Determine if Invalid Phone PBX are in use'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
			SELECT
				COUNT(*) INTO
				:Record_Count
		FROM
				SALES.Sales_Reserved_Views.Fact_Touchpoint_Details
			WHERE source_record_type_key=899
		AND Phone_Number_Customer IN
		(
					SELECT
						phone_number FROM
						SALES.sales_views.kmx_phone_numbers
					WHERE phone_number <> ''NA'') ;
			Count_Source := COALESCE ( :Record_Count , 0 );
			Activity_Desc := ''Count of Invalid phone pbx in Leads DM'';
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Source, :Step_ID);
			IF (Count_Source  = 0 ) THEN
				Activity_Desc := ''No INVALID phone pbx Records to Process'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc || '' ERROR'' , :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);

			END IF;
			----------- 17 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete records in staging tables'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 0, :Step_ID);
				SQL_Statement := Activity_Desc;
				DELETE FROM
					SALES.Sales_Staging.Tmp_Invalid_Leads;
			END IF;
			----------- 18 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
			IF (Count_Source  > 0) THEN
				Activity_Desc :=
 				                 				                ''Insert the invalid appointments into tmp_Invalid_Leads which are present in '' || Database_Target || ''.'' || Table_Target;
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Inserting records in tmp_Invalid_Leads'';
				INSERT INTO SALES.Sales_Staging.Tmp_Invalid_Leads (Source_Record_ID,Source_Record_Type_Key,Customer_Activity_Key,DW_Insert_TS)
				SELECT
					source_record_id,
					source_record_type_key,
					customer_activity_key,
					CURRENT_TIMESTAMP (0)
					FROM
					SALES.Sales_Reserved_Views.Fact_Touchpoint_Details
					WHERE 	source_record_type_key=899
					AND 	Phone_Number_Customer IN
					(
						SELECT
							phone_number FROM
							SALES.sales_views.kmx_phone_numbers
						WHERE phone_number <> ''NA'') ;
			END IF;
			----------- 19 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Count_Source  > 0) THEN
				Activity_Desc := ''Delete the invalid phone pbx from Fact_Touchpoint_Details'';
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Last_Record_Key , :Step_ID);
				SQL_Statement := ''Delete invalid records from Fact_Touchpoint_Details '';
				DELETE FROM
					SALES.Sales.Fact_Touchpoint_Details f
				USING SALES.Sales_Staging.tmp_Invalid_Leads t
				WHERE
					t.Source_Record_ID = f.Source_Record_ID
					AND 	t.Source_Record_Type_Key = f.Source_Record_Type_Key
					AND 	t.Customer_Activity_Key = f.Customer_Activity_Key;
				Count_Last := COALESCE ( :SQLROWCOUNT , 0 );
				Count_Target := Count_Target + Count_Last;
				Activity_Desc := ''Count of records deleted from Fact_Touchpoint_Details'';
				INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last , :Step_ID);
			END IF;

	----------- 20 --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.Sales_Staging.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Target , :Step_ID);
			SQL_Statement := Activity_Desc;
			CALL DATAOPS.Metadata_Controls.sp_Run_Time_Results_Stop(
		:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Target;
		
			Final_output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
			RETURN :Final_output;
	EXCEPTION
When Planned_Exception then
		
	INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
	VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
	
	Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED);
    
When OTHER then

	Error_Count := Error_Count +1 ;
	Error_Condition := 9999 ;
	Out_Error_Count := Error_Count ;
	Out_Hard_Stop_Error := 1 ;
	Out_Records_Loaded := Count_Last ;
	
	INSERT INTO SALES.Sales_Staging.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )	
	VALUES 	( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ;

    INSERT 	INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement) 
	VALUES 	(:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ;
    
    Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED);
    
END;
';