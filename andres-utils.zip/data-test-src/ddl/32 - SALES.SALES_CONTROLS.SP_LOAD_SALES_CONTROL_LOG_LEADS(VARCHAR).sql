CREATE OR REPLACE PROCEDURE "SP_LOAD_SALES_CONTROL_LOG_LEADS"("DATAMART_NAME" VARCHAR(16777216))
RETURNS OBJECT
LANGUAGE SQL
EXECUTE AS OWNER
AS '

DECLARE 

/*****************************************************************************************************************************************************************************
	Created: 2019-03-21		By: Vignesh S
	Purpose: Load Sales Control Log for Leads DM

	  	Modified Date	Modified By	Notes
	-------------	-----------	------------------------------------------------------------------------------------------------------------------------------

*****************************************************************************************************************************************************************************/
	--Declare output variables
		OUT_ERROR_COUNT SMALLINT := 0;
		OUT_HARD_STOP_ERROR BYTEINT := 0;
		OUT_RECORDS_LOADED INTEGER := 0;
		Final_output OBJECT;
		Planned_Exception Exception (-20001, ''Exception based on Error_Condition'');

-- Custom Procedure Variables
		Controls_Start		CHAR(8); -- Time after which extensive controls will run

		Controls_End		CHAR(8); -- Time after which extensive controls won''t start

		Process_Key		INTEGER := 0; -- Holds the record key assigned in the Process_Controls_History table

		Process_Status		BYTEINT := 0; -- Holds the status of dependent processes

		Source_System_ID		BYTEINT := 0; -- Identifies the Source System Key this Job Process is related to

		Start_Time_Key		INTEGER := 0; -- The integer version of Start_Time

		Subject_Area_ID		SMALLINT := 0; -- Defines the Subject_Area_Key

		Table_Count		SMALLINT := 0; -- Incremented with each new table affected by this procedure

		v_Count_SQL 		VARCHAR(10000); -- SQL statement used to count for control

		v_Status_SQL 		VARCHAR(10000); -- SQL statement used to determine status

		SQL_Record_Key		INTEGER; -- Record_key of SQL to be executed	

		Control_EOD_Time		TIME(0); -- Holds parameter value for time of controls

-- Standard Procedure Variables
		Activity_Name	VARCHAR(100); -- The name of the procedure running

		Activity_Desc	VARCHAR(500); -- A description of the step in the procedure running for the Activity Log

		Batch_Number	INTEGER := 0; -- Holds the Batch Key assigned in the Landing process

		Calendar_Key	INTEGER := 0; -- Used to hold today''s Calendar By Day Key

		Code_Lines	SMALLINT := 0; -- Count of lines of code in this procedure for control purposes

		Completed_Flag	CHAR(1)  := ''N''; -- Used for updating the Activity Log

		Count_Last	INTEGER := 0; -- Used within the procedure to compare record count today to yesterday

		Count_Source	INTEGER := 0; -- Used within the procedure to reconcile source to Stage

		Count_Stage	INTEGER := 0; -- Used within the procedure to reconcile source to Stage

		Count_Target	INTEGER := 0; -- Used within the procedure to reconcile Stage to Target

		Database_Source	VARCHAR(100); -- Used to specify the database where data is obtained

		Database_Stage 	VARCHAR(100); -- Used to specify the database in which this procedure runs

		Database_Target	VARCHAR(100); -- Used to specify the public production database 

		Error_Condition	BYTEINT := 0; -- Identifies the last error condition encountered

		Error_Count	SMALLINT := 0; -- Written to Out_Error_Count

		Error_Key	SMALLINT := 0; -- Written to the Error_Log

		Hard_Stop_Count	BYTEINT := 0; -- Count of hard stop errors encountered by all called procs

		First_Record_key  INTEGER := 0;
		Last_Record_Key	INTEGER := 0; -- Used to identify the existing vs new records

		Process_ID	INTEGER := 0; -- Identifies the Process_Control_Key this Job Process is related to

		Record_Count	INTEGER := 0; -- Multi-purpose

		SQL_Return_Code	INTEGER := 0; -- Holds the SQLCODE reported by Teradata when an error occurs - Written to the Error_Log

		SQL_Statement	VARCHAR(10000) := ''''; -- Hold Dynamic SQL - May be written to Error Log also

		SQL_State_Code	VARCHAR(5) := ''''; -- Holds the value reported for SQLSTATE when an error occurs - Written to the Error_Log

		Start_Time TIMESTAMP(6); -- Time when this procedure starts	

		Step_ID		SMALLINT := 0; -- The Step Number in the procedure that runs next (reflected in the Activity Log)

		Table_Source	VARCHAR(100); -- For code repeatability

		Table_Target	VARCHAR(100); -- For code repeatability	

		Table_Stage	VARCHAR(100); -- For code repeatability	

		Target_Balanced	CHAR ( 1 ) := ''N''; -- Identifies whether the Stage, and Target balance

		Version		DECIMAL(6,3) := 0.00; -- The version of this stored procedure in use

	BEGIN

		Activity_Name := ''sp_Load_Sales_Control_Log_Leads'';
		Code_Lines := 540;
		Database_Source := ''Multiple'';
		Database_Stage := ''Sales_Controls'';
		Database_Target := ''Sales_Controls'';
		Process_ID := 476;
		Source_System_ID := 24;
		Subject_Area_ID := 37;
		Table_Source := ''Multiple'';
		Table_Stage := ''Multiple'';
		Table_Target := ''Control_Log'';
		Version := 1.0;
		SELECT
			CAST(TRUNC(Parameter_Value) AS INTEGER) 
		INTO
			:First_Record_key
		FROM
			DATAOPS.METADATA_VIEWS.Parameters_Sales
	WHERE	Parameter_Name = :Datamart_Name ||''_DM_First_Record_Key'';
		SELECT
			CAST(TRUNC(Parameter_Value) AS INTEGER) 
		INTO
			:Last_Record_key
		FROM
			DATAOPS.METADATA_VIEWS.Parameters_Sales
	WHERE	Parameter_Name = :Datamart_Name ||''_DM_Last_Record_Key'';
		SELECT
			Calendar_By_Day_Key INTO
			:Calendar_Key
		FROM
			ACCOUNTING.Valid_Values_Views.Calendar_By_Day
		WHERE Calendar_Date = CURRENT_DATE ;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		LET GET_SQL_STMT CURSOR
		FOR
			SELECT
				Test_SQL,
				Record_Key
						FROM
				SALES.SALES_BUILD.Control_Log_Template
						WHERE 	Test_SQL IS NOT NULL
						AND 	Record_Key BETWEEN ? AND ?
						AND 	Test_SQL <> ''In Procedure''
						AND 	Active_Flag = ''Y''
						ORDER BY Record_Key;
		LET GET_STATUS_STMT CURSOR
		FOR
			SELECT
				Status_SQL,
				Record_Key
						FROM
				SALES.SALES_BUILD.Control_Log_Template
						WHERE 	Status_SQL IS NOT NULL
						AND 	Record_Key BETWEEN ? AND ?
						AND 	Status_SQL <> ''In Procedure''
						AND 	Active_Flag = ''Y''
						ORDER BY Record_Key;

		--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Starting  ****'';
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SQL_Statement := ''Set METADATA_CONTROLS.Run_Time_Results record to zero'';
			CALL DATAOPS.METADATA_CONTROLS.sp_Run_Time_Results_Start(
			:Activity_Name, :Code_Lines, :Database_Stage, :Database_Target,
			:Process_ID , :Process_ID , ''Teradata'' , :Table_Target, :Version ) ;

		--------- 0 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Check Run Parameter'';
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			IF ((
				SELECT
					Parameter_Value FROM
					DATAOPS.METADATA_VIEWS.Parameters_Sales
				WHERE Parameter_Name = ''Run sp_Load_Sales_Control_Log'' ) = 0) THEN
				INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Condition, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, ''Parameter_Sales set to 0 (Do not Run)'', :Completed_Flag, :Error_Condition , :Error_Count, :Record_Count, :Step_ID);
				Activity_Desc := ''****  Complete  ****'';
				Completed_Flag := ''Y'';
				INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, 1 , :Step_ID);
				SQL_Statement := Activity_Desc;
				CALL DATAOPS.METADATA_CONTROLS.sp_Run_Time_Results_Stop(
				:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
				Out_Error_Count := 0;
				Out_Hard_Stop_Error := 0;
				Out_Records_Loaded := 0;
				CALL DATAOPS.METADATA_CONTROLS.sp_Run_Time_Results_Stop(
				:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, 1  , ''Teradata'' , :Target_Balanced ) ;
				
				RAISE Planned_Exception;
			END IF;

		-------- 1 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert new event into Process_Controls_History'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			Table_Count := Table_Count + 1;
			SQL_Statement := Activity_Desc;
			CALL DATAOPS.METADATA_CONTROLS.sp_Process_History_Insert( :Batch_Number , :Calendar_Key , :Error_Count, :Process_ID, :Record_Count, :Source_System_ID, :Table_Count  ) ;
			SQL_Statement := ''SELECT
   max ( DW_Insert_TS ) into Start_Time'';
			SELECT
				MAX ( DW_Insert_TS ) INTO
				:Start_Time
		FROM
				DATAOPS.METADATA_CONTROLS.Process_Controls_History
		WHERE	Batch_Key = 0
		AND	Calendar_By_Day_Key = :Calendar_Key
		AND	Process_Control_Key = :Process_ID
		AND	Process_Status_Key = 1 ;
			SQL_Statement := ''SELECT
   Record_Key into Process_Key'';
			SELECT
				Record_Key INTO
				:Process_Key
		FROM
				DATAOPS.METADATA_CONTROLS.Process_Controls_History
		WHERE	Batch_Key = 0
		AND	Calendar_By_Day_Key = :Calendar_Key
		AND	Process_Control_Key = :Process_ID
		AND	Process_Status_Key = 1
		AND	DW_Insert_TS = :Start_Time ;
			Activity_Desc :=''Process_Key inserted into Process_Controls_History is '' || LEFT(LTRIM(TO_VARCHAR(Process_Key, ''MI9999999999'')), 6);
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);

		-------- 2 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Change Process_Control_History status to Running'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, 0 , 0 , :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE DATAOPS.METADATA_CONTROLS.Process_Controls_History
		SET	Process_Status_Key = 2 	-- (Running)
		WHERE	Record_Key = :Process_Key ;

		-------- 3 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Get parameter value for Control EOD Time'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SELECT
				CAST(Parameter_Value AS TIME(0))
			INTO
				:Control_EOD_Time
		FROM
				DATAOPS.METADATA_VIEWS.Parameters_Sales
		WHERE	Parameter_Name = ''Control_EOD_Time'';

		-------- 4 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Upsert Last results to Staging table'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);

		UPDATE SALES.SALES_CONTROLS.Control_Log_Staging s
		FROM
			SALES.SALES_CONTROLS.Control_Log c
		SET
			Record_Count = c.Record_Count,
			Status = c.Status,
			DW_Insert_TS = CURRENT_TIMESTAMP(0)
		WHERE	s.Record_Key = c.Record_Key
		AND 	s.Source_Record_Type_Key = c.Source_Record_Type_Key
		AND 	c.Record_Key BETWEEN :First_Record_key AND :Last_Record_key;

		-------- 5 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Last results to Staging table for any new record keys'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			INSERT INTO SALES.SALES_CONTROLS.Control_Log_Staging (Source_Record_Type_Key,Record_Key, Activity_Desc, Record_Count, Status, DW_Insert_TS)
			SELECT
				Source_Record_Type_Key,
				Record_Key,
				Activity_Desc,
				Record_Count,
				Status,
				DW_Insert_TS
		FROM
				SALES.SALES_CONTROLS.Control_Log
		WHERE 	( Record_Key,Source_Record_Type_Key ) NOT IN (
					SELECT
						Record_Key,
						Source_Record_Type_Key
									 FROM
						SALES.SALES_CONTROLS.Control_Log_Staging
				)
		AND 	Record_Key BETWEEN :First_Record_key AND :Last_Record_key;

		-------- 6 -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''DELETE old records from Control_Log_History'';
			Step_ID := Step_ID + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SQL_Statement := ''DELETE FROM
   SALES_CONTROLS.Control_Log_History'';
			DELETE FROM
				SALES.SALES_CONTROLS.Control_Log_History
			WHERE
				DW_Insert_TS <=  CURRENT_DATE  - 30
AND 	Record_Key BETWEEN :First_Record_key AND :Last_Record_key;

		-------- 7 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert Last results to History table'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			INSERT INTO SALES.SALES_CONTROLS.Control_Log_History (Source_Record_Type_Key, Record_Key, Activity_Desc, Record_Count, Status, DW_Insert_TS)
			SELECT
				Source_Record_Type_Key,
				Record_Key,
				Activity_Desc,
				Record_Count,
				Status,
				DW_Insert_TS
		FROM
				SALES.SALES_CONTROLS.Control_Log
		WHERE  Record_Key BETWEEN :First_Record_key AND :Last_Record_key;

		-------- 8 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Delete Last results from final table'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			DELETE FROM
				SALES.SALES_CONTROLS.Control_Log
			WHERE
				Record_Key BETWEEN :First_Record_key AND :Last_Record_key;
		-------- 9 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Insert base records from template table'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			INSERT INTO SALES.SALES_CONTROLS.Control_Log (Source_Record_Type_Key,Record_Key, Activity_Desc, Record_Count, Status, DW_Insert_TS)
			SELECT
				t.Source_Record_Type_Key,
				t.Record_key,
				t.Activity_Desc,
				NULL,
				NULL,
				CURRENT_TIMESTAMP(0)
		FROM
				SALES.SALES_BUILD.Control_Log_Template t
		JOIN
					SALES.SALES_VIEWS.Table_Controls c
		ON	c.Target_Table = t.Source_Table_Name
		WHERE	t.Active_Flag = ''Y''
		AND 	t.Record_Key BETWEEN :First_Record_key AND :Last_Record_key
		AND    ((CASE
					WHEN CURRENT_TIME < :Control_EOD_Time
						THEN TIME ''23:59:59''
			     ELSE CURRENT_TIME
				END > CASE
					WHEN t.Source_Table_Interval = 0
						THEN CAST(c.DW_Update_TS AS TIME(0))
			     ELSE TIME ''23:59:00''
				END)

		OR	((
					SELECT
						Parameter_Value
					  FROM
						DATAOPS.METADATA_VIEWS.Parameters_Sales
					  WHERE 	Parameter_Name = ''Run_all_Sales_Controls'') = ''Y'' ) )
		UNION
			SELECT
				t.Source_Record_Type_Key,
				t.Record_Key,
				t.Activity_Desc,
				NULL,
				NULL,
				CURRENT_TIMESTAMP(0)
		FROM
				SALES.SALES_BUILD.Control_Log_Template t
		WHERE	t.Activity_Desc = ''''
		AND 	t.Active_Flag = ''Y''
		AND 	t.Record_Key BETWEEN :First_Record_key AND :Last_Record_key;

		-------- 10 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Open cursor GET_SQL_STMT '';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			OPEN GET_SQL_STMT USING (:First_Record_key,:Last_Record_key);

		-------- 11 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Open cursor GET_STATUS_STMT '';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			OPEN GET_STATUS_STMT USING (:First_Record_key,:Last_Record_key);

		-------- 12 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Loop through cursor and execute SQL '';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);

			FOR i in GET_SQL_STMT DO
				v_Count_SQL := i.Test_SQL;
                SQL_Record_Key := i.Record_Key;
				Activity_Desc :=''Execute Control Count SQL for record_key ''|| LEFT(LTRIM(TO_VARCHAR(SQL_Record_Key, ''MI9999999999'')), 4);
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
				EXECUTE IMMEDIATE v_Count_SQL;
				Count_Target := Count_Target + 1;
			END FOR;

		-------- 13 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Close GET_SQL_STMT cursor'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
		CLOSE  GET_SQL_STMT;


		-------- 14 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Loop through cursor and execute SQL '';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);

			FOR i IN GET_STATUS_STMT DO
				v_Status_SQL := i.Status_SQL;
                SQL_Record_Key := i.Record_Key;
				Activity_Desc :=''Execute Control Status SQL for record_key ''|| LEFT(LTRIM(TO_VARCHAR(SQL_Record_Key, ''MI9999999999'')), 4);
				Step_ID := Step_ID + 1;
				INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
				VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
				EXECUTE IMMEDIATE v_Status_SQL;
			END FOR;

		-------- 15 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Close GET_STATUS_STMT cursor'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
		CLOSE  GET_STATUS_STMT;

		-------- 16 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Collect Statistics'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);

		-------- 17 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''insert Metadata Table_Controls record'';
			Step_ID := Step_ID + 1;
			Record_Count := 0;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Record_Count, :Step_ID);
			SQL_Statement := Activity_Desc;
			INSERT INTO DATAOPS.METADATA_CONTROLS.Table_Controls (
			Batch_Key, Calendar_By_Day_Key, Process_Control_Key,
			Process_Status_Key,
			Balanced_Flag,
			Destination_Database, Destination_Table_Name,
			Error_Detail_Description,
			Source_Server, Source_Database, Source_Table_Name,
			Destination_Aggregate_Amount, Destination_Record_Count, Error_Record_Count,
			Source_Aggregate_Amount, Source_Record_Count)
			VALUES (:Batch_Number, :Calendar_Key , :Process_ID , CASE
				WHEN :Error_Count = 0
					THEN 4 ELSE 5
			END, CASE
				WHEN :Error_Count = 0
					THEN ''Y'' ELSE ''N''
			END,
			:Database_Target , :Table_Target , CASE
				WHEN :Error_Count > 0
					THEN ''See Activity Log'' ELSE ''NA''
			END,
			''Teradata'', :Database_Source , :Table_Source ,
			0 , :Count_Target , :Error_Count ,
			0 , :Count_Source);
			Record_Count := COALESCE ( SQLROWCOUNT , 0 );
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Stage, :Step_ID);

		-------- 18 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''Update Metadata Controls.Process_Controls_History'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Hard_Stop_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Hard_Stop_Count , :Record_Count, :Step_ID);
			SQL_Statement := Activity_Desc;
			UPDATE DATAOPS.METADATA_CONTROLS.Process_Controls_History
		SET	Error_Condition_Key = CASE
						WHEN :Hard_Stop_Count > 0
							THEN 9
						WHEN :Error_Count > 0
							THEN 10
						ELSE 0
					END,
			Process_Status_Key = CASE
						WHEN :Hard_Stop_Count > 0
							THEN 6
						WHEN :Error_Count > 0
							THEN 6
						ELSE 4
					END,
			Error_Detail_Description = CASE
						WHEN :Error_Count > 0
							THEN ''See Activity Log'' ELSE ''NA''
					END,
			Record_Error_Count = CASE
						WHEN :Error_Count > 0
							THEN :Error_Count ELSE 0
					END,
					Record_Count = CASE
						WHEN :Record_Count IS NULL
							THEN 0 ELSE :Record_Count
					END,
			DW_Update_TS = CURRENT_TIMESTAMP ( 6 ) ,
			DW_Update_User = CURRENT_USER
		WHERE	Record_Key = :Process_Key ;
			-------- 19 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			IF (Error_Count = 0 AND Hard_Stop_Count = 0) THEN
		Activity_Desc := ''Update Metadata Controls.Process_Controls_Today'';
		Step_ID := Step_ID + 1;
		INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Hard_Stop_Count, Record_Count, Step_ID)
		VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Hard_Stop_Count , :Record_Count, :Step_ID);
		SQL_Statement := Activity_Desc;
		MERGE INTO DATAOPS.METADATA_CONTROLS.Process_Controls_Today a
		USING (SELECT :Process_ID AS Process_Control_Key) b ON a.Process_Control_Key = b.Process_Control_Key
		WHEN MATCHED THEN
					UPDATE SET
						Batch_Key = 0,
						Calendar_By_Day_Key = :Calendar_Key,
						Error_Condition_Key = CASE
							WHEN :Error_Count > 0
								THEN 10 ELSE 0
						END,
						Process_Status_Key = CASE
							WHEN :Error_Count > 0
								THEN 6 ELSE 4
						END,
						Source_System_Key = :Source_System_ID,
						Record_Count = :Record_Count,
						Record_Error_Count = :Error_Count,
						Table_Count = :Table_Count,
						DW_Update_TS = CURRENT_TIMESTAMP( 0 ),
						DW_Update_User = CURRENT_USER
		WHEN NOT MATCHED THEN
					INSERT
					VALUES (
					:Process_ID, 0 , :Calendar_Key , CASE
						WHEN :Error_Count > 0
							THEN 10 ELSE 0
					END, CASE
						WHEN :Error_Count > 0
							THEN 6 ELSE 4
					END,
					:Source_System_ID , :Record_Count ,
					:Error_Count , :Table_Count ,
					CURRENT_TIMESTAMP(0) ,
					CURRENT_USER ,
					CURRENT_TIMESTAMP(0) ,
					CURRENT_USER);

			END IF;

		-------- 20 ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			Activity_Desc := ''****  Complete  ****'';
			Completed_Flag := ''Y'';
			Step_ID := Step_ID + 1;
			INSERT INTO SALES.SALES_CONTROLS.Activity_Log (Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID)
			VALUES (:Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_stage , :Step_ID);
			CALL DATAOPS.METADATA_CONTROLS.sp_Run_Time_Results_Stop(
			:Activity_Name, :Completed_Flag , :Count_Target, :Database_Stage, :Error_Count, :Hard_Stop_Count  , ''Teradata'' , :Target_Balanced ) ;
			Out_Error_Count := Error_Count;
			Out_Hard_Stop_Error := 0;
			Out_Records_Loaded := Count_Target;
		
			Final_output := OBJECT_CONSTRUCT(''OUT_ERROR_COUNT'', :OUT_ERROR_COUNT, ''OUT_HARD_STOP_ERROR'', :OUT_HARD_STOP_ERROR, ''OUT_RECORDS_LOADED'', :OUT_RECORDS_LOADED);
			RETURN :Final_output;
	EXCEPTION 
	WHEN Planned_Exception THEN 

		INSERT INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

	WHEN OTHER THEN 
		Error_Count := Error_Count +1 ; 
		Error_Condition := 9999 ; 
		Out_Error_Count := Error_Count ; 
		Out_Hard_Stop_Error := 1 ; 
		Out_Records_Loaded := Count_Last ; 

		INSERT INTO SALES.SALES_CONTROLS.Activity_Log ( Activity_Name, Activity_Desc, Completed_Flag, Error_Count, Record_Count, Step_ID )         
		VALUES         ( :Activity_Name, :Activity_Desc, :Completed_Flag, :Error_Count, :Count_Last, :Step_ID ) ; 

		INSERT         INTO DataOps.Metadata_Controls.Error_Log (Activity_Name, Activity_Desc, Activity_Step_ID, Error_Condition ,Name_Database, SQL_Return_Code, SQL_State_Code, SQL_Statement)  
		VALUES         (:Activity_Name, :Activity_Desc , :Step_ID, :Error_Condition , :Database_Stage, :SQLCODE , :SQLSTATE , :SQLERRM ) ; 

    		Return object_construct(''OUT_ERROR_COUNT'',OUT_ERROR_COUNT,''OUT_HARD_STOP_ERROR'',OUT_HARD_STOP_ERROR,''OUT_RECORDS_LOADED'',OUT_RECORDS_LOADED); 

END;
';