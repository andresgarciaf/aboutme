import pandas as pd
import numpy as np
import json
import os
from datetime import date, datetime
from IPython.display import display, HTML


def query(query, target_engine):
    if target_engine.connect():
        return pd.read_sql(
                query,
                target_engine.engine,
            )


def query_envs(source_engine, target_engine, table_name, table_keys, use_order_by=True):
    source_table = ".".join(table_name.split(".")[1:])
    target_table = table_name

    if target_engine.connect():
        target_results = pd.read_sql(
            f"Select * From {target_table} {f'Order By {table_keys[-1]} Desc' if use_order_by else ''} Limit 10;",
            target_engine.engine,
        )
        target_results.columns = target_results.columns.str.lower()

    params = tuple(target_results[table_keys[0]].to_list())

    if len(params) > 0:
        if source_engine.connect():
            query = """
                Select
                    *
                From
                    {0}
                Where
                    {1}
                    {2}
                    ;
            """
            source_results = pd.read_sql(
                query.format(source_table, f"{table_keys[0]} In ", params),
                source_engine.engine,
            )
            source_results.columns = source_results.columns.str.lower()
        return source_results, target_results
    else:
        print("Queries returned 0 recods.")
        return pd.DataFrame(), pd.DataFrame()

def df_info(df1, df2):
    print("Snowflake Results:\n")
    print(df1.info())

    print("Teradata Results:\n")
    print(df2.info())


def reshape_df(to_reshape_df, sample_df):
    return to_reshape_df[
        to_reshape_df.drop(["insert_ts", "lst_upd_ts"], axis=1).apply(
            lambda row: row.to_dict()
            in sample_df.drop(["insert_ts", "lst_upd_ts"], axis=1).to_dict(
                orient="records"
            ),
            axis=1,
        )
    ]


def store_dataframes(df1, df2, join_cols, table_name):
    
    if len(df1) > 0 and len(df2) > 2:
        df1_sorted = df1.sort_values(by=join_cols)
        df2_sorted = df2.sort_values(by=join_cols)

        # check if dataframaes have same row count
        if df2_sorted.shape[0] > df1_sorted.shape[0]:
            print("Cleaning Teradata dataframe to compare same row count.")
            df2_shaped = reshape_df(df2_sorted, df1_sorted)
            df2_sorted = df2_shaped.sort_values(by=join_cols)

        with pd.ExcelWriter(f"output/{table_name}.xlsx") as w:
            df1_sorted.to_excel(
                w, sheet_name="Snowflake", index=False
            )  # Write the dataframe to an Excel file
            df2_sorted.to_excel(w, sheet_name="Teradata", index=False)
    else:
        print("No Data Found to be stored.")


def trim_str(value):
    if isinstance(value, str):
        return value.strip()
    else:
        return value


def get_dataframes(file_path):
    if os.path.exists(file_path):
        df1 = pd.read_excel(file_path, sheet_name="Snowflake")
        df2 = pd.read_excel(file_path, sheet_name="Teradata")
        df2 = df2.applymap(trim_str)

        return df1, df2
    else:
        return pd.DataFrame(), pd.DataFrame()


def compare_source(file_path):
    (
        df1,
        df2,
    ) = get_dataframes(file_path)
    
    if len(df1) > 0 and len(df2) > 0 and len(df1) == len(df2) :   
        return df1 == df2
    else:
        print("No records to compare.")


def show_differences(file_path, common_key):
    differences_dict = {}
    (
        df1,
        df2,
    ) = get_dataframes(file_path)
    
    if len(df1) > 0 and len(df2) > 0:

        for idx in df1[common_key]:
            row1 = df1[df1[common_key] == idx]
            row2 = df2[df2[common_key] == idx]
            if not row1.empty and not row2.empty:
                for col in df1.columns:
                    if row1[col].values[0] != row2[col].values[0]:
                        if idx not in differences_dict:
                            differences_dict[idx] = {}
                        differences_dict[idx][col] = (
                            f"\nSnowflake: {row1[col].values[0]}, "
                            + f"\nTeradata: {row2[col].values[0]}"
                        )

        output_df = pd.DataFrame.from_dict(differences_dict, orient="index")
        output_df.index.name = common_key
        output_df.reset_index(inplace=True)

        return display(HTML(output_df.to_html().replace("\\n", "<br>")))
    else:
        print("No differences to show.")
