from urllib import parse

from sqlalchemy import create_engine, MetaData
from sqlalchemy.exc import SQLAlchemyError

class DatabaseConnector:
    PROVIDER_DIALECT = {
        "POSTGRESSQL": "postgresql://",
        "MYSQL": "mysql+pymysql://",
        "SQLLITE": "sqlite:///",
        "MSSQL": "mssql+pyodbc://",
        "ORACLE": "oracle+cx_oracle://",
        "TERADATA": "teradatasql://",
        "SNOWFLAKE": "snowflake://",
    }

    def __init__(
        self,
        provider,
        username,
        password,
        host,
        connection_attributes={},
    ):
        self.provider = provider.upper()
        self.username = username
        self.password = parse.quote(password)
        self.host = host
        self.database = None
        self.schema = None
        self.connection_attributes = connection_attributes
        self.engine = None
        self.connection = None
        self.meta = MetaData()

    def connect(self):
        connected = False
        connection_string = self._build_connection_string()
        try:
            self.engine = create_engine(connection_string)
            self.connection = self.engine.connect()
            connected = True
        except SQLAlchemyError as e:
            print("Error connecting to the database:", e)
        return connected
    
    def disconnect(self):
        disconnected = False
        try:
            self.connection.close()
            self.engine.dispose()
            disconnected = True
        except SQLAlchemyError as e:
            print("Error disconnecting from the database:", e)
        return disconnected
    
    def execute_query(self, query):
        try:
            result = self.connection.execute(query)
            return result.fetchall()
        except SQLAlchemyError as e:
            print("Error executing query:", e)
            return None
        


    def _build_connection_string(self):
        connection_string = None
        if self.provider not in self.PROVIDER_DIALECT:
            raise ValueError("Invalid database provider specified.")
        else:
            connection_string = f"{self.PROVIDER_DIALECT[self.provider]}"

            connection_string += f"{self.username}:{self.password}@{self.host}"

            optional_params = self.connection_attributes
            if optional_params:
                if "port" in optional_params:
                    connection_string += f":{optional_params['port']}"
                    del optional_params["port"]
                connection_string += (
                    f"?database={self.database}&schema={self.schema}&"
                    + "&".join(
                        f"{key}={value}" for key, value in optional_params.items()
                    )
                )
        return connection_string

    

