import logging

from typing import TypeAlias, Any
import importlib
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.utils import get_openapi
from fastapi.middleware.cors import CORSMiddleware
from pydantic import ValidationError

# Type aliases
Payload: TypeAlias = dict[str, Any]
RouteInfo: TypeAlias = dict[str, Any]

logger = logging.getLogger(__name__)


class APIException(Exception):
    """Custom API exception for handling application errors."""

    def __init__(
        self, message: str, status_code: int = 400, payload: Payload | None = None
    ):
        super().__init__()
        self.message = message
        self.status_code = status_code
        self.payload = payload or {}

    def to_dict(self) -> Payload:
        """Convert exception details to dictionary format."""
        return {
            **self.payload,
            "detail": self.message,  # Changed to 'detail' to match OpenAPI standard
            "status_code": self.status_code,
        }


def custom_openapi(app: FastAPI) -> dict[str, Any]:
    """Generate a custom OpenAPI schema for the application."""
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )

    # Add security schemes if needed
    # openapi_schema["components"]["securitySchemes"] = {
    #     "bearerAuth": {
    #         "type": "http",
    #         "scheme": "bearer",
    #         "bearerFormat": "JWT",
    #     }
    # }

    # Set global security requirement if needed
    # openapi_schema["security"] = [{"bearerAuth": []}]
    openapi_schema["info"]["x-logo"] = {
        "url": "https://cdn.bfldr.com/9AYANS2F/as/jc54c97bcnstfm9xh8qxxz/Databricks_Favicon?auto=webp&format=png"
    }

    app.openapi_schema = openapi_schema
    return app.openapi_schema


def configure_app(app: FastAPI) -> FastAPI:
    """Configure FastAPI application with middleware, exception handlers, and static file serving."""

    # Set up custom OpenAPI schema
    app.openapi = lambda: custom_openapi(app)

    # Mount Next.js static files from 'out' directory if it exists
    static_path = Path("out")
    if static_path.exists():
        app.mount(
            "/_next/static",
            StaticFiles(directory=str(static_path / "_next/static"), html=True),
            name="next_static",
        )

    # CORS middleware configuration
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Exception handlers
    @app.exception_handler(APIException)
    async def api_exception_handler(
        request: Request, exc: APIException
    ) -> JSONResponse:
        # pylint: disable=unused-argument
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.to_dict(),
        )

    @app.exception_handler(ValidationError)
    async def validation_exception_handler(
        request: Request, exc: ValidationError
    ) -> JSONResponse:
        # pylint: disable=unused-argument
        errors = [error["msg"] for error in exc.errors()]
        return JSONResponse(
            status_code=422,
            content={"detail": errors, "error_type": "ValidationError"},
        )

    app = load_routes(app)

    # Only mount Next.js routes if the directory exists
    if static_path.exists():
        # Serve Next.js static assets
        @app.get("/_next/{path:path}", tags=["NextJs"])
        async def serve_next_static(path: str):
            static_file = static_path / "_next" / path
            if static_file.is_file():
                return FileResponse(str(static_file))

        # Handle Next.js page routes
        @app.get("/{full_path:path}", tags=["NextJs"])
        async def serve_next_app(full_path: str, request: Request):
            # Skip API routes
            # pylint: disable=unused-argument
            if full_path.startswith("api/"):
                raise APIException("Not Found", status_code=404)

            # Try to serve specific page HTML if it exists
            page_path = static_path / full_path / "index.html"
            if page_path.is_file():
                return FileResponse(str(page_path))

            # Try to serve the HTML file directly (for non-index pages)
            html_path = static_path / f"{full_path}.html"
            if html_path.is_file():
                print(html_path)
                return FileResponse(str(html_path))

            # Fall back to serving index.html for client-side routing
            index_path = static_path / "index.html"
            if index_path.is_file():
                return FileResponse(str(index_path))

            raise APIException("Not Found", status_code=404)

    return app


def load_routes(app: FastAPI) -> FastAPI:
    """Dynamically load all API routers from the api directory."""
    api_path = Path(__file__).parent

    if not api_path.exists():
        raise APIException(f"API directory not found: {api_path}")

    for route_dir in api_path.glob("**/*"):
        for route_file in route_dir.glob("*.py"):
            if route_file.name not in ["__init__.py"]:
                module_name = f"backend.api.{route_dir.name}.{route_file.stem}"
                try:
                    module = importlib.import_module(module_name)
                    if hasattr(module, "router"):
                        app.include_router(
                            module.router,
                            prefix="/api",
                        )
                except ImportError as e:
                    raise APIException(
                        f"Failed to load router {module_name}: {str(e)}"
                    ) from e
    return app
