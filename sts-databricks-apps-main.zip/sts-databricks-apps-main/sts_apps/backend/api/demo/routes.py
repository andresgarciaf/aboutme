from fastapi import APIRouter, status
from backend.api.models import WelcomeResponse

router = APIRouter()


@router.get(
    "/welcome/",
    response_model=list[WelcomeResponse],
    status_code=status.HTTP_200_OK,
    summary="Welcome message",
    description="Example API endpoint to test the API.",
    responses={200: {"description": "Successful response with welcome message"}},
    tags=["Demo"],
)
async def welcome_api() -> list[WelcomeResponse]:
    """Simple endpoint to verify the API is working.

    Returns:
        List[WelcomeResponse]: A list containing a welcome message
    """
    return [WelcomeResponse(msg="Welcome to the STS APP API")]
