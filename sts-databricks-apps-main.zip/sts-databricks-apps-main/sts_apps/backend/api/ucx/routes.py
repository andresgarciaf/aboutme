import asyncio

from fastapi import APIRouter, UploadFile, File, Form, status, HTTPException
from fastapi.responses import StreamingResponse

from backend.api.models import ErrorResponse

from backend.ucx_analysis.report.analysis import ReportManager

router = APIRouter()


# ucx routes
@router.post(
    "/run-analysis/",
    status_code=status.HTTP_200_OK,
    summary="Run UCX analysis",
    description="Generate a UCX analysis report based on the uploaded file.",
    response_model=None,
    responses={
        200: {
            "description": "Analysis completed, returns ZIP file directly",
            "content": {"application/zip": {}},
        },
        400: {"description": "Bad request", "model": ErrorResponse},
        422: {"description": "Validation error", "model": ErrorResponse},
        500: {"description": "Server error", "model": ErrorResponse},
    },
    tags=["UCX Analysis"],
)
async def run_analysis(
    uploaded_file: UploadFile = File(..., description="UCX file to analyze"),
    cloud: str = Form(..., description="Cloud provider (aws, azure, or gcp)"),
):
    """Generate the UCX analysis report and return as a ZIP file or a job ID.

    Args:
        uploaded_file: The UCX file to analyse
        cloud: The cloud provider (aws, azure, or gcp)

    Returns:
        Either a StreamingResponse with the ZIP file

    Raises:
        HTTPException: If there's an error processing the file
    """
    try:
        report = ReportManager(cloud, uploaded_file)
        zip_buffer = await asyncio.wait_for(report.generate_zipped_report(), timeout=50)

        file_name = (uploaded_file.filename or "default").split("_")[0]

        return StreamingResponse(
            zip_buffer,
            media_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="{file_name}_ucx_analysis_report.zip"'
            },
            status_code=status.HTTP_200_OK,
        )
    except asyncio.TimeoutError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing file: {str(e)}",
        )
