import os
import tempfile
from datetime import datetime
from typing import List

from fastapi import APIRouter, File, UploadFile, HTTPException, status
from fastapi.responses import FileResponse

from backend.lakebridge_analyzer_review.reviewer import LakebridgeReviewer
from backend.logger import get_logger
from backend.api.models import ErrorResponse
from backend.config import Config

router = APIRouter()


# Setup
try:
    Config.setup_directories()
    logger = get_logger()
except Exception as e:
    print(f"Setup warning: {e}")
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

@router.post(
    "/lakebridge-analyzer-review/",
    status_code=status.HTTP_200_OK,
    summary="Review Lakebridge Analyzer outputs for errors, warnings, and notes",
    description="Generate a Lakebridge Analyzer analysis report based on the uploaded file(s).",
    response_model=None,
    responses={
        200: {
            "description": "Analysis completed, returns ZIP file directly",
            "content": {"application/zip": {}},
        },
        400: {"description": "Bad request", "model": ErrorResponse},
        422: {"description": "Validation error", "model": ErrorResponse},
        500: {"description": "Server error", "model": ErrorResponse},
    },
    tags=["Lakebridge Analyzer Review"],
)

async def review_files(
    files: List[UploadFile] = File(description="XLSX files to review")
):
    """Review multiple XLSX files and return a comprehensive PDF report."""
    logger.info(f"Received {len(files)} files for review")
    
    # Validate files
    for file in files:
        if not file.filename or not file.filename.endswith('.xlsx'):
            raise HTTPException(status_code=400, detail=f"File {file.filename} must be an XLSX file")
    
    temp_file_paths = []
    
    try:
        # Process files
        for file in files:
            with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx', dir=Config.UPLOAD_DIR) as temp_file:
                content = await file.read()
                temp_file.write(content)
                temp_file_paths.append(temp_file.name)
        
        # Generate report
        original_filenames = [file.filename or f"file_{i}.xlsx" for i, file in enumerate(files)]
        reviewer = LakebridgeReviewer()
        pdf_path = reviewer.review_multiple_files(temp_file_paths, original_filenames)
        
        # Cleanup
        for temp_path in temp_file_paths:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
        
        # Return PDF with proper filename
        logger.info(f"Returning PDF from path: {pdf_path}")
        filename = f"comprehensive_analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        return FileResponse(pdf_path, media_type="application/pdf", filename=filename)
        
    except Exception as e:
        logger.error(f"Error processing files: {str(e)}")
        # Cleanup on error
        for temp_path in temp_file_paths:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
        raise HTTPException(status_code=500, detail=f"Error processing files: {str(e)}") 