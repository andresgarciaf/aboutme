from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field
from datetime import datetime, date


class ErrorResponse(BaseModel):
    """Standard error response model"""

    detail: str = Field(..., description="Error details")


class WelcomeResponse(BaseModel):
    """Welcome message response model"""

    msg: str = Field(..., description="Welcome message")


class QueryRequest(BaseModel):
    query: str = Field(..., description="Query the required terraform component")


class CodeResponse(BaseModel):
    files: List[Dict[str, Any]] = Field(..., description="Files requires")
    explanation: str = Field(..., description="Description of explanation")


class StatusResponse(BaseModel):
    status: str = Field(..., description="Files requires")
    repo_last_synced: str = Field(..., description="Files requires")
    index_count: int = Field(..., description="Files requires")
