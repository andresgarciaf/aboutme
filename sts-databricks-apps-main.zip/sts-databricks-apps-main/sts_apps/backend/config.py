import os

class Config:
    """Configuration class for the application"""
    
    # Environment detection - single source of truth
    ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

    # Databricks Configuration
    DATABRICKS_WAREHOUSE_ID = os.getenv("DATABRICKS_WAREHOUSE_ID")

    # File Storage Configuration
    UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/tmp/uploads")
    
    
    @classmethod
    def setup_directories(cls):
        """Create necessary directories"""
        os.makedirs(cls.UPLOAD_DIR, exist_ok=True)