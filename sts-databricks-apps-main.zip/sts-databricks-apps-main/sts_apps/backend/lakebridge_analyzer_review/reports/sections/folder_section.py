from typing import List, Dict, Any, Tuple
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from .base_section import BaseSection
from ..utils.table_utils import create_dynamic_table


class FolderSection(BaseSection):
    """Section for folder analysis results."""
    
    def create_section(self, folder_analysis_results: List[Dict[str, Any]]) -> List:
        """Create the folder mapping details analysis section."""
        story = self._create_section_header("Folder Grouping Analysis")
        
        # Group results by filename
        files_by_name = {}
        for result in folder_analysis_results:
            filename = result['filename']
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Sort results: errors first, then warnings (folders found), then successes
            sorted_results = []
            for result in file_results:
                if not result.get('success', False):
                    sorted_results.append(('error', result))
                elif result.get('total_folders', 0) > 0:
                    sorted_results.append(('warning', result))
                else:
                    sorted_results.append(('success', result))
            
            # Sort by priority: error -> warning -> success
            priority_order = {'error': 0, 'warning': 1, 'success': 2}
            sorted_results.sort(key=lambda x: priority_order[x[0]])
            
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result_type, result in sorted_results:
                if result.get('success', False):
                    total_folders = result['total_folders']
                    folder_analysis = result['folder_analysis']
                    
                    if total_folders == 0:
                        story.append(self._create_indented_item("No folders found"))
                    else:
                        message = f"Found {total_folders} folders with mapping details - Review for migration scoping and planning."
                        story.append(self._create_indented_item(message))
                    
                    # Add detailed table with folder analysis
                    if total_folders > 0 and 'sorted_folders' in result:
                        story.append(Spacer(1, 2))  # Add space before indented items
                        story.extend(self._create_folder_details(result['sorted_folders'], filename))
                else:
                    error_msg = f"Error: {result.get('error', 'Unknown error')}"
                    story.append(self._create_indented_item(error_msg))
            
            story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 6))
        return story
    
    def _create_folder_details(self, sorted_folders: List[Tuple[str, Dict[str, Any]]], filename: str) -> List:
        """Create detailed bullet points of folder analysis results."""
        story = []
        
        if not sorted_folders:
            return story
        
        # Create bullet points for each folder analysis result
        for folder_name, folder_data in sorted_folders:
            # Format the folder details with indentation
            formatted_result = self._format_folder_result(folder_name, folder_data)
            story.append(self._create_indented_item(formatted_result))
            story.append(Spacer(1, 2))
        
        return story
    
    def _format_folder_result(self, folder_name: str, folder_data: Dict[str, Any]) -> str:
        """Format folder result to make folder names bold."""
        # Create combinations with formatting
        combinations = []
        for combination_key, data in folder_data['mapping_type_categorization'].items():
            categorization, mapping_type = self._format_combination(combination_key)
            combinations.append({
                'text': f"{data['count']} {categorization} {mapping_type} - {data['total_nodes']:.0f} nodes total",
                'categorization': categorization,
                'count': data['count'],
                'nodes': data['total_nodes']
            })
        
        # Sort combinations by categorization, count, and nodes
        combinations.sort(key=lambda x: (
            self._get_categorization_score(x['categorization']),
            x['count'],
            x['nodes']
        ))
        
        # Format folder result with bold folder name
        details = ', '.join(item['text'] for item in combinations)
        return f"<b>{folder_name}</b>: {details}"
    
    def _format_combination(self, combination_key: str) -> Tuple[str, str]:
        """Format combination key into categorization and mapping type."""
        parts = combination_key.split()
        categorization = parts[0].title()
        mapping_type = ' '.join(parts[1:])
        
        # Add "complexity" suffix for Low and Medium
        if categorization in ['Low', 'Medium']:
            categorization += ' complexity'
            
        return categorization, mapping_type
    
    def _get_categorization_score(self, categorization: str) -> int:
        """Get sorting score for categorization."""
        categorization_lower = categorization.lower()
        if 'low' in categorization_lower:
            return 1
        elif 'medium' in categorization_lower:
            return 2
        elif 'complex' in categorization_lower and 'very' not in categorization_lower:
            return 3
        elif 'very complex' in categorization_lower:
            return 4
        else:
            return 1  # Default to low 