from typing import List, Dict, Any, Union
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from .base_section import BaseSection
from ..utils.table_utils import get_standard_table_style


class DuplicateSection(BaseSection):
    """Section for duplicate program name analysis results."""
    
    def create_section(self, duplicate_name_results: List[Dict[str, Any]]) -> List:
        """Create the duplicate program names analysis section."""
        story = self._create_section_header("Potential Duplicate Program Names Analysis")
        
        # Group results by filename
        files_by_name = {}
        for result in duplicate_name_results:
            filename = result['filename']
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Sort results: errors first, then warnings (duplicates found), then successes
            sorted_results = []
            for result in file_results:
                if not result.get('success', False):
                    sorted_results.append(('error', result))
                elif result.get('duplicate_programs_count', 0) > 0:
                    sorted_results.append(('warning', result))
                else:
                    sorted_results.append(('success', result))
            
            # Sort by priority: error -> warning -> success
            priority_order = {'error': 0, 'warning': 1, 'success': 2}
            sorted_results.sort(key=lambda x: priority_order[x[0]])
            
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result_type, result in sorted_results:
                if result.get('success', False):
                    duplicate_count = result['duplicate_programs_count']
                    
                    if duplicate_count == 0:
                        story.append(self._create_indented_item("No duplicate program names found"))
                    else:
                        message = f"{duplicate_count} potential duplicate program names found - Review and exclude copies."
                        story.append(self._create_indented_item(message))
                    
                    # Add detailed table if there are duplicates
                    if duplicate_count > 0 and 'duplicate_groups' in result:
                        story.append(Spacer(1, 2))  # Add space before indented items
                        story.extend(self._create_duplicate_details(result['duplicate_groups']))
                else:
                    error_msg = f"Error: {result.get('error', 'Unknown error')}"
                    story.append(self._create_indented_item(error_msg))
            
            story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 4))
        return story
    
    def _create_duplicate_details(self, duplicate_groups: List[List[Dict[str, Any]]]) -> List:
        """Create detailed table of duplicate files with similarity analysis."""
        story = []
        
        if not duplicate_groups:
            return story
        
        # Sort groups by similarity score (highest to lowest)
        sorted_groups = []
        for group in duplicate_groups:
            if len(group) >= 2:
                similarity_data = group[-1] if group else {}
                similarity_score = similarity_data.get('similarity_score', 0)
                sorted_groups.append((similarity_score, group))
        
        sorted_groups.sort(key=lambda x: x[0], reverse=True)  # Sort by similarity score, highest first
        
        # Process each duplicate group separately
        for group_idx, (similarity_score, group) in enumerate(sorted_groups, 1):
            # Extract similarity analysis (last item in group)
            similarity_data = group[-1] if group else {}
            programs = group[:-1]  # All items except the last one (similarity data)
            
            # Create group header with numbering
            story.append(self._create_deep_indented_item(f"{group_idx}. Similarity Score: {similarity_score:.1f}%"))
            
            # Create table for this group with Paragraph for program names
            table_data: List[List[Union[str, Paragraph]]] = [['Row', 'Program Name', 'Line Count', 'Complexity', 'Statement Count', 'Procedure/Function Count']]
            
            for program in programs:
                program_name = program.get('name', 'Unknown')
                
                # Create a Paragraph for the program name to handle long text properly
                program_style = ParagraphStyle(
                    'CellText',
                    fontSize=8,
                    fontName='Helvetica',
                    alignment=0,  # Left align
                    spaceAfter=0,
                    spaceBefore=0,
                    leftIndent=0,
                    rightIndent=0,
                    firstLineIndent=0,
                    wordWrap='CJK'  # Better word wrapping
                )
                
                program_paragraph = Paragraph(program_name, program_style)
                
                table_data.append([
                    str(program.get('row', 'Unknown')),
                    program_paragraph,
                    str(program.get('line_count', 'Unknown')),
                    str(program.get('complexity', 'Unknown')),
                    str(program.get('statement_count', 'Unknown')),
                    str(program.get('procedure_function_count', 'Unknown'))
                ])
            
            # Create table with custom column widths like oversize section
            from reportlab.platypus import Table
            from reportlab.lib.units import inch
            
            # Custom column widths: Row, Program Name, Line Count, Complexity, Statement Count, Procedure/Function Count
            col_widths = [0.4*inch, 2.4*inch, 0.8*inch, 1.0*inch, 1.2*inch, 1.8*inch]
            
            # Create table
            table = Table(table_data, colWidths=col_widths)
            
            # Apply custom style with word wrapping for program name column only
            from reportlab.lib import colors
            style = [
                # Header styling
                ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('TOPPADDING', (0, 0), (-1, 0), 6),
                # Body styling
                ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('TOPPADDING', (0, 1), (-1, -1), 4),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
                # Left align and word wrap Program Name column (column 1)
                ('ALIGN', (1, 0), (1, -1), 'LEFT'),
                ('WORDWRAP', (1, 0), (1, -1), True),
            ]
            
            table.setStyle(style)
            story.append(Spacer(1, 2))
            story.append(table)
            
            story.append(Spacer(1, 2))
        
        return story 