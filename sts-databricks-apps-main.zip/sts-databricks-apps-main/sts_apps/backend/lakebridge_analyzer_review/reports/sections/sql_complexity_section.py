from typing import List, Dict, Any, Union
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from .base_section import BaseSection


class SQLComplexitySection(BaseSection):
    """PDF section for SQL Complexity Analysis results."""
    
    def create_section(self, results: List[Dict[str, Any]]) -> List:
        """Create the SQL Complexity Analysis section for the PDF report."""
        story = []
        
        # Add section header
        story.extend(self._create_section_header("SQL Complexity Analysis"))
        
        # Group results by filename
        files_by_name = {}
        for result in results:
            filename = result.get('filename', 'Unknown')
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result in file_results:
                if not result.get('success', False):
                    # Handle error case
                    story.append(self._create_error_item(filename, result.get('error', 'Unknown error')))
                    story.append(Spacer(1, 6))
                    continue
                
                total_files = result.get('total_files', 0)
                complexity_counts = result.get('complexity_counts', {})
                percentages = result.get('percentages', {})
                has_complex_files = result.get('has_complex_files', False)
                complex_files = result.get('complex_files', [])
                very_complex_files = result.get('very_complex_files', [])
                
                # Add complexity statistics
                if total_files > 0:
                    story.append(self._create_indented_item("Complexity Distribution:"))
                    
                    # Add percentage breakdown with deeper indented items
                    for complexity, count in complexity_counts.items():
                        percentage = percentages.get(complexity, 0)
                        # Skip if count is 0 (0%)
                        if count == 0:
                            continue
                        complexity_name = complexity.replace('_', ' ').title()
                        story.append(self._create_deep_indented_item(
                            f"{complexity_name}: {count} files ({percentage:.1f}%)"
                        ))
                    
                    # Add warning if complex files exist
                    if has_complex_files:
                        story.append(self._create_indented_item("Review the file content below to verify complexity."))

            
                        # Create tables for complex and very complex files (indented)
                        if complex_files:
                            story.extend(self._create_complexity_table("Complex Files", complex_files, filename))
                            story.append(Spacer(1, 4))
                        
                        if very_complex_files:
                            story.extend(self._create_complexity_table("Very Complex Files", very_complex_files, filename))
                            story.append(Spacer(1, 4))
                else:
                    story.append(self._create_indented_item("No SQL files found for analysis"))
            
            story.append(Spacer(1, 6))
        
        return story
    
    def _create_filename_header(self, filename: str, subtitle: str = "") -> Paragraph:
        """Create a header with filename and optional subtitle."""
        # Use the centralized method from base section for consistency
        if subtitle:
            # For subtitle case, create a custom version that includes subtitle
            filename_style = ParagraphStyle(
                'FilenameHeader',
                parent=self.styles['Normal'],
                fontSize=self.FONT_SIZES['body'],
                fontName='Helvetica-Bold',
                spaceAfter=self.SPACING['small'],
                spaceBefore=self.SPACING['small'],
                textColor=colors.black
            )
            return Paragraph(f"• {filename}: {subtitle}", filename_style)
        else:
            # Use the standard centralized method
            return super()._create_filename_header(filename)
    

    
    def _create_complexity_table(self, title: str, files: List[Dict[str, Any]], filename: str) -> List:
        """Create a table showing complex or very complex files."""
        story = []
        
        # Add table title with deeper indented item
        story.append(self._create_deep_indented_item(f"{title}"))
        
        if not files:
            story.append(self._create_deep_indented_item("No files found"))
            return story
        
        # Create table data with Paragraph for program names to handle long text properly
        table_data: List[List[Union[str, Paragraph]]] = [['Row', 'Program Name']]
        
        for file_info in files:
            program_name = file_info.get('file_name', 'N/A')
            
            # Create a Paragraph for the program name to handle long text properly
            program_style = ParagraphStyle(
                'CellText',
                fontSize=8,
                fontName='Helvetica',
                alignment=0,  # Left align
                spaceAfter=0,
                spaceBefore=0,
                leftIndent=0,
                rightIndent=0,
                firstLineIndent=0,
                wordWrap='CJK'  # Better word wrapping
            )
            
            program_paragraph = Paragraph(program_name, program_style)
            
            table_data.append([
                str(file_info.get('row', 'N/A')),
                program_paragraph
            ])
        
        # Create table with custom sizing for wider program names
        col_widths, row_heights = self._calculate_complexity_table_sizing(table_data)
        
        table = Table(table_data, colWidths=col_widths, rowHeights=row_heights)
        
        # Apply custom style with word wrapping for program name column only
        style = [
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 6),
            # Body styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 1), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
            # Left align and word wrap Program Name column (column 1)
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('WORDWRAP', (1, 0), (1, -1), True),
        ]
        
        # Add custom row heights if provided (skip header row 0)
        if row_heights:
            for i, height in enumerate(row_heights):
                if i > 0:  # Skip header row (row 0)
                    style.append(('ROWBACKGROUNDS', (0, i), (-1, i), [colors.beige]))
                style.append(('MINIMUMHEIGHT', (0, i), (-1, i), height))
        
        table.setStyle(TableStyle(style))
        
        # Add indentation to the table
        story.append(Spacer(1, 3))
        story.append(table)
        
        return story
    
    def _calculate_complexity_table_sizing(self, table_data: List[List[Union[str, Paragraph]]]) -> tuple[List[float], List[float]]:
        """Calculate table sizing specifically for complexity tables with wider program name column."""
        if not table_data:
            return [], []
        
        num_cols = len(table_data[0])
        num_rows = len(table_data)
        
        # Estimate character widths for different font types
        header_char_width = 0.08 * inch  # Bold font (Helvetica-Bold, size 10) takes more space
        data_char_width = 0.06 * inch    # Regular font (Helvetica, size 8)
        
        # Calculate column widths based on content
        col_widths = []
        for col_idx in range(num_cols):
            max_col_width = 0
            
            # First, check header row (row 0) with header font characteristics
            if col_idx < len(table_data[0]):
                header_cell = table_data[0][col_idx]
                header_text = str(header_cell) if isinstance(header_cell, str) else str(header_cell.text)
                # Use minimal padding for first column (Row), more padding for others
                padding = 0.05 * inch if col_idx == 0 else 0.2 * inch
                header_width = len(header_text) * header_char_width + padding
                max_col_width = max(max_col_width, header_width)
            
            # Then check data rows with data font characteristics
            for row_idx in range(1, num_rows):  # Start from row 1 (skip header)
                if col_idx < len(table_data[row_idx]):
                    cell_content = table_data[row_idx][col_idx]
                    cell_text = str(cell_content) if isinstance(cell_content, str) else str(cell_content.text)
                    # Use minimal padding for first column (Row), more padding for others
                    padding = 0.05 * inch if col_idx == 0 else 0.2 * inch
                    data_width = len(cell_text) * data_char_width + padding
                    max_col_width = max(max_col_width, data_width)
            
            # Set minimum and maximum bounds - allow wider columns for program names
            if col_idx == 0:  # Row column
                min_width = 0.4 * inch
                max_width_per_col = 1.0 * inch
            elif col_idx == 1:  # Program Name column
                min_width = 0.8 * inch
                max_width_per_col = 5.0 * inch  # Much wider for program names
            else:
                min_width = 0.8 * inch
                max_width_per_col = 2.5 * inch  # Standard width for other columns
            col_width = max(min_width, min(max_col_width, max_width_per_col))
            col_widths.append(col_width)
        
        # Don't normalize - let the table be as wide as needed
        # total_width = sum(col_widths)
        # if total_width > max_width:
        #     scale_factor = max_width / total_width
        #     col_widths = [width * scale_factor for width in col_widths]
        
        # Calculate row heights based on content
        row_heights = []
        for row_idx in range(num_rows):
            max_row_height = 0.3 * inch  # Minimum row height
            
            for col_idx in range(num_cols):
                if col_idx < len(table_data[row_idx]):
                    cell_content = table_data[row_idx][col_idx]
                    cell_text = str(cell_content) if isinstance(cell_content, str) else str(cell_content.text)
                    # Calculate wrapping for this cell
                    available_width = col_widths[col_idx] - 0.1 * inch  # Account for padding
                    wrapped_lines = self._calculate_text_wrapping(cell_text, available_width)
                    
                    # Estimate height based on number of lines
                    line_height = 0.15 * inch
                    cell_height = wrapped_lines * line_height + 0.1 * inch  # Add padding
                    max_row_height = max(max_row_height, cell_height)
            
            row_heights.append(max_row_height)
        
        return col_widths, row_heights 