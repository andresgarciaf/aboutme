from typing import List, Dict, Any
from reportlab.platypus import Spacer
from .base_section import BaseSection


class VersionSection(BaseSection):
    """Section for version check results."""
    
    def create_section(self, version_results: List[Dict[str, Any]]) -> List:
        """Create the version check section."""
        story = self._create_section_header("Version Check")
        
        # Group results by filename
        files_by_name = {}
        for result in version_results:
            filename = result['filename']
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Sort results: errors first, then warnings (old version), then successes
            sorted_results = []
            for result in file_results:
                if not result.get('success', False):
                    sorted_results.append(('error', result))
                elif result.get('is_old_version', False):
                    sorted_results.append(('warning', result))
                else:
                    sorted_results.append(('success', result))
            
            # Sort by priority: error -> warning -> success
            priority_order = {'error': 0, 'warning': 1, 'success': 2}
            sorted_results.sort(key=lambda x: priority_order[x[0]])
            
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result_type, result in sorted_results:
                if result.get('success', False):
                    if result.get('is_old_version', False):
                        version_number = result.get('version_number', 'Unknown')
                        message = f"Analyzer Version {version_number} - Version is outdated. Update Analyzer for more accurate results."
                        story.append(self._create_indented_item(message))
                    else:
                        version_number = result.get('version_number', 'Unknown')
                        message = f"Analyzer Version {version_number} - Version is current. No action required."
                        story.append(self._create_indented_item(message))
                else:
                    error_msg = f"Error: {result.get('error', 'Unknown error')}"
                    story.append(self._create_indented_item(error_msg))
            
            story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 6))
        return story 