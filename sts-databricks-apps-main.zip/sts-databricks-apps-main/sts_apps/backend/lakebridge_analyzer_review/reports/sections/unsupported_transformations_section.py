from typing import List, Dict, Any
from reportlab.platypus import Spacer, Paragraph, Table
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from .base_section import BaseSection


class UnsupportedTransformationsSection(BaseSection):
    """Section for unsupported transformations analysis results."""
    
    def create_section(self, unsupported_transformations_results: List[Dict[str, Any]]) -> List:
        """Create the unsupported transformations analysis section."""
        story = self._create_section_header("Unsupported Transformations Analysis")
        
        # Group results by filename
        files_by_name = {}
        for result in unsupported_transformations_results:
            filename = result['filename']
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Sort results: errors first, then warnings (unsupported found), then successes
            sorted_results = []
            for result in file_results:
                if not result.get('success', False):
                    sorted_results.append(('error', result))
                elif result.get('unsupported_count', 0) > 0:
                    sorted_results.append(('warning', result))
                else:
                    sorted_results.append(('success', result))
            
            # Sort by priority: error -> warning -> success
            priority_order = {'error': 0, 'warning': 1, 'success': 2}
            sorted_results.sort(key=lambda x: priority_order[x[0]])
            
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result_type, result in sorted_results:
                if result.get('success', False):
                    supported_count = result.get('supported_count', 0)
                    unsupported_count = result.get('unsupported_count', 0)
                    
                    # Add unsupported transformations message
                    if unsupported_count > 0:
                        unsupported_msg = f"There are {unsupported_count} transformations that need manual conversion or additional configuration."
                        story.append(self._create_indented_item(unsupported_msg))
                    
                    # Add supported transformations message
                    if supported_count > 0:
                        supported_msg = f"There are {supported_count} transformations that can be converted automatedly."
                        story.append(self._create_indented_item(supported_msg))
                    
                    # Add detailed table if there are unsupported transformations
                    if unsupported_count > 0 and 'unsupported_details' in result:
                        story.append(Spacer(1, 2))  # Add space before indented items
                        total_occurrences = result.get('total_occurrences', 0)
                        unsupported_percentage = result.get('unsupported_percentage', 0)
                        story.extend(self._create_unsupported_details(result['unsupported_details'], unsupported_percentage, total_occurrences))
                else:
                    error_msg = f"Error: {result.get('error', 'Unknown error')}"
                    story.append(self._create_indented_item(error_msg))
            
            story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 4))
        return story
    
    def _create_unsupported_details(self, unsupported_details: Dict[str, int], unsupported_percentage: float, total_occurrences: int) -> List:
        """Create detailed table of unsupported transformations with percentages."""
        story = []
        
        if not unsupported_details:
            return story
        
        # Sort transformations by occurrence count (highest to lowest)
        sorted_transformations = sorted(unsupported_details.items(), key=lambda x: x[1], reverse=True)
        
        # Create table data
        table_data = [['Transformation Name', 'Occurrences', 'Percentage']]
        
        for transformation_name, occurrence_count in sorted_transformations:
            # Calculate percentage for this transformation relative to total occurrences
            transformation_percentage = (occurrence_count / total_occurrences) * 100 if total_occurrences > 0 else 0
            
            table_data.append([
                transformation_name,
                str(occurrence_count),
                f"{transformation_percentage:.1f}%"
            ])
        
        # Add total row
        total_occurrences = sum(unsupported_details.values())
        table_data.append([
            'TOTAL',
            str(total_occurrences),
            f"{unsupported_percentage:.1f}%"
        ])
        
        # Create table with custom column widths
        col_widths = [3.0*inch, 1.5*inch, 1.5*inch]
        
        # Create table
        table = Table(table_data, colWidths=col_widths)
        
        # Apply custom style
        style = [
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 6),
            # Body styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 1), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
            # Left align transformation names
            ('ALIGN', (0, 1), (0, -1), 'LEFT'),
            # Bold the total row
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            # Enable text wrapping for transformation names
            ('WORDWRAP', (0, 0), (0, -1), True),
        ]
        
        table.setStyle(style)
        story.append(Spacer(1, 2))
        story.append(table)
        
        story.append(Spacer(1, 2))
        
        return story 