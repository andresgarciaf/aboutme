from typing import List, Dict, Any
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from .base_section import BaseSection


class SummarySection(BaseSection):
    """Section for summary of all errors and warnings from all checks."""
    
    def create_section(self, all_results: List[Dict[str, Any]]) -> List:
        """Create the summary section with all errors and warnings aggregated across files."""
        story = []
        
        # Collect all errors across files
        all_errors = set()
        
        # Aggregate counts across all files for warnings and notes
        aggregated_data = {
            'oversize_files_count': 0,
            'duplicate_programs_count': 0,
            'uncategorized_files_count': 0,
            'has_unknown_sheet_values': False,
            'complex_sql_files': 0,
            'very_complex_sql_files': 0,
            'is_old_version': False,
            'version_number': None,
            'total_folders': 0,
            'workflow_mapping_ratio': None,
            'total_workflows': 0,
            'total_mappings': 0,
            'unsupported_transformations_count': 0,
            'supported_transformations_count': 0
        }
        
        # For complexity aggregation
        sql_complexity_counts = {'low': 0, 'medium': 0, 'complex': 0, 'very_complex': 0}
        sql_total_files = 0
        etl_complexity_counts = {'low': 0, 'medium': 0, 'complex': 0, 'very_complex': 0}
        etl_total_files = 0
        job_complexity_counts = {'low': 0, 'medium': 0, 'complex': 0, 'very_complex': 0}
        job_total_files = 0
        
        for result in all_results:
            if not result.get('success', False):
                # Error case
                error_msg = result.get('error', 'Unknown error')
                all_errors.add(error_msg)
            else:
                # Aggregate counts for warnings
                if 'oversize_files_count' in result:
                    aggregated_data['oversize_files_count'] += result['oversize_files_count']
                if 'duplicate_programs_count' in result:
                    aggregated_data['duplicate_programs_count'] += result['duplicate_programs_count']
                if 'uncategorized_files_count' in result:
                    aggregated_data['uncategorized_files_count'] += result['uncategorized_files_count']
                if 'has_unknown_sheet_values' in result and result['has_unknown_sheet_values']:
                    aggregated_data['has_unknown_sheet_values'] = True
                if result.get('script_type') == 'SQL' and 'complexity_counts' in result:
                    for k in sql_complexity_counts:
                        sql_complexity_counts[k] += result['complexity_counts'].get(k, 0)
                    sql_total_files += result.get('total_files', 0)
                    aggregated_data['complex_sql_files'] += result['complexity_counts'].get('complex', 0)
                    aggregated_data['very_complex_sql_files'] += result['complexity_counts'].get('very_complex', 0)
                if result.get('script_type') == 'ETL' and 'complexity_counts' in result:
                    for k in etl_complexity_counts:
                        etl_complexity_counts[k] += result['complexity_counts'].get(k, 0)
                    etl_total_files += result.get('total_files', 0)
                if result.get('script_type') == 'JOB' and 'complexity_counts' in result:
                    for k in job_complexity_counts:
                        job_complexity_counts[k] += result['complexity_counts'].get(k, 0)
                    job_total_files += result.get('total_files', 0)
                if 'is_old_version' in result and result['is_old_version'] and not aggregated_data['is_old_version']:
                    aggregated_data['is_old_version'] = True
                    aggregated_data['version_number'] = result.get('version_number', 'Unknown')
                if 'total_folders' in result:
                    aggregated_data['total_folders'] += result['total_folders']
                if 'workflow_mapping_ratio' in result and aggregated_data['workflow_mapping_ratio'] is None:
                    aggregated_data['workflow_mapping_ratio'] = result['workflow_mapping_ratio']
                    aggregated_data['total_workflows'] = result.get('total_workflows', 0)
                    aggregated_data['total_mappings'] = result.get('total_mappings', 0)
                if 'unsupported_count' in result:
                    aggregated_data['unsupported_transformations_count'] += result['unsupported_count']
                if 'supported_count' in result:
                    aggregated_data['supported_transformations_count'] += result['supported_count']
        
        # Calculate total complexity (SQL+ETL+JOB)
        total_complexity_counts = {k: sql_complexity_counts[k] + etl_complexity_counts[k] + job_complexity_counts[k] for k in sql_complexity_counts}
        total_files = sql_total_files + etl_total_files + job_total_files
        
        def make_distribution_note(label, counts, total):
            if total == 0:
                return None
            parts = []
            for k in ['low', 'medium', 'complex', 'very_complex']:
                count = counts[k]
                pct = (count / total) * 100 if total > 0 else 0
                if count > 0:
                    parts.append(f"{k.replace('_', ' ').title()}: {count} ({pct:.1f}%)")
            return f"{label} Complexity Distribution: {', '.join(parts)}" if parts else None
        
        # Generate aggregated warnings and notes
        all_warnings = set()
        all_notes = []  # preserve order for total, sql, etl
        
        # Warnings
        if aggregated_data['oversize_files_count'] > 0:
            all_warnings.add(f"{aggregated_data['oversize_files_count']} oversize files found - Split files by object.")
        if aggregated_data['duplicate_programs_count'] > 0:
            all_warnings.add(f"{aggregated_data['duplicate_programs_count']} potential duplicate program names found - Review and exclude copies.")
        if aggregated_data['uncategorized_files_count'] > 0:
            all_warnings.add(f"{aggregated_data['uncategorized_files_count']} uncategorized files found - Review file content to confirm importance and logic.")
            all_warnings.add("Review the UNKNOWN SQL Category sheet to confirm important logic are not uncategorized.")
        if aggregated_data['uncategorized_files_count'] == 0 and aggregated_data['has_unknown_sheet_values']:
            all_warnings.add("Review the UNKNOWN SQL Category sheet to confirm important logic are not uncategorized.")
        if aggregated_data['complex_sql_files'] > 0 or aggregated_data['very_complex_sql_files'] > 0:
            total_complex = aggregated_data['complex_sql_files'] + aggregated_data['very_complex_sql_files']
            all_warnings.add(f"{total_complex} complex/very complex SQL files found - Review the file content below to verify complexity.")
        if aggregated_data['is_old_version']:
            version = aggregated_data['version_number'] or 'Unknown'
            all_warnings.add(f"Using old analyzer version {version} - Consider upgrading.")
        if aggregated_data['unsupported_transformations_count'] > 0:
            all_warnings.add(f"{aggregated_data['unsupported_transformations_count']} unsupported transformations found - Manual conversion or additional configuration required.")
        
        # Notes
        # 1. Complexity notes (total + indented breakdowns)
        complexity_notes = []
        
        # Determine which section types are present
        section_types_present = []
        if sql_total_files > 0:
            section_types_present.append('SQL')
        if etl_total_files > 0:
            section_types_present.append('ETL')
        if job_total_files > 0:
            section_types_present.append('Job')
        
        # If only one section type is present, show only the total
        # If multiple section types are present, show total + breakdowns
        if len(section_types_present) == 1:
            # Only one section type - show total only
            total_note = make_distribution_note("Total", total_complexity_counts, total_files)
            if total_note:
                complexity_notes.append(total_note)
        else:
            # Multiple section types - show total + breakdowns
            total_note = make_distribution_note("Total", total_complexity_counts, total_files)
            if total_note:
                complexity_notes.append(total_note)
            sql_note = make_distribution_note("SQL", sql_complexity_counts, sql_total_files)
            if sql_note:
                complexity_notes.append(sql_note)
            etl_note = make_distribution_note("ETL", etl_complexity_counts, etl_total_files)
            if etl_note:
                complexity_notes.append(etl_note)
            job_note = make_distribution_note("Job", job_complexity_counts, job_total_files)
            if job_note:
                complexity_notes.append(job_note)

        # 2. Other notes (not indented)
        other_notes = []
        if aggregated_data['total_folders'] > 0:
            other_notes.append(f"There are {aggregated_data['total_folders']} unique Informatica folders that can be used for scoping.")
        if aggregated_data['workflow_mapping_ratio'] is not None:
            ratio = aggregated_data['workflow_mapping_ratio']
            workflow_count = aggregated_data['total_workflows']
            mapping_count = aggregated_data['total_mappings']
            if ratio < 0.8:
                other_notes.append(f"Workflow to mapping ratio is {ratio:.2f}:1 ({workflow_count} workflows, {mapping_count} mappings) - Complexity appears to be in Informatica.")
            else:
                other_notes.append(f"Workflow to mapping ratio is {ratio:.2f}:1 ({workflow_count} workflows, {mapping_count} mappings) - Check if there are external orchestrators.")
        if aggregated_data['supported_transformations_count'] > 0:
            other_notes.append(f"There are {aggregated_data['supported_transformations_count']} transformations that can be converted automatedly.")

        # Combine all notes for output
        all_notes = complexity_notes + other_notes
        
        # Display aggregated errors, warnings, and notes
        if all_errors or all_warnings or all_notes:
            # Errors section
            if all_errors:
                story.append(self._create_subsection_header("Errors", colors.red))
                for error in sorted(all_errors):
                    story.append(self._create_error_item("", error))
                story.append(Spacer(1, 4))
            # Warnings section
            if all_warnings:
                story.append(self._create_subsection_header("Warnings", colors.orange))
                for warning in sorted(all_warnings):
                    story.append(self._create_warning_item("", warning))
                story.append(Spacer(1, 4))
            # Notes section
            if all_notes:
                story.append(self._create_subsection_header("Notes", colors.black))
                
                # Handle complexity notes with proper indentation
                if complexity_notes:
                    # Total complexity (not indented)
                    if len(complexity_notes) > 0:
                        story.append(self._create_summary_note_item(complexity_notes[0]))
                    
                    # Breakdown notes (indented)
                    for note in complexity_notes[1:]:
                        story.append(self._create_indented_summary_note_item(note))
                
                # Other notes (not indented)
                for note in other_notes:
                    story.append(self._create_summary_note_item(note))
                
                story.append(Spacer(1, 4))
        # Add success message if no issues
        if not all_errors and not all_warnings and not all_notes:
            success_style = ParagraphStyle(
                'SuccessText',
                fontSize=10,
                spaceAfter=12,
                alignment=0,
                textColor=colors.green
            )
            story.append(Paragraph("✓ All checks passed successfully. No issues detected.", success_style))
        story.append(Spacer(1, 8))
        return story
    
    def _create_warning_item(self, filename: str, message: str) -> Paragraph:
        """Create a warning item with orange color."""
        warning_style = ParagraphStyle(
            'WarningText',
            fontSize=self.FONT_SIZES['body'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            leftIndent=self.INDENTATION['standard'],
            textColor=colors.orange
        )
        return Paragraph(f"! {message}", warning_style)
    
    def _create_error_item(self, filename: str, message: str) -> Paragraph:
        """Create an error item with red color."""
        error_style = ParagraphStyle(
            'ErrorText',
            fontSize=self.FONT_SIZES['body'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            leftIndent=self.INDENTATION['standard'],
            textColor=colors.red
        )
        return Paragraph(f"! {message}", error_style)
    
    def _create_summary_note_item(self, message: str) -> Paragraph:
        """Create a summary note item without filename colon."""
        note_style = ParagraphStyle(
            'SummaryNoteText',
            fontSize=self.FONT_SIZES['body'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            leftIndent=self.INDENTATION['standard'],
            textColor=colors.black
        )
        return Paragraph(f"• {message}", note_style)
    
    def _create_indented_summary_note_item(self, message: str) -> Paragraph:
        """Create an indented summary note item without filename colon."""
        note_style = ParagraphStyle(
            'IndentedSummaryNoteText',
            fontSize=self.FONT_SIZES['body'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            leftIndent=self.INDENTATION['deep'],
            textColor=colors.black
        )
        return Paragraph(f"• {message}", note_style) 