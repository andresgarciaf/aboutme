from typing import List, Dict, Any, Optional
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors


class BaseSection:
    """Base class for all PDF report sections."""
    
    # Standardized font sizes and spacing
    FONT_SIZES = {
        'title': 16,
        'section_header': 14,
        'subsection_header': 12,
        'body': 10,
        'small': 9,
        'table_header': 10,
        'table_body': 9
    }
    
    # Standardized indentation
    INDENTATION = {
        'standard': 12,
        'indented': 24,
        'deep': 36
    }
    
    # Standardized spacing
    SPACING = {
        'small': 2,
        'medium': 4,
        'large': 8,
        'section': 12
    }
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
    
    def _create_section_header(self, title: str) -> List:
        """Create a section header with title and spacing."""
        header_style = ParagraphStyle(
            'SectionHeader',
            fontSize=self.FONT_SIZES['section_header'],
            fontName='Helvetica-Bold',
            spaceAfter=self.SPACING['medium'],
            spaceBefore=self.SPACING['large'],
            textColor=colors.black
        )
        return [
            Paragraph(title, header_style),
            Spacer(1, self.SPACING['small'])
        ]
    
    def _create_status_item(self, text: str, color, font_size: int = 10) -> Paragraph:
        """Create a status item with bullet point and specified color."""
        return Paragraph(f"• {text}", ParagraphStyle(
            'StatusItem',
            parent=self.styles['Normal'],
            textColor=color,
            fontSize=font_size,
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            leftIndent=self.INDENTATION['standard']
        ))
    
    def _create_error_item(self, filename: str, error_msg: str) -> Paragraph:
        """Create an error status item."""
        return self._create_status_item(
            f"{filename}: Analysis failed - {error_msg}",
            colors.red
        )
    
    def _create_information_item(self, filename: str, message: str) -> Paragraph:
        """Create an information status item."""
        return self._create_status_item(f"{filename}: {message}", colors.black)
    
    def _create_indented_item(self, text: str) -> Paragraph:
        """Create an indented item with bullet point in black color (no filename)."""
        return Paragraph(f"   • {text}", ParagraphStyle(
            'IndentedItem',
            parent=self.styles['Normal'],
            textColor=colors.black,
            fontSize=self.FONT_SIZES['body'],
            leftIndent=self.INDENTATION['indented'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small']
        ))
    
    def _create_deep_indented_item(self, text: str) -> Paragraph:
        """Create a deeply indented item with bullet point in black color (no filename)."""
        return Paragraph(f"      • {text}", ParagraphStyle(
            'DeepIndentedItem',
            parent=self.styles['Normal'],
            textColor=colors.black,
            fontSize=self.FONT_SIZES['body'],
            leftIndent=self.INDENTATION['deep'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small']
        ))
    
    def _create_warning_item(self, filename: str, message: str) -> Paragraph:
        """Create a warning status item."""
        return self._create_status_item(f"{filename}: {message}", colors.orange)
    
    def _create_note_item(self, filename: str, message: str) -> Paragraph:
        """Create a note item with black color."""
        return self._create_status_item(f"{filename}: {message}", colors.black)
    
    def _create_indented_note_item(self, filename: str, message: str) -> Paragraph:
        """Create an indented note item."""
        return Paragraph(f"• {message}", ParagraphStyle(
            'IndentedNoteText',
            fontSize=self.FONT_SIZES['body'],
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            leftIndent=self.INDENTATION['deep'],
            textColor=colors.black
        ))
    
    def _create_subsection_header(self, title: str, color: colors.Color = colors.black) -> Paragraph:
        """Create a subsection header with custom color."""
        header_style = ParagraphStyle(
            'SubsectionHeader',
            fontSize=self.FONT_SIZES['subsection_header'],
            fontName='Helvetica-Bold',
            spaceAfter=self.SPACING['medium'],
            spaceBefore=self.SPACING['medium'],
            textColor=color
        )
        return Paragraph(title, header_style)
    
    def _create_filename_header(self, filename: str) -> Paragraph:
        """Create a standardized filename header with bullet point and bold formatting."""
        filename_style = ParagraphStyle(
            'FilenameHeader',
            parent=self.styles['Normal'],
            fontSize=self.FONT_SIZES['body'],
            fontName='Helvetica-Bold',
            spaceAfter=self.SPACING['small'],
            spaceBefore=self.SPACING['small'],
            textColor=colors.black
        )
        return Paragraph(f"• {filename}:", filename_style)
    
    def _get_table_style(self) -> TableStyle:
        """Get the standard table style."""
        return TableStyle([
            # Header styling - make it more visible
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), self.FONT_SIZES['table_header']),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 6),
            # Body styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), self.FONT_SIZES['table_body']),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 1), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
            # Enable text wrapping for all cells
            ('WORDWRAP', (0, 0), (-1, -1), True),
        ])
    
    def _calculate_dynamic_table_sizing(self, table_data: List[List[str]], max_width: float = 7.5*inch) -> tuple[List[float], List[float]]:
        """Calculate dynamic column widths and row heights based on content."""
        if not table_data:
            return [], []
        
        num_cols = len(table_data[0])
        num_rows = len(table_data)
        
        # Estimate character widths for different font types
        header_char_width = 0.08 * inch  # Bold font (Helvetica-Bold, size 10) takes more space
        data_char_width = 0.06 * inch    # Regular font (Helvetica, size 8)
        
        # Calculate column widths based on content
        col_widths = []
        for col_idx in range(num_cols):
            max_col_width = 0
            
            # First, check header row (row 0) with header font characteristics
            if col_idx < len(table_data[0]):
                header_text = str(table_data[0][col_idx])
                header_width = len(header_text) * header_char_width + 0.2 * inch
                max_col_width = max(max_col_width, header_width)
            
            # Then check data rows with data font characteristics
            for row_idx in range(1, num_rows):  # Start from row 1 (skip header)
                if col_idx < len(table_data[row_idx]):
                    cell_text = str(table_data[row_idx][col_idx])
                    data_width = len(cell_text) * data_char_width + 0.2 * inch
                    max_col_width = max(max_col_width, data_width)
            
            # Set minimum and maximum bounds
            min_width = 0.8 * inch
            max_width_per_col = 2.5 * inch
            col_width = max(min_width, min(max_col_width, max_width_per_col))
            col_widths.append(col_width)
        
        # Normalize column widths to fit within max_width
        total_width = sum(col_widths)
        if total_width > max_width:
            scale_factor = max_width / total_width
            col_widths = [width * scale_factor for width in col_widths]
        
        # Calculate row heights based on content
        row_heights = []
        for row_idx in range(num_rows):
            max_row_height = 0.3 * inch  # Minimum row height
            
            for col_idx in range(num_cols):
                if col_idx < len(table_data[row_idx]):
                    cell_text = str(table_data[row_idx][col_idx])
                    # Calculate wrapping for this cell
                    available_width = col_widths[col_idx] - 0.1 * inch  # Account for padding
                    wrapped_lines = self._calculate_text_wrapping(cell_text, available_width)
                    
                    # Estimate height based on number of lines
                    line_height = 0.15 * inch
                    cell_height = wrapped_lines * line_height + 0.1 * inch  # Add padding
                    max_row_height = max(max_row_height, cell_height)
            
            row_heights.append(max_row_height)
        
        return col_widths, row_heights
    
    def _calculate_text_wrapping(self, text: str, available_width: float, font_size: int = 8) -> int:
        """Calculate how many lines text will wrap to based on available width."""
        if not text:
            return 1
        
        # Rough estimation of characters per line
        # This is a simplified calculation - in practice, you might want more sophisticated text measurement
        chars_per_line = int(available_width / (font_size * 0.06))  # Approximate character width
        
        if chars_per_line <= 0:
            return 1
        
        # Count lines needed
        lines = 1
        current_line_length = 0
        
        for char in text:
            if char == '\n':
                lines += 1
                current_line_length = 0
            else:
                current_line_length += 1
                if current_line_length >= chars_per_line:
                    lines += 1
                    current_line_length = 0
        
        return max(1, lines)
    
    def _get_dynamic_table_style(self, row_heights: Optional[List[float]] = None) -> TableStyle:
        """Get dynamic table style with custom row heights."""
        style = [
            # Header styling - make it more visible
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), self.FONT_SIZES['table_header']),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 6),
            # Body styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), self.FONT_SIZES['table_body']),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 1), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
            # Enable text wrapping for all cells
            ('WORDWRAP', (0, 0), (-1, -1), True),
        ]
        
        # Add custom row heights if provided (skip header row 0)
        if row_heights:
            for i, height in enumerate(row_heights):
                if i > 0:  # Skip header row (row 0)
                    style.append(('ROWBACKGROUNDS', (0, i), (-1, i), [colors.beige]))
                style.append(('MINIMUMHEIGHT', (0, i), (-1, i), height))
        
        return TableStyle(style) 