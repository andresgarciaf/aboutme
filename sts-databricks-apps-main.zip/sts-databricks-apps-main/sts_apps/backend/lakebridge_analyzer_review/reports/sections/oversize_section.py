from typing import List, Dict, Any, Union
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from .base_section import BaseSection
from ..utils.table_utils import create_dynamic_table


class OversizeSection(BaseSection):
    """Section for oversize file analysis results."""
    
    def create_section(self, oversize_file_results: List[Dict[str, Any]]) -> List:
        """Create the oversize file analysis section."""
        story = self._create_section_header("Oversize File Analysis")
        
        # Group results by filename
        files_by_name = {}
        for result in oversize_file_results:
            filename = result['filename']
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Sort results: errors first, then warnings (oversize files), then successes
            sorted_results = []
            for result in file_results:
                if not result.get('success', False):
                    sorted_results.append(('error', result))
                elif result.get('oversize_files_count', 0) > 0:
                    sorted_results.append(('warning', result))
                else:
                    sorted_results.append(('success', result))
            
            # Sort by priority: error -> warning -> success
            priority_order = {'error': 0, 'warning': 1, 'success': 2}
            sorted_results.sort(key=lambda x: priority_order[x[0]])
            
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result_type, result in sorted_results:
                if result.get('success', False):
                    oversize_count = result['oversize_files_count']
                    percentage = result['percentage']
                    
                    if oversize_count == 0:
                        story.append(self._create_indented_item("No oversize files found"))
                    else:
                        if percentage > 1.0 or oversize_count > 1:
                            message = f"{oversize_count} oversize files found ({percentage:.1f}%) - Split files by object"
                        else:
                            message = f"{oversize_count} oversize file found - Split file by object"
                        story.append(self._create_indented_item(message))
                    
                    # Add detailed table if there are oversize files
                    if oversize_count > 0 and 'oversize_files' in result:
                        story.append(Spacer(1, 2))  # Add space before indented items
                        story.extend(self._create_oversize_details(result['oversize_files']))
                else:
                    error_msg = f"Error: {result.get('error', 'Unknown error')}"
                    story.append(self._create_indented_item(error_msg))
            
            story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 4))
        return story
    
    def _create_oversize_details(self, oversize_files: List[Dict[str, Any]]) -> List:
        """Create detailed table of oversize files."""
        story = []
        
        if not oversize_files:
            return story
        
        # Create table data with 'Row' as the first column
        table_data: List[List[Union[str, Paragraph]]] = [['Row', 'Program Name', 'Procedure/Function Count']]
        
        for file_info in oversize_files:
            program_name = file_info.get('program_name', 'Unknown')
            
            # Create a Paragraph for the program name to handle long text properly
            program_style = ParagraphStyle(
                'CellText',
                fontSize=8,
                fontName='Helvetica',
                alignment=0,  # Left align
                spaceAfter=0,
                spaceBefore=0,
                leftIndent=0,
                rightIndent=0,
                firstLineIndent=0,
                wordWrap='CJK'  # Better word wrapping
            )
            
            program_paragraph = Paragraph(program_name, program_style)
            
            table_data.append([
                str(file_info.get('row', 'Unknown')),
                program_paragraph,
                str(file_info.get('value', 0))
            ])
        
        # Create table with custom style for program name column wrapping
        from reportlab.platypus import Table
        from reportlab.lib.units import inch
        
        # Calculate column widths - make program name column wider and count column fit header
        col_widths = [0.8*inch, 3.2*inch, 2.0*inch]  # Row, Program Name, Count
        
        # Create table
        table = Table(table_data, colWidths=col_widths)
        
        # Apply custom style with word wrapping for program name column only
        from reportlab.lib import colors
        style = [
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 6),
            # Body styling
            ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 1), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
            # Left align and word wrap Program Name column (column 1)
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('WORDWRAP', (1, 0), (1, -1), True),
        ]
        
        table.setStyle(style)
        
        story.append(Spacer(1, 4))
        story.append(table)
        story.append(Spacer(1, 4))
        
        return story 