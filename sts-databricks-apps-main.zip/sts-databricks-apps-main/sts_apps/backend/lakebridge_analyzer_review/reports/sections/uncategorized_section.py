from typing import List, Dict, Any
from reportlab.platypus import Spacer, Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from .base_section import BaseSection
from ..utils.table_utils import create_dynamic_table


class UncategorizedSection(BaseSection):
    """Section for uncategorized file analysis results."""
    
    def create_section(self, uncategorized_results: List[Dict[str, Any]]) -> List:
        """Create the uncategorized files analysis section (no table, just summary/status)."""
        story = self._create_section_header("Uncategorized Files Analysis")
        
        # Group results by file
        file_results = {}
        for result in uncategorized_results:
            filename = result.get('filename', 'Unknown')
            if filename not in file_results:
                file_results[filename] = []
            file_results[filename].append(result)
        
        # Process each file
        for filename, results in file_results.items():
            # Check if any result has errors
            has_errors = any(not result.get('success', False) for result in results)
            
            if has_errors:
                # Show error for this file
                for result in results:
                    if not result.get('success', False):
                        story.append(self._create_error_item(filename, result.get('error', 'Unknown error')))
                        story.append(Spacer(1, 4))
            else:
                # Show warnings for this file
                file_warnings = []
                
                for result in results:
                    if result.get('success', False):
                        uncategorized_count = result['uncategorized_files_count']
                        total_files = result['total_rows']
                        percentage = (uncategorized_count / total_files * 100) if total_files > 0 else 0
                        has_unknown_sheet_values = result.get('has_unknown_sheet_values', False)
                        
                        if uncategorized_count > 0:
                            message = f"{uncategorized_count} uncategorized files found ({percentage:.1f}% of {total_files} total files) - Find these files in the SQL Programs sheet by filtering for rows with only UNKNOWN in the Script Category column."
                            file_warnings.append(message)
                            file_warnings.append("Review the UNKNOWN SQL Category sheet to confirm important logic are not uncategorized.")
                        elif has_unknown_sheet_values:
                            file_warnings.append("Review the UNKNOWN SQL Category sheet to confirm important logic are not uncategorized.")
                
                # Add file header and warnings
                if file_warnings:
                    story.append(self._create_filename_header(filename))
                    for warning in file_warnings:
                        story.append(self._create_indented_item(warning))
                    story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 6))
        return story
    
 