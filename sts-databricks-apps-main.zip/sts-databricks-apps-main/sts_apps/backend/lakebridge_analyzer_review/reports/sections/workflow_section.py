from typing import List, Dict, Any
from reportlab.platypus import Spacer, Table
from reportlab.lib.units import inch
from reportlab.lib import colors
from .base_section import BaseSection


class WorkflowSection(BaseSection):
    """Section for workflow mapping analysis results."""
    
    def create_section(self, workflow_mapping_results: List[Dict[str, Any]]) -> List:
        """Create the workflow to mapping ratio analysis section."""
        story = self._create_section_header("Workflow to Mapping Ratio Analysis")
        
        # Group results by filename
        files_by_name = {}
        for result in workflow_mapping_results:
            filename = result['filename']
            if filename not in files_by_name:
                files_by_name[filename] = []
            files_by_name[filename].append(result)
        
        # Process each file
        for filename, file_results in files_by_name.items():
            # Sort results: errors first, then warnings (high ratio), then successes
            sorted_results = []
            for result in file_results:
                if not result.get('success', False):
                    sorted_results.append(('error', result))
                elif result.get('workflow_mapping_ratio', 0) > 1.0:
                    sorted_results.append(('warning', result))
                else:
                    sorted_results.append(('success', result))
            
            # Sort by priority: error -> warning -> success
            priority_order = {'error': 0, 'warning': 1, 'success': 2}
            sorted_results.sort(key=lambda x: priority_order[x[0]])
            
            # Create filename header with bullet point
            story.append(self._create_filename_header(filename))
            
            # Process each result for this file
            for result_type, result in sorted_results:
                if result.get('success', False):
                    workflow_count = result['total_workflows']
                    mapping_count = result['total_mappings']
                    ratio = result['workflow_mapping_ratio']
                    
                    if workflow_count == 0 and mapping_count == 0:
                        story.append(self._create_indented_item("No workflows or mappings found"))
                    elif ratio >= 0.8:
                        message = f"Workflow to mapping ratio is {ratio:.2f} ({workflow_count} workflows, {mapping_count} mappings) - Ask about external orchestrators. Complexity might be in an external tool."
                        story.append(self._create_indented_item(message))
                    else:
                        message = f"Workflow to mapping ratio is {ratio:.2f} ({workflow_count} workflows, {mapping_count} mappings) - The complexity appears to be within Informatica."
                        story.append(self._create_indented_item(message))
                else:
                    error_msg = f"Error: {result.get('error', 'Unknown error')}"
                    story.append(self._create_indented_item(error_msg))
            
            story.append(Spacer(1, 4))
        
        story.append(Spacer(1, 6))
        return story 