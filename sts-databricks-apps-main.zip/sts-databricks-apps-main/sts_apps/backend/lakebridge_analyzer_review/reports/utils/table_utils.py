from typing import List, Dict, Any, Optional, Union
from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib.units import inch
from reportlab.lib import colors


def create_dynamic_table(table_data: List[List[Union[str, Paragraph]]], max_width: float = 7.5*inch) -> Table:
    """Create a table with dynamic column widths and row heights."""
    if not table_data:
        return Table([[]])
    
    # Calculate dynamic sizing
    col_widths, row_heights = calculate_dynamic_table_sizing(table_data, max_width)
    
    # Create table
    table = Table(table_data, colWidths=col_widths, rowHeights=row_heights)
    table.setStyle(get_dynamic_table_style(row_heights))
    
    return table


def calculate_dynamic_table_sizing(table_data: List[List[Union[str, Paragraph]]], max_width: float = 7.5*inch) -> tuple[List[float], List[float]]:
    """Calculate dynamic column widths and row heights based on content."""
    if not table_data:
        return [], []
    
    num_cols = len(table_data[0])
    num_rows = len(table_data)
    
    # Estimate character widths for different font types
    header_char_width = 0.08 * inch  # Bold font (Helvetica-Bold, size 10) takes more space
    data_char_width = 0.06 * inch    # Regular font (Helvetica, size 8)
    
    # Calculate column widths based on content
    col_widths = []
    for col_idx in range(num_cols):
        max_col_width = 0
        
        # First, check header row (row 0) with header font characteristics
        if col_idx < len(table_data[0]):
            header_cell = table_data[0][col_idx]
            header_text = str(header_cell) if isinstance(header_cell, str) else str(header_cell.text)
            # Use minimal padding for first column (Row), more padding for others
            padding = 0.05 * inch if col_idx == 0 else 0.2 * inch
            header_width = len(header_text) * header_char_width + padding
            max_col_width = max(max_col_width, header_width)
        
        # Then check data rows with data font characteristics
        for row_idx in range(1, num_rows):  # Start from row 1 (skip header)
            if col_idx < len(table_data[row_idx]):
                cell_content = table_data[row_idx][col_idx]
                cell_text = str(cell_content) if isinstance(cell_content, str) else str(cell_content.text)
                # Use minimal padding for first column (Row), more padding for others
                padding = 0.05 * inch if col_idx == 0 else 0.2 * inch
                data_width = len(cell_text) * data_char_width + padding
                max_col_width = max(max_col_width, data_width)
        
        # Set minimum and maximum bounds with special handling for first column
        if col_idx == 0:
            # Very narrow minimum for Row column
            min_width = 0.4 * inch
            max_width_per_col = 1.0 * inch
        else:
            min_width = 0.8 * inch
            max_width_per_col = 2.5 * inch
        
        col_width = max(min_width, min(max_col_width, max_width_per_col))
        col_widths.append(col_width)
    
    # Normalize column widths to fit within max_width
    total_width = sum(col_widths)
    if total_width > max_width:
        scale_factor = max_width / total_width
        col_widths = [width * scale_factor for width in col_widths]
    
    # Calculate row heights based on content
    row_heights = []
    for row_idx in range(num_rows):
        max_row_height = 0.3 * inch  # Minimum row height
        
        for col_idx in range(num_cols):
            if col_idx < len(table_data[row_idx]):
                cell_content = table_data[row_idx][col_idx]
                cell_text = str(cell_content) if isinstance(cell_content, str) else str(cell_content.text)
                # Calculate wrapping for this cell
                available_width = col_widths[col_idx] - 0.1 * inch  # Account for padding
                wrapped_lines = calculate_text_wrapping(cell_text, available_width)
                
                # Estimate height based on number of lines
                line_height = 0.15 * inch
                cell_height = wrapped_lines * line_height + 0.1 * inch  # Add padding
                max_row_height = max(max_row_height, cell_height)
        
        row_heights.append(max_row_height)
    
    return col_widths, row_heights


def calculate_text_wrapping(text: str, available_width: float, font_size: int = 8) -> int:
    """Calculate how many lines text will wrap to based on available width."""
    if not text:
        return 1
    
    # Rough estimation of characters per line
    # This is a simplified calculation - in practice, you might want more sophisticated text measurement
    chars_per_line = int(available_width / (font_size * 0.06))  # Approximate character width
    
    if chars_per_line <= 0:
        return 1
    
    # Count lines needed
    lines = 1
    current_line_length = 0
    
    for char in text:
        if char == '\n':
            lines += 1
            current_line_length = 0
        else:
            current_line_length += 1
            if current_line_length >= chars_per_line:
                lines += 1
                current_line_length = 0
    
    return max(1, lines)


def get_dynamic_table_style(row_heights: Optional[List[float]] = None) -> TableStyle:
    """Get dynamic table style with custom row heights. Header is always dark blue, body is light grey."""
    style = [
        # Header styling
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('TOPPADDING', (0, 0), (-1, 0), 6),
        # Body styling (do NOT override header)
        ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 1), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
        # Enable text wrapping for all cells
        ('WORDWRAP', (0, 0), (-1, -1), True),
    ]
    
    # Add custom row heights if provided (skip header row 0)
    if row_heights:
        for i, height in enumerate(row_heights):
            if i > 0:  # Skip header row (row 0)
                style.append(('ROWBACKGROUNDS', (0, i), (-1, i), [colors.lightgrey]))
            style.append(('MINIMUMHEIGHT', (0, i), (-1, i), height))
    
    return TableStyle(style)


def get_standard_table_style() -> TableStyle:
    """Get the standard table style."""
    return TableStyle([
        # Header styling - make it more visible
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkslategray),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('TOPPADDING', (0, 0), (-1, 0), 6),
        # Body styling
        ('BACKGROUND', (0, 1), (-1, -1), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 1), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 4),
        # Enable text wrapping for all cells
        ('WORDWRAP', (0, 0), (-1, -1), True),
    ]) 