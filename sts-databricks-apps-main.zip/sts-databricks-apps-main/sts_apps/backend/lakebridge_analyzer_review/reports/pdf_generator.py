import tempfile
import os
from datetime import datetime
from typing import List, Dict, Any
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from backend.logger import get_logger

# Import section classes
from .sections.summary_section import SummarySection
from .sections.version_section import VersionSection
from .sections.oversize_section import OversizeSection
from .sections.duplicate_section import DuplicateSection
from .sections.uncategorized_section import UncategorizedSection
from .sections.workflow_section import WorkflowSection
from .sections.folder_section import FolderSection
from .sections.sql_complexity_section import SQLComplexitySection
from .sections.unsupported_transformations_section import UnsupportedTransformationsSection


class PDFGenerator:
    """
    Generate PDF reports for Lakebridge Analyzer results using modular sections.
    """
    
    def __init__(self):
        self.logger = get_logger()
        self.styles = getSampleStyleSheet()
        
        # Initialize section handlers
        self.summary_section = SummarySection()
        self.version_section = VersionSection()
        self.oversize_section = OversizeSection()
        self.duplicate_section = DuplicateSection()
        self.uncategorized_section = UncategorizedSection()
        self.workflow_section = WorkflowSection()
        self.folder_section = FolderSection()
        self.sql_complexity_section = SQLComplexitySection()
        self.unsupported_transformations_section = UnsupportedTransformationsSection()
    
    def generate_report(self, oversize_file_results: List[Dict[str, Any]], 
                       version_results: List[Dict[str, Any]], 
                       duplicate_name_results: List[Dict[str, Any]],
                       workflow_mapping_results: List[Dict[str, Any]] = [],
                       folder_analysis_results: List[Dict[str, Any]] = [],
                       uncategorized_results: List[Dict[str, Any]] = [],
                       sql_complexity_results: List[Dict[str, Any]] = [],
                       etl_complexity_results: List[Dict[str, Any]] = [],
                       job_complexity_results: List[Dict[str, Any]] = [],
                       unsupported_transformations_results: List[Dict[str, Any]] = []) -> str:
        """
        Generate a comprehensive PDF report with analysis results from multiple files.
        
        Args:
            oversize_file_results: List of oversize file analysis results for each file
            version_results: List of version check results for each file
            duplicate_name_results: List of duplicate program name analysis results for each file
            workflow_mapping_results: List of workflow mapping analysis results for each file
            folder_analysis_results: List of folder analysis results for each file
            uncategorized_results: List of uncategorized file analysis results for each file
            
        Returns:
            Path to the generated PDF file
        """
        self.logger.debug(f"Generating PDF report for {len(oversize_file_results)} analysis results")
        
        # Create temporary PDF file
        temp_pdf_path = self._create_pdf_file()
        
        # Create PDF document
        doc = SimpleDocTemplate(temp_pdf_path, pagesize=letter)
        story = []
        
        # Add title and date
        story.extend(self._create_header(datetime.now().strftime("%Y-%m-%d")))
        
        # Collect all results for summary
        all_results = []
        all_results.extend(version_results)
        all_results.extend(oversize_file_results)
        all_results.extend(duplicate_name_results)
        all_results.extend(uncategorized_results)
        all_results.extend(workflow_mapping_results)
        all_results.extend(folder_analysis_results)
        all_results.extend(sql_complexity_results)
        all_results.extend(etl_complexity_results)
        all_results.extend(job_complexity_results)
        all_results.extend(unsupported_transformations_results)
        
        # Add summary section first
        if all_results:
            story.extend(self.summary_section.create_section(all_results))
        
        # Add Details section header
        details_header_style = ParagraphStyle(
            'DetailsHeader',
            fontSize=14,
            fontName='Helvetica-Bold',
            spaceAfter=8,
            spaceBefore=12,
            alignment=1,  # Center alignment
            textColor=colors.black
        )
        story.append(Paragraph("Details", details_header_style))
        
        # Define sections to process with their handlers
        sections = [
            (version_results, self.version_section),
            (oversize_file_results, self.oversize_section),
            (duplicate_name_results, self.duplicate_section),
            (uncategorized_results, self.uncategorized_section),
            (sql_complexity_results, self.sql_complexity_section),
            (workflow_mapping_results, self.workflow_section),
            (folder_analysis_results, self.folder_section),
            (unsupported_transformations_results, self.unsupported_transformations_section)
        ]
        
        # Add sections with results
        for results, section_handler in sections:
            if results:
                story.extend(section_handler.create_section(results))
        
        # Build PDF
        doc.build(story)
        
        # Rename the temporary file to the final filename
        pdf_dir = os.path.dirname(temp_pdf_path)
        pdf_path = os.path.join(pdf_dir, "temp_report.pdf")
        if os.path.exists(temp_pdf_path):
            os.rename(temp_pdf_path, pdf_path)
            self.logger.debug(f"Renamed temporary file to: {pdf_path}")
        
        return pdf_path
    
    def _create_pdf_file(self) -> str:
        """Create and return path to temporary PDF file."""
        pdf_file = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf', prefix='temp_')
        temp_pdf_path = pdf_file.name
        pdf_file.close()
        
        # Create the final PDF path
        pdf_dir = os.path.dirname(temp_pdf_path)
        pdf_path = os.path.join(pdf_dir, "temp_report.pdf")
        
        self.logger.debug(f"Created temporary PDF file: {temp_pdf_path}")
        self.logger.debug(f"Final PDF path will be: {pdf_path}")
        
        return pdf_path
    
    def _create_header(self, current_date: str) -> List:
        """Create the report header with title and date."""
        story = []
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            fontSize=16,
            fontName='Helvetica-Bold',
            spaceAfter=8,
            spaceBefore=12,
            alignment=1,
            textColor=colors.black
        )
        story.append(Paragraph("Lakebridge Analyzer Review", title_style))
        
        # Date
        date_style = ParagraphStyle(
            'DateStyle',
            fontSize=10,
            spaceAfter=12,
            alignment=1,
            textColor=colors.grey
        )
        story.append(Paragraph(f"Date Reviewed: {current_date}", date_style))
        
        return story 