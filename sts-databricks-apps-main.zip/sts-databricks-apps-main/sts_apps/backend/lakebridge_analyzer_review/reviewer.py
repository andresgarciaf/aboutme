from typing import List, Dict, Any
from backend.logger import get_logger
from .checks.oversize_check import OversizeCheck
from .checks.version_check import VersionCheck
from .checks.duplicate_check import DuplicateCheck
from .checks.workflow_mapping_check import WorkflowMappingCheck
from .checks.folder_analysis_check import FolderAnalysisCheck
from .checks.uncategorized_check import UncatagorizedCheck
from .checks.sql_complexity_check import SQLComplexityCheck
from .checks.etl_complexity_check import ETLComplexityCheck
from .checks.job_complexity_check import JobComplexityCheck
from .checks.unsupported_transformations_check import UnsupportedTransformationsCheck
from .reports.pdf_generator import PDFGenerator
import openpyxl


class LakebridgeReviewer:
    """
    Main reviewer class that orchestrates all checks and generates reports.
    """
    
    def __init__(self):
        self.logger = get_logger()
        self.oversize_check = OversizeCheck()
        self.version_check = VersionCheck()
        self.duplicate_check = DuplicateCheck()
        self.workflow_mapping_check = WorkflowMappingCheck()
        self.folder_analysis_check = FolderAnalysisCheck()
        self.uncategorized_check = UncatagorizedCheck()
        self.sql_complexity_check = SQLComplexityCheck()
        self.etl_complexity_check = ETLComplexityCheck()
        self.job_complexity_check = JobComplexityCheck()
        self.unsupported_transformations_check = UnsupportedTransformationsCheck()
        self.pdf_generator = PDFGenerator()
        
        # Simple configuration for which checks apply to each file type
        self.file_type_checks = {
            'SQL': ['version', 'duplicate', 'oversize', 'uncategorized', 'sql_complexity', 'etl_complexity'],
            'INFA': ['version', 'workflow_mapping', 'folder_analysis', 'job_complexity', 'unsupported_transformations'],
            'INFADEV': ['version', 'workflow_mapping', 'folder_analysis', 'job_complexity', 'unsupported_transformations'],
            'INFACLOUD': ['version', 'workflow_mapping', 'folder_analysis', 'job_complexity', 'unsupported_transformations'],
            # Easy to add more file types:
            # 'PYTHON': ['version', 'oversize'],
            # 'JAVA': ['version', 'duplicate'],
            # 'SCALA': ['version', 'oversize'],
        }

    def _get_file_type(self, file_path: str, original_filename: str = "") -> str:
        """Read F9 or F10 from Summary sheet to determine file type."""
        try:
            workbook = openpyxl.load_workbook(file_path)
            if 'Summary' not in workbook.sheetnames:
                self.logger.error(f"Summary sheet not found in {original_filename}")
                return 'SQL'  # Default to SQL
            
            sheet = workbook['Summary']
            
            # Check F10 first, then F9 as fallback
            f10_value = sheet['F10'].value
            f9_value = sheet['F9'].value
            
            # Determine which cell to use
            if f10_value and str(f10_value).strip():
                # F10 has a value, use it
                file_type = str(f10_value).strip().upper()
                self.logger.info(f"Using F10 value '{file_type}' for {original_filename}")
            elif f9_value and str(f9_value).strip():
                # F10 is empty but F9 has a value, use F9
                file_type = str(f9_value).strip().upper()
                self.logger.info(f"Using F9 value '{file_type}' for {original_filename}")
            else:
                # Both cells are empty
                self.logger.warning(f"Both F9 and F10 are empty in {original_filename}, defaulting to SQL")
                return 'SQL'
            
            self.logger.info(f"Detected file type '{file_type}' for {original_filename}")
            return file_type
            
        except Exception as e:
            self.logger.error(f"Error reading F9/F10 from {original_filename}: {str(e)}")
            return 'SQL'  # Default to SQL

    def review_multiple_files(self, file_paths: List[str], original_filenames: List[str] = []) -> str:
        """
        Review multiple XLSX files and generate a comprehensive PDF report.
        
        Args:
            file_paths: List of paths to XLSX files
            original_filenames: List of original filenames from upload
            
        Returns:
            Path to the generated PDF file
        """
        self.logger.info(f"Starting review of {len(file_paths)} files")
    
        oversize_file_results = []
        version_results = []
        duplicate_name_results = []
        workflow_mapping_results = []
        folder_analysis_results = []
        uncategorized_results = []
        sql_complexity_results = []
        etl_complexity_results = []
        job_complexity_results = []
        unsupported_transformations_results = []
    
        for i, file_path in enumerate(file_paths):
            original_filename = original_filenames[i] if original_filenames and i < len(original_filenames) else ""
            self.logger.debug(f"Processing file {i+1}/{len(file_paths)}: {original_filename}")
        
            # Determine file type from F9
            file_type = self._get_file_type(file_path, original_filename)
            applicable_checks = self.file_type_checks.get(file_type, self.file_type_checks['SQL'])
            
            self.logger.info(f"File type: {file_type}, Applicable checks: {applicable_checks}")
        
            # Run applicable checks only
            if 'version' in applicable_checks:
                version_result = self.version_check.check(file_path, original_filename)
                version_results.append(version_result)
            
            if 'duplicate' in applicable_checks:
                duplicate_result = self.duplicate_check.check(file_path, original_filename)
                duplicate_name_results.append(duplicate_result)
            
            if 'oversize' in applicable_checks:
                oversize_result = self.oversize_check.check(file_path, original_filename)
                oversize_file_results.append(oversize_result)
            
            if 'uncategorized' in applicable_checks:
                uncategorized_result = self.uncategorized_check.check(file_path, original_filename)
                uncategorized_results.append(uncategorized_result)
            
            if 'sql_complexity' in applicable_checks:
                sql_complexity_result = self.sql_complexity_check.check(file_path, original_filename)
                sql_complexity_results.append(sql_complexity_result)
            
            if 'etl_complexity' in applicable_checks:
                etl_complexity_result = self.etl_complexity_check.check(file_path, original_filename)
                etl_complexity_results.append(etl_complexity_result)
            
            if 'job_complexity' in applicable_checks:
                job_complexity_result = self.job_complexity_check.check(file_path, original_filename)
                job_complexity_results.append(job_complexity_result)
            
            if 'workflow_mapping' in applicable_checks:
                workflow_mapping_result = self.workflow_mapping_check.check(file_path, original_filename)
                workflow_mapping_results.append(workflow_mapping_result)
            
            if 'folder_analysis' in applicable_checks:
                folder_analysis_result = self.folder_analysis_check.check(file_path, original_filename)
                folder_analysis_results.append(folder_analysis_result)
            
            if 'unsupported_transformations' in applicable_checks:
                unsupported_transformations_result = self.unsupported_transformations_check.check(file_path, original_filename)
                unsupported_transformations_results.append(unsupported_transformations_result)
        
        # Generate PDF report
        self.logger.info("Generating comprehensive PDF report")
        pdf_path = self.pdf_generator.generate_report(oversize_file_results, version_results, duplicate_name_results, workflow_mapping_results, folder_analysis_results, uncategorized_results, sql_complexity_results, etl_complexity_results, job_complexity_results, unsupported_transformations_results)
        self.logger.info(f"PDF report generated successfully: {pdf_path}")
    
        return pdf_path 