import re
from typing import Dict, Any
from .base_check import BaseCheck
from ..utils.version_utils import compare_versions


class VersionCheck(BaseCheck):
    """
    Check the analyzer version from the summary sheet.
    """
    
    def __init__(self, required_version: str = "5.6.4"):
        super().__init__()
        self.required_version = required_version
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Check the analyzer version from the summary sheet in an XLSX file.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing version check results
        """
        self.logger.info(f"Starting version check for file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get Summary sheet
        sheet = self.get_sheet(workbook, 'Summary', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Summary sheet not found")
        
        try:
            # Check cells E1:F1 for the analyzer version
            e1_value = sheet['E1'].value
            f1_value = sheet['F1'].value
            
            self.logger.debug(f"E1 value: {e1_value}")
            self.logger.debug(f"F1 value: {f1_value}")
            
            # Look for "Analyzer Version:" in either E1 or F1
            version_str = None
            if e1_value and isinstance(e1_value, str) and 'Analyzer Version:' in e1_value:
                version_str = e1_value
            elif f1_value and isinstance(f1_value, str) and 'Analyzer Version:' in f1_value:
                version_str = f1_value
            
            if not version_str:
                return self.create_error_result(original_filename, "Analyzer Version not found in E1:F1")
            
            # Parse the version number from "Analyzer Version: X.X.X Build YYYYMMDD"
            version_match = re.search(r'Analyzer Version:\s*(\d+\.\d+\.\d+)', version_str)
            if not version_match:
                return self.create_error_result(original_filename, f"Could not parse version number from: {version_str}")
            
            version_number = version_match.group(1)
            self.logger.debug(f"Parsed version number: {version_number}")
            
            # Compare version numbers
            is_old_version = compare_versions(version_number, self.required_version) < 0
            
            self.logger.info(f"Version check complete for {original_filename or file_path}: "
                           f"Version: {version_number}, Required: {self.required_version}, Is old: {is_old_version}")
            
            return self.create_success_result(
                filename=original_filename,
                version_number=version_number,
                is_old_version=is_old_version
            )
            
        except Exception as e:
            self.logger.error(f"Error checking version for file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e)) 