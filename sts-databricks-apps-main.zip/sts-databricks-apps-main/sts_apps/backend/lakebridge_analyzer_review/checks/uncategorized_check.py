from typing import Dict, Any
from .base_check import BaseCheck


class UncatagorizedCheck(BaseCheck):
    """
    Check for uncategorized SQL files (Script Category is exactly "UNKNOWN").
    """
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze an XLSX file to find uncategorized files (Script Category = "UNKNOWN").
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing analysis results
        """
        self.logger.info(f"Starting uncategorized analysis of file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get SQL Programs sheet
        sheet = self.get_sheet(workbook, 'SQL Programs', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Sheet 'SQL Programs' not found in the Excel file")
        
        try:
            # Find uncategorized files (Script Category = "UNKNOWN")
            uncategorized_files = []
            
            for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
                if len(row) >= 8:  # Ensure we have at least 8 columns (A-H)
                    script_category = row[7]  # Column H (0-indexed, so 7)
                    program_name = row[0] if len(row) > 0 else 'Unknown'
                    line_count = row[3] if len(row) > 3 else 'N/A'  # Column D
                    
                    # Check if Script Category is exactly "UNKNOWN" (not "UNKNOWN,READ_DML" etc.)
                    if script_category == "UNKNOWN":
                        uncategorized_files.append({
                            'row': row_num,
                            'program_name': str(program_name).strip(),
                            'line_count': line_count
                        })
            
            # Check for UNKNOWN SQL Category sheet
            unknown_sheet = self.get_sheet(workbook, 'UNKNOWN SQL Category', original_filename)
            has_unknown_sheet_values = False
            
            # Only check UNKNOWN sheet if no uncategorized files found in SQL Programs
            if len(uncategorized_files) == 0 and unknown_sheet:
                # Check if the sheet has any data beyond header
                rows = list(unknown_sheet.iter_rows(min_row=2, values_only=True))
                has_unknown_sheet_values = any(any(cell is not None and str(cell).strip() != '' for cell in row) for row in rows)
            
            # Calculate statistics
            total_rows = len(list(sheet.iter_rows(min_row=2, values_only=True)))
            uncategorized_count = len(uncategorized_files)
            
            self.logger.info(f"Uncategorized analysis complete for {original_filename or file_path}: "
                           f"{uncategorized_count} uncategorized files found out of {total_rows} total rows")
            
            return self.create_success_result(
                filename=original_filename,
                total_rows=total_rows,
                uncategorized_files_count=uncategorized_count,
                uncategorized_files=uncategorized_files,
                has_unknown_sheet_values=has_unknown_sheet_values
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing uncategorized files in {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e)) 