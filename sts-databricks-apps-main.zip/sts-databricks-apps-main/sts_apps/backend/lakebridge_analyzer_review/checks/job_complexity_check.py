import openpyxl
from typing import Dict, Any, List
from .base_check import BaseCheck


class JobComplexityCheck(BaseCheck):
    """
    Job complexity check that analyzes INFA, INFADEV, INFACLOUD files by counting mappings by complexity level.
    """
    
    def __init__(self):
        """Initialize the job complexity check."""
        super().__init__()
        self.check_name = "job_complexity"
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze job complexity from Mapping Details sheet by counting mappings by complexity level.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing job complexity analysis results
        """
        self.logger.info(f"Starting job complexity analysis of file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get Mapping Details sheet for analysis
        mapping_sheet = self.get_sheet(workbook, 'Mapping Details', original_filename)
        if not mapping_sheet:
            return self.create_error_result(original_filename, "Sheet 'Mapping Details' not found in the Excel file")
        
        try:
            # Count mappings by complexity level
            low_count = 0
            medium_count = 0
            complex_count = 0
            very_complex_count = 0
            
            # Get detailed information for complex and very complex mappings
            complex_mappings = []
            very_complex_mappings = []
            
            # Column F is Categorization (6th column, index 5)
            for row_num, row in enumerate(mapping_sheet.iter_rows(min_row=2, values_only=True), start=2):
                if len(row) > 5:  # Ensure we have enough columns
                    categorization = row[5] if len(row) > 5 else None  # Column F (Categorization)
                    mapping_name = row[0] if len(row) > 0 else f"Row {row_num}"  # Column A (Mapping Name)
                    folder = row[1] if len(row) > 1 else "Unknown"  # Column B (Folder)
                    
                    if categorization:
                        categorization_str = str(categorization).strip().lower()
                        
                        if categorization_str == 'low':
                            low_count += 1
                        elif categorization_str == 'medium':
                            medium_count += 1
                        elif categorization_str == 'complex':
                            complex_count += 1
                            complex_mappings.append({
                                'row': row_num,
                                'mapping_name': str(mapping_name).strip() if mapping_name else f"Row {row_num}",
                                'folder': str(folder).strip() if folder else "Unknown"
                            })
                        elif categorization_str == 'very complex':
                            very_complex_count += 1
                            very_complex_mappings.append({
                                'row': row_num,
                                'mapping_name': str(mapping_name).strip() if mapping_name else f"Row {row_num}",
                                'folder': str(folder).strip() if folder else "Unknown"
                            })
            
            # Calculate total
            total_count = low_count + medium_count + complex_count + very_complex_count
            
            # Calculate percentages
            percentages = {}
            if total_count > 0:
                percentages = {
                    'low': (low_count / total_count) * 100,
                    'medium': (medium_count / total_count) * 100,
                    'complex': (complex_count / total_count) * 100,
                    'very_complex': (very_complex_count / total_count) * 100
                }
            else:
                percentages = {'low': 0, 'medium': 0, 'complex': 0, 'very_complex': 0}
            
            # Check if there are complex or very complex mappings
            has_complex_mappings = complex_count > 0 or very_complex_count > 0
            
            self.logger.info(f"Job complexity analysis complete for {original_filename or file_path}: "
                           f"Total mappings: {total_count}, Complex: {complex_count}, Very Complex: {very_complex_count}")
            
            return self.create_success_result(
                filename=original_filename,
                total_files=total_count,
                complexity_counts={
                    'low': low_count,
                    'medium': medium_count,
                    'complex': complex_count,
                    'very_complex': very_complex_count
                },
                percentages=percentages,
                has_complex_files=has_complex_mappings,
                complex_files=complex_mappings,
                very_complex_files=very_complex_mappings,
                script_type='JOB'
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing job complexity in file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e)) 