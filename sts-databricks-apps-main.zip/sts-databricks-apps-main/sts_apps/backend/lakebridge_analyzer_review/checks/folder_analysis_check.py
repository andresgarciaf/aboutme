from typing import Dict, Any, List, Tuple
from collections import defaultdict
from .base_check import BaseCheck


class FolderAnalysisCheck(BaseCheck):
    """
    Check for INFA, INFADEV, INFACLOUD files to analyze mapping details by folder.
    """
    
    # Categorization complexity scores for sorting
    CATEGORIZATION_SCORES = {
        'low': 1, 'medium': 2, 'complex': 3, 'very complex': 4
    }
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze an INFA XLSX file to check mapping details by folder.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing analysis results
        """
        self.logger.info(f"Starting INFA mapping details analysis of file: {original_filename or file_path}")
        
        # Load Excel file (will use calculated values by default)
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get Mapping Details sheet
        sheet = self.get_sheet(workbook, 'Mapping Details', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Sheet 'Mapping Details' not found in the Excel file")
        
        try:
            # Analyze the data starting from row 2 (assuming row 1 is header)
            folder_analysis = self._analyze_mapping_details(sheet)
            
            if not folder_analysis:
                return self.create_error_result(original_filename, "No valid data found in Mapping Details sheet")
            
            # Sort folders by complexity (lowest total nodes first)
            sorted_folders = self._sort_folders_by_complexity(folder_analysis)
            
            # Format results for report
            formatted_results = self._format_folder_results(sorted_folders)
            
            self.logger.info(f"INFA mapping details analysis complete for {original_filename or file_path}: "
                           f"Found {len(folder_analysis)} folders")
            
            return self.create_success_result(
                filename=original_filename,
                folder_analysis=folder_analysis,
                sorted_folders=sorted_folders,
                formatted_results=formatted_results,
                total_folders=len(folder_analysis)
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing INFA mapping details in file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e))
    
    def _analyze_mapping_details(self, sheet) -> Dict[str, Dict[str, Any]]:
        """
        Analyze the Mapping Details sheet to group by folder and count mappings.
        
        Args:
            sheet: Worksheet object
            
        Returns:
            Dictionary with folder analysis data
        """
        folder_data: Dict[str, Dict[str, Any]] = {}
        
        # Start from row 2 (assuming row 1 is header)
        for row_num in range(2, sheet.max_row + 1):
            # Get cell values
            folder = str(sheet[f'B{row_num}'].value or '').strip()
            if not folder:
                continue
                
            mapping_type = str(sheet[f'E{row_num}'].value or 'Unknown').strip()
            categorization = str(sheet[f'F{row_num}'].value or 'Unknown').strip()
            nodes = self._parse_nodes(sheet[f'G{row_num}'].value)
            
            # Initialize folder data if not exists
            if folder not in folder_data:
                folder_data[folder] = {
                    'mapping_type_categorization': defaultdict(lambda: {'count': 0, 'total_nodes': 0}),
                    'total_nodes': 0,
                    'mapping_count': 0
                }
            
            # Create combination key and update data
            combination_key = f"{categorization} {mapping_type}s"
            folder_data[folder]['mapping_type_categorization'][combination_key]['count'] += 1
            folder_data[folder]['mapping_type_categorization'][combination_key]['total_nodes'] += nodes
            folder_data[folder]['total_nodes'] += nodes
            folder_data[folder]['mapping_count'] += 1
        
        return folder_data
    
    def _parse_nodes(self, value) -> int:
        """Parse nodes value, returning 0 if invalid."""
        try:
            return int(value) if value is not None else 0
        except (ValueError, TypeError):
            return 0
    
    def _get_complexity_score(self, folder_data: Dict[str, Any]) -> Tuple[int, int, int]:
        """
        Calculate complexity score for sorting folders.
        
        Args:
            folder_data: Dictionary containing folder analysis data with mapping_type_categorization,
                        mapping_count, and total_nodes keys
                        
        Returns:
            Tuple of (categorization_complexity, total_count, total_nodes) where:
            - categorization_complexity: 1=low, 2=medium, 3=complex, 4=very complex
            - total_count: Total number of mappings in the folder
            - total_nodes: Total number of nodes in the folder
        """
        max_categorization_score = max(
            self.CATEGORIZATION_SCORES.get(combination_key.split()[0].lower(), 1)
            for combination_key in folder_data['mapping_type_categorization'].keys()
        )
        
        return (max_categorization_score, folder_data['mapping_count'], folder_data['total_nodes'])
    
    def _sort_folders_by_complexity(self, folder_analysis: Dict[str, Dict[str, Any]]) -> List[Tuple[str, Dict[str, Any]]]:
        """
        Sort folders by complexity based on categorization, count, and total nodes.
        
        Args:
            folder_analysis: Dictionary with folder analysis data
            
        Returns:
            List of tuples (folder_name, folder_data) sorted by complexity
        """
        return sorted(folder_analysis.items(), key=lambda x: self._get_complexity_score(x[1]))
    
    def _format_folder_results(self, sorted_folders: List[Tuple[str, Dict[str, Any]]]) -> List[str]:
        """
        Format folder results for the report.
        
        Args:
            sorted_folders: List of sorted folder data
            
        Returns:
            List of formatted strings for the report
        """
        formatted_results = []
        
        for folder_name, folder_data in sorted_folders:
            # Create combinations with formatting
            combinations = []
            for combination_key, data in folder_data['mapping_type_categorization'].items():
                categorization, mapping_type = self._format_combination(combination_key)
                combinations.append({
                    'text': f"{data['count']} {categorization} {mapping_type} - {data['total_nodes']:.0f} nodes total",
                    'categorization': categorization,
                    'count': data['count'],
                    'nodes': data['total_nodes']
                })
            
            # Sort combinations by categorization, count, and nodes
            combinations.sort(key=lambda x: (
                self._get_categorization_score(x['categorization']),
                x['count'],
                x['nodes']
            ))
            
            # Format folder result
            formatted_results.append(f"{folder_name}:\n  {', '.join(item['text'] for item in combinations)}")
        
        return formatted_results
    
    def _format_combination(self, combination_key: str) -> Tuple[str, str]:
        """Format combination key into categorization and mapping type."""
        parts = combination_key.split()
        categorization = parts[0].title()
        mapping_type = ' '.join(parts[1:])
        
        # Add "complexity" suffix for Low and Medium
        if categorization in ['Low', 'Medium']:
            categorization += ' complexity'
            
        return categorization, mapping_type
    
    def _get_categorization_score(self, categorization: str) -> int:
        """
        Get sorting score for categorization.
        
        Args:
            categorization: Categorization string (e.g., "Low complexity", "Medium complexity", "Complex")
            
        Returns:
            Integer score for sorting (1=low, 2=medium, 3=complex, 4=very complex)
        """
        categorization_lower = categorization.lower()
        if 'low' in categorization_lower:
            return 1
        elif 'medium' in categorization_lower:
            return 2
        elif 'complex' in categorization_lower and 'very' not in categorization_lower:
            return 3
        elif 'very complex' in categorization_lower:
            return 4
        else:
            return 1  # Default to low 