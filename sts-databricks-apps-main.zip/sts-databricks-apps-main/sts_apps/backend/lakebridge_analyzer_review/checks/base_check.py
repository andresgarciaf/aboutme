import openpyxl
import os
from typing import Dict, Any, Optional
from backend.logger import get_logger


class BaseCheck:
    """
    Base class for all Lakebridge Analyzer checks.
    Provides common Excel loading and error handling functionality.
    """
    
    def __init__(self):
        self.logger = get_logger()
    
    def load_excel_file(self, file_path: str, original_filename: str = "", data_only: bool = True) -> Optional[openpyxl.Workbook]:
        """
        Load an Excel file with error handling.
        
        Args:
            file_path: Path to the Excel file
            original_filename: Original filename for logging
            data_only: If True, load calculated values instead of formulas
            
        Returns:
            openpyxl.Workbook object or None if loading fails
        """
        try:
            self.logger.debug(f"Loading Excel workbook from: {file_path} (data_only={data_only})")
            return openpyxl.load_workbook(file_path, data_only=data_only)
        except Exception as e:
            self.logger.error(f"Error loading Excel file {original_filename or os.path.basename(file_path)}: {str(e)}")
            return None
    
    def get_sheet(self, workbook: openpyxl.Workbook, sheet_name: str, original_filename: str = ""):
        """
        Get a specific sheet from the workbook with error handling.
        
        Args:
            workbook: openpyxl.Workbook object
            sheet_name: Name of the sheet to retrieve
            original_filename: Original filename for logging
            
        Returns:
            Worksheet object or None if sheet doesn't exist
        """
        if sheet_name not in workbook.sheetnames:
            self.logger.error(f"Sheet '{sheet_name}' not found in file: {original_filename}")
            return None
        
        self.logger.debug(f"Found '{sheet_name}' sheet")
        return workbook[sheet_name]
    
    def create_error_result(self, filename: str, error: str) -> Dict[str, Any]:
        """
        Create a standardized error result dictionary.
        
        Args:
            filename: Original filename
            error: Error message
            
        Returns:
            Dictionary with error information
        """
        return {
            'filename': filename,
            'error': error,
            'success': False
        }
    
    def create_success_result(self, filename: str, **kwargs) -> Dict[str, Any]:
        """
        Create a standardized success result dictionary.
        
        Args:
            filename: Original filename
            **kwargs: Additional result data
            
        Returns:
            Dictionary with success information
        """
        result = {
            'filename': filename,
            'success': True
        }
        result.update(kwargs)
        return result 