from .complexity_check import ComplexityCheck


class ETLComplexityCheck(ComplexityCheck):
    """
    Check for ETL complexity analysis based on SQL Programs sheet data.
    """
    
    def __init__(self):
        """Initialize the ETL complexity check."""
        super().__init__("ETL") 