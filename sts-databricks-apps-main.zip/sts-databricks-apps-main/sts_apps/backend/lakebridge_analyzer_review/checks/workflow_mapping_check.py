from typing import Dict, Any
from .base_check import BaseCheck


class WorkflowMappingCheck(BaseCheck):
    """
    Check for INFA files to analyze workflow to mapping ratio.
    """
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze an INFA XLSX file to check workflow to mapping ratio.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing analysis results
        """
        self.logger.info(f"Starting workflow to mapping ratio analysis of file: {original_filename or file_path}")
        
        # Load Excel file (will use calculated values by default)
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get Summary sheet
        sheet = self.get_sheet(workbook, 'Summary', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Sheet 'Summary' not found in the Excel file")
        
        try:
            # Read B4 (Total Mappings) and B5 (Total Workflows)
            b4_value = sheet['B4'].value
            b5_value = sheet['B5'].value
            
            self.logger.debug(f"B4 (Total Mappings): {b4_value}, B5 (Total Workflows): {b5_value}")
            
            # Validate that we have numeric values
            if b4_value is None or b5_value is None:
                return self.create_error_result(original_filename, "B4 (Total Mappings) or B5 (Total Workflows) is empty")
            
            try:
                total_mappings = int(b4_value)  # Convert directly to int
                total_workflows = int(b5_value)  # Convert directly to int
            except (ValueError, TypeError):
                return self.create_error_result(original_filename, "B4 (Total Mappings) or B5 (Total Workflows) contains non-numeric values")
            
            # Check for zero mappings to avoid division by zero
            if total_mappings == 0:
                return self.create_error_result(original_filename, "Total Mappings (B4) is zero, cannot calculate ratio")
            
            # Calculate ratio
            workflow_mapping_ratio = total_workflows / total_mappings
            
            # Determine recommendation based on ratio
            if workflow_mapping_ratio >= 0.8:
                recommendation = "Ask if there are external orchestrators. There is almost a 1-1 ratio of workflows to mappings."
                complexity_level = "Low"
            else:
                recommendation = "Complexity appears to be within Informatica as there is a low workflows to mappings ratio."
                complexity_level = "High"
            
            self.logger.info(f"Workflow to mapping ratio analysis complete for {original_filename or file_path}: "
                           f"Ratio = {workflow_mapping_ratio:.3f}, {recommendation}")
            
            return self.create_success_result(
                filename=original_filename,
                total_mappings=total_mappings,
                total_workflows=total_workflows,
                workflow_mapping_ratio=workflow_mapping_ratio,
                recommendation=recommendation,
                complexity_level=complexity_level
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing workflow to mapping ratio in file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e)) 