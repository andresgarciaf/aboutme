import openpyxl
from typing import Dict, Any, List
from .base_check import BaseCheck


class ComplexityCheck(BaseCheck):
    """
    Generic complexity check that can analyze SQL or ETL complexity.
    """
    
    def __init__(self, script_type: str):
        """
        Initialize the complexity check.
        
        Args:
            script_type: The type of script to filter for ('SQL' or 'ETL')
        """
        super().__init__()
        self.script_type = script_type.upper()
        self.check_name = f"{script_type.lower()}_complexity"
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze complexity from SQL Programs sheet by counting files by complexity level.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing complexity analysis results
        """
        self.logger.info(f"Starting {self.script_type} complexity analysis of file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get SQL Programs sheet for analysis
        sql_sheet = self.get_sheet(workbook, 'SQL Programs', original_filename)
        if not sql_sheet:
            return self.create_error_result(original_filename, "Sheet 'SQL Programs' not found in the Excel file")
        
        try:
            # Count files by complexity level, filtering for specified script type
            low_count = 0
            medium_count = 0
            complex_count = 0
            very_complex_count = 0
            
            # Get detailed information for complex and very complex files
            complex_files = []
            very_complex_files = []
            
            # Column E is Complexity (5th column, index 4)
            # Column L is Script Type (12th column, index 11)
            for row_num, row in enumerate(sql_sheet.iter_rows(min_row=2, values_only=True), start=2):
                if len(row) > 11:  # Ensure we have enough columns
                    script_type_col = row[11]  # Column L (Script Type)
                    complexity = row[4] if len(row) > 4 else None  # Column E (Complexity)
                    file_name = row[0] if len(row) > 0 else f"Row {row_num}"  # Column A (File Name)
                    
                    # Filter for specified script type only
                    if script_type_col and str(script_type_col).strip().upper() == self.script_type:
                        if complexity:
                            complexity_str = str(complexity).strip().lower()
                            
                            if complexity_str == 'low':
                                low_count += 1
                            elif complexity_str == 'medium':
                                medium_count += 1
                            elif complexity_str == 'complex':
                                complex_count += 1
                                complex_files.append({
                                    'row': row_num,
                                    'file_name': str(file_name).strip() if file_name else f"Row {row_num}"
                                })
                            elif complexity_str == 'very_complex':
                                very_complex_count += 1
                                very_complex_files.append({
                                    'row': row_num,
                                    'file_name': str(file_name).strip() if file_name else f"Row {row_num}"
                                })
            
            # Calculate total
            total_count = low_count + medium_count + complex_count + very_complex_count
            
            # Calculate percentages
            percentages = {}
            if total_count > 0:
                percentages = {
                    'low': (low_count / total_count) * 100,
                    'medium': (medium_count / total_count) * 100,
                    'complex': (complex_count / total_count) * 100,
                    'very_complex': (very_complex_count / total_count) * 100
                }
            else:
                percentages = {'low': 0, 'medium': 0, 'complex': 0, 'very_complex': 0}
            
            # Check if there are complex or very complex files
            has_complex_files = complex_count > 0 or very_complex_count > 0
            
            self.logger.info(f"{self.script_type} complexity analysis complete for {original_filename or file_path}: "
                           f"Total {self.script_type} files: {total_count}, Complex: {complex_count}, Very Complex: {very_complex_count}")
            
            return self.create_success_result(
                filename=original_filename,
                total_files=total_count,
                complexity_counts={
                    'low': low_count,
                    'medium': medium_count,
                    'complex': complex_count,
                    'very_complex': very_complex_count
                },
                percentages=percentages,
                has_complex_files=has_complex_files,
                complex_files=complex_files,
                very_complex_files=very_complex_files,
                script_type=self.script_type
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing {self.script_type} complexity in file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e)) 