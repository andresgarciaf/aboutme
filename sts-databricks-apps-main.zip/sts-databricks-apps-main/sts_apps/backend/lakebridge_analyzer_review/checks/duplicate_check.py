import re
from typing import Dict, Any, List
from .base_check import BaseCheck


class DuplicateCheck(BaseCheck):
    """
    Check for duplicate program names with similarity analysis.
    """
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze an XLSX file to find program names that are repeated with only numeric suffixes.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing analysis results
        """
        self.logger.info(f"Starting duplicate program name analysis of file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get SQL Programs sheet
        sheet = self.get_sheet(workbook, 'SQL Programs', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Sheet 'SQL Programs' not found in the Excel file")
        
        try:
            # Extract program names and characteristics from columns A, D, E, F, G, H, I
            program_names = []
            for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
                if len(row) > 0 and row[0]:  # Ensure we have a value in column A
                    program_names.append({
                        'row': row_num,
                        'name': str(row[0]).strip(),
                        'line_count': row[3] if len(row) > 3 else None,  # Column D
                        'complexity': row[4] if len(row) > 4 else None,   # Column E
                        'statement_count': row[5] if len(row) > 5 else None,  # Column F
                        'procedure_function_count': row[6] if len(row) > 6 else None,  # Column G
                        'script_category': row[7] if len(row) > 7 else None,  # Column H
                        'categorization_metrics': row[8] if len(row) > 8 else None  # Column I
                    })
            
            # Sort program names alphabetically
            program_names.sort(key=lambda x: x['name'])
            
            # Find potential duplicates while excluding hash-based names
            duplicate_groups = self._find_duplicate_groups(program_names)
            
            # Analyze similarity within each group
            for group in duplicate_groups:
                group_similarity = self._analyze_group_similarity(group)
                group.append(group_similarity)  # Add similarity analysis to the group
            
            # Calculate statistics
            total_programs = len(program_names)
            duplicate_count = sum(len(group) - 1 for group in duplicate_groups)  # Subtract 1 for similarity data
            unique_duplicate_groups = len(duplicate_groups)
            
            self.logger.info(f"Duplicate program name analysis complete for {original_filename or file_path}: "
                           f"{unique_duplicate_groups} duplicate groups found with {duplicate_count} total duplicate programs")
            
            return self.create_success_result(
                filename=original_filename,
                total_programs=total_programs,
                duplicate_groups_count=unique_duplicate_groups,
                duplicate_programs_count=duplicate_count,
                duplicate_groups=duplicate_groups
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing duplicate program names in file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e))
    
    def _find_duplicate_groups(self, program_names: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """Find groups of programs with similar base names."""
        duplicate_groups = []
        current_group = []
        
        for i, program in enumerate(program_names):
            current_name = program['name']
            
            # Skip hash-based names (very long alphanumeric strings)
            if re.match(r'^.*[a-f0-9]{32,}.*$', current_name, re.IGNORECASE):
                continue
            
            # Extract base name - handle various suffix patterns
            base_name_match = re.match(r'^(.+?)(?:_[a-zA-Z0-9]+)?$', current_name)
            if not base_name_match:
                continue
                
            base_name = base_name_match.group(1)
            
            # Skip if base name is too short (likely not meaningful)
            if len(base_name) < 3:
                continue
            
            # Check if this is the first item or if it has the same base name as previous
            if not current_group or base_name == current_group[0]['base_name']:
                if not current_group:
                    # Start new group
                    current_group = [{
                        'row': program['row'],
                        'name': current_name,
                        'base_name': base_name,
                        'line_count': program['line_count'],
                        'complexity': program['complexity'],
                        'statement_count': program['statement_count'],
                        'procedure_function_count': program['procedure_function_count'],
                        'script_category': program['script_category'],
                        'categorization_metrics': program['categorization_metrics']
                    }]
                else:
                    # Add to existing group
                    current_group.append({
                        'row': program['row'],
                        'name': current_name,
                        'base_name': base_name,
                        'line_count': program['line_count'],
                        'complexity': program['complexity'],
                        'statement_count': program['statement_count'],
                        'procedure_function_count': program['procedure_function_count'],
                        'script_category': program['script_category'],
                        'categorization_metrics': program['categorization_metrics']
                    })
            else:
                # Different base name - check if previous group has duplicates
                if len(current_group) > 1:
                    duplicate_groups.append(current_group)
                # Start new group
                current_group = [{
                    'row': program['row'],
                    'name': current_name,
                    'base_name': base_name,
                    'line_count': program['line_count'],
                    'complexity': program['complexity'],
                    'statement_count': program['statement_count'],
                    'procedure_function_count': program['procedure_function_count'],
                    'script_category': program['script_category'],
                    'categorization_metrics': program['categorization_metrics']
                }]
        
        # Check the last group
        if len(current_group) > 1:
            duplicate_groups.append(current_group)
        
        return duplicate_groups
    
    def _analyze_group_similarity(self, group: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze the similarity of characteristics within a group of programs."""
        if len(group) < 2:
            return {'similarity_score': 0, 'similar_characteristics': []}
        
        # Define the characteristics to compare
        characteristics = [
            'line_count', 'complexity', 'statement_count', 
            'procedure_function_count', 'script_category', 'categorization_metrics'
        ]
        
        similar_characteristics = []
        total_characteristics = len(characteristics)
        matching_characteristics = 0
        
        # Check each characteristic across all programs in the group
        for char_name in characteristics:
            values = [prog.get(char_name) for prog in group]
            # Remove None values for comparison
            non_none_values = [v for v in values if v is not None]
            
            if len(non_none_values) > 1 and len(set(non_none_values)) == 1:
                # All non-None values are the same
                similar_characteristics.append(char_name)
                matching_characteristics += 1
        
        # Calculate similarity score (percentage of matching characteristics)
        similarity_score = (matching_characteristics / total_characteristics) * 100 if total_characteristics > 0 else 0
        
        return {
            'similarity_score': similarity_score,
            'total_characteristics': total_characteristics,
            'matching_characteristics': matching_characteristics
        } 