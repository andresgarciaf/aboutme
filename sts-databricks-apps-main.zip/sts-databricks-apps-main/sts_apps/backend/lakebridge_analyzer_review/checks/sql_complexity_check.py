import openpyxl
from typing import Dict, Any, List
from .base_check import BaseCheck
from .complexity_check import ComplexityCheck


class SQLComplexityCheck(ComplexityCheck):
    """
    Check for SQL complexity analysis based on SQL Programs sheet data.
    """
    
    def __init__(self):
        """Initialize the SQL complexity check."""
        super().__init__("SQL") 