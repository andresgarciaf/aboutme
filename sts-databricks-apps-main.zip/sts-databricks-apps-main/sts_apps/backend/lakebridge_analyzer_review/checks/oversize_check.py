from typing import Dict, Any
from .base_check import BaseCheck


class OversizeCheck(BaseCheck):
    """
    Check for oversize files (multiple statements in one file).
    """
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze an XLSX file to find oversize files (multiple statements in one file).
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing analysis results
        """
        self.logger.info(f"Starting oversize analysis of file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get SQL Programs sheet
        sheet = self.get_sheet(workbook, 'SQL Programs', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Sheet 'SQL Programs' not found in the Excel file")
        
        try:
            # Find column G (Procedure And Function Counts)
            column_g_values = []
            rows_with_high_counts = []
            
            for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
                if len(row) >= 7:  # Ensure we have at least 7 columns (A-G)
                    value = row[6]  # Column G (0-indexed, so 6)
                    column_g_values.append(value)
                    
                    # Check if value is greater than 1
                    try:
                        if isinstance(value, (int, float)) and value > 1:
                            rows_with_high_counts.append({
                                'row': row_num,
                                'value': int(value),  # Convert to int to avoid decimals
                                'program_name': row[0] if len(row) > 0 else 'Unknown'
                            })
                    except (TypeError, ValueError):
                        # Skip non-numeric values
                        continue
            
            # Calculate statistics
            total_rows = len(column_g_values)
            high_count_rows = len(rows_with_high_counts)
            percentage = (high_count_rows/total_rows*100) if total_rows > 0 else 0
            
            self.logger.info(f"Oversize analysis complete for {original_filename or file_path}: "
                           f"{high_count_rows} oversize files found out of {total_rows} total rows ({percentage:.1f}%)")
            
            return self.create_success_result(
                filename=original_filename,
                total_rows=total_rows,
                oversize_files_count=high_count_rows,
                percentage=percentage,
                oversize_files=rows_with_high_counts
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing oversize files in {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e)) 