from typing import Dict, Any, List
from .base_check import BaseCheck


class UnsupportedTransformationsCheck(BaseCheck):
    """
    Check for unsupported transformations analysis in INFA, INFADEV, and INFACLOUD files.
    Analyzes the Transformations sheet to count supported vs unsupported transformations.
    """
    
    def __init__(self):
        """Initialize the unsupported transformations check."""
        super().__init__()
        self.check_name = "unsupported_transformations"
    
    def check(self, file_path: str, original_filename: str = "") -> Dict[str, Any]:
        """
        Analyze an INFA XLSX file to check unsupported transformations from the Transformations sheet.
        
        Args:
            file_path: Path to the XLSX file
            original_filename: Original filename from upload
            
        Returns:
            Dictionary containing unsupported transformations analysis results
        """
        self.logger.info(f"Starting unsupported transformations analysis of file: {original_filename or file_path}")
        
        # Load Excel file
        workbook = self.load_excel_file(file_path, original_filename)
        if not workbook:
            return self.create_error_result(original_filename, "Failed to load Excel file")
        
        # Get Transformations sheet
        sheet = self.get_sheet(workbook, 'Transformations', original_filename)
        if not sheet:
            return self.create_error_result(original_filename, "Sheet 'Transformations' not found in the Excel file")
        
        try:
            # Analyze the data starting from row 2 (assuming row 1 is header)
            transformation_analysis = self._analyze_transformations(sheet)
            
            if not transformation_analysis:
                return self.create_error_result(original_filename, "No valid data found in Transformations sheet")
            
            # Calculate statistics
            supported_count = transformation_analysis['supported_count']
            unsupported_count = transformation_analysis['unsupported_count']
            total_count = supported_count + unsupported_count
            total_occurrences = transformation_analysis['total_occurrences']
            unsupported_occurrences = transformation_analysis['unsupported_occurrences']
            
            # Calculate percentage of unsupported transformations based on occurrences
            unsupported_percentage = 0
            if total_occurrences > 0:
                unsupported_percentage = (unsupported_occurrences / total_occurrences) * 100
            
            # Get list of unsupported transformations with their occurrence counts
            unsupported_details = transformation_analysis['unsupported_details']
            
            self.logger.info(f"Unsupported transformations analysis complete for {original_filename or file_path}: "
                           f"Supported: {supported_count}, Unsupported: {unsupported_count}, "
                           f"Total Occurrences: {total_occurrences}, Unsupported Occurrences: {unsupported_occurrences}, "
                           f"Percentage: {unsupported_percentage:.1f}%")
            
            return self.create_success_result(
                filename=original_filename,
                supported_count=supported_count,
                unsupported_count=unsupported_count,
                total_count=total_count,
                total_occurrences=total_occurrences,
                unsupported_occurrences=unsupported_occurrences,
                unsupported_percentage=unsupported_percentage,
                unsupported_details=unsupported_details,
                has_unsupported_transformations=unsupported_count > 0
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing unsupported transformations in file {original_filename or file_path}: {str(e)}")
            return self.create_error_result(original_filename, str(e))
    
    def _analyze_transformations(self, sheet) -> Dict[str, Any]:
        """
        Analyze the Transformations sheet to count supported vs unsupported transformations.
        
        Args:
            sheet: The Transformations worksheet
            
        Returns:
            Dictionary containing analysis results
        """
        supported_count = 0
        unsupported_count = 0
        total_occurrences = 0
        unsupported_occurrences = 0
        unsupported_details = {}  # transformation_name -> occurrence_count
        
        # Process each row starting from row 2 (skip header)
        for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
            if len(row) >= 4:  # Need at least 4 columns: Transformation Name, Occurrences, Supported
                transformation_name = row[0] if len(row) > 0 else None  # Column A (Transformation Name)
                occurrence_count = row[1] if len(row) > 1 else 1  # Column B (# of Occurrences)
                supported_value = row[3] if len(row) > 3 else None  # Column D (Supported)
                
                # Skip rows with no transformation name
                if not transformation_name or str(transformation_name).strip() == '':
                    continue
                
                transformation_name = str(transformation_name).strip()
                
                # Convert occurrence_count to integer, default to 1 if not a number
                try:
                    occurrence_count = int(occurrence_count) if occurrence_count is not None else 1
                except (ValueError, TypeError):
                    occurrence_count = 1
                
                # Add to total occurrences
                total_occurrences += occurrence_count
                
                # Check if supported (Yes/No)
                if supported_value is not None:
                    supported_str = str(supported_value).strip().lower()
                    
                    if supported_str == 'yes':
                        supported_count += 1
                    elif supported_str == 'no':
                        unsupported_count += 1
                        unsupported_occurrences += occurrence_count
                        # Track unsupported transformation details with actual occurrence count
                        if transformation_name in unsupported_details:
                            unsupported_details[transformation_name] += occurrence_count
                        else:
                            unsupported_details[transformation_name] = occurrence_count
        
        return {
            'supported_count': supported_count,
            'unsupported_count': unsupported_count,
            'total_occurrences': total_occurrences,
            'unsupported_occurrences': unsupported_occurrences,
            'unsupported_details': unsupported_details
        } 