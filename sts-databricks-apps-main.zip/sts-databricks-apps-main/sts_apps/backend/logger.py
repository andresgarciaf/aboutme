import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

# Import config from backend directory
from backend.config import Config


class Logger:
    """Logger class for the Lakebridge Analyzer Reviewer application"""
    
    _instance: Optional['Logger'] = None
    _logger: Optional[logging.Logger] = None
    _is_configured: bool = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Logger, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        pass
    
    def _ensure_configured(self):
        """Ensure logger is configured"""
        if not self._is_configured:
            self._setup_logger()
    
    def _setup_logger(self):
        """Setup the logger with appropriate configuration"""
        # Create logger
        self._logger = logging.getLogger('lakebridge_reviewer')
        self._logger.setLevel(logging.DEBUG if Config.ENVIRONMENT == "development" else logging.INFO)
        
        # Clear any existing handlers
        self._logger.handlers.clear()
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(console_formatter)
        self._logger.addHandler(console_handler)
        
        # File handler for development
        if Config.ENVIRONMENT == "development":
            log_file_path = self._get_dev_log_path()
            if log_file_path:
                log_file_path.parent.mkdir(parents=True, exist_ok=True)
                file_handler = logging.FileHandler(log_file_path)
                file_handler.setLevel(logging.DEBUG)
                file_formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(funcName)s - %(message)s'
                )
                file_handler.setFormatter(file_formatter)
                self._logger.addHandler(file_handler)
        
        self._is_configured = True
    
    def _get_dev_log_path(self) -> Optional[Path]:
        """Get log file path for development environment"""
        if sys.platform == 'darwin':  # macOS
            log_dir = Path.home() / 'Library' / 'Logs' / 'LakebridgeReviewer'
        elif sys.platform == 'win32':  # Windows
            log_dir = Path.home() / 'AppData' / 'Local' / 'LakebridgeReviewer' / 'logs'
        else:  # Linux and others
            log_dir = Path.home() / '.local' / 'share' / 'lakebridge_reviewer' / 'logs'
        
        return log_dir / f'lakebridge_reviewer_{datetime.now().strftime("%Y%m%d")}.log'
    
    def get_logger(self) -> logging.Logger:
        """Get the configured logger instance"""
        self._ensure_configured()
        assert self._logger is not None
        return self._logger
    
    def debug(self, message: str):
        """Log debug message"""
        if self._logger is not None:
            self._logger.debug(message)
    
    def info(self, message: str):
        """Log info message"""
        if self._logger is not None:
            self._logger.info(message)
    
    def warning(self, message: str):
        """Log warning message"""
        if self._logger is not None:
            self._logger.warning(message)
    
    def error(self, message: str):
        """Log error message"""
        if self._logger is not None:
            self._logger.error(message)
    
    def critical(self, message: str):
        """Log critical message"""
        if self._logger is not None:
            self._logger.critical(message)
    
    def exception(self, message: str):
        """Log exception with traceback"""
        if self._logger is not None:
            self._logger.exception(message)


# Global logger instance
def get_logger() -> logging.Logger:
    """Get the global logger instance"""
    return Logger().get_logger()


# Convenience functions for direct logging
def debug(message: str):
    """Log debug message"""
    Logger().debug(message)


def info(message: str):
    """Log info message"""
    Logger().info(message)


def warning(message: str):
    """Log warning message"""
    Logger().warning(message)


def error(message: str):
    """Log error message"""
    Logger().error(message)


def critical(message: str):
    """Log critical message"""
    Logger().critical(message)


def exception(message: str):
    """Log exception with traceback"""
    Logger().exception(message) 