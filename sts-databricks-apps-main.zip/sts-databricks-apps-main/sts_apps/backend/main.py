import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from backend.api.utils import configure_app

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event handler for FastAPI app."""
    logger.info("Starting STS Databricks Apps API")
    logger.info(f"Environment: {os.getenv('ENVIRONMENT', 'development')}")
    yield
    logger.info("Shutting down STS Databricks Apps API")


# Create and configure FastAPI app
app = FastAPI(
    title="STS Apps API",
    description="""
    API for STS Apps

    ## Features

    * All STS API endpoints centralized for any application.

    ## Authentication

    This API currently doesn't require authentication for testing purposes.

    ## Additional Notes

    All API endpoints are accessed via the `/api` prefix.
    """,
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# Configure app with middleware and exception handlers
app = configure_app(app)
