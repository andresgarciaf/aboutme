import os
import logging
import re

from pathlib import Path
from dataclasses import dataclass, field
from functools import lru_cache

import yaml
import openpyxl

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parents[1]

_CLEAN_FORMAT_REGEX = re.compile(
    r"COM\.DATABRICKS\.SPARK\.(CSV|JSON|AVRO|ORC|TEXT|XML)"
)


@dataclass(frozen=True)
class Articles:
    resources: dict[str, str | dict[str, str]] = field(
        default_factory=lambda: {
            "MIGRATION OVERVIEW": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/data-governance/unity-catalog/migrate",
                "aws": "https://docs.databricks.com/en/data-governance/unity-catalog/migrate.html#hive-to-unity-catalog-migration-options",
                "gcp": "https://docs.gcp.databricks.com/en/data-governance/unity-catalog/migrate.html?_ga=2.33846248.89958740.1718399394-1511206587.1708537116",
            },
            "MIGRATION OPTIONS": "https://www.databricks.com/blog/migrating-tables-hive-metastore-unity-catalog-metastore",
            "ANALYZE MANUALLY": "https://www.databricks.com/blog/migrating-tables-hive-metastore-unity-catalog-metastore",
            "SYNC": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-syntax-aux-sync",
                "aws": "https://docs.databricks.com/en/sql/language-manual/sql-ref-syntax-aux-sync.html",
                "gcp": "https://docs.gcp.databricks.com/en/sql/language-manual/sql-ref-syntax-aux-sync.html?_ga=2.38021348.6961092.1717540940-1511206587.1708537116",
            },
            "DEEP CLONE": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/delta-clone",
                "aws": "https://docs.databricks.com/en/sql/language-manual/delta-clone.html",
                "gcp": "https://docs.gcp.databricks.com/en/sql/language-manual/delta-clone.html",
            },
            "CTAS": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-syntax-ddl-create-table-using",
                "aws": "https://docs.databricks.com/en/sql/language-manual/sql-ref-syntax-ddl-create-table-using.html",
                "gcp": "https://docs.gcp.databricks.com/en/sql/language-manual/sql-ref-syntax-ddl-create-table-using.html",
            },
            "CREATE VIEW": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/data-governance/unity-catalog/create-views",
                "aws": "https://docs.databricks.com/en/data-governance/unity-catalog/create-views.html",
                "gcp": "https://docs.gcp.databricks.com/en/data-governance/unity-catalog/create-views.html",
            },
            "LAKEHOUSE FEDERATION (READ-ONLY)": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/query-federation/",
                "aws": "https://docs.databricks.com/en/query-federation/index.html",
                "gcp": "https://docs.gcp.databricks.com/en/query-federation/index.html",
            },
            "UC PRIVILEGES": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/data-governance/unity-catalog/manage-privileges/privileges",
                "aws": "https://docs.databricks.com/en/data-governance/unity-catalog/manage-privileges/privileges.html",
                "gcp": "https://docs.gcp.databricks.com/en/data-governance/unity-catalog/manage-privileges/privileges.html",
            },
            "USE CATALOG": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-syntax-ddl-use-catalog",
                "aws": "https://docs.databricks.com/en/sql/language-manual/sql-ref-syntax-ddl-use-catalog.html",
                "gcp": "https://docs.gcp.databricks.com/en/sql/language-manual/sql-ref-syntax-ddl-use-catalog.html",
            },
            "VOLUMES": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/sql/language-manual/sql-ref-volumes",
                "aws": "https://docs.databricks.com/en/sql/language-manual/sql-ref-volumes.html",
                "gcp": "https://docs.gcp.databricks.com/en/sql/language-manual/sql-ref-volumes.html",
            },
            "EXTERNAL LOCATIONS": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/connect/unity-catalog/external-locations",
                "aws": "https://docs.databricks.com/en/connect/unity-catalog/external-locations.html",
                "gcp": "https://docs.gcp.databricks.com/en/connect/unity-catalog/external-locations.html",
            },
            "MOUNTPOINTS": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/dbfs/mounts",
                "aws": "https://docs.databricks.com/en/dbfs/mounts.html",
                "gcp": "https://docs.gcp.databricks.com/en/dbfs/mounts.html",
            },
            "ACCESS STORAGE IN UC": {
                "azure": "https://learn.microsoft.com/en-us/azure/databricks/connect/unity-catalog/",
                "aws": "https://docs.databricks.com/en/connect/unity-catalog/index.html",
                "gcp": "https://docs.gcp.databricks.com/en/connect/unity-catalog/index.html",
            },
            "DBR MIGRATION TOOL": "https://dbrmg.databricks.com/",
        }
    )


_DOCS = Articles()


@lru_cache(maxsize=1)
def get_html_template() -> str:
    """Get the HTML template from the configured path. Cached for performance."""
    template_path = _PROJECT_ROOT / "configs" / "index.html"
    try:
        return template_path.read_text(encoding="utf-8")
    except Exception as e:
        logger.error(f"Error reading HTML template: {e}")
        return ""


@lru_cache(maxsize=1)
def load_migration_config() -> dict:
    """Load and cache the migration configuration from YAML."""
    config_path = _PROJECT_ROOT / "configs" / "migration_config.yml"
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
            return config or {}
    except Exception as e:
        logger.error(f"Error loading migration config: {e}")
        return {}


def get_cloud_article(cloud_provider: str, doc_key: str) -> str | None:
    """Return the URL for the given document key based on the cloud provider."""
    doc_urls = _DOCS.resources.get(doc_key)
    if isinstance(doc_urls, dict):
        return doc_urls.get(cloud_provider.lower())
    return doc_urls


def save_workbook(
    workbook: openpyxl.Workbook, output_folder: str, output_filename: str
) -> str:
    """Save the workbook to the specified folder and filename."""
    os.makedirs(output_folder, exist_ok=True)
    output_file = os.path.join(output_folder, f"{output_filename}.xlsx")
    try:
        workbook.save(output_file)
    except Exception as err:
        logger.error(f"Error saving workbook: {err}")
    return output_file


def get_clean_format(value: str) -> str:
    """Extract and return the clean format using a precompiled regex."""
    match = _CLEAN_FORMAT_REGEX.search(value)
    if match:
        return match.group(1)
    return value


def _validate_hms_format(hms_format: str, valid_formats: str) -> bool:
    """Validate the HMS format against a list of valid formats."""
    valid_formats_list = valid_formats.split("/")
    hms_format_lower = hms_format.lower()
    return any(
        fmt.lower() in hms_format_lower or hms_format_lower in fmt.lower()
        for fmt in valid_formats_list
    )


def get_migration_approach(
    hms_type: str, hms_format: str, hms_storage: str
) -> str | None:
    """Return the migration options for a table type based on the migration configuration."""
    config = load_migration_config()
    mappings = config.get("mappings", {}).get(hms_type, [])
    recommendations = []
    for mapping in mappings:
        if (
            _validate_hms_format(hms_format, mapping["hms"]["format"])
            and mapping["hms"]["storage"] == hms_storage
        ):
            if mapping["uc"]["approach"] == "CREATE VIEW":
                recommendations.append(
                    "CREATE VIEW using the view definition provided from hive_metastore."
                )
            else:
                recommendations.append(
                    f"<li>To use {mapping['uc']['format'].upper()} format on Unity Catalog as a(n) {mapping['uc']['type'].upper()} table, "
                    f"you must migrate using the {mapping['uc']['approach']} approach.</li>"
                )
    if recommendations:
        return "|".join(recommendations)
    return None
