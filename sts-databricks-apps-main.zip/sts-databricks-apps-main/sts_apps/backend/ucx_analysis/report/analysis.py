import os
import tempfile
import logging
from io import BytesIO
from zipfile import ZipFile
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import openpyxl
import pypandoc  # type: ignore
from fastapi import UploadFile

from backend.ucx_analysis.report.data import AssessmentData
from backend.ucx_analysis.utils.helper import (
    get_html_template,
    get_migration_approach,
    get_cloud_article,
    get_clean_format,
)

logger = logging.getLogger(__name__)
_PROJECT_ROOT = Path(__file__).resolve().parents[1]


class HtmlReportRenderer:
    def __init__(self, cloud: str, data: AssessmentData):
        self.cloud = cloud.lower()
        self.data = data

    def render_overview(self) -> str:
        overview_url = get_cloud_article(self.cloud, "MIGRATION OVERVIEW")
        blog_url = get_cloud_article(self.cloud, "MIGRATION OPTIONS")
        return (
            f"<p>For a better understanding of migrating into Unity Catalog, "
            f"<a href='{overview_url}'>this article</a> will provide a great overview of the steps required for a smooth migration.</p>"
            f"<p>This <a href='{blog_url}'>article</a> works as a complementary read to understand the different flavors of table migration.</p>"
        )

    async def render_tables_and_views(self) -> str:
        deep_clone_url = get_cloud_article(self.cloud, "DEEP CLONE")
        ctas_url = get_cloud_article(self.cloud, "CTAS")
        sync_url = get_cloud_article(self.cloud, "SYNC")
        views_url = get_cloud_article(self.cloud, "CREATE VIEW")

        df = await self.data.get_dataframes("all_tables")
        if df is None or df.empty:
            return "<li>No findings</li>"

        df["format"] = df["format"].apply(get_clean_format)
        df["migration_approach"] = df.apply(
            lambda row: get_migration_approach(
                row["type"], row["format"], row["storage"]
            ),
            axis=1,
        )
        migration_type_count = (
            df.groupby(["type", "format", "storage", "migration_approach"])
            .size()
            .reset_index(name="table_count")
            .sort_values("table_count", ascending=False)
        )

        def generate_recommendation_html(migration_type: str) -> str:
            return "".join(
                f"<ul>{recommendation}</ul>"
                for recommendation in migration_type.split("|")
            )

        def generate_table_description(row: dict[str, Any]) -> str:
            table_type = row["type"]
            table_format = row["format"]
            table_storage = row["storage"]
            table_count = row["table_count"]
            migration_type = row["migration_approach"]
            description = (
                f"<p>The workspace has <strong>{table_count}</strong> {table_type} "
                f"{'tables with ' + table_format + ' format, in ' + table_storage + ' storage' if table_type != 'VIEW' else ''}.</p>"
                f"<p>Recommended migration options:</p>"
            )
            return description + generate_recommendation_html(migration_type)

        html = "".join(
            generate_table_description(row.to_dict())
            for _, row in migration_type_count.iterrows()
        )

        def generate_footer_links() -> str:
            return (
                f"<p>For more information on the migration approaches, refer to the documentation "
                f"<a href='{deep_clone_url}'>DEEP Clone</a>, "
                f"<a href='{ctas_url}'>CTAS</a>, "
                f"<a href='{sync_url}'>SYNC</a>, and "
                f"<a href='{views_url}'>CREATE View</a>.</p>"
            )

        html += generate_footer_links()
        return html

    def render_tables_and_view_rec(self) -> str:
        common_pitfalls_a_url = "https://docs.google.com/presentation/d/1U7_66n8vHf0esvRGzXZ229idlhLepGGrn8Tq5jBPmCs/edit#slide=id.g2b253d1c1b3_0_5107"
        common_pitfalls_b_url = (
            "https://databricks.slack.com/archives/C027U33QZ9R/p1685021517795909"
        )
        return (
            "<li>"
            "SYNC requires UC external location to exist beforehand, pointing to the location or a parent location."
            f"{'<ul><li>Also, SYNC needs to be run by a cluster with instance profile (AWS only).</li></ul>' if self.cloud == 'aws' else ''}"
            "</li>"
            "<li>SYNC forces maintaining the same table name. If table name change is required, use CTAS instead of SYNC.</li>"
            "<li>SYNC when the source table HMS type = MANAGED requires some extra steps. See steps above.</li>"
            "<li>SYNC with a table with mount location as source uses the real location (not the mnt point) for the new location. This is nice because we want to sunset those mount points.</li>"
            "<li>UNSUPPORTED Tables indicate that they may break downstream or upstream dependencies if not accounted for.</li>"
            "<li>All data in DBFS ROOT needs to be moved somewhere else.</li>"
            "<li>DEEP CLONing a parquet table creates a Delta Table, not parquet. This may not be what the customer wants in some cases. For example, if some external dependency assumes parquet format.</li>"
            "<li>Scala code to convert HMS managed to HMS external is in the Appendix section of this article. Just need to USE CATALOG hive_metastore; before running the Scala.<a href='https://www.databricks.com/blog/migrating-tables-hive-metastore-unity-catalog-metastore'>please read.</a></li>"
            "<li>DEEP CLONE keeps metadata while >CTA loses it, creating a brand-new table.</li>"
            "<li>DEEP CLONE also preserves the existing partitioning scheme. If that is not the desired outcome, please use CTAS.</li>"
            f"{'<li>If data is in ADLS or wasb, then CTAS is required (Azure only).</li>' if self.cloud == 'azure' else ''}"
            "<li>If the HMS table is non-Delta+partitioned, and you register it as UC external, there will be a performance penalty because UC does not store external table partition metadata for non-Delta tables. "
            f"More info <a href='{common_pitfalls_a_url}'>here</a> and <a href='{common_pitfalls_b_url}'>here</a>."
            "</li>"
        )

    async def render_storage_locations(self) -> str:
        external_location_url = get_cloud_article(self.cloud, "EXTERNAL LOCATIONS")
        volumes_url = get_cloud_article(self.cloud, "VOLUMES")

        def generate_recommendation_list() -> str:
            return (
                "<li>Do not mount storage accounts to <strong>DBFS</strong> that are being used as External Locations."
                "<ul>"
                "<li>As this is not governed by UC, you would allow your users to circumvent ACLs.</li>"
                "<li>Mounting External Locations is blocked on shared, but not on single-user clusters.</li>"
                "<li>Limit the roles/service principals that have access to buckets/accounts governed by External Locations in Unity Catalog.</li>"
                "</ul></li>"
                f"<li>Follow public <a href='{external_location_url}'>documentation</a> requirements for setting up ADLS "
                f"and external locations on your Workspace. Also, consider using <a href='{volumes_url}'>Databricks Volumes</a>.</li>"
                "<li>Do not use <strong>EXTERNAL LOCATIONS</strong> for anything other than creating tables and do not use "
                "path-based access for data science and other non-tabular data use cases.</li>"
            )

        df = await self.data.get_dataframes("external_locations")
        if df is None or df.empty:
            return generate_recommendation_list()

        storage_loc_count = df.shape[0]
        return (
            f"<li>Your Workspace currently shows <strong>{storage_loc_count}</strong> external locations being used.</li>"
            + generate_recommendation_list()
        )

    async def render_mount_points(self) -> str:
        df = await self.data.get_dataframes("mount_points")
        if df is None or df.empty:
            return "<li>No findings</li>"

        exclude_values = [
            "databricks-datasets",
            "UnityCatalogVolumes",
            "databricks/mlflow-tracking",
            "databricks-results",
            "databricks/mlflow-registry",
            "DbfsReserved",
            "DatabricksRoot",
        ]
        mountpoints_count = df[~df["source"].isin(exclude_values)].shape[0]
        mountpoint_doc = get_cloud_article(self.cloud, "MOUNTPOINTS")
        storage_in_uc = get_cloud_article(self.cloud, "ACCESS STORAGE IN UC")

        return (
            f"<li>Your Workspace currently shows <strong>{mountpoints_count}</strong> locations being used as mount points.</li>"
            f"<li>Databricks now recommends using Unity Catalog for managing all data access instead of the <a href='{mountpoint_doc}'>legacy mount access pattern</a>. <a href='{storage_in_uc}'>See Connect to cloud object storage using Unity Catalog</a>.</li>"
            "<li>After migrating the tables, consider unmounting external data locations, as Databricks no longer supports mounting them to Databricks Filesystem.</li>"
        )

    async def render_compute(self) -> str:
        assessment_finding_index = "https://github.com/databrickslabs/ucx/blob/main/docs/assessment.md#assessment-finding-index"
        dataframes_info = {
            "20_0_clusters": "Clusters",
            "30_3_jobs": "Jobs",
            "30_5_submit_runs": "Submit Run",
        }
        html_parts = []
        for df_key, section_name in dataframes_info.items():
            df = await self.data.get_dataframes(df_key)
            if df is None or df.empty:
                html_parts.append(
                    f"<h4>{section_name}</h4><ul><li>No findings.</li></ul>"
                )
                continue

            findings_columns = "finding" if "finding" in df.columns else "problem"
            grouped_df = (
                df.groupby(findings_columns)
                .size()
                .reset_index(name="finding_count")
                .sort_values("finding_count", ascending=False)
            )
            section_html = [f"<h4>{section_name}</h4><ul>"]
            for _, row in grouped_df.iterrows():
                finding = row[findings_columns]
                finding_count = row["finding_count"]
                section_html.append(
                    f"<li><strong>{finding_count}</strong> {section_name.lower()}(s) found with <strong>{finding}</strong> setting.</li>"
                )
            section_html.append("</ul>")
            html_parts.append("".join(section_html))
        html_parts.append(
            f"<p>The <a href={assessment_finding_index}>Assessment Finding Index</a> will explain and provide recommendations for each of the findings.</p>"
        )
        html_parts.append(
            "<h4>Other compute-related recommendations:</h4>"
            "<ul><li>Upgrade cluster runtime to latest LTS version (e.g. 14.3 LTS)."
            "<li>Migrate users with GPU, Distributed ML, Spark Context, R type workloads to Assigned clusters. Implement cluster policies and pools to even out startup time and limit upper cost boundary.</li>"
            "<li>Upgrade SQL only users (and BI tools) to SQL Warehouses (much better SQL / Warehouse experience and lower cost).</li>"
            "<li>For users with single node python ML requirements, Shared Compute with <code>%pip install</code> library support or Personal Compute with pools and compute controls may provide a better experience and better manageability.</li>"
            "<li>For single node ML users on a crowded driver node of a large shared cluster, will get a better experience with Personal Compute policies combined with (warm) Compute pools.</li></ul>"
        )
        return "".join(html_parts)

    async def render_code(self) -> str:
        linter_message_codes = "https://github.com/databrickslabs/ucx/blob/main/README.md#linter-message-codes"
        df = await self.data.get_dataframes("1_code_compatibility_problem")
        if df is None or df.empty:
            return "<li>No findings</li>"
        html = (
            "<p>The table <em>Workflow migration problems</em> in the UCX Assessment Main Dashboard will assist with verifying if workflows and dashboards are Unity Catalog compatible. "
            "It can be filtered on the path, problem code and workflow name.</p>"
        )
        html += (
            "<p>Each Row:</p>"
            "<ul><li>Points to a problem detected in the code using the code path, query or workflow & task reference and start/end line & column.</li>"
            "<li>Explains the problem with a human-readable message and a code.</li></ul>"
        )
        html += f"<p>For additional information related to code compatibility problems, refer to <a href={linter_message_codes}>Linter message Codes</a></p>"
        return html

    def render_identity_and_access(self) -> str:
        uc_permissions_url = get_cloud_article(self.cloud, "UC PRIVILEGES")
        return (
            f"<li>You have some grants that will require migration. You must reproduce those grants using "
            f"<a href='{uc_permissions_url}'>UC permission mechanisms</a>.</li>"
            "<li>Groups in your Workspace where the source is equal to Workspace will need to be migrated to the account level.</li>"
            "<li>Consider adopting a grant strategy that emphasizes assigning permissions to groups rather than individuals.</li>"
            "<li>Additionally, consider managing those groups at the account level and syncing them with your IDP through the SCIM API if it is not currently used.</li>"
        )

    def render_roadmap(self) -> str:
        roadmap_path = _PROJECT_ROOT / "assets/uc_roadmap.png"
        return f"<img alt='Unity Catalog Migration Roadmap' width='100%' src='{roadmap_path}'>"

    async def prepare_full_report_async(self) -> str:
        placeholders = {
            "{html_overview}": self.render_overview(),
            "{html_tables_and_views}": await self.render_tables_and_views(),
            "{html_tables_and_view_rec}": self.render_tables_and_view_rec(),
            "{html_storage_locations}": await self.render_storage_locations(),
            "{html_mount_points}": await self.render_mount_points(),
            "{html_compute}": await self.render_compute(),
            "{html_code}": await self.render_code(),
            "{html_roadmap}": self.render_roadmap(),
            "{html_identity_and_access}": self.render_identity_and_access(),
        }
        html_report = get_html_template()
        for key, value in placeholders.items():
            html_report = html_report.replace(key, value)
        return html_report


class DocumentConverter:
    @staticmethod
    def convert_html_to_docx(
        html_report: str, prefix: str
    ) -> Optional[Tuple[str, BytesIO]]:
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as temp_file:
                temp_file_path = temp_file.name
            pypandoc.convert_text(
                html_report, "docx", format="html", outputfile=temp_file_path
            )
            with open(temp_file_path, "rb") as f:
                docx_buffer = BytesIO(f.read())
            output_file = f"{prefix}_hms_summary.docx"
            return output_file, docx_buffer
        except RuntimeError as e:
            logger.error(f"An error occurred while generating the Word document: {e}")
            return None
        finally:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)


class TableMigrationMatrixGenerator:
    def __init__(self, data: AssessmentData, prefix: str):
        self.data = data
        self.prefix = prefix

    async def generate(self) -> Optional[Tuple[str, BytesIO]]:
        df = await self.data.get_dataframes("all_tables")
        if df is None or df.empty:
            return None

        template_path = _PROJECT_ROOT / "configs/table_migration_template.xlsx"
        workbook = openpyxl.load_workbook(template_path)
        sheet = workbook["Raw_Data"]

        for row_num, row_data in enumerate(df.values.tolist(), start=2):
            for col_num, cell_value in enumerate(row_data, start=1):
                sheet.cell(row=row_num, column=col_num, value=cell_value)

        excel_buffer = BytesIO()
        workbook.save(excel_buffer)
        output_file = f"{self.prefix}_table_migration_matrix.xlsx"
        return output_file, excel_buffer


class UpgradePlanGenerator:
    def __init__(self, data: AssessmentData, cloud: str, prefix: str):
        self.data = data
        self.cloud = cloud.lower().strip()
        self.prefix = prefix

    async def generate(self) -> Optional[Tuple[str, BytesIO]]:
        template_path = _PROJECT_ROOT / "configs/upgrade_plan_template.xlsx"
        workbook = openpyxl.load_workbook(template_path)
        sheets_to_delete = {
            "azure": ["UpgradePlanAWS", "UpgradePlanGCP"],
            "aws": ["UpgradePlanAzure", "UpgradePlanGCP"],
            "gcp": ["UpgradePlanAzure", "UpgradePlanAWS"],
        }.get(self.cloud, [])

        for sheet in sheets_to_delete:
            if sheet in workbook.sheetnames:
                del workbook[sheet]

        excel_buffer = BytesIO()
        workbook.save(excel_buffer)
        output_file = f"{self.prefix}_uc_upgrade_plan.xlsx"
        return output_file, excel_buffer


class ReportZipper:
    @staticmethod
    def zip_reports(reports: Dict[str, Optional[Tuple[str, BytesIO]]]) -> BytesIO:
        zip_buffer = BytesIO()
        with ZipFile(zip_buffer, "w") as zip_file:
            for filename, report_data in reports.items():
                if report_data and report_data[0] and report_data[1]:
                    zip_file.writestr(filename, report_data[1].getvalue())
        zip_buffer.seek(0)
        return zip_buffer


class ReportManager:
    def __init__(self, cloud_provider: str, input_file: UploadFile):
        self.cloud = cloud_provider.lower()
        self.input_file = input_file
        self.assessment_data = AssessmentData(self.input_file)
        self.prefix = str(self.input_file.filename).split("_", maxsplit=1)[0]
        self.html_renderer = HtmlReportRenderer(self.cloud, self.assessment_data)
        self.doc_converter = DocumentConverter()
        self.table_matrix_generator = TableMigrationMatrixGenerator(
            self.assessment_data, self.prefix
        )
        self.upgrade_plan_generator = UpgradePlanGenerator(
            self.assessment_data, self.cloud, self.prefix
        )

    async def generate_hms_report(self) -> Optional[Tuple[str, BytesIO]]:
        html_report = await self.html_renderer.prepare_full_report_async()
        return self.doc_converter.convert_html_to_docx(html_report, self.prefix)

    async def generate_table_migration_matrix(self) -> Optional[Tuple[str, BytesIO]]:
        return await self.table_matrix_generator.generate()

    async def generate_upgrade_plan(self) -> Optional[Tuple[str, BytesIO]]:
        return await self.upgrade_plan_generator.generate()

    async def generate_zipped_report(self) -> BytesIO:
        reports = {
            "hms_report.docx": await self.generate_hms_report(),
            "tbl_migration_matrix.xlsx": await self.generate_table_migration_matrix(),
            "upgrade_plan.xlsx": await self.generate_upgrade_plan(),
        }
        return ReportZipper.zip_reports(reports)
