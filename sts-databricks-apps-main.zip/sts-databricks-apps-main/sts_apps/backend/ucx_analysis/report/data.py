from typing import Any
from io import BytesIO
from zipfile import ZipFile
import pandas as pd
import asyncio
from fastapi import UploadFile
from databricks.labs.blueprint.parallel import Threads


class AssessmentData:
    def __init__(self, uploaded_file: UploadFile):
        self.path: UploadFile = uploaded_file
        self.ucx_dataframes: list[dict[str, Any]] = []
        self._data_ready = asyncio.Event()

        asyncio.create_task(self._compute_dataframes())

    @staticmethod
    def _load_excel_sheet(sheet: str, file_bytes: bytes) -> dict[str, Any]:
        """Load a single Excel sheet into a DataFrame."""
        with BytesIO(file_bytes) as byte_io:
            df = pd.read_excel(byte_io, sheet_name=sheet, engine="openpyxl")
        return {"source": sheet, "data": df}

    @staticmethod
    def _load_csv_file(file_name: str, zip_content: bytes) -> dict[str, Any]:
        """Load a single CSV file inside a ZIP into a DataFrame."""
        with ZipFile(BytesIO(zip_content), "r") as zip_file:
            with zip_file.open(file_name) as csv_file:
                df = pd.read_csv(csv_file)
        return {"source": file_name, "data": df}

    async def _compute_dataframes(self):
        """Load all sheets into dataframes concurrently and store them."""
        file_content = await self.path.read()

        if self.path.content_type is not None:
            if "spreadsheetml.sheet" in self.path.content_type:
                with BytesIO(file_content) as byte_io:
                    sheets = pd.ExcelFile(byte_io).sheet_names

                # Create a separate copy of the file bytes for each thread
                tasks = [
                    lambda s=s, fc=file_content: self._load_excel_sheet(s, fc)
                    for s in sheets
                ]
                self.ucx_dataframes = Threads.strict("Load Excel Sheets", tasks)

            else:
                with ZipFile(BytesIO(file_content), "r") as zip_file:
                    csv_files = [f for f in zip_file.namelist() if f.endswith(".csv")]

                # Create a separate copy of the file bytes for each thread
                tasks = [
                    lambda f=f, fc=file_content: self._load_csv_file(f, fc)
                    for f in csv_files
                ]
                self.ucx_dataframes = Threads.strict("Load CSV Files", tasks)

        self._data_ready.set()

    async def get_dataframes(self, data_sheet: str) -> pd.DataFrame | None:
        """Retrieve the dataframe for a specific sheet name, waiting for computation if necessary."""
        await self._data_ready.wait()

        for item in self.ucx_dataframes:
            if data_sheet in item["source"]:
                return item["data"].copy()
        return None
