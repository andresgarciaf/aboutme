import abc
import os
import logging
from functools import cached_property

from databricks.labs.lsql.backends import SqlBackend, StatementExecutionBackend

from databricks.sdk import WorkspaceClient


logger = logging.getLogger(__name__)


class GlobalContext(abc.ABC):
    @cached_property
    def workspace_client(self) -> WorkspaceClient:
        raise ValueError("Workspace client not set")

    @cached_property
    def sql_backend(self) -> SqlBackend:
        raise ValueError("SQL backend not set")


class WorkspaceContext(GlobalContext):
    @cached_property
    def workspace_client(self) -> WorkspaceClient:
        return WorkspaceClient()

    @cached_property
    def sql_backend(self) -> SqlBackend:
        return StatementExecutionBackend(
            self.workspace_client, os.getenv("DATABRICKS_WAREHOUSE_ID")
        )
