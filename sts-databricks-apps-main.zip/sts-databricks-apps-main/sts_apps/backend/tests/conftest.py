"""
Pytest configuration and shared fixtures for backend tests.
"""
import pytest
import openpyxl
import tempfile
import os
from fastapi.testclient import TestClient
from backend.main import app


@pytest.fixture
def client():
    """Test client for FastAPI app."""
    return TestClient(app)


@pytest.fixture
def sample_lakebridge_data():
    """Sample data for Lakebridge tests."""
    return {
        "files": [
            {
                "name": "sample_notebook.py",
                "content": "# Sample notebook content"
            }
        ]
    }


@pytest.fixture
def sample_ucx_data():
    """Sample data for UCX tests."""
    return {
        "cloud_provider": "aws",
        "files": [
            {
                "name": "sample_workspace.json",
                "content": '{"workspace": "sample"}'
            }
        ]
    }


def create_sample_workbook_basic(path):
    """Create a basic sample workbook for testing."""
    wb = openpyxl.Workbook()
    if 'Sheet' in wb.sheetnames:
        ws = wb['Sheet']
        ws.title = 'Mapping Details'
    else:
        ws = wb.create_sheet('Mapping Details')
    # Header
    ws.append(['A', 'Folder', 'C', 'D', 'Mapping Type', 'Categorization', 'Number of Nodes'])
    # Data
    ws.append(['', 'FolderA', '', '', 'Workflow', 'Low', 10])
    ws.append(['', 'FolderA', '', '', 'Mapping', 'Medium', 15])
    ws.append(['', 'FolderA', '', '', 'Workflow', 'Low', 5])
    ws.append(['', 'FolderB', '', '', 'Mapping', 'Complex', 20])
    ws.append(['', 'FolderB', '', '', 'Mapping', 'Very Complex', 25])
    ws.append(['', 'FolderC', '', '', 'Mapping', 'Low', 2])
    wb.save(path)


def create_sample_workbook_with_mapping_names(path):
    """Create a sample workbook with mapping names for job complexity tests."""
    wb = openpyxl.Workbook()
    if 'Sheet' in wb.sheetnames:
        ws = wb['Sheet']
        ws.title = 'Mapping Details'
    else:
        ws = wb.create_sheet('Mapping Details')
    # Header
    ws.append(['Mapping Name', 'Folder', 'C', 'D', 'Mapping Type', 'Categorization', 'Number of Nodes'])
    # Data
    ws.append(['Mapping1', 'FolderA', '', '', 'Workflow', 'Low', 10])
    ws.append(['Mapping2', 'FolderA', '', '', 'Mapping', 'Medium', 15])
    ws.append(['Mapping3', 'FolderA', '', '', 'Workflow', 'Low', 5])
    ws.append(['Mapping4', 'FolderB', '', '', 'Mapping', 'Complex', 20])
    ws.append(['Mapping5', 'FolderB', '', '', 'Mapping', 'Very Complex', 25])
    ws.append(['Mapping6', 'FolderC', '', '', 'Mapping', 'Low', 2])
    wb.save(path) 