"""
Tests for UCX analysis functionality.
"""
import pytest


def test_ucx_analysis_import():
    """Test that UCX analysis module can be imported."""
    try:
        from backend.ucx_analysis import report
        assert report is not None
    except ImportError:
        pytest.skip("UCX analysis module not available")


def test_ucx_config_loading():
    """Test that UCX configuration can be loaded."""
    try:
        import backend.ucx_analysis.configs
        assert backend.ucx_analysis.configs is not None
    except ImportError:
        pytest.skip("UCX config module not available")


def test_ucx_utils():
    """Test UCX utility functions."""
    try:
        from backend.ucx_analysis.utils import helper
        assert helper is not None
    except ImportError:
        pytest.skip("UCX utils module not available")


def test_ucx_report_manager():
    """Test that ReportManager can be imported."""
    try:
        from backend.ucx_analysis.report.analysis import ReportManager
        assert ReportManager is not None
    except ImportError:
        pytest.skip("UCX ReportManager not available") 