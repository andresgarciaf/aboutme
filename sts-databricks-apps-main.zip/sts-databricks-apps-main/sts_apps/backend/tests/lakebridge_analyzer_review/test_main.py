"""
Tests for the main.py API endpoints.
"""

import pytest
import tempfile
import os
from fastapi.testclient import TestClient
from unittest.mock import patch

# Import the app
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.main import app

client = TestClient(app)


def test_lakebridge_endpoint_structure():
    """Test that the Lakebridge endpoint structure is correct."""
    # The actual endpoint is /api/lakebridge-analyzer-review/
    # This test validates the endpoint structure
    from backend.api.lakebridge.routes import router as lakebridge_router
    assert lakebridge_router is not None
    assert len(lakebridge_router.routes) > 0


@patch('backend.lakebridge_analyzer_review.reviewer.LakebridgeReviewer.review_multiple_files')
def test_lakebridge_endpoint_success(mock_review):
    """Test the Lakebridge endpoint with valid files."""
    # Mock the review function to return a temporary PDF
    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as temp_pdf:
        temp_pdf.write(b"Fake PDF content")
        temp_pdf_path = temp_pdf.name
    
    mock_review.return_value = temp_pdf_path
    
    try:
        # Create a test Excel file
        with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
            import openpyxl
            wb = openpyxl.Workbook()
            ws = wb.active
            if ws is not None:  # Add null check
                ws.title = "SQL Programs"
                ws['A1'] = "Program Name"
                ws['G1'] = "Procedure And Function Counts"
                ws['A2'] = "Test Program"
                ws['G2'] = 1
            wb.save(temp_file.name)
            temp_file_path = temp_file.name
        
        try:
            with open(temp_file_path, 'rb') as f:
                response = client.post(
                    "/api/lakebridge-analyzer-review/",
                    files={"files": ("test.xlsx", f, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}
                )
            
            assert response.status_code == 200
            assert response.headers["content-type"] == "application/pdf"
            # Check that the filename contains the expected pattern with date
            content_disposition = response.headers["content-disposition"]
            assert content_disposition.startswith('attachment; filename="comprehensive_analysis_report_')
            assert content_disposition.endswith('.pdf"')
            
        finally:
            os.unlink(temp_file_path)
            
    finally:
        os.unlink(temp_pdf_path)


if __name__ == "__main__":
    pytest.main([__file__]) 