import os
import tempfile
from backend.lakebridge_analyzer_review.reports.pdf_generator import PDFGenerator


def test_table_rendering_with_oversize_data():
    """Test that tables render correctly with visible headers and proper data."""
    generator = PDFGenerator()
    
    # Test data with oversize files to trigger table creation
    oversize_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_rows': 10,
            'oversize_files_count': 2,
            'percentage': 20.0,
            'oversize_files': [
                {
                    'row': 3,
                    'value': 5,
                    'program_name': 'Program1'
                },
                {
                    'row': 7,
                    'value': 3,
                    'program_name': 'Program2'
                }
            ]
        }
    ]
    
    version_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'version_number': '5.6.4',
            'required_version': '5.6.4',
            'is_old_version': False
        }
    ]
    
    duplicate_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_programs': 5,
            'duplicate_groups_count': 0,
            'duplicate_programs_count': 0,
            'duplicate_groups': []
        }
    ]
    
    # Generate PDF
    pdf_path = generator.generate_report(oversize_results, version_results, duplicate_results)
    
    # Check that PDF was created and has content
    assert os.path.exists(pdf_path)
    assert pdf_path.endswith('.pdf')
    assert os.path.getsize(pdf_path) > 1000  # Should be more than 1KB for a proper PDF
    
    print(f"PDF generated successfully: {pdf_path}")
    print(f"PDF size: {os.path.getsize(pdf_path)} bytes")
    
    # Clean up
    os.unlink(pdf_path)


if __name__ == "__main__":
    import pytest
    pytest.main([__file__]) 