import unittest
import tempfile
import os
from openpyxl import Workbook
from backend.lakebridge_analyzer_review.checks.version_check import VersionCheck

class TestVersionCheck(unittest.TestCase):
    def setUp(self):
        self.check = VersionCheck()
        self.temp_dir = tempfile.mkdtemp()
    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir)
    def _create_excel(self, version_value=None, sheet_name="Summary", cell="F1"):
        wb = Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = sheet_name
            if version_value is not None:
                ws[cell] = version_value
        file_path = os.path.join(self.temp_dir, "test_version.xlsx")
        wb.save(file_path)
        return file_path
    def test_correct_version(self):
        file_path = self._create_excel("Analyzer Version: 5.6.4 Build 20240601", cell="F1")
        result = self.check.check(file_path, "test_version.xlsx")
        self.assertTrue(result['success'])
        self.assertFalse(result['is_old_version'])
        self.assertEqual(result['version_number'], "5.6.4")
    def test_old_version(self):
        file_path = self._create_excel("Analyzer Version: 5.5.0 Build 20240601", cell="F1")
        result = self.check.check(file_path, "test_version.xlsx")
        self.assertTrue(result['success'])
        self.assertTrue(result['is_old_version'])
        self.assertEqual(result['version_number'], "5.5.0")
    def test_missing_sheet(self):
        file_path = self._create_excel("Analyzer Version: 5.6.4 Build 20240601", sheet_name="NotSummary", cell="F1")
        result = self.check.check(file_path, "test_version.xlsx")
        self.assertFalse(result['success'])
        self.assertIn("Summary", result['error'])
    def test_missing_version_cell(self):
        file_path = self._create_excel(None, cell="F1")
        result = self.check.check(file_path, "test_version.xlsx")
        self.assertFalse(result['success'])
        self.assertIn("E1:F1", result['error'])

if __name__ == '__main__':
    unittest.main() 