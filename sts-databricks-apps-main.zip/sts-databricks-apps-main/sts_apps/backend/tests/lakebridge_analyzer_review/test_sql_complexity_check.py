import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os
from backend.lakebridge_analyzer_review.checks.sql_complexity_check import SQLComplexityCheck


class TestSQLComplexityCheck(unittest.TestCase):
    """Test cases for SQL Complexity Analysis check."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.check = SQLComplexityCheck()
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        self.temp_file.close()
    
    def tearDown(self):
        """Clean up test fixtures."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)
    
    @patch('openpyxl.load_workbook')
    def test_check_success_with_complex_files(self, mock_load_workbook):
        """Test successful analysis with complex files."""
        # Mock SQL sheet
        mock_sql_sheet = Mock()
        
        # Mock SQL Programs sheet data (tuples of real values)
        # Column A: File Name, Column E: Complexity, Column L: Script Type
        mock_sql_sheet.iter_rows.return_value = [
            # 10 low
            *[(f'file{i+1}.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL') for i in range(10)],
            # 20 medium
            *[(f'file{i+11}.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL') for i in range(20)],
            # 5 complex
            *[(f'file{i+31}.sql', '', '', '', 'complex', '', '', '', '', '', '', 'SQL') for i in range(5)],
            # 3 very_complex
            *[(f'file{i+36}.sql', '', '', '', 'very_complex', '', '', '', '', '', '', 'SQL') for i in range(3)],
            # Non-SQL files (should be ignored)
            ('file39.py', '', '', '', 'complex', '', '', '', '', '', '', 'PYTHON'),
            ('file40.java', '', '', '', 'very_complex', '', '', '', '', '', '', 'JAVA'),
        ]
        
        # Create workbook with MagicMock for subscripting
        mock_workbook = MagicMock()
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sql_sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test.xlsx')
        
        # Verify results
        self.assertTrue(result['success'])
        self.assertEqual(result['filename'], 'test.xlsx')
        self.assertEqual(result['total_files'], 38)  # 38 SQL files
        self.assertEqual(result['complexity_counts']['low'], 10)
        self.assertEqual(result['complexity_counts']['medium'], 20)
        self.assertEqual(result['complexity_counts']['complex'], 5)
        self.assertEqual(result['complexity_counts']['very_complex'], 3)
        self.assertTrue(result['has_complex_files'])
        self.assertEqual(len(result['complex_files']), 5)
        self.assertEqual(len(result['very_complex_files']), 3)
    
    @patch('openpyxl.load_workbook')
    def test_check_success_no_complex_files(self, mock_load_workbook):
        """Test successful analysis with no complex files."""
        # Mock SQL sheet
        mock_sql_sheet = Mock()
        
        # Mock SQL Programs sheet data - no complex files (tuples of real values)
        # Column A: File Name, Column E: Complexity, Column L: Script Type
        mock_sql_sheet.iter_rows.return_value = [
            ('file1.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file2.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file3.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file4.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file5.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file6.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file7.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file8.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file9.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file10.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file11.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file12.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file13.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file14.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file15.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file16.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file17.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file18.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file19.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file20.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file21.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file22.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file23.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file24.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file25.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file26.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file27.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file28.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file29.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file30.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file31.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file32.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file33.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file34.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file35.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file36.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file37.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file38.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file39.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file40.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            # Non-SQL files (should be ignored)
            ('file41.py', '', '', '', 'complex', '', '', '', '', '', '', 'PYTHON'),
            ('file42.java', '', '', '', 'very_complex', '', '', '', '', '', '', 'JAVA'),
        ]
        
        # Create workbook with MagicMock for subscripting
        mock_workbook = MagicMock()
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sql_sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test.xlsx')
        
        # Verify results
        self.assertTrue(result['success'])
        self.assertEqual(result['filename'], 'test.xlsx')
        self.assertEqual(result['total_files'], 40)  # 40 SQL files
        self.assertFalse(result['has_complex_files'])
        self.assertEqual(len(result['complex_files']), 0)
        self.assertEqual(len(result['very_complex_files']), 0)
    
    @patch('openpyxl.load_workbook')
    def test_check_missing_sql_programs_sheet(self, mock_load_workbook):
        """Test error handling when SQL Programs sheet is missing."""
        mock_workbook = Mock()
        mock_workbook.sheetnames = ['Summary']  # Missing SQL Programs sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test.xlsx')
        
        # Verify error result
        self.assertFalse(result['success'])
        self.assertIn('SQL Programs', result['error'])
    
    @patch('openpyxl.load_workbook')
    def test_check_empty_sql_programs_sheet(self, mock_load_workbook):
        """Test handling of empty SQL Programs sheet."""
        mock_sql_sheet = Mock()
        mock_sql_sheet.iter_rows.return_value = []  # Empty sheet
        
        # Create workbook with MagicMock for subscripting
        mock_workbook = MagicMock()
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sql_sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test.xlsx')
        
        # Verify results for empty sheet
        self.assertTrue(result['success'])
        self.assertEqual(result['total_files'], 0)
        self.assertFalse(result['has_complex_files'])
        self.assertEqual(len(result['complex_files']), 0)
        self.assertEqual(len(result['very_complex_files']), 0)
    
    @patch('openpyxl.load_workbook')
    def test_check_mixed_script_types(self, mock_load_workbook):
        """Test filtering for SQL files only."""
        mock_sql_sheet = Mock()
        
        # Mock SQL Programs sheet data with mixed script types
        mock_sql_sheet.iter_rows.return_value = [
            ('file1.sql', '', '', '', 'complex', '', '', '', '', '', '', 'SQL'),
            ('file2.py', '', '', '', 'very_complex', '', '', '', '', '', '', 'PYTHON'),
            ('file3.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('file4.java', '', '', '', 'medium', '', '', '', '', '', '', 'JAVA'),
            ('file5.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),
            ('file6.scala', '', '', '', 'complex', '', '', '', '', '', '', 'SCALA'),
            ('file7.sql', '', '', '', 'very_complex', '', '', '', '', '', '', 'SQL'),
        ]
        
        # Create workbook with MagicMock for subscripting
        mock_workbook = MagicMock()
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sql_sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test.xlsx')
        
        # Verify results - only SQL files should be counted
        self.assertTrue(result['success'])
        self.assertEqual(result['total_files'], 4)  # Only 4 SQL files
        self.assertEqual(result['complexity_counts']['low'], 1)
        self.assertEqual(result['complexity_counts']['medium'], 1)
        self.assertEqual(result['complexity_counts']['complex'], 1)
        self.assertEqual(result['complexity_counts']['very_complex'], 1)
        self.assertTrue(result['has_complex_files'])
        self.assertEqual(len(result['complex_files']), 1)
        self.assertEqual(len(result['very_complex_files']), 1)
    
    @patch('openpyxl.load_workbook')
    def test_check_case_insensitive_filtering(self, mock_load_workbook):
        """Test case insensitive filtering for SQL files."""
        mock_sql_sheet = Mock()
        
        # Mock SQL Programs sheet data with different case variations
        mock_sql_sheet.iter_rows.return_value = [
            ('file1.sql', '', '', '', 'complex', '', '', '', '', '', '', 'sql'),
            ('file2.sql', '', '', '', 'very_complex', '', '', '', '', '', '', 'SQL'),
            ('file3.sql', '', '', '', 'low', '', '', '', '', '', '', 'Sql'),
            ('file4.sql', '', '', '', 'medium', '', '', '', '', '', '', 'sQL'),
        ]
        
        # Create workbook with MagicMock for subscripting
        mock_workbook = MagicMock()
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sql_sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test.xlsx')
        
        # Verify results - all SQL files should be counted regardless of case
        self.assertTrue(result['success'])
        self.assertEqual(result['total_files'], 4)  # All 4 SQL files
        self.assertEqual(result['complexity_counts']['low'], 1)
        self.assertEqual(result['complexity_counts']['medium'], 1)
        self.assertEqual(result['complexity_counts']['complex'], 1)
        self.assertEqual(result['complexity_counts']['very_complex'], 1)
        self.assertTrue(result['has_complex_files'])
        self.assertEqual(len(result['complex_files']), 1)
        self.assertEqual(len(result['very_complex_files']), 1)


if __name__ == '__main__':
    unittest.main() 