import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os
from backend.lakebridge_analyzer_review.reviewer import LakebridgeReviewer


class TestReviewerIntegration(unittest.TestCase):
    """Test integration of ETL complexity check in the reviewer."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.reviewer = LakebridgeReviewer()
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        self.temp_file.close()
    
    def tearDown(self):
        """Clean up test fixtures."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)
    
    def test_etl_complexity_check_integration(self):
        """Test that ETL complexity check is properly integrated."""
        # Verify that ETL complexity check is initialized
        self.assertIsNotNone(self.reviewer.etl_complexity_check)
        self.assertEqual(self.reviewer.etl_complexity_check.script_type, "ETL")
        
        # Verify that ETL complexity check is configured for SQL files
        self.assertIn('etl_complexity', self.reviewer.file_type_checks['SQL'])
    
    @patch('openpyxl.load_workbook')
    def test_reviewer_with_sql_file_type_runs_both_complexity_checks(self, mock_load_workbook):
        """Test that reviewer runs both SQL and ETL complexity checks for SQL files."""
        # Mock workbook for file type detection
        mock_workbook = MagicMock()
        
        # Mock Summary sheet with SQL in F10
        mock_summary_sheet = MagicMock()
        mock_cell = Mock()
        mock_cell.value = 'SQL'
        mock_summary_sheet.__getitem__.return_value = mock_cell
        mock_workbook.sheetnames = ['Summary', 'SQL Programs']
        
        # Mock SQL Programs sheet with both SQL and ETL data
        mock_sql_sheet = Mock()
        mock_sql_sheet.iter_rows.return_value = [
            ('sql_file1.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),
            ('sql_file2.sql', '', '', '', 'complex', '', '', '', '', '', '', 'SQL'),
            ('etl_file1.sql', '', '', '', 'medium', '', '', '', '', '', '', 'ETL'),
            ('etl_file2.sql', '', '', '', 'very_complex', '', '', '', '', '', '', 'ETL'),
        ]
        mock_workbook.__getitem__.side_effect = lambda x: mock_summary_sheet if x == 'Summary' else mock_sql_sheet
        
        mock_load_workbook.return_value = mock_workbook
        
        # Mock other checks to avoid running them
        with patch.object(self.reviewer.version_check, 'check') as mock_version, \
             patch.object(self.reviewer.duplicate_check, 'check') as mock_duplicate, \
             patch.object(self.reviewer.oversize_check, 'check') as mock_oversize, \
             patch.object(self.reviewer.uncategorized_check, 'check') as mock_uncategorized, \
             patch.object(self.reviewer.sql_complexity_check, 'check') as mock_sql_complexity, \
             patch.object(self.reviewer.etl_complexity_check, 'check') as mock_etl_complexity, \
             patch.object(self.reviewer.pdf_generator, 'generate_report') as mock_pdf:
            
            # Mock successful results
            mock_version.return_value = {'success': True, 'filename': 'test.xlsx'}
            mock_duplicate.return_value = {'success': True, 'filename': 'test.xlsx'}
            mock_oversize.return_value = {'success': True, 'filename': 'test.xlsx'}
            mock_uncategorized.return_value = {'success': True, 'filename': 'test.xlsx'}
            mock_sql_complexity.return_value = {
                'success': True, 
                'filename': 'test.xlsx',
                'total_files': 2,
                'has_complex_files': True,
                'script_type': 'SQL'
            }
            mock_etl_complexity.return_value = {
                'success': True, 
                'filename': 'test.xlsx',
                'total_files': 2,
                'has_complex_files': True,
                'script_type': 'ETL'
            }
            mock_pdf.return_value = '/tmp/test_report.pdf'
            
            # Run the reviewer
            result = self.reviewer.review_multiple_files([self.temp_file.name], ['test.xlsx'])
            
            # Verify that both complexity checks were called
            mock_sql_complexity.assert_called_once_with(self.temp_file.name, 'test.xlsx')
            mock_etl_complexity.assert_called_once_with(self.temp_file.name, 'test.xlsx')
            
            # Verify that PDF generator was called with both complexity results
            call_args = mock_pdf.call_args[0]
            self.assertEqual(len(call_args), 10)  # Should have 10 arguments including both complexity results and unsupported transformations


if __name__ == '__main__':
    unittest.main() 