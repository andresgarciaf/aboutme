import unittest
import tempfile
import os
from unittest.mock import Mock, patch
from backend.lakebridge_analyzer_review.checks.uncategorized_check import UncatagorizedCheck


class TestUncatagorizedCheck(unittest.TestCase):
    
    def setUp(self):
        self.check = UncatagorizedCheck()
    
    def test_check_with_uncategorized_files(self):
        """Test that uncategorized files are correctly identified."""
        # Mock workbook and sheet
        mock_workbook = Mock()
        mock_sheet = Mock()
        
        # Mock data with some uncategorized files
        mock_data = [
            ['Program1', None, None, 100, None, None, None, 'UNKNOWN'],  # Uncategorized
            ['Program2', None, None, 200, None, None, None, 'READ_DML'],  # Categorized
            ['Program3', None, None, 150, None, None, None, 'UNKNOWN'],  # Uncategorized
            ['Program4', None, None, 300, None, None, None, 'UNKNOWN,READ_DML'],  # Not exactly UNKNOWN
        ]
        
        # Create proper mock rows that match the expected structure
        mock_rows = []
        for row_data in mock_data:
            mock_rows.append(row_data)
        
        mock_sheet.iter_rows.return_value = mock_rows
        
        with patch.object(self.check, 'load_excel_file', return_value=mock_workbook), \
             patch.object(self.check, 'get_sheet', return_value=mock_sheet):
            
            result = self.check.check('dummy_path.xlsx', 'test_file.xlsx')
            
            self.assertTrue(result['success'])
            self.assertEqual(result['uncategorized_files_count'], 2)
            self.assertEqual(len(result['uncategorized_files']), 2)
            
            # Check first uncategorized file
            self.assertEqual(result['uncategorized_files'][0]['row'], 2)
            self.assertEqual(result['uncategorized_files'][0]['program_name'], 'Program1')
            self.assertEqual(result['uncategorized_files'][0]['line_count'], 100)
            
            # Check second uncategorized file
            self.assertEqual(result['uncategorized_files'][1]['row'], 4)
            self.assertEqual(result['uncategorized_files'][1]['program_name'], 'Program3')
            self.assertEqual(result['uncategorized_files'][1]['line_count'], 150)
    
    def test_check_with_no_uncategorized_files(self):
        """Test when no uncategorized files are found."""
        mock_workbook = Mock()
        mock_sheet = Mock()
        
        # Mock data with no uncategorized files
        mock_data = [
            ['Program1', None, None, 100, None, None, None, 'READ_DML'],
            ['Program2', None, None, 200, None, None, None, 'WRITE_DML'],
            ['Program3', None, None, 150, None, None, None, 'UNKNOWN,READ_DML'],  # Not exactly UNKNOWN
        ]
        
        # Create proper mock rows that match the expected structure
        mock_rows = []
        for row_data in mock_data:
            mock_rows.append(row_data)
        
        mock_sheet.iter_rows.return_value = mock_rows
        
        with patch.object(self.check, 'load_excel_file', return_value=mock_workbook), \
             patch.object(self.check, 'get_sheet', return_value=mock_sheet):
            
            result = self.check.check('dummy_path.xlsx', 'test_file.xlsx')
            
            self.assertTrue(result['success'])
            self.assertEqual(result['uncategorized_files_count'], 0)
            self.assertEqual(len(result['uncategorized_files']), 0)
    
    def test_check_with_excel_load_error(self):
        """Test error handling when Excel file cannot be loaded."""
        with patch.object(self.check, 'load_excel_file', return_value=None):
            result = self.check.check('dummy_path.xlsx', 'test_file.xlsx')
            
            self.assertFalse(result['success'])
            self.assertIn('Failed to load Excel file', result['error'])
    
    def test_check_with_missing_sheet(self):
        """Test error handling when SQL Programs sheet is missing."""
        mock_workbook = Mock()
        
        with patch.object(self.check, 'load_excel_file', return_value=mock_workbook), \
             patch.object(self.check, 'get_sheet', return_value=None):
            
            result = self.check.check('dummy_path.xlsx', 'test_file.xlsx')
            
            self.assertFalse(result['success'])
            self.assertIn('Sheet \'SQL Programs\' not found', result['error'])


if __name__ == '__main__':
    unittest.main() 