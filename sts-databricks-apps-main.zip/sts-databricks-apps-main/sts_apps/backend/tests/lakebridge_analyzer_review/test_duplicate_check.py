import unittest
import tempfile
import os
from openpyxl import Workbook
from backend.lakebridge_analyzer_review.checks.duplicate_check import DuplicateCheck

class TestDuplicateCheck(unittest.TestCase):
    def setUp(self):
        self.check = DuplicateCheck()
        self.temp_dir = tempfile.mkdtemp()
    def tearDown(self):
        import shutil
        shutil.rmtree(self.temp_dir)
    def _create_excel(self, names, sheet_name="SQL Programs"):
        wb = Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = sheet_name
            ws['A1'] = "Program Name"
            for i, name in enumerate(names, start=2):
                ws[f'A{i}'] = name
        file_path = os.path.join(self.temp_dir, "test_duplicate.xlsx")
        wb.save(file_path)
        return file_path
    def test_duplicates_found(self):
        # Names with numeric suffixes
        file_path = self._create_excel(["prog1", "prog2", "prog1_2", "prog1_3"])
        result = self.check.check(file_path, "test_duplicate.xlsx")
        self.assertTrue(result['success'])
        self.assertGreater(result['duplicate_groups_count'], 0)
        self.assertGreater(result['duplicate_programs_count'], 0)
    def test_no_duplicates(self):
        file_path = self._create_excel(["alpha", "beta", "gamma"])
        result = self.check.check(file_path, "test_duplicate.xlsx")
        self.assertTrue(result['success'])
        self.assertEqual(result['duplicate_groups_count'], 0)
        self.assertEqual(result['duplicate_programs_count'], 0)
    def test_missing_sheet(self):
        file_path = self._create_excel(["prog1", "prog2"], sheet_name="NotSQL")
        result = self.check.check(file_path, "test_duplicate.xlsx")
        self.assertFalse(result['success'])
        self.assertIn("SQL Programs", result['error'])
    def test_empty_file(self):
        wb = Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "SQL Programs"
        file_path = os.path.join(self.temp_dir, "test_duplicate.xlsx")
        wb.save(file_path)
        result = self.check.check(file_path, "test_duplicate.xlsx")
        self.assertTrue(result['success'])
        self.assertEqual(result['duplicate_groups_count'], 0)
        self.assertEqual(result['duplicate_programs_count'], 0)

if __name__ == '__main__':
    unittest.main() 