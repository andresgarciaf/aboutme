import unittest
import tempfile
import os
from unittest.mock import patch
from backend.lakebridge_analyzer_review.checks.etl_complexity_check import ETLComplexityCheck


class TestETLComplexityRealData(unittest.TestCase):
    """Test ETL complexity check with real Excel data."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.check = ETLComplexityCheck()
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        self.temp_file.close()
    
    def tearDown(self):
        """Clean up test fixtures."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)
    
    def test_etl_complexity_with_real_excel_data(self):
        """Test ETL complexity analysis with real Excel file containing ETL data."""
        # Create a real Excel file with ETL data
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "SQL Programs"
            
            # Add headers (columns A, E, L)
            ws['A1'] = "File Name"
            ws['E1'] = "Complexity"
            ws['L1'] = "Script Type"
            
            # Add ETL data
            ws['A2'] = "etl_file1.sql"
            ws['E2'] = "low"
            ws['L2'] = "ETL"
            
            ws['A3'] = "etl_file2.sql"
            ws['E3'] = "medium"
            ws['L3'] = "ETL"
            
            ws['A4'] = "etl_file3.sql"
            ws['E4'] = "complex"
            ws['L4'] = "ETL"
            
            ws['A5'] = "etl_file4.sql"
            ws['E5'] = "very_complex"
            ws['L5'] = "ETL"
            
            # Add some SQL files (should be ignored)
            ws['A6'] = "sql_file1.sql"
            ws['E6'] = "complex"
            ws['L6'] = "SQL"
        
        wb.save(self.temp_file.name)
        
        # Run the ETL complexity check
        result = self.check.check(self.temp_file.name, 'test_etl.xlsx')
        
        # Verify the result
        self.assertTrue(result['success'])
        self.assertEqual(result['filename'], 'test_etl.xlsx')
        self.assertEqual(result['total_files'], 4)  # Only ETL files
        self.assertEqual(result['complexity_counts']['low'], 1)
        self.assertEqual(result['complexity_counts']['medium'], 1)
        self.assertEqual(result['complexity_counts']['complex'], 1)
        self.assertEqual(result['complexity_counts']['very_complex'], 1)
        self.assertTrue(result['has_complex_files'])
        self.assertEqual(result['script_type'], 'ETL')
        
        # Check percentages
        self.assertEqual(result['percentages']['low'], 25.0)
        self.assertEqual(result['percentages']['medium'], 25.0)
        self.assertEqual(result['percentages']['complex'], 25.0)
        self.assertEqual(result['percentages']['very_complex'], 25.0)
        
        # Check that complex files are captured
        self.assertEqual(len(result['complex_files']), 1)
        self.assertEqual(len(result['very_complex_files']), 1)
        self.assertEqual(result['complex_files'][0]['file_name'], 'etl_file3.sql')
        self.assertEqual(result['very_complex_files'][0]['file_name'], 'etl_file4.sql')
    
    def test_etl_complexity_no_etl_files(self):
        """Test ETL complexity analysis when no ETL files are present."""
        # Create a real Excel file with only SQL data
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "SQL Programs"
            
            # Add headers
            ws['A1'] = "File Name"
            ws['E1'] = "Complexity"
            ws['L1'] = "Script Type"
            
            # Add only SQL data
            ws['A2'] = "sql_file1.sql"
            ws['E2'] = "low"
            ws['L2'] = "SQL"
            
            ws['A3'] = "sql_file2.sql"
            ws['E3'] = "complex"
            ws['L3'] = "SQL"
        
        wb.save(self.temp_file.name)
        
        # Run the ETL complexity check
        result = self.check.check(self.temp_file.name, 'test_sql_only.xlsx')
        
        # Verify the result
        self.assertTrue(result['success'])
        self.assertEqual(result['filename'], 'test_sql_only.xlsx')
        self.assertEqual(result['total_files'], 0)  # No ETL files
        self.assertFalse(result['has_complex_files'])
        self.assertEqual(result['script_type'], 'ETL')
        
        # Check percentages (all should be 0)
        for complexity in ['low', 'medium', 'complex', 'very_complex']:
            self.assertEqual(result['percentages'][complexity], 0)


if __name__ == '__main__':
    unittest.main() 