import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os
from openpyxl import Workbook
from backend.lakebridge_analyzer_review.checks.unsupported_transformations_check import UnsupportedTransformationsCheck


class TestUnsupportedTransformationsCheck(unittest.TestCase):
    """Test cases for UnsupportedTransformationsCheck."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.check = UnsupportedTransformationsCheck()
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def create_test_excel_file(self, transformations_data):
        """Create a test Excel file with Transformations sheet data."""
        wb = Workbook()
        
        # Remove default sheet
        if wb.active:
            wb.remove(wb.active)
        
        # Create Transformations sheet
        ws = wb.create_sheet("Transformations")
        
        # Add header
        ws['A1'] = "Transformation Name"
        ws['B1'] = "# of Occurrences"
        ws['D1'] = "Supported"
        
        # Add data
        for i, (name, occurrences, supported) in enumerate(transformations_data, start=2):
            ws[f'A{i}'] = name
            ws[f'B{i}'] = occurrences
            ws[f'D{i}'] = supported
        
        # Save to temporary file
        file_path = os.path.join(self.temp_dir, "test_transformations.xlsx")
        wb.save(file_path)
        return file_path
    
    def test_successful_analysis_with_mixed_transformations(self):
        """Test successful analysis with both supported and unsupported transformations."""
        transformations_data = [
            ("Source Qualifier", 10, "Yes"),
            ("Expression", 15, "Yes"),
            ("Filter", 8, "Yes"),
            ("Custom Transformation", 5, "No"),
            ("Java Transformation", 3, "No"),
            ("Stored Procedure", 2, "No")
        ]
        
        file_path = self.create_test_excel_file(transformations_data)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['supported_count'], 3)
        self.assertEqual(result['unsupported_count'], 3)
        self.assertEqual(result['total_count'], 6)
        self.assertEqual(result['total_occurrences'], 43)  # 10+15+8+5+3+2
        self.assertEqual(result['unsupported_occurrences'], 10)  # 5+3+2
        self.assertAlmostEqual(result['unsupported_percentage'], 23.3, places=1)  # (10/43)*100 ≈ 23.3
        self.assertTrue(result['has_unsupported_transformations'])
        
        # Check unsupported details
        unsupported_details = result['unsupported_details']
        self.assertEqual(unsupported_details['Custom Transformation'], 5)
        self.assertEqual(unsupported_details['Java Transformation'], 3)
        self.assertEqual(unsupported_details['Stored Procedure'], 2)
    
    def test_all_supported_transformations(self):
        """Test analysis when all transformations are supported."""
        transformations_data = [
            ("Source Qualifier", 10, "Yes"),
            ("Expression", 15, "Yes"),
            ("Filter", 8, "Yes"),
            ("Aggregator", 12, "Yes")
        ]
        
        file_path = self.create_test_excel_file(transformations_data)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['supported_count'], 4)
        self.assertEqual(result['unsupported_count'], 0)
        self.assertEqual(result['total_count'], 4)
        self.assertEqual(result['total_occurrences'], 45)  # 10+15+8+12
        self.assertEqual(result['unsupported_occurrences'], 0)
        self.assertEqual(result['unsupported_percentage'], 0.0)
        self.assertFalse(result['has_unsupported_transformations'])
        self.assertEqual(len(result['unsupported_details']), 0)
    
    def test_all_unsupported_transformations(self):
        """Test analysis when all transformations are unsupported."""
        transformations_data = [
            ("Custom Transformation", 5, "No"),
            ("Java Transformation", 3, "No"),
            ("Stored Procedure", 2, "No"),
            ("External Procedure", 1, "No")
        ]
        
        file_path = self.create_test_excel_file(transformations_data)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['supported_count'], 0)
        self.assertEqual(result['unsupported_count'], 4)
        self.assertEqual(result['total_count'], 4)
        self.assertEqual(result['total_occurrences'], 11)  # 5+3+2+1
        self.assertEqual(result['unsupported_occurrences'], 11)  # 5+3+2+1
        self.assertEqual(result['unsupported_percentage'], 100.0)
        self.assertTrue(result['has_unsupported_transformations'])
        
        # Check unsupported details
        unsupported_details = result['unsupported_details']
        self.assertEqual(len(unsupported_details), 4)
    
    def test_empty_transformations_sheet(self):
        """Test analysis with empty Transformations sheet."""
        transformations_data = []  # No data rows
        
        file_path = self.create_test_excel_file(transformations_data)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['supported_count'], 0)
        self.assertEqual(result['unsupported_count'], 0)
        self.assertEqual(result['total_count'], 0)
        self.assertEqual(result['total_occurrences'], 0)
        self.assertEqual(result['unsupported_occurrences'], 0)
        self.assertEqual(result['unsupported_percentage'], 0.0)
        self.assertFalse(result['has_unsupported_transformations'])
    
    def test_missing_transformations_sheet(self):
        """Test error handling when Transformations sheet is missing."""
        wb = Workbook()
        if wb.active:
            wb.remove(wb.active)
        wb.create_sheet("Summary")  # Create a different sheet
        
        file_path = os.path.join(self.temp_dir, "test_no_transformations.xlsx")
        wb.save(file_path)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertFalse(result['success'])
        self.assertIn("Sheet 'Transformations' not found", result['error'])
    
    def test_case_insensitive_supported_values(self):
        """Test that supported values are case insensitive."""
        transformations_data = [
            ("Source Qualifier", 10, "YES"),
            ("Expression", 15, "yes"),
            ("Filter", 8, "Yes"),
            ("Custom Transformation", 5, "NO"),
            ("Java Transformation", 3, "no")
        ]
        
        file_path = self.create_test_excel_file(transformations_data)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['supported_count'], 3)
        self.assertEqual(result['unsupported_count'], 2)
        self.assertEqual(result['total_count'], 5)
        self.assertEqual(result['total_occurrences'], 41)  # 10+15+8+5+3
        self.assertEqual(result['unsupported_occurrences'], 8)  # 5+3
    
    def test_skip_empty_transformation_names(self):
        """Test that rows with empty transformation names are skipped."""
        transformations_data = [
            ("Source Qualifier", 10, "Yes"),
            ("", 5, "Yes"),  # Empty name
            ("   ", 3, "No"),  # Whitespace only
            ("Expression", 15, "Yes")
        ]
        
        file_path = self.create_test_excel_file(transformations_data)
        
        result = self.check.check(file_path, "test_file.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['supported_count'], 2)
        self.assertEqual(result['unsupported_count'], 0)
        self.assertEqual(result['total_count'], 2)
        self.assertEqual(result['total_occurrences'], 25)  # 10+15 (empty rows are skipped)
        self.assertEqual(result['unsupported_occurrences'], 0)


if __name__ == '__main__':
    unittest.main() 