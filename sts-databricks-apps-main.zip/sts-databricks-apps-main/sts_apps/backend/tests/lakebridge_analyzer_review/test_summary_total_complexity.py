import pytest
from backend.lakebridge_analyzer_review.reports.sections.summary_section import SummarySection

class TestSummaryTotalComplexity:
    def setup_method(self):
        self.summary_section = SummarySection()

    def test_total_complexity_calculation_and_hierarchy(self):
        # Mock results for SQL and ETL complexity
        sql_result = {
            'filename': 'file1.xlsx',
            'success': True,
            'script_type': 'SQL',
            'total_files': 3,
            'complexity_counts': {'low': 1, 'medium': 1, 'complex': 1, 'very_complex': 0},
            'percentages': {'low': 33.3, 'medium': 33.3, 'complex': 33.3, 'very_complex': 0.0}
        }
        etl_result = {
            'filename': 'file2.xlsx',
            'success': True,
            'script_type': 'ETL',
            'total_files': 2,
            'complexity_counts': {'low': 0, 'medium': 1, 'complex': 0, 'very_complex': 1},
            'percentages': {'low': 0.0, 'medium': 50.0, 'complex': 0.0, 'very_complex': 50.0}
        }
        results = [sql_result, etl_result]
        story = self.summary_section.create_section(results)
        # Extract note texts
        note_texts = [item.text for item in story if hasattr(item, 'text') and 'Complexity Distribution' in item.text]
        # Check for total, SQL, and ETL lines with correct bullet
        assert any(t.startswith('• Total Complexity Distribution:') for t in note_texts)
        assert any(t.startswith('• SQL Complexity Distribution:') for t in note_texts)
        assert any(t.startswith('• ETL Complexity Distribution:') for t in note_texts)
        # Check that the numbers are correct (only present categories)
        assert any('Low: 1' in t and 'Medium: 2' in t and 'Complex: 1' in t and 'Very Complex: 1' in t for t in note_texts if t.startswith('• Total'))
        assert any('Low: 1' in t and 'Medium: 1' in t and 'Complex: 1' in t for t in note_texts if t.startswith('• SQL'))
        assert any('Medium: 1' in t and 'Very Complex: 1' in t for t in note_texts if t.startswith('• ETL')) 