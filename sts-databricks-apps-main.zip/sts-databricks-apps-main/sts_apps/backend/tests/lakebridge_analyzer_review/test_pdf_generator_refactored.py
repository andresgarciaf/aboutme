import os
import tempfile
from backend.lakebridge_analyzer_review.reports.pdf_generator import PDFGenerator
from backend.lakebridge_analyzer_review.reports.sections.version_section import VersionSection
from backend.lakebridge_analyzer_review.reports.sections.oversize_section import OversizeSection
from backend.lakebridge_analyzer_review.reports.sections.duplicate_section import DuplicateSection
from backend.lakebridge_analyzer_review.reports.sections.uncategorized_section import UncategorizedSection
from backend.lakebridge_analyzer_review.reports.sections.workflow_section import WorkflowSection
from backend.lakebridge_analyzer_review.reports.sections.folder_section import FolderSection
from backend.lakebridge_analyzer_review.reports.sections.unsupported_transformations_section import UnsupportedTransformationsSection


def test_pdf_generator_import():
    """Test that the refactored PDF generator can be imported and instantiated."""
    generator = PDFGenerator()
    assert generator is not None
    assert hasattr(generator, 'version_section')
    assert hasattr(generator, 'oversize_section')
    assert hasattr(generator, 'duplicate_section')
    assert hasattr(generator, 'uncategorized_section')
    assert hasattr(generator, 'workflow_section')
    assert hasattr(generator, 'folder_section')


def test_section_classes_import():
    """Test that all section classes can be imported and instantiated."""
    sections = [
        VersionSection(),
        OversizeSection(),
        DuplicateSection(),
        UncategorizedSection(),
        WorkflowSection(),
        FolderSection(),
        UnsupportedTransformationsSection()
    ]
    
    for section in sections:
        assert section is not None
        assert hasattr(section, 'create_section')


def test_pdf_generator_generate_report():
    """Test that the refactored PDF generator can generate a report."""
    generator = PDFGenerator()
    
    # Sample test data
    oversize_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_rows': 5,
            'oversize_files_count': 0,
            'percentage': 0.0,
            'oversize_files': []
        }
    ]
    
    version_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'version_number': '5.6.4',
            'required_version': '5.6.4',
            'is_old_version': False
        }
    ]
    
    duplicate_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_programs': 5,
            'duplicate_groups_count': 0,
            'duplicate_programs_count': 0,
            'duplicate_groups': []
        }
    ]
    
    # Generate PDF
    pdf_path = generator.generate_report(oversize_results, version_results, duplicate_results)
    
    # Check that PDF was created
    assert os.path.exists(pdf_path)
    assert pdf_path.endswith('.pdf')
    assert os.path.getsize(pdf_path) > 0
    
    # Clean up
    os.unlink(pdf_path)


def test_section_creation():
    """Test that individual sections can create their content."""
    version_section = VersionSection()
    oversize_section = OversizeSection()
    duplicate_section = DuplicateSection()
    
    # Test data
    version_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'version_number': '5.6.4',
            'is_old_version': False
        }
    ]
    
    oversize_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_rows': 5,
            'oversize_files_count': 0,
            'percentage': 0.0,
            'oversize_files': []
        }
    ]
    
    duplicate_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_programs': 5,
            'duplicate_groups_count': 0,
            'duplicate_programs_count': 0,
            'duplicate_groups': []
        }
    ]
    
    # Test section creation
    version_story = version_section.create_section(version_results)
    oversize_story = oversize_section.create_section(oversize_results)
    duplicate_story = duplicate_section.create_section(duplicate_results)
    
    assert len(version_story) > 0
    assert len(oversize_story) > 0
    assert len(duplicate_story) > 0


def test_oversize_section_with_data():
    """Test that oversize section correctly handles oversize file data and creates tables."""
    oversize_section = OversizeSection()
    
    # Test data with oversize files
    oversize_results = [
        {
            'filename': 'test.xlsx',
            'success': True,
            'total_rows': 10,
            'oversize_files_count': 2,
            'percentage': 20.0,
            'oversize_files': [
                {
                    'row': 3,
                    'value': 5,
                    'program_name': 'Program1'
                },
                {
                    'row': 7,
                    'value': 3,
                    'program_name': 'Program2'
                }
            ]
        }
    ]
    
    # Test section creation
    oversize_story = oversize_section.create_section(oversize_results)
    assert len(oversize_story) > 0
    
    # Check that we have a table in the story (should have more than just headers)
    # The story should contain: header, status item, spacer, table, spacer, final spacer
    assert len(oversize_story) >= 6


def test_workflow_section_data_structure():
    """Test that workflow section handles the correct data structure."""
    workflow_section = WorkflowSection()
    
    # Test data matching the actual workflow mapping check structure
    workflow_results = [
        {
            'filename': 'test_infa.xlsx',
            'success': True,
            'total_mappings': 10,
            'total_workflows': 8,
            'workflow_mapping_ratio': 0.8,
            'recommendation': 'Ask if there are external orchestrators.',
            'complexity_level': 'Low'
        }
    ]
    
    # Test section creation
    workflow_story = workflow_section.create_section(workflow_results)
    assert len(workflow_story) > 0


def test_folder_section_data_structure():
    """Test that folder section handles the correct data structure."""
    folder_section = FolderSection()
    
    # Test data matching the actual folder analysis check structure
    folder_results = [
        {
            'filename': 'test_infa.xlsx',
            'success': True,
            'total_folders': 3,
            'folder_analysis': {},
            'sorted_folders': [],
            'formatted_results': [
                'Folder1: 2 Low complexity Mappings - 15 nodes total',
                'Folder2: 1 Medium complexity Workflows - 8 nodes total'
            ]
        }
    ]
    
    # Test section creation
    folder_story = folder_section.create_section(folder_results)
    assert len(folder_story) > 0


def test_unsupported_transformations_section_data_structure():
    """Test that unsupported transformations section handles the correct data structure."""
    unsupported_section = UnsupportedTransformationsSection()
    
    # Test data matching the actual unsupported transformations check structure
    unsupported_results = [
        {
            'filename': 'test_infa.xlsx',
            'success': True,
            'supported_count': 3,
            'unsupported_count': 2,
            'total_count': 5,
            'total_occurrences': 25,
            'unsupported_occurrences': 8,
            'unsupported_percentage': 32.0,
            'unsupported_details': {
                'Custom Transformation': 5,
                'Java Transformation': 3
            },
            'has_unsupported_transformations': True
        }
    ]
    
    # Test section creation
    unsupported_story = unsupported_section.create_section(unsupported_results)
    assert len(unsupported_story) > 0
    
    # Check that we have content (should have header, warning, note, and potentially table)
    assert len(unsupported_story) >= 4


def test_unsupported_transformations_section_with_no_unsupported():
    """Test that unsupported transformations section handles case with no unsupported transformations."""
    unsupported_section = UnsupportedTransformationsSection()
    
    # Test data with no unsupported transformations
    unsupported_results = [
        {
            'filename': 'test_infa.xlsx',
            'success': True,
            'supported_count': 5,
            'unsupported_count': 0,
            'total_count': 5,
            'total_occurrences': 30,
            'unsupported_occurrences': 0,
            'unsupported_percentage': 0.0,
            'unsupported_details': {},
            'has_unsupported_transformations': False
        }
    ]
    
    # Test section creation
    unsupported_story = unsupported_section.create_section(unsupported_results)
    assert len(unsupported_story) > 0


if __name__ == "__main__":
    import pytest
    pytest.main([__file__]) 