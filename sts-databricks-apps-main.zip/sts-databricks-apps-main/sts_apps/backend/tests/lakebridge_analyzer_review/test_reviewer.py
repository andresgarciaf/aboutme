"""
Tests for the reviewer module.
Tests the oversize file detection and PDF generation functionality.
"""

import pytest
import tempfile
import os
from unittest.mock import patch, MagicMock

# Import the functions to test
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.lakebridge_analyzer_review.reviewer import LakebridgeReviewer


def test_find_oversize_files_success():
    """Test successful oversize file detection."""
    # Create a test Excel file with oversize data
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "SQL Programs"
            
            # Add headers
            ws['A1'] = "Program Name"
            ws['G1'] = "Procedure And Function Counts"
        
            # Add data with some oversize files
            ws['A2'] = "Program1"
            ws['G2'] = 1  # Normal
            ws['A3'] = "Program2"
            ws['G3'] = 5  # Oversize
            ws['A4'] = "Program3"
            ws['G4'] = 2  # Oversize
        
        wb.save(temp_file.name)
        temp_file_path = temp_file.name
    
    try:
        # Test the function
        reviewer = LakebridgeReviewer()
        result = reviewer.oversize_check.check(temp_file_path, "test_file.xlsx")
        
        # Check results
        assert result['success'] is True
        assert result['filename'] == "test_file.xlsx"
        assert result['total_rows'] == 3
        assert result['oversize_files_count'] == 2
        assert result['percentage'] == pytest.approx(66.7, rel=1e-2)
        assert len(result['oversize_files']) == 2
        
        # Check oversize files details
        oversize_files = result['oversize_files']
        assert oversize_files[0]['program_name'] == "Program2"
        assert oversize_files[0]['value'] == 5
        assert oversize_files[1]['program_name'] == "Program3"
        assert oversize_files[1]['value'] == 2
        
    finally:
        # Clean up
        os.unlink(temp_file_path)


def test_find_oversize_files_no_oversize():
    """Test when no oversize files are found."""
    # Create a test Excel file with no oversize data
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "SQL Programs"
            
            # Add headers
            ws['A1'] = "Program Name"
            ws['G1'] = "Procedure And Function Counts"
        
            # Add data with no oversize files
            ws['A2'] = "Program1"
            ws['G2'] = 1
            ws['A3'] = "Program2"
            ws['G3'] = 1
            ws['A4'] = "Program3"
            ws['G4'] = 0
            
        wb.save(temp_file.name)
        temp_file_path = temp_file.name
    
    try:
        # Test the function
        reviewer = LakebridgeReviewer()
        result = reviewer.oversize_check.check(temp_file_path, "test_file.xlsx")
        
        # Check results
        assert result['success'] is True
        assert result['filename'] == "test_file.xlsx"
        assert result['total_rows'] == 3
        assert result['oversize_files_count'] == 0
        assert result['percentage'] == 0.0
        assert len(result['oversize_files']) == 0
        
    finally:
        # Clean up
        os.unlink(temp_file_path)


def test_find_oversize_files_missing_sheet():
    """Test error handling for missing sheet."""
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
        # Create a minimal Excel file without the required sheet
        import openpyxl
        wb = openpyxl.Workbook()
        wb.save(temp_file.name)
        temp_file_path = temp_file.name
    
    try:
        # Test the function
        reviewer = LakebridgeReviewer()
        result = reviewer.oversize_check.check(temp_file_path, "test_file.xlsx")
        
        # Check that it failed gracefully
        assert result['success'] is False
        assert result['filename'] == "test_file.xlsx"
        assert "Sheet 'SQL Programs' not found" in result['error']
        
    finally:
        # Clean up
        os.unlink(temp_file_path)


def test_generate_comprehensive_pdf_report():
    """Test comprehensive PDF report generation."""
    # Sample results data
    oversize_results = [
        {
            'filename': 'file1.xlsx',
            'success': True,
            'total_rows': 10,
            'oversize_files_count': 2,
            'percentage': 20.0,
            'oversize_files': [
                {'row': 3, 'value': 5, 'program_name': 'Program1'},
                {'row': 7, 'value': 3, 'program_name': 'Program2'}
            ]
        },
        {
            'filename': 'file2.xlsx',
            'success': True,
            'total_rows': 5,
            'oversize_files_count': 0,
            'percentage': 0.0,
            'oversize_files': []
        }
    ]
    
    version_results = [
        {
            'filename': 'file1.xlsx',
            'success': True,
            'version_number': '5.6.4',
            'required_version': '5.6.4',
            'is_old_version': False
        },
        {
            'filename': 'file2.xlsx',
            'success': True,
            'version_number': '5.6.4',
            'required_version': '5.6.4',
            'is_old_version': False
        }
    ]
    
    duplicate_results = [
        {
            'filename': 'file1.xlsx',
            'success': True,
            'total_programs': 10,
            'duplicate_groups_count': 0,
            'duplicate_programs_count': 0,
            'duplicate_groups': []
        },
        {
            'filename': 'file2.xlsx',
            'success': True,
            'total_programs': 5,
            'duplicate_groups_count': 0,
            'duplicate_programs_count': 0,
            'duplicate_groups': []
        }
    ]
    
    # Generate PDF
    reviewer = LakebridgeReviewer()
    pdf_path = reviewer.pdf_generator.generate_report(oversize_results, version_results, duplicate_results)
    
    # Check that PDF was created
    assert os.path.exists(pdf_path)
    assert pdf_path.endswith('.pdf')
    
    # Check file size (should be > 0)
    assert os.path.getsize(pdf_path) > 0
    
    # Clean up
    os.unlink(pdf_path)


def test_review_multiple_files():
    """Test reviewing multiple files."""
    # Create test files
    temp_files = []
    original_filenames = []
    
    try:
        for i in range(2):
            with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as temp_file:
                import openpyxl
                wb = openpyxl.Workbook()
                ws = wb.active
                if ws is not None:
                    ws.title = "SQL Programs"
                    
                    # Add headers
                    ws['A1'] = "Program Name"
                    ws['G1'] = "Procedure And Function Counts"
                
                    # Add some data
                    ws['A2'] = f"Program{i+1}"
                    ws['G2'] = i + 1  # First file has 1, second has 2
                
                wb.save(temp_file.name)
                temp_files.append(temp_file.name)
                original_filenames.append(f"test_file_{i+1}.xlsx")
        
        # Test the function
        reviewer = LakebridgeReviewer()
        pdf_path = reviewer.review_multiple_files(temp_files, original_filenames)
        
        # Check that PDF was created
        assert os.path.exists(pdf_path)
        assert pdf_path.endswith('.pdf')
        assert os.path.getsize(pdf_path) > 0
        
        # Clean up PDF
        os.unlink(pdf_path)
        
    finally:
        # Clean up test files
        for temp_file in temp_files:
            if os.path.exists(temp_file):
                os.unlink(temp_file)


if __name__ == "__main__":
    pytest.main([__file__]) 