import openpyxl
import tempfile
import os
import pytest
from backend.lakebridge_analyzer_review.checks.job_complexity_check import JobComplexityCheck
from backend.tests.conftest import create_sample_workbook_with_mapping_names

def test_job_complexity_check_success():
    """Test successful job complexity analysis."""
    check = JobComplexityCheck()
    
    with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp:
        create_sample_workbook_with_mapping_names(tmp.name)
        
        result = check.check(tmp.name, "test_file.xlsx")
        
        os.unlink(tmp.name)
    
    assert result['success'] is True
    assert result['filename'] == "test_file.xlsx"
    assert result['script_type'] == 'JOB'
    assert result['total_files'] == 6
    
    complexity_counts = result['complexity_counts']
    assert complexity_counts['low'] == 3
    assert complexity_counts['medium'] == 1
    assert complexity_counts['complex'] == 1
    assert complexity_counts['very_complex'] == 1
    
    percentages = result['percentages']
    assert percentages['low'] == 50.0
    assert abs(percentages['medium'] - 16.67) < 0.01
    assert abs(percentages['complex'] - 16.67) < 0.01
    assert abs(percentages['very_complex'] - 16.67) < 0.01
    
    assert result['has_complex_files'] is True
    assert len(result['complex_files']) == 1
    assert len(result['very_complex_files']) == 1
    
    # Check complex file details
    complex_file = result['complex_files'][0]
    assert complex_file['mapping_name'] == 'Mapping4'
    assert complex_file['folder'] == 'FolderB'
    assert complex_file['row'] == 5
    
    # Check very complex file details
    very_complex_file = result['very_complex_files'][0]
    assert very_complex_file['mapping_name'] == 'Mapping5'
    assert very_complex_file['folder'] == 'FolderB'
    assert very_complex_file['row'] == 6

def test_job_complexity_check_no_mapping_details_sheet():
    """Test job complexity check when Mapping Details sheet is missing."""
    check = JobComplexityCheck()
    
    with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp:
        wb = openpyxl.Workbook()
        wb.save(tmp.name)
        
        result = check.check(tmp.name, "test_file.xlsx")
        
        os.unlink(tmp.name)
    
    assert result['success'] is False
    assert "Sheet 'Mapping Details' not found" in result['error']

def test_job_complexity_check_empty_data():
    """Test job complexity check with empty data."""
    check = JobComplexityCheck()
    
    with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp:
        wb = openpyxl.Workbook()
        ws = wb.create_sheet('Mapping Details')
        # Only header, no data
        ws.append(['Mapping Name', 'Folder', 'C', 'D', 'Mapping Type', 'Categorization', 'Number of Nodes'])
        wb.save(tmp.name)
        
        result = check.check(tmp.name, "test_file.xlsx")
        
        os.unlink(tmp.name)
    
    assert result['success'] is True
    assert result['total_files'] == 0
    assert result['complexity_counts']['low'] == 0
    assert result['complexity_counts']['medium'] == 0
    assert result['complexity_counts']['complex'] == 0
    assert result['complexity_counts']['very_complex'] == 0
    assert result['has_complex_files'] is False

def test_job_complexity_check_case_insensitive():
    """Test that complexity categorization is case insensitive."""
    check = JobComplexityCheck()
    
    with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp:
        wb = openpyxl.Workbook()
        ws = wb.create_sheet('Mapping Details')
        # Header
        ws.append(['Mapping Name', 'Folder', 'C', 'D', 'Mapping Type', 'Categorization', 'Number of Nodes'])
        # Data with mixed case
        ws.append(['Mapping1', 'FolderA', '', '', 'Workflow', 'LOW', 10])
        ws.append(['Mapping2', 'FolderA', '', '', 'Mapping', 'Medium', 15])
        ws.append(['Mapping3', 'FolderB', '', '', 'Mapping', 'COMPLEX', 20])
        ws.append(['Mapping4', 'FolderB', '', '', 'Mapping', 'Very Complex', 25])
        wb.save(tmp.name)
        
        result = check.check(tmp.name, "test_file.xlsx")
        
        os.unlink(tmp.name)
    
    assert result['success'] is True
    assert result['total_files'] == 4
    assert result['complexity_counts']['low'] == 1
    assert result['complexity_counts']['medium'] == 1
    assert result['complexity_counts']['complex'] == 1
    assert result['complexity_counts']['very_complex'] == 1

def test_job_complexity_check_invalid_file():
    """Test job complexity check with invalid file."""
    check = JobComplexityCheck()
    
    result = check.check("nonexistent_file.xlsx", "test_file.xlsx")
    
    assert result['success'] is False
    assert "Failed to load Excel file" in result['error'] 