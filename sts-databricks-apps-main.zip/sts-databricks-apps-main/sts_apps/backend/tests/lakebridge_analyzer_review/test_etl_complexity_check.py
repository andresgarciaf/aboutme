import unittest
from unittest.mock import Mock, patch, MagicMock
import tempfile
import os
from backend.lakebridge_analyzer_review.checks.etl_complexity_check import ETLComplexityCheck


class TestETLComplexityCheck(unittest.TestCase):
    """Test cases for ETLComplexityCheck."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.check = ETLComplexityCheck()
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        self.temp_file.close()
    
    def tearDown(self):
        """Clean up test fixtures."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)
    
    def test_init(self):
        """Test that the check is initialized correctly."""
        self.assertEqual(self.check.script_type, "ETL")
        self.assertEqual(self.check.check_name, "etl_complexity")
    
    @patch('openpyxl.load_workbook')
    def test_check_success_with_etl_files(self, mock_load_workbook):
        """Test successful ETL complexity analysis with ETL files."""
        # Mock workbook and sheet
        mock_workbook = MagicMock()
        mock_sheet = Mock()
        
        # Mock data for ETL files with different complexity levels
        mock_sheet.iter_rows.return_value = [
            ('file1.sql', '', '', '', 'low', '', '', '', '', '', '', 'ETL'),  # Row 2
            ('file2.sql', '', '', '', 'medium', '', '', '', '', '', '', 'ETL'),  # Row 3
            ('file3.sql', '', '', '', 'complex', '', '', '', '', '', '', 'ETL'),  # Row 4
            ('file4.sql', '', '', '', 'very_complex', '', '', '', '', '', '', 'ETL'),  # Row 5
            ('file5.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),  # Row 6 - should be ignored
        ]
        
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sheet
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test_file.xlsx')
        
        # Verify the result
        self.assertTrue(result['success'])
        self.assertEqual(result['filename'], 'test_file.xlsx')
        self.assertEqual(result['total_files'], 4)  # Only ETL files
        self.assertEqual(result['complexity_counts']['low'], 1)
        self.assertEqual(result['complexity_counts']['medium'], 1)
        self.assertEqual(result['complexity_counts']['complex'], 1)
        self.assertEqual(result['complexity_counts']['very_complex'], 1)
        self.assertTrue(result['has_complex_files'])
        self.assertEqual(result['script_type'], 'ETL')
        
        # Check percentages
        self.assertEqual(result['percentages']['low'], 25.0)
        self.assertEqual(result['percentages']['medium'], 25.0)
        self.assertEqual(result['percentages']['complex'], 25.0)
        self.assertEqual(result['percentages']['very_complex'], 25.0)
    
    @patch('openpyxl.load_workbook')
    def test_check_no_etl_files(self, mock_load_workbook):
        """Test ETL complexity analysis when no ETL files are found."""
        # Mock workbook and sheet
        mock_workbook = MagicMock()
        mock_sheet = Mock()
        
        # Mock data with only SQL files
        mock_sheet.iter_rows.return_value = [
            ('file1.sql', '', '', '', 'low', '', '', '', '', '', '', 'SQL'),  # Row 2
            ('file2.sql', '', '', '', 'medium', '', '', '', '', '', '', 'SQL'),  # Row 3
        ]
        
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sheet
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test_file.xlsx')
        
        # Verify the result
        self.assertTrue(result['success'])
        self.assertEqual(result['filename'], 'test_file.xlsx')
        self.assertEqual(result['total_files'], 0)  # No ETL files
        self.assertFalse(result['has_complex_files'])
        self.assertEqual(result['script_type'], 'ETL')
        
        # Check percentages (all should be 0)
        for complexity in ['low', 'medium', 'complex', 'very_complex']:
            self.assertEqual(result['percentages'][complexity], 0)
    
    @patch('openpyxl.load_workbook')
    def test_check_file_not_found(self, mock_load_workbook):
        """Test ETL complexity analysis when file cannot be loaded."""
        mock_load_workbook.side_effect = FileNotFoundError("File not found")
        
        # Run the check
        result = self.check.check('nonexistent_file.xlsx', 'nonexistent_file.xlsx')
        
        # Verify the result
        self.assertFalse(result['success'])
        self.assertEqual(result['filename'], 'nonexistent_file.xlsx')
        self.assertIn('Failed to load Excel file', result['error'])
    
    @patch('openpyxl.load_workbook')
    def test_check_sheet_not_found(self, mock_load_workbook):
        """Test ETL complexity analysis when SQL Programs sheet is not found."""
        # Mock workbook without SQL Programs sheet
        mock_workbook = Mock()
        mock_workbook.sheetnames = ['Summary', 'Other Sheet']
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check('test_file.xlsx', 'test_file.xlsx')
        
        # Verify the result
        self.assertFalse(result['success'])
        self.assertEqual(result['filename'], 'test_file.xlsx')
        self.assertIn("Sheet 'SQL Programs' not found", result['error'])
    
    @patch('openpyxl.load_workbook')
    def test_check_with_file_names(self, mock_load_workbook):
        """Test ETL complexity analysis with actual file names."""
        # Mock workbook and sheet
        mock_workbook = MagicMock()
        mock_sheet = Mock()
        
        # Mock data with file names
        mock_sheet.iter_rows.return_value = [
            ('etl_file1.sql', '', '', '', 'complex', '', '', '', '', '', '', 'ETL'),  # Row 2
            ('etl_file2.sql', '', '', '', 'very_complex', '', '', '', '', '', '', 'ETL'),  # Row 3
        ]
        
        mock_workbook.sheetnames = ['SQL Programs']
        mock_workbook.__getitem__.return_value = mock_sheet
        mock_load_workbook.return_value = mock_workbook
        
        # Run the check
        result = self.check.check(self.temp_file.name, 'test_file.xlsx')
        
        # Verify the result
        self.assertTrue(result['success'])
        self.assertEqual(result['total_files'], 2)
        self.assertTrue(result['has_complex_files'])
        
        # Check complex files
        self.assertEqual(len(result['complex_files']), 1)
        self.assertEqual(result['complex_files'][0]['file_name'], 'etl_file1.sql')
        self.assertEqual(result['complex_files'][0]['row'], 2)
        
        # Check very complex files
        self.assertEqual(len(result['very_complex_files']), 1)
        self.assertEqual(result['very_complex_files'][0]['file_name'], 'etl_file2.sql')
        self.assertEqual(result['very_complex_files'][0]['row'], 3)


if __name__ == '__main__':
    unittest.main() 