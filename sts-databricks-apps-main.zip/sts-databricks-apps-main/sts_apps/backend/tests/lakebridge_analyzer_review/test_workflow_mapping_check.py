import unittest
import tempfile
import os
from openpyxl import Workbook
from backend.lakebridge_analyzer_review.checks.workflow_mapping_check import WorkflowMappingCheck


class TestWorkflowMappingCheck(unittest.TestCase):
    """Test cases for WorkflowMappingCheck."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.check = WorkflowMappingCheck()
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Clean up test fixtures."""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def _create_test_excel_file(self, mappings: int, workflows: int) -> str:
        """Create a test Excel file with specified mappings and workflows."""
        wb = Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "Summary"
            
            # Set B4 (Total Mappings) and B5 (Total Workflows)
            ws['B4'] = mappings
            ws['B5'] = workflows
        
        # Save to temporary file
        file_path = os.path.join(self.temp_dir, "test_infa.xlsx")
        wb.save(file_path)
        return file_path
    
    def test_high_ratio_recommendation(self):
        """Test that high workflow to mapping ratio gives correct recommendation."""
        # Create test file with 10 mappings and 8 workflows (ratio = 0.8)
        file_path = self._create_test_excel_file(10, 8)
        
        result = self.check.check(file_path, "test_infa.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['total_mappings'], 10)
        self.assertEqual(result['total_workflows'], 8)
        self.assertEqual(result['workflow_mapping_ratio'], 0.8)
        self.assertEqual(result['complexity_level'], "Low")
        self.assertIn("external orchestrators", result['recommendation'])
        self.assertIn("1-1 ratio", result['recommendation'])
    
    def test_low_ratio_recommendation(self):
        """Test that low workflow to mapping ratio gives correct recommendation."""
        # Create test file with 10 mappings and 5 workflows (ratio = 0.5)
        file_path = self._create_test_excel_file(10, 5)
        
        result = self.check.check(file_path, "test_infa.xlsx")
        
        self.assertTrue(result['success'])
        self.assertEqual(result['total_mappings'], 10)
        self.assertEqual(result['total_workflows'], 5)
        self.assertEqual(result['workflow_mapping_ratio'], 0.5)
        self.assertEqual(result['complexity_level'], "High")
        self.assertIn("within Informatica", result['recommendation'])
        self.assertIn("low workflows to mappings ratio", result['recommendation'])
    
    def test_zero_mappings_error(self):
        """Test that zero mappings returns an error."""
        file_path = self._create_test_excel_file(0, 5)
        
        result = self.check.check(file_path, "test_infa.xlsx")
        
        self.assertFalse(result['success'])
        self.assertIn("zero", result['error'])
    
    def test_missing_sheet_error(self):
        """Test that missing Summary sheet returns an error."""
        wb = Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "WrongSheet"  # Not "Summary"
            ws['B4'] = 10
            ws['B5'] = 5
        
        file_path = os.path.join(self.temp_dir, "test_infa.xlsx")
        wb.save(file_path)
        
        result = self.check.check(file_path, "test_infa.xlsx")
        
        self.assertFalse(result['success'])
        self.assertIn("Summary", result['error'])
    
    def test_empty_cells_error(self):
        """Test that empty B4 or B5 returns an error."""
        wb = Workbook()
        ws = wb.active
        if ws is not None:
            ws.title = "Summary"
            ws['B4'] = ""  # Empty string instead of None
            ws['B5'] = 5
        
        file_path = os.path.join(self.temp_dir, "test_infa.xlsx")
        wb.save(file_path)
        
        result = self.check.check(file_path, "test_infa.xlsx")
        
        self.assertFalse(result['success'])
        self.assertIn("empty", result['error'])


if __name__ == '__main__':
    unittest.main() 