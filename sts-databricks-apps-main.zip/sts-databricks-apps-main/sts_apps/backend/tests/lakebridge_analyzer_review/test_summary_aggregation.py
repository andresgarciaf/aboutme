import pytest
from unittest.mock import Mock
from backend.lakebridge_analyzer_review.reports.sections.summary_section import SummarySection


class TestSummaryAggregation:
    """Test that summary section aggregates results across multiple files and prevents repetition."""
    
    def test_aggregate_errors_across_files(self):
        """Test that errors are aggregated across multiple files."""
        section = SummarySection()
        
        # Create results with same error across multiple files
        results = [
            {
                'filename': 'file1.xlsx',
                'success': False,
                'error': 'Sheet not found'
            },
            {
                'filename': 'file2.xlsx',
                'success': False,
                'error': 'Sheet not found'
            },
            {
                'filename': 'file3.xlsx',
                'success': False,
                'error': 'Invalid format'
            }
        ]
        
        story = section.create_section(results)
        
        # Should have only 2 unique errors, not 3
        error_texts = []
        for item in story:
            if hasattr(item, 'text'):
                if 'Sheet not found' in item.text or 'Invalid format' in item.text:
                    error_texts.append(item.text)
        
        # Should have exactly 2 unique errors
        assert len(error_texts) == 2
        assert any('Sheet not found' in text for text in error_texts)
        assert any('Invalid format' in text for text in error_texts)
    
    def test_aggregate_warnings_across_files(self):
        """Test that warnings are aggregated across multiple files."""
        section = SummarySection()
        
        # Create results with same warning across multiple files
        results = [
            {
                'filename': 'file1.xlsx',
                'success': True,
                'oversize_files_count': 5,
                'percentage': 10.0
            },
            {
                'filename': 'file2.xlsx',
                'success': True,
                'oversize_files_count': 3,
                'percentage': 8.0
            },
            {
                'filename': 'file3.xlsx',
                'success': True,
                'duplicate_programs_count': 2
            }
        ]
        
        story = section.create_section(results)
        
        # Should have warnings for oversize files and duplicate programs
        warning_texts = []
        for item in story:
            if hasattr(item, 'text'):
                if 'oversize files found' in item.text or 'duplicate program names found' in item.text:
                    warning_texts.append(item.text)
        
        # Should have exactly 2 unique warnings
        assert len(warning_texts) == 2
        assert any('oversize files found' in text for text in warning_texts)
        assert any('duplicate program names found' in text for text in warning_texts)
    
    def test_aggregate_notes_across_files(self):
        """Test that notes are aggregated across multiple files."""
        section = SummarySection()
        
        # Create results with same notes across multiple files
        results = [
            {
                'filename': 'file1.xlsx',
                'success': True,
                'total_folders': 10
            },
            {
                'filename': 'file2.xlsx',
                'success': True,
                'total_folders': 15
            },
            {
                'filename': 'file3.xlsx',
                'success': True,
                'workflow_mapping_ratio': 0.5,
                'total_workflows': 20,
                'total_mappings': 10
            }
        ]
        
        story = section.create_section(results)
        
        # Should have a single note for folders (sum) and one for workflow mapping
        note_texts = []
        for item in story:
            if hasattr(item, 'text'):
                if 'unique Informatica folders' in item.text or 'Workflow to mapping ratio' in item.text:
                    note_texts.append(item.text)
        
        # Should have exactly 2 unique notes: one for folders (sum), one for workflow mapping
        assert len(note_texts) == 2
        assert any('There are 25 unique Informatica folders' in t for t in note_texts)
        assert any('Workflow to mapping ratio' in t for t in note_texts)
    
    def test_no_file_names_in_summary(self):
        """Test that file names are not displayed in the summary."""
        section = SummarySection()
        
        results = [
            {
                'filename': 'file1.xlsx',
                'success': True,
                'oversize_files_count': 5,
                'percentage': 10.0
            },
            {
                'filename': 'file2.xlsx',
                'success': True,
                'duplicate_programs_count': 2
            }
        ]
        
        story = section.create_section(results)
        
        # Should not contain any file names in the story
        for item in story:
            if hasattr(item, 'text'):
                assert 'file1.xlsx' not in item.text
                assert 'file2.xlsx' not in item.text
    
    def test_success_message_when_no_issues(self):
        """Test that success message is shown when no issues exist."""
        section = SummarySection()
        
        results = [
            {
                'filename': 'file1.xlsx',
                'success': True,
                'oversize_files_count': 0,
                'percentage': 0.0
            },
            {
                'filename': 'file2.xlsx',
                'success': True,
                'duplicate_programs_count': 0
            }
        ]
        
        story = section.create_section(results)
        
        # Should contain success message
        success_found = False
        for item in story:
            if hasattr(item, 'text') and 'All checks passed successfully' in item.text:
                success_found = True
                break
        
        assert success_found 