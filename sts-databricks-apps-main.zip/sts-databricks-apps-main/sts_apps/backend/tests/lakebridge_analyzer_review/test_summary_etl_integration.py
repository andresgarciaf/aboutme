import unittest
from unittest.mock import Mock
from backend.lakebridge_analyzer_review.reports.sections.summary_section import SummarySection


class TestSummaryETLIntegration(unittest.TestCase):
    """Test that ETL complexity results are properly processed in the summary section."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.summary_section = SummarySection()
    
    def test_etl_complexity_distribution_note(self):
        """Test that ETL complexity results generate the correct distribution note."""
        # Mock ETL complexity result
        etl_result = {
            'filename': 'test.xlsx',
            'success': True,
            'total_files': 10,
            'complexity_counts': {
                'low': 3,
                'medium': 4,
                'complex': 2,
                'very_complex': 1
            },
            'percentages': {
                'low': 30.0,
                'medium': 40.0,
                'complex': 20.0,
                'very_complex': 10.0
            },
            'has_complex_files': True,
            'script_type': 'ETL'
        }
        
        # Process the result through the summary section
        all_results = [etl_result]
        story = self.summary_section.create_section(all_results)
        
        # Convert story to text for easier checking
        story_text = ' '.join([str(item) for item in story])
        
        # Check that Total complexity distribution note is present (since only ETL is present)
        self.assertIn('Total Complexity Distribution', story_text)
        self.assertIn('Low: 3 (30.0%)', story_text)
        self.assertIn('Medium: 4 (40.0%)', story_text)
        self.assertIn('Complex: 2 (20.0%)', story_text)
        self.assertIn('Very Complex: 1 (10.0%)', story_text)
    
    def test_etl_complexity_warning_suppressed(self):
        """Test that ETL complexity results do NOT generate warnings (only SQL does)."""
        # Mock ETL complexity result with complex files
        etl_result = {
            'filename': 'test.xlsx',
            'success': True,
            'total_files': 5,
            'complexity_counts': {
                'low': 2,
                'medium': 1,
                'complex': 1,
                'very_complex': 1
            },
            'percentages': {
                'low': 40.0,
                'medium': 20.0,
                'complex': 20.0,
                'very_complex': 20.0
            },
            'has_complex_files': True,
            'script_type': 'ETL'
        }
        
        # Process the result through the summary section
        all_results = [etl_result]
        story = self.summary_section.create_section(all_results)
        
        # Convert story to text for easier checking
        story_text = ' '.join([str(item) for item in story])
        
        # Check that ETL complexity warning is NOT present
        self.assertNotIn('complex/very complex ETL files found', story_text)
        # But the distribution note should still be present
        self.assertIn('Total Complexity Distribution', story_text)
    
    def test_sql_complexity_warning_shown(self):
        """Test that SQL complexity results DO generate warnings."""
        # Mock SQL complexity result with complex files
        sql_result = {
            'filename': 'test.xlsx',
            'success': True,
            'total_files': 5,
            'complexity_counts': {
                'low': 2,
                'medium': 1,
                'complex': 1,
                'very_complex': 1
            },
            'percentages': {
                'low': 40.0,
                'medium': 20.0,
                'complex': 20.0,
                'very_complex': 20.0
            },
            'has_complex_files': True,
            'script_type': 'SQL'
        }
        
        # Process the result through the summary section
        all_results = [sql_result]
        story = self.summary_section.create_section(all_results)
        
        # Convert story to text for easier checking
        story_text = ' '.join([str(item) for item in story])
        
        # Check that SQL complexity warning IS present
        self.assertIn('2 complex/very complex SQL files found', story_text)
        self.assertIn('Total Complexity Distribution', story_text)
    
    def test_mixed_sql_and_etl_complexity(self):
        """Test that both SQL and ETL complexity results are processed correctly."""
        # Mock SQL complexity result
        sql_result = {
            'filename': 'test_sql.xlsx',
            'success': True,
            'total_files': 8,
            'complexity_counts': {
                'low': 4,
                'medium': 3,
                'complex': 1,
                'very_complex': 0
            },
            'percentages': {
                'low': 50.0,
                'medium': 37.5,
                'complex': 12.5,
                'very_complex': 0.0
            },
            'has_complex_files': True,
            'script_type': 'SQL'
        }
        
        # Mock ETL complexity result
        etl_result = {
            'filename': 'test_etl.xlsx',
            'success': True,
            'total_files': 6,
            'complexity_counts': {
                'low': 2,
                'medium': 2,
                'complex': 1,
                'very_complex': 1
            },
            'percentages': {
                'low': 33.3,
                'medium': 33.3,
                'complex': 16.7,
                'very_complex': 16.7
            },
            'has_complex_files': True,
            'script_type': 'ETL'
        }
        
        # Process both results through the summary section
        all_results = [sql_result, etl_result]
        story = self.summary_section.create_section(all_results)
        
        # Convert story to text for easier checking
        story_text = ' '.join([str(item) for item in story])
        
        # Check that both Total and breakdown complexity distributions are present
        self.assertIn('Total Complexity Distribution', story_text)
        self.assertIn('SQL Complexity Distribution', story_text)
        self.assertIn('ETL Complexity Distribution', story_text)
        # SQL should have warnings, ETL should not
        self.assertIn('1 complex/very complex SQL files found', story_text)
        self.assertNotIn('complex/very complex ETL files found', story_text)


if __name__ == '__main__':
    unittest.main() 