import tempfile
import os
import pytest
from backend.lakebridge_analyzer_review.checks.folder_analysis_check import FolderAnalysisCheck
from backend.tests.conftest import create_sample_workbook_basic


def test_folder_analysis_check_basic():
    with tempfile.TemporaryDirectory() as tmpdir:
        file_path = os.path.join(tmpdir, 'test_infa.xlsx')
        create_sample_workbook_basic(file_path)
        check = FolderAnalysisCheck()
        result = check.check(file_path, 'test_infa.xlsx')
        assert result['success']
        assert 'folder_analysis' in result
        assert 'sorted_folders' in result
        assert 'formatted_results' in result
        # Check folder counts
        assert result['total_folders'] == 3
        # Check sorting (FolderC should be first due to lowest categorization complexity)
        sorted_names = [folder for folder, _ in result['sorted_folders']]
        assert sorted_names[0] == 'FolderC'
        # Check formatted output
        assert any('FolderA' in line for line in result['formatted_results'])
        assert any('FolderB' in line for line in result['formatted_results'])
        assert any('FolderC' in line for line in result['formatted_results'])
        # Check that we have the detailed breakdown format with commas
        assert any('Low complexity Workflows' in line for line in result['formatted_results'])
        assert any('Medium complexity Mappings' in line for line in result['formatted_results'])
        # Check for comma formatting
        assert any(',' in line for line in result['formatted_results']) 