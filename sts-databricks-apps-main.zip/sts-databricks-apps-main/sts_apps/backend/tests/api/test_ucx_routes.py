"""
Tests for UCX API routes.
"""
import pytest
from backend.api.ucx.routes import router as ucx_router


def test_ucx_router_structure():
    """Test that the UCX router is properly configured and has routes."""
    assert ucx_router is not None
    assert hasattr(ucx_router, "routes")
    assert len(ucx_router.routes) > 0 