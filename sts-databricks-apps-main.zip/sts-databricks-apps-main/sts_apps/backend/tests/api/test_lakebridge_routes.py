"""
Tests for Lakebridge API routes.
"""
import pytest
from backend.api.lakebridge.routes import router as lakebridge_router


def test_lakebridge_router_structure():
    """Test that the Lakebridge router is properly configured and has routes."""
    assert lakebridge_router is not None
    assert hasattr(lakebridge_router, "routes")
    assert len(lakebridge_router.routes) > 0 