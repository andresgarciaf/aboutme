"""
End-to-end integration tests for the application.
"""
from fastapi.testclient import TestClient


def test_application_startup(client: TestClient):
    """Test that the application starts up correctly."""
    # Test the welcome endpoint which should exist
    response = client.get("/api/welcome/")
    assert response.status_code == 200


def test_api_docs_accessible(client: TestClient):
    """Test that the API documentation is accessible."""
    response = client.get("/api/docs")
    assert response.status_code == 200 