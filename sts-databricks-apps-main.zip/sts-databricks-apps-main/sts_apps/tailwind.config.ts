import { plugin, content } from "flowbite-react/tailwind";
import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    content(),
  ],
  theme: {
    extend: {
      colors: {
        //Primary
        "dbx-orange-600": "#FF3621",
        "dbx-navy-800": "#1B3139",
        "dbx-oat-light": "#F9F7F4",
        "dbx-oat-medium": "#EEEDE9",
        "dbx-white": "#FFFFFF",
        "dbx-dark-mode": "#1B1B1B",
        "dbx-dark-mode-900": "#242526",

        //Secondary
        "dbx-maroon-600": "#98102A",
        "dbx-yellow-600": "#FFAB00",
        "dbx-green-600": "#00A972",
        "dbx-blue-600": "#2272B4",
        "dbx-gray-navigation": "#303F47",
        "dbx-gray-text": "#5A6F77",
        "dbx-gray-lines": "#DCE0E2",

        //Extended
        "dbx-maroon-800": "#4A121A",
        "dbx-maroon-700": "#730D21",
        "dbx-maroon-500": "#AB4057",
        "dbx-maroon-400": "#BF7080",
        "dbx-maroon-300": "#D69EA8",
        "dbx-maroon-200": "#EAC0C7",
        "dbx-maroon-100": "#F8D5DC",
        "dbx-orange-800": "#801C17",
        "dbx-orange-700": "#BD2B26",
        "dbx-orange-500": "#FF5F46",
        "dbx-orange-400": "#FF9E94",
        "dbx-orange-300": "#FABFBA",
        "dbx-orange-200": "#F8DEDC",
        "dbx-orange-100": "#FAECEB",
        "dbx-yellow-800": "#7D5319",
        "dbx-yellow-700": "#BA7B23",
        "dbx-yellow-500": "#FCBA33",
        "dbx-yellow-400": "#FFCC66",
        "dbx-yellow-300": "#FFDB96",
        "dbx-yellow-200": "#FFE6B8",
        "dbx-yellow-100": "#FFF0D3",
        "dbx-green-800": "#095A35",
        "dbx-green-700": "#00875C",
        "dbx-green-500": "#42BA91",
        "dbx-green-400": "#70C4AB",
        "dbx-green-300": "#9ED6C4",
        "dbx-green-200": "#BAE9DA",
        "dbx-green-100": "#DCF4ED",
        "dbx-blue-800": "#04355D",
        "dbx-blue-700": "#0E538B",
        "dbx-blue-500": "#4299E0",
        "dbx-blue-400": "#8ACAFF",
        "dbx-blue-300": "#BAE1FC",
        "dbx-blue-200": "#D7EDFE",
        "dbx-blue-100": "#F0F8FF",
        "dbx-navy-700": "#143D4A",
        "dbx-navy-600": "#1B5162",
        "dbx-navy-500": "#618794",
        "dbx-navy-400": "#90A5B1",
        "dbx-navy-300": "#C4CCD6",
        "dbx-navy-100": "#EDF2F8",
      },
    },
  },
  plugins: [plugin()],
};
export default config;
