"use client";

import { Button } from "flowbite-react";
import { HiOutlineHome, HiOutlineArrowLeft } from "react-icons/hi";
import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-white p-6 dark:bg-dbx-dark-mode-900">
      <div className="mx-auto max-w-2xl text-center">
        {/* Error code */}
        <h1 className="mb-4 text-9xl font-extrabold text-dbx-gray-navigation dark:text-dbx-white">
          404
        </h1>

        {/* Error message */}
        <h2 className="mb-6 text-3xl font-bold tracking-tight text-dbx-gray-navigation dark:text-dbx-white">
          Page Not Found
        </h2>

        {/* Error description */}
        <p className="mb-10 text-lg font-normal text-dbx-gray-navigation dark:text-dbx-white">
          Sorry, we couldn&apos;t find the page you&apos;re looking for. It
          might have been moved or deleted.
        </p>

        {/* Action buttons */}
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
          <Link href="/">
            <Button
              color="dark"
              className="border-dbx-gray-light dark:border-dbx-dark-mode-600 dark:bg-dbx-dark-mode-800 w-full border text-dbx-white dark:text-dbx-white sm:w-auto"
            >
              <HiOutlineHome className="mr-2 size-5 text-dbx-white" />
              Go Home
            </Button>
          </Link>

          <Button
            color="dark"
            className="border-dbx-gray-light dark:border-dbx-dark-mode-600 dark:bg-dbx-dark-mode-800 w-full border text-dbx-white dark:text-dbx-white sm:w-auto"
            onClick={() => window.history.back()}
          >
            <HiOutlineArrowLeft className="mr-2 size-5 text-dbx-white" />
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
}
