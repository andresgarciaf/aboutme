import { Metadata } from "next";
import "../globals.css";

// Global components
import { Menu } from "@/components/global/appsMenu";

// Local components
import { AppContent } from "./_components/appContent";

export const metadata: Metadata = {
  title: "Lakebridge Analyzer Tool",
  description: "Upload Lakebridge Analyzer XLSX files to receive an automated report",
};

export default function LakebridgeAnalyzerTool() {
  return (
    <main className="m-1">
      <Menu pageTitle="Lakebridge Analyzer Tool" />
      <div className="m-4">
        <AppContent />
      </div>
    </main>
  );
} 