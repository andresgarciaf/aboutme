"use client";

import { useState } from "react";
import axios from "axios";
import { getApiBaseUrl } from "../../config";

export function AppContent() {
  // State management for file upload and processing
  const [files, setFiles] = useState<File[]>([]);
  const [customerName, setCustomerName] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFilename, setDownloadFilename] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  /**
   * Validates and adds files to the review list
   * Only accepts XLSX files and prevents duplicates
   */

  const validateAndAddFiles = (selectedFiles: File[]) => {
    const validFiles = selectedFiles.filter(file => 
      file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      file.name.toLowerCase().endsWith('.xlsx')
    );
    
    if (validFiles.length === selectedFiles.length && validFiles.length > 0) {
      // Add new files to existing list, avoiding duplicates
      setFiles(prevFiles => {
        const existingNames = new Set(prevFiles.map(f => f.name));
        const newFiles = validFiles.filter(file => !existingNames.has(file.name));
        return [...prevFiles, ...newFiles];
      });
      setError(null);
    } else {
      setError("Please select valid XLSX files only");
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    validateAndAddFiles(selectedFiles);
    
    // Reset the input value to allow selecting the same file again
    event.target.value = '';
  };

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragOver(false);
    
    const droppedFiles = Array.from(event.dataTransfer.files);
    validateAndAddFiles(droppedFiles);
  };

  const removeFile = (indexToRemove: number) => {
    setFiles(prevFiles => prevFiles.filter((_, index) => index !== indexToRemove));
  };

  const clearAllFiles = () => {
    setFiles([]);
    setCustomerName('');
    setDownloadUrl(null);
    setDownloadFilename('');
  };

  const handleUpload = async () => {
    if (files.length === 0) return;

    setIsProcessing(true);
    setError(null);


    const formData = new FormData();
    files.forEach(file => {
      formData.append("files", file);
    });

    try {
      const response = await axios.post(getApiBaseUrl() + "api/lakebridge-analyzer-review/", formData, {
        responseType: "blob",
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);
      
      // Generate filename on frontend using the same logic as backend
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10).replace(/-/g, ''); // YYYYMMDD
      const timeStr = now.toTimeString().slice(0, 8).replace(/:/g, ''); // HHMMSS
      
      let filename = 'lakebridge_analyzer_report.pdf';
      if (customerName && customerName.trim()) {
        // Sanitize customer name for filename (same logic as backend)
        const sanitizedCustomerName = customerName.trim().replace(/[^a-zA-Z0-9\s\-_]/g, '').replace(/\s+/g, '_');
        filename = `${sanitizedCustomerName}_lakebridge_analyzer_report_${dateStr}_${timeStr}.pdf`;
      } else {
        filename = `lakebridge_analyzer_report_${dateStr}_${timeStr}.pdf`;
      }
      
      setDownloadUrl(url);
      setDownloadFilename(filename);
    } catch (err: unknown) {
      if (axios.isAxiosError(err) && err.response?.status === 422) {
        setError("Backend server error (422). Please check if the backend is running on port 8000.");
      } else if (axios.isAxiosError(err) && err.response?.data?.detail) {
        setError(err.response.data.detail);
      } else {
        setError("Error processing files. Please try again.");
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (downloadUrl) {
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = downloadFilename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up the URL object
      window.URL.revokeObjectURL(downloadUrl);
      setDownloadUrl(null);
      setDownloadFilename('');
    }
  };

  return (
    <div className="container mx-auto max-w-4xl px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="mb-2 text-4xl font-bold text-dbx-navy-800 dark:text-dbx-white">
          Lakebridge Analyzer Reviewer
        </h1>
        <p className="text-lg text-dbx-gray-text dark:text-dbx-white">
          Upload Lakebridge Analyzer XLSX files (SQL and Informatica) to receive an automated report
        </p>

      </div>
      
      <div className="overflow-hidden rounded-lg border border-dbx-gray-lines bg-dbx-white p-6 shadow-lg dark:border-gray-700 dark:bg-dbx-dark-mode-900">
        <h2 className="mb-6 text-2xl font-semibold text-dbx-navy-800 dark:text-dbx-white">Upload XLSX Files</h2>
        
        <div className="mb-6">
          <label className="mb-3 block text-sm font-medium text-dbx-gray-text dark:text-dbx-white">
          Select one or multiple XLSX files to add to your review list
          </label>
          <div 
            className={`relative rounded-lg border-2 border-dashed p-6 text-center transition-colors ${
              isDragOver 
                ? 'bg-dbx-blue-50 dark:bg-dbx-blue-900 border-dbx-blue-400' 
                : 'border-dbx-gray-300 hover:border-dbx-gray-400 dark:border-gray-600 dark:hover:border-gray-500'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="space-y-3">
              <div className="dark:bg-dbx-blue-900 mx-auto flex size-10 items-center justify-center rounded-full bg-dbx-blue-100">
                <svg className="size-5 text-dbx-blue-600 dark:text-dbx-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
              <div>
                <p className="text-sm text-dbx-gray-text dark:text-dbx-white">
                  <span className="font-medium text-dbx-blue-600 dark:text-dbx-blue-400">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-dbx-gray-text dark:text-dbx-white">XLSX files only</p>
              </div>
              <input
                type="file"
                multiple
                accept=".xlsx"
                onChange={handleFileChange}
                className="absolute inset-0 size-full cursor-pointer opacity-0"
              />
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center space-x-4">
            <label htmlFor="customerName" className="whitespace-nowrap text-sm font-medium text-dbx-gray-text dark:text-dbx-white">
              Customer Name
            </label>
            <input
              type="text"
              id="customerName"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Enter customer name (optional)"
              className="border-dbx-gray-300 dark:bg-dbx-dark-mode-800 max-w-xs flex-1 rounded-lg border bg-white px-4 py-3 text-dbx-navy-800 transition-colors placeholder:text-dbx-gray-text focus:border-dbx-blue-500 focus:ring-2 focus:ring-dbx-blue-500 dark:border-gray-600 dark:text-dbx-white dark:placeholder:text-gray-400"
            />
          </div>
          <p className="ml-0 mt-1 text-xs text-dbx-gray-text dark:text-dbx-white">
            This will be included in the PDF filename for easy identification
          </p>
        </div>

        {error && (
          <div className="dark:bg-dbx-orange-900 mb-4 rounded-lg border border-dbx-orange-300 bg-dbx-orange-100 p-4 dark:border-dbx-orange-700">
            <p className="text-sm font-medium text-dbx-orange-700 dark:text-dbx-orange-300">{error}</p>
          </div>
        )}

        {downloadUrl && (
          <div className="bg-dbx-green-50 dark:bg-dbx-green-900 mb-6 rounded-lg border border-dbx-green-200 p-6 shadow-sm dark:border-dbx-green-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex size-8 items-center justify-center rounded-full bg-dbx-green-100 dark:bg-dbx-green-800">
                  <svg className="size-5 text-dbx-green-600 dark:text-dbx-green-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <p className="font-semibold text-dbx-green-800 dark:text-dbx-green-200">Analysis Complete!</p>
                  <p className="text-sm text-dbx-green-700 dark:text-dbx-green-300">Your comprehensive report is ready for download</p>
                </div>
              </div>
              <button
                onClick={handleDownload}
                className="flex items-center space-x-2 rounded-lg bg-dbx-green-600 px-4 py-2 text-sm font-semibold text-dbx-white transition-colors hover:bg-dbx-green-700"
              >
                <svg className="size-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
                <span>Download PDF</span>
              </button>
            </div>
          </div>
        )}

        {files.length > 0 && (
          <div className="mb-6">
            {downloadUrl && <div className="border-dbx-gray-200 mb-4 border-t dark:border-gray-700"></div>}
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-dbx-navy-800 dark:text-dbx-white">
                  Files to Review ({files.length})
                </h3>
                <p className="text-xs text-dbx-gray-text dark:text-dbx-white">
                  Total size: {(files.reduce((total, file) => total + file.size, 0) / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleUpload}
                  disabled={files.length === 0 || isProcessing}
                  className="rounded-lg bg-dbx-blue-600 px-4 py-2 text-sm font-semibold text-dbx-white transition-colors hover:bg-dbx-blue-700 disabled:cursor-not-allowed disabled:bg-dbx-gray-lines disabled:text-dbx-gray-text"
                >
                  {isProcessing ? (
                    <div className="flex items-center justify-center space-x-2">
                      <svg className="size-4 animate-spin text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span>Processing...</span>
                    </div>
                  ) : (
                    `Review ${files.length} File${files.length !== 1 ? 's' : ''}`
                  )}
                </button>
                <button
                  onClick={clearAllFiles}
                  className="text-dbx-red-600 hover:text-dbx-red-700 text-sm font-medium transition-colors"
                >
                  Clear All
                </button>
              </div>
            </div>
            
            <div className="border-dbx-gray-200 bg-dbx-gray-50 dark:bg-dbx-dark-mode-800 rounded-lg border p-4 dark:border-gray-700">
              <div className="space-y-2">
                {files.map((file, index) => (
                  <div key={index} className="border-dbx-gray-200 hover:border-dbx-gray-300 flex items-center justify-between rounded border bg-dbx-white p-3 transition-colors dark:border-gray-600 dark:bg-dbx-dark-mode-900 dark:hover:border-gray-500">
                    <div className="flex items-center space-x-3">
                      <div className="dark:bg-dbx-blue-900 flex size-8 items-center justify-center rounded-full bg-dbx-blue-100">
                        <svg className="size-4 text-dbx-blue-600 dark:text-dbx-blue-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-dbx-navy-800 dark:text-dbx-white">{file.name}</p>
                        <p className="text-xs text-dbx-gray-text dark:text-dbx-white">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => removeFile(index)}
                      className="text-dbx-red-500 hover:text-dbx-red-700 dark:text-dbx-red-400 dark:hover:text-dbx-red-300 transition-colors"
                    >
                      <svg className="size-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 