import { type CustomFlowbiteTheme } from "flowbite-react";

export const flowbiteTheme: CustomFlowbiteTheme = {
  button: {
    base: "",
    color: {
      dark: "float-right bg-dbx-blue-500 hover:bg-dbx-blue-700 text-dbx-white",
    },
  },
};
