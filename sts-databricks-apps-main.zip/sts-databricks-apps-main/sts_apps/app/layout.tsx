import { ThemeModeScript, Flowbite } from "flowbite-react";
import { Inter } from "next/font/google";
import type { Metadata } from "next";
import { twMerge } from "tailwind-merge";
import "./globals.css";
import { flowbiteTheme } from "./theme";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "STS Apps",
  description: "Databricks App using flowbite react",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <ThemeModeScript />
      </head>

      <body className={twMerge("dark:bg-dbx-dark-mode", inter.className)}>
        <Flowbite theme={{ theme: flowbiteTheme }}>{children}</Flowbite>
      </body>
    </html>
  );
}
