export const getApiBaseUrl = (): string => {
  if (typeof window !== "undefined") {
    // Client-side only
    if (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") {
      return "http://localhost:8000/";
    } else {
      return `https://${window.location.hostname}/`;
    }
  }
  // Server-side fallback
  return "http://localhost:8000/";
};

// For backward compatibility, export a default value
export const API_BASE_URL: string = "http://localhost:8000/";
