"use client";
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Button, Spinner } from "flowbite-react";
import { getApiBaseUrl } from "../../config";

interface AppResultsProps {
  selectedCloud: string;
  uploadedFile: File | null;
}

export function AppResults({ selectedCloud, uploadedFile }: AppResultsProps) {
  const [error, setError] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<{
    url: string;
    filename: string;
  } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (selectedCloud && uploadedFile) {
      handleProcessFile();
    }
  }, [selectedCloud, uploadedFile]); // eslint-disable-line

  const handleProcessFile = async () => {
    if (!uploadedFile || !selectedCloud) return;

    setError(null);
    setIsProcessing(true);

    const formData = new FormData();
    formData.append("uploaded_file", uploadedFile);
    formData.append("cloud", selectedCloud);

    try {
      const response = await axios.post(
        getApiBaseUrl() + "api/run-analysis/",
        formData,
        {
          responseType: "blob",
          headers: {
            "Content-Type": "multipart/form-data",
          },
        },
      );

      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);

      const contentDisposition = response.headers["content-disposition"];
      const firstPart = uploadedFile.name.split("_")[0];
      let filename = `${firstPart}_ucx_analysis_report.zip`;

      if (contentDisposition) {
        const match = contentDisposition.match(/filename="(.+)"/);
        if (match && match[1]) {
          filename = match[1];
        }
      }

      setDownloadUrl({ url, filename });
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "An error occurred while processing the file",
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadResults = () => {
    if (!downloadUrl) return;

    const link = document.createElement("a");
    link.href = downloadUrl.url;
    link.setAttribute("download", downloadUrl.filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    window.URL.revokeObjectURL(downloadUrl.url);

    window.location.reload();
  };

  if (selectedCloud === "" || uploadedFile === null) {
    return null;
  }

  return (
    <div className="my-6 flex flex-col items-start space-y-4">
      <div
        className={`items-center gap-2 ${isProcessing ? "visible" : "invisible"}`}
      >
        <p className="text-lg font-semibold text-dbx-gray-navigation dark:text-dbx-white">
          Creating reports <Spinner aria-label="Processing file" size="md" />
        </p>
      </div>

      {downloadUrl && !isProcessing && (
        <div className="flex w-fit max-w-md items-center gap-4 border-b-2 border-dbx-oat-medium p-4">
          <div className="text-lg font-semibold text-dbx-gray-navigation dark:text-dbx-white">
            Analysis Ready
          </div>
          <Button color="dark" size="sm" onClick={downloadResults}>
            Download
          </Button>
        </div>
      )}

      {error && <div className="text-red-500">{error}</div>}
    </div>
  );
}
