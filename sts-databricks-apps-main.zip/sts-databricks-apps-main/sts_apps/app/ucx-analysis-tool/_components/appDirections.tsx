"use client";

import React, { useState } from "react";
import { List, Button, Modal } from "flowbite-react";
import { HiOutlineInformationCircle } from "react-icons/hi";

interface AppDirectionsProps {
  buttonText?: string;
  modalTitle?: string;
}

export function AppDirections({
  buttonText = "See Instructions",
  modalTitle = "Application Instructions",
}: AppDirectionsProps): React.ReactElement {
  const [openModal, setOpenModal] = useState<boolean>(false);

  return (
    <>
      <div className="flex w-full justify-start">
        <Button
          onClick={() => setOpenModal(true)}
          color="dark"
          className="ml-6 flex items-center rounded-lg"
        >
          <span>{buttonText}</span>
        </Button>
      </div>

      <Modal
        show={openModal}
        onClose={() => setOpenModal(false)}
        size="3xl"
        className="mt-4 shadow-none dark:bg-dbx-dark-mode-900"
        dismissible
        theme={{
          root: {
            base: "fixed inset-0 z-50 flex items-start justify-center overflow-visible !bg-transparent pt-4",
            show: {
              on: "flex !bg-transparent",
              off: "hidden",
            },
          },
          content: {
            base: "relative mx-auto w-11/12 max-w-2xl overflow-visible",
            inner:
              "relative overflow-hidden rounded-lg bg-white shadow-lg ring-4 ring-gray-900/10 ring-offset-8 ring-offset-gray-900/20 dark:bg-dbx-dark-mode-900 dark:ring-gray-800/10 dark:ring-offset-gray-900/20",
          },
        }}
      >
        <Modal.Header className="border-b border-gray-200 dark:border-gray-700 dark:bg-dbx-dark-mode-900 dark:text-dbx-white">
          {modalTitle}
        </Modal.Header>
        <Modal.Body className="max-h-[60vh] overflow-y-auto dark:bg-dbx-dark-mode-900">
          <div className="space-y-4 p-3 md:p-4">
            <section>
              <h5 className="mb-3 text-lg font-semibold text-dbx-gray-navigation dark:text-dbx-white">
                Supported File Types
              </h5>
              <List className="space-y-2">
                <List.Item className="flex items-center">
                  <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    1
                  </span>
                  <strong className="mr-2 text-dbx-gray-navigation dark:text-dbx-white">
                    Excel
                  </strong>
                  :
                  <code className="ml-2 rounded bg-dbx-oat-medium px-2 py-0.5 text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    .xlsx
                  </code>
                </List.Item>
                <List.Item className="flex items-center">
                  <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    2
                  </span>
                  <strong className="mr-2 text-dbx-gray-navigation dark:text-dbx-white">
                    ZIP
                  </strong>
                  :
                  <code className="ml-2 rounded bg-dbx-oat-medium px-2 py-0.5 text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    .zip
                  </code>
                </List.Item>
              </List>
            </section>

            <section>
              <h5 className="mb-3 text-lg font-semibold text-dbx-gray-navigation dark:text-dbx-white">
                File Naming Requirements
              </h5>
              <p className="mb-2 text-dbx-gray-navigation dark:text-dbx-white">
                Confirm the uploaded file name matches the following format:
              </p>
              <List className="space-y-2">
                <List.Item className="flex items-center">
                  <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    1
                  </span>
                  <strong className="mr-2 text-dbx-gray-navigation dark:text-dbx-white">
                    Excel
                  </strong>
                  :
                  <code className="ml-2 rounded bg-dbx-oat-medium px-2 py-0.5 text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    client_name_ucx_assessment_main.xlsx
                  </code>
                </List.Item>
                <List.Item className="flex items-center">
                  <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    2
                  </span>
                  <strong className="mr-2 text-dbx-gray-navigation dark:text-dbx-white">
                    ZIP
                  </strong>
                  :
                  <code className="ml-2 rounded bg-dbx-oat-medium px-2 py-0.5 text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    client_name_ucx_assessment_main.zip
                  </code>
                </List.Item>
              </List>
            </section>

            <section>
              <h5 className="mb-3 text-lg font-semibold text-dbx-gray-navigation dark:text-dbx-white">
                How to Use the Tool
              </h5>
              <ol className="list-none space-y-4 pl-0">
                <li>
                  <div className="mb-2 flex items-center">
                    <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                      1
                    </span>
                    <strong className="text-dbx-gray-navigation dark:text-dbx-white">
                      Prepare Your File:
                    </strong>
                  </div>
                  <ul className="ml-8 list-disc space-y-1 text-dbx-gray-navigation dark:text-dbx-white">
                    <li>Use the supported file type and naming conventions.</li>
                  </ul>
                </li>

                <li>
                  <div className="mb-2 flex items-center">
                    <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                      2
                    </span>
                    <strong className="text-dbx-gray-navigation dark:text-dbx-white">
                      Generate Analysis:
                    </strong>
                  </div>
                  <ul className="ml-8 list-disc space-y-1 text-dbx-gray-navigation dark:text-dbx-white">
                    <li>
                      Scroll down to the{" "}
                      <strong className="text-dbx-gray-navigation dark:text-dbx-white">
                        Analysis Tool
                      </strong>{" "}
                      section.
                    </li>
                    <li>
                      Click{" "}
                      <strong className="text-dbx-blue-600">
                        Browse files
                      </strong>{" "}
                      or{" "}
                      <strong className="text-dbx-blue-600">
                        drag and drop
                      </strong>{" "}
                      the Assessment Results into the upload area.
                    </li>
                    <li>Select your cloud provider from the dropdown.</li>
                    <li>Wait for the analysis to complete.</li>
                  </ul>
                </li>

                <li>
                  <div className="mb-2 flex items-center">
                    <span className="mr-2 flex size-6 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                      3
                    </span>
                    <strong className="text-dbx-gray-navigation dark:text-dbx-white">
                      Download the reports:
                    </strong>
                  </div>
                  <ul className="ml-8 list-disc space-y-1 text-dbx-gray-navigation dark:text-dbx-white">
                    <li>
                      <strong>HMS Summary</strong>: Review the DOCX, edit as
                      needed, and share as a PDF.
                    </li>
                    <li>
                      <strong>Table Migration Matrix</strong>: Details table
                      migration progress.
                    </li>
                    <li>
                      <strong>UC Migration Template</strong>: A template for
                      migration details.
                    </li>
                  </ul>
                </li>
              </ol>
            </section>

            <section>
              <h5 className="mb-3 text-lg font-semibold text-dbx-gray-navigation dark:text-dbx-white">
                Notes
              </h5>
              <List className="space-y-2 marker:text-dbx-gray-navigation dark:marker:text-dbx-white">
                <List.Item className="flex items-start">
                  <span className="mr-2 mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    <HiOutlineInformationCircle className="size-4" />
                  </span>
                  <span className="text-dbx-gray-navigation dark:text-dbx-white">
                    Reports will be downloaded as a ZIP file. Extract the ZIP to
                    access the reports.
                  </span>
                </List.Item>
                <List.Item className="flex items-start">
                  <span className="mr-2 mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    <HiOutlineInformationCircle className="size-4" />
                  </span>
                  <span className="text-dbx-gray-navigation dark:text-dbx-white">
                    Files must comply with the naming format and file type
                    requirements.
                  </span>
                </List.Item>
                <List.Item className="flex items-start">
                  <span className="mr-2 mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    <HiOutlineInformationCircle className="size-4" />
                  </span>
                  <span className="text-dbx-gray-navigation dark:text-dbx-white">
                    UCX results are compatible starting from version{" "}
                    <strong className="text-dbx-gray-navigation dark:text-dbx-white">
                      0.40.0
                    </strong>
                    .
                  </span>
                </List.Item>
                <List.Item className="flex items-start">
                  <span className="mr-2 mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-dbx-oat-medium text-xs font-semibold text-dbx-gray-navigation dark:bg-dbx-dark-mode dark:text-dbx-white">
                    <HiOutlineInformationCircle className="size-4" />
                  </span>
                  <span className="text-dbx-gray-navigation dark:text-dbx-white">
                    For support, click on the{" "}
                    <strong className="text-dbx-blue-600">Contact</strong> link
                    on the Navigation Bar.
                  </span>
                </List.Item>
              </List>
            </section>
          </div>
        </Modal.Body>
        <Modal.Footer className="flex justify-end dark:border-gray-700 dark:bg-dbx-dark-mode-900">
          <Button
            onClick={() => setOpenModal(false)}
            color="dark"
            className="flex items-center"
          >
            <span>Close</span>
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
