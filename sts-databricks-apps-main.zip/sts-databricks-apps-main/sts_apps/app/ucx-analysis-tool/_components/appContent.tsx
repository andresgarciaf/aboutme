"use client";
import React, { useState } from "react";
import {
  Button,
  Dropdown,
  FileInput,
  Label,
  Tooltip,
  Alert,
} from "flowbite-react";
import { CheckCircle, Info } from "lucide-react";
import { HiXCircle } from "react-icons/hi2";
import { AppResults } from "./appResults";

export function AppContent() {
  const [selectedCloud, setSelectedCloud] = useState("");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [alert, setAlert] = useState(""); // State for alert message
  const clouds = ["AWS", "Azure", "GCP"];

  const handleCloudChange = (cloud: string) => {
    setSelectedCloud(cloud);
  };

  const handleFileUpload = (event: any) => {
    const file = event.target.files[0];
    const validPattern = /^[^_]+_ucx_assessment_main\.(xlsx|zip)$/i;

    if (!validPattern.test(file.name)) {
      setAlert(
        "The file should be in the format: \nExcel: client_name_ucx_assessment_main.xlsx\nZIP: client_name_ucx_assessment_main.zip",
      );
      return;
    }

    setAlert(""); // Clear alert if file is valid
    setUploadedFile(file);
  };

  const reloadPage = () => {
    window.location.reload();
  };

  return (
    <div className="m-6">
      <h1 className="mb-2 text-3xl font-semibold text-dbx-gray-navigation dark:text-dbx-white">
        Analysis Tool
      </h1>

      <p className="my-4 text-dbx-gray-navigation dark:text-dbx-white">
        Which Cloud Provider is the client using?
      </p>
      <div className="flex w-2/12 items-center justify-between">
        <Dropdown
          label={selectedCloud || "Select Cloud"}
          color="dark"
          dismissOnClick={false}
          disabled={Boolean(uploadedFile)}
          className="border-gray-300 bg-dbx-oat-light hover:bg-dbx-oat-medium dark:border-gray-600 dark:bg-dbx-dark-mode-900 dark:text-dbx-white dark:hover:border-gray-500 dark:hover:bg-dbx-dark-mode"
        >
          {clouds.map((cloud, index) => (
            <Dropdown.Item key={index} onClick={() => handleCloudChange(cloud)}>
              {cloud}
            </Dropdown.Item>
          ))}
        </Dropdown>

        {uploadedFile && (
          <Button color="dark" onClick={reloadPage}>
            Reset
          </Button>
        )}
      </div>

      <p className="my-4 text-dbx-gray-navigation dark:text-dbx-white">
        Please upload the UCX assessment results
      </p>

      {alert && (
        <Alert
          className="my-4"
          additionalContent={alert}
          color="failure"
          icon={HiXCircle}
        >
          <span className="font-medium">Invalid file name!</span> Update your
          file and try again.
        </Alert>
      )}

      <div className="relative flex w-full items-center justify-center">
        <Label
          htmlFor="dropzone-file"
          className={`flex h-64 w-full flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-300 bg-dbx-oat-light dark:border-gray-600 dark:bg-dbx-dark-mode-900 ${
            !selectedCloud || uploadedFile
              ? "cursor-not-allowed opacity-50"
              : "hover:bg-dbx-oat-medium dark:hover:bg-dbx-dark-mode"
          }`}
        >
          {!selectedCloud && !uploadedFile && (
            <Tooltip content="Select a cloud provider first" placement="top">
              <Info className="absolute right-3 top-3 size-6 text-gray-500" />
            </Tooltip>
          )}

          <div className="flex flex-col items-center justify-center pb-6 pt-5">
            {uploadedFile ? (
              <CheckCircle className="size-14 text-green-500" />
            ) : (
              <>
                <svg
                  className="mb-4 size-8 text-dbx-gray-navigation dark:text-dbx-white"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 20 16"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                  />
                </svg>
                <p className="mb-2 text-sm text-dbx-gray-navigation dark:text-dbx-white">
                  <span className="font-semibold">Click to upload</span> or drag
                  and drop
                </p>
                <p className="text-xs text-dbx-gray-navigation dark:text-dbx-white">
                  .ZIP, .XLSX
                </p>
              </>
            )}
          </div>

          <FileInput
            id="dropzone-file"
            className="hidden"
            accept=".zip, .xlsx"
            onChange={handleFileUpload}
            // @ts-ignore
            disabled={!selectedCloud || uploadedFile}
          />
        </Label>
      </div>

      <AppResults selectedCloud={selectedCloud} uploadedFile={uploadedFile} />
    </div>
  );
}
