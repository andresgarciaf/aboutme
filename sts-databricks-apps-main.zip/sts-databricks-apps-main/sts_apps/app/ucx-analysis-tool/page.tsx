import { Metadata } from "next";
import "../globals.css";

// Global components
import { Menu } from "@/components/global/appsMenu";

// Local components
import { AppDirections } from "./_components/appDirections";
import { AppContent } from "./_components/appContent";

export const metadata: Metadata = {
  title: "UCX Analysis Tool",
  description: "Your static page description",
};

export default function UCXAnalysisTool() {
  return (
    <main className="m-1">
      <Menu pageTitle="UCX Analysis Tool" />
      <div className="m-4">
        <AppDirections />
        <AppContent />
      </div>
    </main>
  );
}
