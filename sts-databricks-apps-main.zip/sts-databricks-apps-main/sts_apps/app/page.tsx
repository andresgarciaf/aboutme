import { Menu } from "@/components/global/appsMenu";
import { Apps } from "@/components/global/apps";

export default function Home() {
  return (
    <main className="m-1">
      <Menu pageTitle="STS Apps" />
      <Apps />
    </main>
  );
}
