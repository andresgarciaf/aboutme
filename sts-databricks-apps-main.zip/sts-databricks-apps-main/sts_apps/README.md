# STS Apps

A comprehensive web application platform for Databricks Apps containing multiple tools for data analysis and review.

## Quick Start

### Prerequisites
- Node.js 18+ and npm
- Python 3.12
- pipenv
- Databricks CLI

### Development
```bash
# Install dependencies and start development servers
make dev
```

This starts:
- Backend server on `http://localhost:8000`
- Frontend server on `http://localhost:3000`

### Deploy to Databricks
```bash
# Test build process locally
make dev-build

# Deploy to production
make sync
```

## Available Commands

```bash
make help  # Show all commands
```

### Development
- `make dev` - Start development servers
- `make dev-build` - Test build process locally
- `make test` - Run linting and tests

### Code Quality
- `make pyfmt` - Format Python code
- `make tsfmt` - Format TypeScript code
- `make tslint` - Lint TypeScript code
- `make verify` - Verify code quality

### Maintenance
- `make clean` - Clean build artifacts
- `make clear-env` - Clear environment cache

## Applications

### UCX Analysis Tool (`/ucx-analysis-tool`)
Analyzes UCX results and generates migration assets.

### Lakebridge Analyzer Reviewer (`/lakebridge-analyzer-tool`)
Review Lakebridge Analyzer results and generates a PDF with errors, warnings, and notes.

## Project Structure

```
sts_apps/
├── app/                     # Next.js React application
│   ├── lakebridge-analyzer-tool/  # Lakebridge Analyzer tool
│   └── ucx-analysis-tool/   # UCX Analysis tool
├── backend/                 # FastAPI Python backend
│   ├── api/                 # API routes (auto-loaded)
│   │   ├── lakebridge/      # Lakebridge analyzer routes
│   │   ├── ucx/            # UCX analysis routes
│   │   └── demo/           # Demo routes
│   ├── lakebridge_analyzer_review/  # Lakebridge analysis logic
│   └── ucx_analysis/       # UCX analysis logic
├── components/              # React components
└── app.yml                 # Databricks App configuration
```

## API Structure

- **Base URL**: `/api`
- **Documentation**: `/api/docs` (Swagger UI)
- **Routes**: Automatically loaded from `backend/api/` directory

### Available Endpoints
- `/api/lakebridge/*` - Lakebridge analyzer endpoints
- `/api/ucx/*` - UCX analysis endpoints
- `/api/demo/*` - Demo endpoints

## Manual Setup (Alternative)

```bash
# Frontend
npm install
npm run dev

# Backend
pipenv install -d
pipenv run uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

## Environment Configuration

### Development
- API URL: `http://localhost:8000/api`
- CORS: Enabled for localhost
- Logging: Debug level

### Production (Databricks Apps)
- API URL: `/api` (relative to workspace)
- CORS: Handled by Databricks
- Logging: Info level
- Static files: Served from `/app/out`

## Logging

```python
from backend.logger import get_logger, info, debug, warning, error

logger = get_logger()
logger.info("Processing request...")
```

**Log Locations**:
- macOS: `~/Library/Logs/LakebridgeReviewer/`
- Windows: `~/AppData/Local/LakebridgeReviewer/logs/`
- Linux: `~/.local/share/lakebridge_reviewer/logs/`

## Development

### Frontend
- Next.js 15 + React 18
- Tailwind CSS
- TypeScript
- Static export for Databricks Apps

### Backend
- FastAPI
- Dynamic route loading
- Automatic OpenAPI documentation
- Environment-aware configuration

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License 