"use client";

import {
  Button,
  DarkThemeToggle,
  MegaMenu,
  Navbar,
  ThemeModeScript,
} from "flowbite-react";
import Image from "next/image";

interface MenuTitleProps {
  pageTitle: string;
}

export function Menu({ pageTitle }: MenuTitleProps) {
  const slackContact =
    "https://databricks.enterprise.slack.com/archives/C05EW2H2P89";
  const logo =
    "https://cdn.bfldr.com/9AYANS2F/as/jc54c97bcnstfm9xh8qxxz/Databricks_Favicon?auto=webp&format=png";
  const shortCuts = [
    { page: "Home", path: "/" },
    { page: "Contact", path: slackContact },
  ];
  return (
    <MegaMenu className="border-b-2 border-dbx-oat-medium bg-dbx-white dark:bg-dbx-dark-mode-900">
      <div className="mx-auto flex max-w-screen-xl flex-wrap items-center justify-between p-4 md:space-x-8">
        <Navbar.Brand href="/">
          <div className="absolute left-20">
            <Image
              src={logo}
              height={40}
              width={40}
              alt="Databricks Logo"
              className="h-10 w-auto"
              priority
            />
          </div>
          <span className="self-center whitespace-nowrap text-xl font-semibold text-dbx-gray-navigation dark:text-dbx-white">
            {pageTitle}
          </span>
        </Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse>
          {shortCuts.map((page, index) => (
            <Navbar.Link
              key={index}
              className="text-dbx-gray-navigation dark:text-dbx-white"
              href={page.path}
            >
              {page.page}
            </Navbar.Link>
          ))}
        </Navbar.Collapse>
      </div>
      <DarkThemeToggle />
    </MegaMenu>
  );
}
