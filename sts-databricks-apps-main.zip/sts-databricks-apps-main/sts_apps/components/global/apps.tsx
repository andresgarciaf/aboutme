"use client";

import { Button, Card } from "flowbite-react";
import { HiOutlineArrowRight } from "react-icons/hi";
import Link from "next/link";

export function Apps() {
  let apps = [
    {
      name: "UCX Analysis Tool",
      description:
        "This tool helps you analyze your UCX results automatically and generate the assets required to move forward with your engagement.",
      path: "/ucx-analysis-tool",
    },
    {
      name: "Lakebridge Analyzer Reviewer",
      description:
        "Review Analyzer results and generates a PDF with errors, warnings, and notes.",
      path: "/lakebridge-analyzer-tool",
    }
  ];

  return (
    <div className="mt-5 flex flex-wrap gap-10 p-6 md:grid-cols-2 lg:grid-cols-3">
      {apps.map((app, index) => (
        <Card key={index} className="max-w-sm p-4 dark:bg-dbx-dark-mode-900">
          <h5 className="text-2xl font-bold tracking-tight text-dbx-gray-navigation dark:text-dbx-white">
            {app.name}
          </h5>
          <p className="font-normal text-dbx-gray-navigation dark:text-dbx-white">
            {app.description}
          </p>
          <Link href={app.path}>
            <Button color="dark">
              <HiOutlineArrowRight className="size-6 text-dbx-white" />
            </Button>
          </Link>
        </Card>
      ))}
    </div>
  );
}
