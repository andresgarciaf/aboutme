# STS Apps

This repository contains applications developed by the STS Team. It follows a monorepo structure, allowing us to maintain multiple applications in a single repository while keeping them logically separated.

## Repository Structure

```
sts-apps/
├── sts_apps/   # UCX Assessment and Lakebridge Analyzer Reviewer applications
│   ├── app/
│   ├── backend/
│   ├── README.md
│   └── ...
├── <your_new_app>/   # New application directory
│   ├── src/
│   ├── tests/
│   ├── README.md
│   └── ...
└── README.md         # This file
```

## Applications

### Lakebridge Analyzer Tool

The Lakebridge Analyzer Tool is located in the `sts_apps/app/lakebridge-analyzer-tool` directory. This tool provides comprehensive analysis of Lakebridge Analyzer output.

### UCX Analysis Tool

The UCX Analysis Tool is located in the `sts_apps/app/ucx-analysis-tool` directory. This tool provides analysis of the UCX assessment output .

## Working with the Repository

### Cloning the Repository

To clone this repository, run the following command:

```bash
git clone git@github.com:databricks-field-eng/sts-databricks-apps.git
cd sts-apps
```

### Adding a New Application

To add a new application to the repository:

1. Create a new directory for your application:

```bash
mkdir -p your_new_app/src your_new_app/tests
```

2. Initialize your application with necessary files:

```bash
# Create a README for your application
touch your_new_app/README.md

# Create any other necessary files for your application
# For example, if using Python:
touch your_new_app/src/__init__.py
touch your_new_app/tests/__init__.py
```

3. Document your application in its README file.

4. Update the main README.md (this file) to include your application in the list.

### Development Guidelines

- Each application should be self-contained within its own directory.
- Common utilities or shared code can be placed in a `common` or `shared` directory if needed.
- Each application should include its own README with specific instructions for setup, development, and deployment.
- Follow standard Git workflows:
  - Create feature branches for new features or bug fixes
  - Submit pull requests for code review
  - Keep commits small and focused on specific changes

### Continuous Integration

CI/CD pipelines are configured to build and test each application independently. See the individual application READMEs for specific CI/CD information.


